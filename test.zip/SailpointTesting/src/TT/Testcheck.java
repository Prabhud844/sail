package TT;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Testcheck {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		
		

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vn52odq\\Sailpoint\\SailpointTesting\\Driver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://spt-qa-task-01.lab.wal-mart.com/login.jsf");


		driver.manage().window().maximize();

		
		By Userid = By.xpath("//input[@id ='loginForm:accountId']");
		By Password = By.xpath("//input[@id ='loginForm:password']");
		By Login = By.xpath("//input[@id ='loginForm:loginButton']");
		
		driver.findElement(By.xpath("//input[@id ='loginForm:accountId']")).sendKeys("QA-vn52odq");
		driver.findElement(By.xpath("//input[@id ='loginForm:password']")).sendKeys("Test@123");
		driver.findElement(By.xpath("//input[@id ='loginForm:loginButton']")).click();;

		Thread.sleep(10000);
		driver.findElement(By.xpath("//*[@class='header bg-primary navbar']/ul[1]/li[5]/a[1]")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("//a[@role='menuitem'][normalize-space()='Application Definition']")).click();
		
		Thread.sleep(10000);
		driver.findElement(By.xpath("//input[@id='searchfield-1025-inputEl']")).sendKeys("InContactWMUS");
		
		Thread.sleep(10000);
		driver.findElement(By.xpath("//div[@id='ext-gen1099']")).click();
		
		Thread.sleep(10000);
		//driver.findElement(By.xpath("//div[normalize-space()='InContactWMUS']")).click();
		driver.findElement(By.xpath("//tbody/tr[2]/td[1]/div[1]")).click();
		WebElement  ele = driver.findElement(By.xpath("//input[@id='editForm:appName']"));
    	String Textboxvalue = ele.getAttribute("value");
    	System.out.println("Testx value :: " +Textboxvalue);
    	
    	
    			
    			WebElement  ele1 = driver.findElement(By.xpath("(//td[@id='applicationPageOwner-inputCell'])[1]"));
    	    	String Textboxvalue1 = ele1.getText();
    	    	System.out.println("Testx2 value :: " +Textboxvalue1);
    	    	
    	    	WebElement web_el = driver.findElement(By.xpath("//select[@id='editForm:appType']"));
    	        Select select = new Select(web_el);
    	        List<WebElement> option = select.getOptions();
    	        String value =option.get(0).getText();
    	        System.out.println("Type of app ::"+ value);
    	        
    	       
    	    	
    	    	
    	    	WebElement checkbox = driver.findElement(By.xpath("//input[@id='editForm:selectedOperations:1']"));
    	    	System.out.println("The checkbox is selection state is - " + checkbox.isSelected());

    	    	boolean status = checkbox.isSelected();
    			
    			//confirming what is there in status for learning purpose otherwise no need
    			System.out.println("Checking boolean status:"+status);
    			
    			//checking condition is true or not.
    			if(status)
    			{
    				System.out.println("Working check box is selected sucessfully at profession.");
    				
    			}
    			
    			else
    			{
    				System.out.println("Working check box is not clicked at profession.");
    			}
    	    	
    			driver.findElement(By.xpath("//span[.='Configuration']")).click();
		
    			 Select select2 = new Select(driver.findElement(By.xpath("//table[@id='ftable']//tr[1]// td[2]//select[@class='form-control']")));
 	    	    WebElement option2 = select2.getFirstSelectedOption();
 	    	    String defaultItem = option2.getText();
 	    	    System.out.println("Type Name in list::" +defaultItem );
		
 	    	   WebElement checkbox1 = driver.findElement(By.xpath("//table[@id='ftable']//tr[1]// td[5]//input[@type ='checkbox']"));
   	    	System.out.println("The checkbox is selection state is - " + checkbox1.isSelected());
   	    	String checbx = checkbox1.getAttribute("name");
   	    	System.out.println("checkbox value ::" +checbx);
   	    	boolean status1 = checkbox1.isSelected();
   			
   			//confirming what is there in status for learning purpose otherwise no need
   			System.out.println("Checking boolean status:"+status1);
   			
   			//checking condition is true or not.
   			if(status1)
   			{
   				System.out.println("operation check box is selected ");
   				
   			}
   			
   			else
   			{
   				System.out.println("operation check box is not selected .");
   			}
   	    	
   	
   			//WebElement btnaction = driver.findElement(By.xpath("//table[@id='ftable']//tr[1]// td[7]//a[1]"));
   		 
   	 	  
   	 		  //btnaction.click();
   	 		  int lastrow = 6;
   	 		for (int j=1;j<=lastrow;j++) {
   	 		//WebElement btnaction = driver.findElement(By.xpath("//table[@id='ftable']//tr[" + j + "]// td[7]//a[1]"));
   	 		//System.out.println("xapth" + //table[@id='ftable']//tr[" + j + "]// td[7]//a[" + j + "]);
  
   	 			try {
System.out.println("xapth oper::" +driver.findElement(By.xpath("//table[@id='ftable']//tr[" + j + "]// td[7]//a[1]")) );
WebElement element;
	

WebDriverWait wait = new WebDriverWait(driver, 10);
element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table[@id='ftable']//tr[" + j + "]// td[7]//a[1]")));

element.click();
   	 			}
   	 			
   	 			catch(org.openqa.selenium.StaleElementReferenceException ex) {
   	 			WebElement element;
   	 		

   	 		WebDriverWait wait = new WebDriverWait(driver, 10);
   	 		element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table[@id='ftable']//tr[" + j + "]// td[7]//a[1]")));

   	 		element.click();
   	 				
   	 			}
   	 			
   	 		
   	 	 
   	 	WebElement  text1 = driver.findElement(By.xpath("//input[@id='editForm:contextendpoint']"));
   	 	String ContextURLAct = text1.getAttribute("value");
   	 	System.out.println("Testx value :: " +ContextURLAct);
   	 	
   			
   	 		//String MethodAct=   driver.findElement(By.xpath("(//select[@class='form-control'])[8]//option[@selected ='selected']")).getText();
   	 		
   	 	try {
   	 	String MethodAct=   driver.findElement(By.xpath("//select[@id='editForm:methodid']//option[@selected ='selected']")).getAttribute("value");
 	 	 System.out.println("Method in operation::" +MethodAct );
  	 	
   	 		
   	 	}
   	 	
   	 catch(org.openqa.selenium.StaleElementReferenceException ex) { 
   		String MethodAct=   driver.findElement(By.xpath("//select[@id='editForm:methodid']//option[@selected ='selected']")).getAttribute("value");
 	 	 System.out.println("Method in operation::" +MethodAct );
  	 	
   		 
   	 }
   	
   	 	
   	 	//Select select1 = new Select(driver.findElement(By.xpath("//select[@id='editForm:methodid']")));
   	 	    ////WebElement option1 = select1.getFirstSelectedOption();
   	 	    //String MethodAct = option1.getAttribute("value");
   	 	//System.out.println("Method in operation::" +MethodAct );
   	 	try {
   	 	
   	 WebElement element1;
 	

   	WebDriverWait wait = new WebDriverWait(driver, 10);
   	element1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[.='Back']")));

   	element1.click();
   	   	 			}
   	   	 			
   	   	 			catch(org.openqa.selenium.StaleElementReferenceException ex) {
   	   	 			
   	   	 			WebElement element1;
   	   	 	 	

   	   	 	   	WebDriverWait wait = new WebDriverWait(driver, 10);
   	   	 	   	element1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[.='Back']")));

   	   	 	   	element1.click();
   	   	 				
   	   	 			}
   	 	
   	 //WebElement backbutton = driver.findElement(By.xpath("//span[.='Back']"));
		//backbutton.click();
		// System.out.println("Method in operation::" +MethodAct );
		
   	 		}
		
		
		//closing the browser   
 	    //confi checkxpath	    //table[@id='ftable']//tr[1]// td[5]//input[@type ='checkbox']
		//driver.close();
 	    	    // 

	}

}
