package TT;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class tasktest {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		


		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vn52odq\\Sailpoint\\SailpointTesting\\Driver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://spt-qa-task-01.lab.wal-mart.com/login.jsf");


		driver.manage().window().maximize();

		
		By Userid = By.xpath("//input[@id ='loginForm:accountId']");
		By Password = By.xpath("//input[@id ='loginForm:password']");
		By Login = By.xpath("//input[@id ='loginForm:loginButton']");
		
		driver.findElement(By.xpath("//input[@id ='loginForm:accountId']")).sendKeys("QA-vn52odq");
		driver.findElement(By.xpath("//input[@id ='loginForm:password']")).sendKeys("Test@123");
		driver.findElement(By.xpath("//input[@id ='loginForm:loginButton']")).click();;

		Thread.sleep(2000);
		driver.findElement(By.xpath("(//a[@role='menuitem'])[22]")).click();
		
		driver.findElement(By.xpath("//a[@role='menuitem'][normalize-space()='Tasks']")).click();
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='tasksSearchField-inputEl']")).sendKeys("InContactWMUS Full Account Aggregation Task");
		
		Thread.sleep(8000);
		
		driver.findElement(By.xpath("//div[@id='ext-gen1227']")).click();
		
		Thread.sleep(8000);
		
		String taskaccount ="InContactWMUS Full Account Aggregation Task";
		int r = driver.findElements(By.xpath("//div[@id='gridview-1026']//tbody//tr")).size();
	
System.out.println("Row value ::" +r);

for ( int i =1; i<=3;i++)
{
	String task = driver.findElement(By.xpath("//div[@id='gridview-1026']//tbody//tr[" + i + "]")).getText();
	
	System.out.println("TaskValue in table ::" + task);
	
	if (task.contains(taskaccount)) {
		System.out.println("Loop entered");
		
		 driver.findElement(By.xpath("//div[@id='gridview-1026']//tbody//tr[" + i + "]")).click();
		 break;
	}
}
JavascriptExecutor js = (JavascriptExecutor) driver;
//Locating element by link text and store in variable "Element"        		
WebElement Element = driver.findElement(By.xpath("//span[normalize-space()='Save and Execute']"));
//Scrolling down the page till the element is found		
js.executeScript("arguments[0].scrollIntoView();", Element);

driver.findElement(By.xpath("//span[normalize-space()='Save and Execute']")).click();
 Thread.sleep(2000);
 driver.findElement(By.xpath("//span[@id='button-1013-btnInnerEl']")).click();
 Thread.sleep(2000);
 
 driver.findElement(By.xpath("//span[@id='tab-1091-btnInnerEl']")).click();
 Thread.sleep(2000);
 
	driver.findElement(By.xpath("//input[@id='resultsSearchField-inputEl']")).sendKeys("InContactWMUS Full Account Aggregation Task");
	Thread.sleep(2000);
	
	driver.findElement(By.xpath("(//div[@role='button'])[6]")).click();
	
	Thread.sleep(2000);
	
	driver.findElement(By.xpath("(//div[@role='button'])[7]")).click();
	Thread.sleep(2000);
	
	driver.findElement(By.xpath("(//span[normalize-space()='Today'])[1]")).click();
	Thread.sleep(2000);
	
	driver.findElement(By.xpath("//span[@id='resultFilterButton-btnInnerEl']")).click();
	Thread.sleep(18000);
	
	driver.findElement(By.xpath("//span[@id='resultFilterButton-btnInnerEl']")).click();
	Thread.sleep(2000);
	
	int c = driver.findElements(By.xpath("//div[@id='gridview-1069']//tbody/tr/td")).size();
	
	System.out.println("columns value ::" +c);
	
	
	
	
	for ( int j =1; j<=3;j++)
	{
		String taskresult = driver.findElement(By.xpath("//div[@id='gridview-1069']//tbody/tr/td[" + j + "]")).getText();
		
		System.out.println("TaskValue in table ::" + taskresult);
		
		if (taskresult.contains(taskaccount)) {
			System.out.println("Loop entered 2");
			
			 driver.findElement(By.xpath("//div[@id='gridview-1069']//tbody/tr/td[" + j + "]")).click();
			 break;
		}
	}
	
	
	
	
	
	
 
 
 
 
 
 
 
 
 





	}

}
