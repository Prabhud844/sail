package SailpointPageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;

import utili.Helper;

public class LoginPage {
	
	
		
		WebDriver driver;
		
		//By Userid = By.xpath("//input[@id ='loginForm:accountId']");
		//By Password = By.xpath("//input[@id ='loginForm:password']");
		//By Login = By.xpath("//input[@id ='loginForm:loginButton']");
		
		
		//Login page UI elements
	    @FindBy(xpath="//input[@id ='loginForm:accountId']") WebElement Userid;
	    @FindBy(xpath="//input[@id ='loginForm:password']") WebElement Password;
	    @FindBy(xpath="//input[@id ='loginForm:loginButton']") WebElement Login;
		
		public LoginPage(WebDriver driver) {
			
			this.driver =driver;
			
		}
		
		public void loginToApplication(String uname,String pass,ExtentTest logger)
	    {
	        Helper.waitForWebElementAndType(driver,Userid,uname,"Enter email",logger);
	     
	        Helper.waitForWebElementAndType(driver, Password, pass, "Enter password",logger);
	        Helper.waitForWebElementAndClick(driver, Login, "Click On Login button",logger);
	        //Assert.assertTrue(Helper.waitForURL(driver, "dashboard"));
	    }
		
		
		
		

	}


