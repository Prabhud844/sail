package SailpointPageobject;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import utili.ExcelDataProvider;
import utili.Helper;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class applicationSearchinapp extends BaseClass  {



    WebDriver driver;

   
    public applicationSearchinapp(WebDriver ldriver)
    {
        this.driver=ldriver;


    }

    
    //Application Definition page UI elements
   
    public static  By liapplications = By.xpath("(//a[@role='menuitem'])[12]");
    
    public static  By lnAppdefinition = By.xpath("(//a[@role='menuitem'])[13]");
    public static  By lnconfig = By.xpath("//span[.='Configuration']");
    public static  By lnsettingcon = By.xpath("//span[.='Settings']");
    
  
    
    //public static By btntesc = By.xpath("//span[.='Test Connection']");
    public static  final String btntesc = "//span[.='Test Connection']";
    //public static final String lnconfig = "//span[.='Configuration']";
    
    public static  final String  txtsearchapp = "//input[@class='x-form-field x-form-empty-field x-form-text']";
    
  //body/div/div[@id='spHeaderPanelDiv']/div[@id='menuMainDiv']/nav/ul[@role='menubar']/li[5]/a[1]
   // @FindBy(xpath="(//a[@role='menuitem'])[12]") WebElement liapplications;
    //@FindBy(xpath="//a[@role='menuitem'][normalize-space()='Application Definition']") WebElement lnAppdefinition;
    //@FindBy(xpath="//input[@id='searchfield-1025-inputEl']") WebElement txtsearchapp;
        @FindBy(xpath="//div[@id='ext-gen1099']") WebElement btnsearch;
    @FindBy(xpath="//tbody/tr[2]/td[1]/div[1]") WebElement srchresult;
    @FindBy(xpath="(//span[@id='tab-1091-btnInnerEl'])[1]") WebElement lnConfiguration;
   @FindBy(xpath="(//span[@id='tab-1082-btnInnerEl'])[1]") WebElement lnsetting;
  @FindBy(xpath="//span[normalize-space()='Test Connection']") WebElement testconnect;
  //@FindBy(xpath ="//body[1]/div[2]/div[2]/form[1]/div[4]/div[1]/div[1]/div[2]/div[1]/div[4]/div[1]/table[1]/tbody[1]/tr[2]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[2]/div[1]")  WebElement accoutnamecheck; 
  @FindBy (xpath = "(//span[@id='tab-1132-btnInnerEl'])[1]") WebElement lnAccount ;
    public static final String txt1 ="//input[@id='editForm:appName']";
    public static final String checkcreate = "(//input[@id='editForm:selectedOperations:0'])[1]";
    public static final String checkmodify ="(//input[@id='editForm:selectedOperations:1'])[1]";
    public static final String checkdelete ="(//input[@id='editForm:selectedOperations:2'])[1]";
    public static final String testsucceful = "//div[@id='testResultsDiv']";
    public static final String checkmanger = "(//input[@type='checkbox'])[8]";
    public static final String accoutnamecheck = "//body[1]/div[2]/div[2]/form[1]/div[4]/div[1]/div[1]/div[2]/div[1]/div[4]/div[1]/table[1]/tbody[1]/tr[2]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[2]/div[1]";
    public static final String txtbaseurl = "//input[@id='editForm:BaseUrlID']";
    public static final String  radinoauth ="//input[@value='No Auth']";
    public static final String  radioauth2 ="//input[@value='OAuth2Login']";
    public static final String  radioapitoken ="//input[@value='OAuthLogin']";
    public static final String  radibasicauth ="//input[@value='BasicLogin']";
    public static final String lisoperation ="//table[@id='ftable']//tr[1]// td[2]//select[@class='form-control']";
  
   
    	
   
    
public void appsearch(ExtentTest logger) throws Exception {
	Helper.click(driver, liapplications,"Click On applications Link ",logger);
	//Helper.waitForWebElementAndClick(driver, liapplications, "Click On applications Link ",logger);
	Helper.click(driver, lnAppdefinition,"Click On applications Appdefinition Link ",logger);
	
	
}

    public void ApplicationSearch(String appname,ExtentTest logger) throws Exception
    {
    	driver.findElement(By.xpath(txtsearchapp)).sendKeys(appname);
    	//Helper.waitForWebElementAndClick(driver, lnAppdefinition, "Click On applications Appdefinition Link ",logger);
    	 //Helper.waitForWebElementAndType(driver,txtsearchapp,appname,"Entered App Name to Search in search bar",logger);
        Helper.waitForWebElementAndClick(driver, btnsearch, "Click On Search  button",logger);
        //logger.log(Status.PASS, "Sailpoint App Name"+logger.addScreenCaptureFromPath(captureScreen()));
        
        Thread.sleep(20000);
        Helper.waitForWebElementAndClick(driver, srchresult, "Click On App Search Result  ",logger);
      
       // logger.log(Status.PASS, "Sailpoint App Name"+logger.addScreenCaptureFromPath(captureScreen()));
        
    
    }
    
    public void textboxcheck(String appname,ExtentTest logger) {
    	Helper.validatetextbox(driver, txt1, appname, "Name of the Application is validate from App Defintion", logger);
    	
    }

	public void checkboxchangeopertaion(ExtentTest logger) throws IOException {
		
		Helper.checkboxcheckedvalidation(driver, checkcreate, "Native Change Operations :Create checkbox validation check", logger);
		Helper.checkboxcheckedvalidation(driver, checkmodify, "Native Change Operations :Modify checkbox validation check", logger);
		Helper.checkboxcheckedvalidation(driver, checkmanger, "Manager Approval Checkbox validation check", logger);
		
		Helper.checkboxuncheckedvalidation(driver, checkdelete, "Native Change Operations :Delete checkbox validation check", logger);
	
		//logger.log(Status.PASS, "Sailpoint Checkbox Checked"+logger.addScreenCaptureFromPath(captureScreen()));
        
		
	}
	
	public void Accountsaddcheck(ExtentTest logger) {
		Helper.waitForWebElementAndClick(driver, lnAccount, "Click On Account Link from Applications   ",logger);
    	
		Helper.Webelementclickcheck(driver, accoutnamecheck, "Click On AccountName Link from Account Section", logger);
		
		
	}
	
	public void configurationsettingcheck(ExtentTest logger) throws InterruptedException
    {
    	Helper.waitForWebElementAndClick(driver, lnConfiguration, "Click On Configuration tab from Application ",logger);
    	Helper.waitForWebElementAndClick(driver, lnsetting, "Click On Setting tab from Applications   ",logger);
    	
    	//Helper.gettextfromweb(driver, txtbaseurl, baseurl, "Base URL comparsion with actual URL from Design ", logger);
    	Helper.radiobuttoncheckvalidation(driver, radinoauth, " Radio button check :No / Custom Authentication ", logger);
    	Helper.radiobuttonuncheckvalidation(driver, radioauth2, " Radio button uncheck :OAuth2 ", logger);
    	Helper.radiobuttonuncheckvalidation(driver, radioapitoken, " Radio button uncheck :API Token ", logger);
    	Helper.radiobuttonuncheckvalidation(driver, radibasicauth, " Radio button uncheck :Basic Authentication ", logger);
    	
    	//Helper.scrolldown(driver, testconnect, "Scroll Down", logger);
    	
    	//Helper.waitForWebElementAndClick(driver, testconnect, "Click On TestConnection  button",logger);
    	//Thread.sleep(20000);
        //Helper.gettextvalue(driver, testsucceful, textvalue, "Testconnection is Succesfully message is displayed", logger);
    	
    
    }
	
	public void baseurlcheck(String baseurl,ExtentTest logger) {
		Helper.validatetextbox(driver, txtbaseurl, baseurl, "Base URL comparsion with actual URL from Design ", logger);

    	
		
	}
	
	public  void beforeafterrule (ExtentTest logger) {
		
		
		try {
			
			FileInputStream fs =new FileInputStream(Filepath);
	    	HSSFWorkbook ExcelWorkbook =new HSSFWorkbook(fs);
	    	HSSFSheet Excelsheet  = ExcelWorkbook.getSheet("operator");
	    	int lastrow = Excelsheet.getLastRowNum();
	    	String operatorionExp = null;
	    	String BeforeRuleExp = null;
	    	String AfterRuleExp = null;
	    	String ContextURLExp = null;
	    	String MethodExp = null;
	    	
	    	for (int j=1;j<=lastrow;j++) {
	    		SoftAssert Assert = new SoftAssert();
	    		
	    		System.out.println("iteration in ::"+ j);
	    		System.out.println("row  value ::"+ lastrow);
	    		
	    		//operatorionExp = ExcelDataProvider.getInputData("operator","operatorcolumn", j);
	    		BeforeRuleExp = ExcelDataProvider.getInputData("operator","BeforeRule", j);
	    		AfterRuleExp = ExcelDataProvider.getInputData("operator","AfterRule", j);
	    		//ContextURLExp = ExcelDataProvider.getInputData("operator","ContextURL", j);
	    		//MethodExp = ExcelDataProvider.getInputData("operator","Method", j);
	    		/*
	    		
	    		System.out.println("Opetator name from excel ::" + operatorionExp);
	    		
	    		//Select select = new Select(driver.findElement(By.xpath("//table[@id='ftable']//tr[" + j + "]// td[2]//select[@class='form-control']//option[@selected ='selected']")));
 	    	    //WebElement option = select.getFirstSelectedOption();
 	    	    String operatorionAct = driver.findElement(By.xpath("(//table[@id='ftable']//tr[" + j + "]// td[2]//select[@class='form-control']//option[@selected ='selected'])")).getText();
 	    	    System.out.println("Operator Name in list::" +operatorionAct );
 	    	    
 	    	   System.out.println("xapth oper::" +driver.findElement(By.xpath("(//table[@id='ftable']//tr[" + j + "]// td[2]//select[@class='form-control']//option[@selected ='selected'])")) );
 	    	    
 	    	    
 	    	   if ( operatorionExp.equalsIgnoreCase(operatorionAct)){
 	                 Assert.assertTrue(operatorionExp.equals(operatorionAct));
 	                System.out.println("Entered in 1st if condition value is '"+operatorionExp +"' : :  '"+operatorionAct+"'"   );
 	            logger.info("LOG:INFO-  Operation List box validation for   :'"+j +"' :  '"+operatorionAct+"'" );
 	            logger.pass("Expected Name value is present in Listbox  as:   '" + operatorionExp +"' Actual Value present in Listbox operation '"+operatorionAct +"'");
 	           
 	        }
 	             else {
 	            	 //logger.info("Expected APP Name value is not present as :   '" + appname +"' Actual Value present in Sailpoint Name '"+Textboxvalue +"'");
 	            	 Assert.assertFalse(operatorionExp.equals(operatorionAct));
  	                System.out.println("Entered in 2nd if condition value is '"+operatorionExp +"' : :  '"+operatorionAct+"'"   );
  	              logger.info("LOG:INFO-  Operation List box validation for   :'"+j +"' :  '"+operatorionAct+"'" );
   	            
 	            	  logger.fail("Expected  Name value is not present in listbox operation as :   '" + operatorionExp +"' Actual Value present in Listbox operation  '"+operatorionAct +"'");
 	             } */
 	             //Assert.assertAll();
 	    	   
 	// Before Rule Check box validation
 	 
 	    	  
 	    	   WebElement checkbox1 = driver.findElement(By.xpath("//table[@id='ftable']//tr[" + j + "]// td[5]//input[@type ='checkbox']"));
 	   	    	//System.out.println("The checkbox is selection state is - " + checkbox1.isSelected());
 	   	    	String BeforeRuleAct = checkbox1.getAttribute("name");
 	   	    	System.out.println("checkbox1 beforerule value ::" +BeforeRuleAct);   
	    		
 	   	    if ( BeforeRuleExp.equalsIgnoreCase(BeforeRuleAct)){
                 Assert.assertTrue(BeforeRuleExp.equals(BeforeRuleAct));
                System.out.println("Entered in 1st if condition value is '"+BeforeRuleExp +"' : :  '"+BeforeRuleAct+"'"   );
            logger.info("LOG:INFO-  BeforeRuleCheckbox validation for   :'"+j +"' :  '"+BeforeRuleAct+"'" );
            logger.pass("Expected  value is present in BeforeRuleCheckbox  as:   '" + BeforeRuleExp +"' Actual Value present in BeforeRuleCheckbox '"+BeforeRuleAct +"'");
           
        }
             else {
            	 //logger.info("Expected APP Name value is not present as :   '" + appname +"' Actual Value present in Sailpoint Name '"+Textboxvalue +"'");
            	 Assert.assertFalse(BeforeRuleExp.equals(BeforeRuleAct));
	                System.out.println("Entered in 2nd if condition value is '"+BeforeRuleExp +"' : :  '"+BeforeRuleAct+"'"   );
	              logger.info("LOG:INFO-  Operation List box validation for   :'"+j +"' :  '"+BeforeRuleAct+"'" );
	            
            	  logger.fail("Expected  value in BeforeRuleCheckbox as :   '" + BeforeRuleExp +"' Actual Value present in BeforeRuleCheckbox  '"+BeforeRuleAct +"'");
             }
            
	    	
 	   // AfterRule Check box
 	   	 WebElement checkbox2 = driver.findElement(By.xpath("//table[@id='ftable']//tr[" + j + "]// td[6]//input[@type ='checkbox']"));
 	    	//System.out.println("The checkbox is selection state is - " + checkbox1.isSelected());
 	    	String AfterRuleAct = checkbox2.getAttribute("name");
 	    	System.out.println("checkbox1 beforerule value ::" +AfterRuleAct);   
 		
 	    if ( AfterRuleExp.equalsIgnoreCase(AfterRuleAct)){
          Assert.assertTrue(AfterRuleExp.equals(AfterRuleAct));
         System.out.println("Entered in 1st if condition value is '"+AfterRuleExp +"' : :  '"+AfterRuleAct+"'"   );
     logger.info("LOG:INFO-  BeforeRuleCheckbox validation for   :'"+j +"' :  '"+AfterRuleAct+"'" );
     logger.pass("Expected  value is present in BeforeRuleCheckbox  as:   '" + AfterRuleExp +"' Actual Value present in BeforeRuleCheckbox '"+AfterRuleAct +"'");
    
 }
      else {
     	 //logger.info("Expected APP Name value is not present as :   '" + appname +"' Actual Value present in Sailpoint Name '"+Textboxvalue +"'");
     	 Assert.assertFalse(AfterRuleExp.equals(AfterRuleAct));
             System.out.println("Entered in 2nd if condition value is '"+AfterRuleExp +"' : :  '"+AfterRuleAct+"'"   );
           logger.info("LOG:INFO-  Operation List box validation for   :'"+j +"' :  '"+AfterRuleAct+"'" );
         
     	  logger.fail("Expected  value in BeforeRuleCheckbox as :   '" + AfterRuleExp +"' Actual Value present in BeforeRuleCheckbox  '"+AfterRuleAct +"'");
      }
 	    
 	    /*
 	    
 	   WebElement btnaction = driver.findElement(By.xpath("//table[@id='ftable']//tr[" + j + "]// td[7]//a[" + j + "]"));
 	  btnaction.click();
		 System.out.println("Action button is clicked   ::" );  
		 logger.info("LOG:INFO-  Action Button clicked   :'"+j +"' " );
		logger.pass("Action button is clicked ");
		
		Thread.sleep(5000);
		
		
		
		
		WebElement  text1 = driver.findElement(By.xpath("//input[@id='editForm:contextendpoint']"));
 	String ContextURLAct = text1.getAttribute("value");
 	System.out.println("Testx value :: " +ContextURLAct);
 	
 	if ( ContextURLExp.equalsIgnoreCase(ContextURLAct)){
        Assert.assertTrue(ContextURLExp.equals(ContextURLAct));
       System.out.println("Entered in 1st if condition value is '"+ContextURLExp +"' : :  '"+ContextURLAct+"'"   );
   logger.info("LOG:INFO-  ContextURL validation for   :'"+j +"' :  '"+ContextURLAct+"'" );
   logger.pass("Expected  value is present in ContextURL TextBox  as:   '" + ContextURLExp +"' Actual Value present in ContextURL TextBox as '"+ContextURLAct +"'");

   }
    else {
   	 //logger.info("Expected APP Name value is not present as :   '" + appname +"' Actual Value present in Sailpoint Name '"+Textboxvalue +"'");
   	 Assert.assertFalse(ContextURLExp.equals(ContextURLAct));
           System.out.println("Entered in 2nd if condition value is '"+ContextURLExp +"' : :  '"+ContextURLAct+"'"   );
         logger.info("LOG:INFO-  Operation List box validation for   :'"+j +"' :  '"+ContextURLAct+"'" );
       
   	  logger.fail("Expected  value in ContextURL TextBox as :   '" + ContextURLExp +"' Actual Value present in ContextURL TextBox  '"+ContextURLAct +"'");
    }

 	
 	
 		
	    
 	String MethodAct=   driver.findElement(By.xpath("(//select[@class='form-control'])[8]//option[@selected ='selected']")).getText();
 	 System.out.println("Method in operation::" +MethodAct );
		
 	if ( MethodExp.equalsIgnoreCase(MethodAct)){
        Assert.assertTrue(MethodExp.equals(MethodAct));
       System.out.println("Entered in 1st if condition value is '"+MethodExp +"' : :  '"+MethodAct+"'"   );
   logger.info("LOG:INFO-  Method List box validation for   :'"+j +"' :  '"+MethodAct+"'" );
   logger.pass("Expected Name value is present in Method Listbox  as:   '" + MethodExp +"' Actual Value present in Method Listbox  '"+MethodAct +"'");
  
}
    else {
   	 //logger.info("Expected APP Name value is not present as :   '" + appname +"' Actual Value present in Sailpoint Name '"+Textboxvalue +"'");
   	 Assert.assertFalse(operatorionExp.equals(MethodAct));
        System.out.println("Entered in 2nd if condition value is '"+MethodExp +"' : :  '"+MethodAct+"'"   );
      logger.info("LOG:INFO-   Method List box validation for   :'"+j +"' :  '"+MethodAct+"'" );
     
   	  logger.fail("Expected  Name value is not present in  Method listbox  as :   '" + MethodExp +"' Actual Value present in Method Listbox   '"+MethodAct +"'");
    }
   

 	 
 	
 	
 	WebElement backbutton = driver.findElement(By.xpath("//span[.='Back']"));
 		backbutton.click();
 		
 	
 	*/
 	
 	
 	
 	   
	    	}
	    	
		}
		catch(Exception e) {
			e.getMessage();
		
		
		}
		
		
		
	}
	
	
	
public  void Actionbtncheck (ExtentTest logger) {
		
		
		try {
			
			FileInputStream fs =new FileInputStream(Filepath);
	    	HSSFWorkbook ExcelWorkbook =new HSSFWorkbook(fs);
	    	HSSFSheet Excelsheet  = ExcelWorkbook.getSheet("operator");
	    	int lastrow = Excelsheet.getLastRowNum();
	    	String operatorionExp = null;
	    	String BeforeRuleExp = null;
	    	String AfterRuleExp = null;
	    	String ContextURLExp = null;
	    	String MethodExp = null;
	    	
	    	for (int j=1;j<=lastrow;j++) {
	    		SoftAssert Assert = new SoftAssert();
	    		
	    		System.out.println("iteration in ::"+ j);
	    		System.out.println("row  value ::"+ lastrow);
	    		
	    		//operatorionExp = ExcelDataProvider.getInputData("operator","operatorcolumn", j);
	    		//BeforeRuleExp = ExcelDataProvider.getInputData("operator","BeforeRule", j);
	    		//AfterRuleExp = ExcelDataProvider.getInputData("operator","AfterRule", j);
	    		ContextURLExp = ExcelDataProvider.getInputData("operator","ContextURL", j);
	    		MethodExp = ExcelDataProvider.getInputData("operator","Method", j);
	    		 /*
	    		
	    		System.out.println("Opetator name from excel ::" + operatorionExp);
	    		
	    		//Select select = new Select(driver.findElement(By.xpath("//table[@id='ftable']//tr[" + j + "]// td[2]//select[@class='form-control']//option[@selected ='selected']")));
 	    	    //WebElement option = select.getFirstSelectedOption();
 	    	    String operatorionAct = driver.findElement(By.xpath("(//table[@id='ftable']//tr[" + j + "]// td[2]//select[@class='form-control']//option[@selected ='selected'])")).getText();
 	    	    System.out.println("Operator Name in list::" +operatorionAct );
 	    	    
 	    	   System.out.println("xapth oper::" +driver.findElement(By.xpath("(//table[@id='ftable']//tr[" + j + "]// td[2]//select[@class='form-control']//option[@selected ='selected'])")) );
 	    	    
 	    	    
 	    	   if ( operatorionExp.equalsIgnoreCase(operatorionAct)){
 	                 Assert.assertTrue(operatorionExp.equals(operatorionAct));
 	                System.out.println("Entered in 1st if condition value is '"+operatorionExp +"' : :  '"+operatorionAct+"'"   );
 	            logger.info("LOG:INFO-  Operation List box validation for   :'"+j +"' :  '"+operatorionAct+"'" );
 	            logger.pass("Expected Name value is present in Listbox  as:   '" + operatorionExp +"' Actual Value present in Listbox operation '"+operatorionAct +"'");
 	           
 	        }
 	             else {
 	            	 //logger.info("Expected APP Name value is not present as :   '" + appname +"' Actual Value present in Sailpoint Name '"+Textboxvalue +"'");
 	            	 Assert.assertFalse(operatorionExp.equals(operatorionAct));
  	                System.out.println("Entered in 2nd if condition value is '"+operatorionExp +"' : :  '"+operatorionAct+"'"   );
  	              logger.info("LOG:INFO-  Operation List box validation for   :'"+j +"' :  '"+operatorionAct+"'" );
   	            
 	            	  logger.fail("Expected  Name value is not present in listbox operation as :   '" + operatorionExp +"' Actual Value present in Listbox operation  '"+operatorionAct +"'");
 	             }
 	             //Assert.assertAll();
 	    	   
 	// Before Rule Check box validation
 	 
 	    	  
 	    	   WebElement checkbox1 = driver.findElement(By.xpath("//table[@id='ftable']//tr[" + j + "]// td[5]//input[@type ='checkbox']"));
 	   	    	//System.out.println("The checkbox is selection state is - " + checkbox1.isSelected());
 	   	    	String BeforeRuleAct = checkbox1.getAttribute("name");
 	   	    	System.out.println("checkbox1 beforerule value ::" +BeforeRuleAct);   
	    		
 	   	    if ( BeforeRuleExp.equalsIgnoreCase(BeforeRuleAct)){
                 Assert.assertTrue(BeforeRuleExp.equals(BeforeRuleAct));
                System.out.println("Entered in 1st if condition value is '"+BeforeRuleExp +"' : :  '"+BeforeRuleAct+"'"   );
            logger.info("LOG:INFO-  BeforeRuleCheckbox validation for   :'"+j +"' :  '"+BeforeRuleAct+"'" );
            logger.pass("Expected  value is present in BeforeRuleCheckbox  as:   '" + BeforeRuleExp +"' Actual Value present in BeforeRuleCheckbox '"+BeforeRuleAct +"'");
           
        }
             else {
            	 //logger.info("Expected APP Name value is not present as :   '" + appname +"' Actual Value present in Sailpoint Name '"+Textboxvalue +"'");
            	 Assert.assertFalse(BeforeRuleExp.equals(BeforeRuleAct));
	                System.out.println("Entered in 2nd if condition value is '"+BeforeRuleExp +"' : :  '"+BeforeRuleAct+"'"   );
	              logger.info("LOG:INFO-  Operation List box validation for   :'"+j +"' :  '"+BeforeRuleAct+"'" );
	            
            	  logger.fail("Expected  value in BeforeRuleCheckbox as :   '" + BeforeRuleExp +"' Actual Value present in BeforeRuleCheckbox  '"+BeforeRuleAct +"'");
             }
            
	    	
 	   // AfterRule Check box
 	   	 WebElement checkbox2 = driver.findElement(By.xpath("//table[@id='ftable']//tr[" + j + "]// td[6]//input[@type ='checkbox']"));
 	    	//System.out.println("The checkbox is selection state is - " + checkbox1.isSelected());
 	    	String AfterRuleAct = checkbox2.getAttribute("name");
 	    	System.out.println("checkbox1 beforerule value ::" +AfterRuleAct);   
 		
 	    if ( AfterRuleExp.equalsIgnoreCase(AfterRuleAct)){
          Assert.assertTrue(AfterRuleExp.equals(AfterRuleAct));
         System.out.println("Entered in 1st if condition value is '"+AfterRuleExp +"' : :  '"+AfterRuleAct+"'"   );
     logger.info("LOG:INFO-  BeforeRuleCheckbox validation for   :'"+j +"' :  '"+AfterRuleAct+"'" );
     logger.pass("Expected  value is present in BeforeRuleCheckbox  as:   '" + AfterRuleExp +"' Actual Value present in BeforeRuleCheckbox '"+AfterRuleAct +"'");
    
 }
      else {
     	 //logger.info("Expected APP Name value is not present as :   '" + appname +"' Actual Value present in Sailpoint Name '"+Textboxvalue +"'");
     	 Assert.assertFalse(AfterRuleExp.equals(AfterRuleAct));
             System.out.println("Entered in 2nd if condition value is '"+AfterRuleExp +"' : :  '"+AfterRuleAct+"'"   );
           logger.info("LOG:INFO-  Operation List box validation for   :'"+j +"' :  '"+AfterRuleAct+"'" );
         
     	  logger.fail("Expected  value in BeforeRuleCheckbox as :   '" + AfterRuleExp +"' Actual Value present in BeforeRuleCheckbox  '"+AfterRuleAct +"'");
      }
 	    
 	    
 	    */
	    		try {
	    			System.out.println("xapth oper::" +driver.findElement(By.xpath("//table[@id='ftable']//tr[" + j + "]// td[7]//a[1]")) );
	    			WebElement element;
	    				

	    			WebDriverWait wait = new WebDriverWait(driver, 10);
	    			element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table[@id='ftable']//tr[" + j + "]// td[7]//a[1]")));

	    			element.click();
	    			 logger.info("LOG:INFO-  Action Button clicked   :'"+j +"' " );
	    				logger.pass("Action button is clicked ");
	    			   	 			}
	    			   	 			
	    			   	 			catch(org.openqa.selenium.StaleElementReferenceException ex) {
	    			   	 			WebElement element;
	    			   	 		

	    			   	 		WebDriverWait wait = new WebDriverWait(driver, 10);
	    			   	 		element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table[@id='ftable']//tr[" + j + "]// td[7]//a[1]")));

	    			   	 		element.click();
	    			   	 	 logger.info("LOG:INFO-  Action Button clicked   :'"+j +"' " );
	    			 		logger.pass("Action button is clicked ");
	    			   	 				
	    			   	 			}
	    		
	    		
 	   //WebElement btnaction = driver.findElement(By.xpath("//table[@id='ftable']//tr[" + j + "]// td[7]//a[" + j + "]"));
 	  //btnaction.click();
		 //System.out.println("Action button is clicked   ::" );  
		 //logger.info("LOG:INFO-  Action Button clicked   :'"+j +"' " );
		//logger.pass("Action button is clicked ");
		
		Thread.sleep(5000);
		

		
		
		WebElement  text1 = driver.findElement(By.xpath("//input[@id='editForm:contextendpoint']"));
 	String ContextURLAct = text1.getAttribute("value");
 	System.out.println("Testx value :: " +ContextURLAct);
 	
 	if ( ContextURLExp.equalsIgnoreCase(ContextURLAct)){
        Assert.assertTrue(ContextURLExp.equals(ContextURLAct));
       System.out.println("Entered in 1st if condition value is '"+ContextURLExp +"' : :  '"+ContextURLAct+"'"   );
   logger.info("LOG:INFO-  ContextURL validation for   :'"+j +"' :  '"+ContextURLAct+"'" );
   logger.pass("Expected  value is present in ContextURL TextBox  as:   '" + ContextURLExp +"' Actual Value present in ContextURL TextBox as '"+ContextURLAct +"'");

   }
    else {
   	 //logger.info("Expected APP Name value is not present as :   '" + appname +"' Actual Value present in Sailpoint Name '"+Textboxvalue +"'");
   	 Assert.assertFalse(ContextURLExp.equals(ContextURLAct));
           System.out.println("Entered in 2nd if condition value is '"+ContextURLExp +"' : :  '"+ContextURLAct+"'"   );
         logger.info("LOG:INFO-  Operation List box validation for   :'"+j +"' :  '"+ContextURLAct+"'" );
       
   	  logger.fail("Expected  value in ContextURL TextBox as :   '" + ContextURLExp +"' Actual Value present in ContextURL TextBox  '"+ContextURLAct +"'");
    }

 	String MethodAct =null;
 	try {
   	 	 MethodAct=   driver.findElement(By.xpath("//select[@id='editForm:methodid']//option[@selected ='selected']")).getAttribute("value");
 	 	 System.out.println("Method in operation::" +MethodAct );
 	    logger.info("Log: info -Data in method list is : "+MethodAct);
  	 	
   	 		
   	 	}
   	 	
   	 catch(org.openqa.selenium.StaleElementReferenceException ex) { 
   		 MethodAct=   driver.findElement(By.xpath("//select[@id='editForm:methodid']//option[@selected ='selected']")).getAttribute("value");
 	 	 System.out.println("Method in operation::" +MethodAct );
 	 	logger.info(" Data in method list is : "+MethodAct);
  	 	
   		 
   	 }
 	
 	
 		
	    
 	//String MethodAct=   driver.findElement(By.xpath("(//select[@class='form-control'])[8]//option[@selected ='selected']")).getText();
 	 System.out.println("Method in operation outer::" +MethodAct );
		
 	if ( MethodExp.equalsIgnoreCase(MethodAct)){
        Assert.assertTrue(MethodExp.equals(MethodAct));
       System.out.println("Entered in 1st if condition value is '"+MethodExp +"' : :  '"+MethodAct+"'"   );
   logger.info("LOG:INFO-  Method List box validation for   :'"+j +"' :  '"+MethodAct+"'" );
   logger.pass("Expected Name value is present in Method Listbox  as:   '" + MethodExp +"' Actual Value present in Method Listbox  '"+MethodAct +"'");
  
}
    else {
   	 //logger.info("Expected APP Name value is not present as :   '" + appname +"' Actual Value present in Sailpoint Name '"+Textboxvalue +"'");
   	 Assert.assertFalse(operatorionExp.equals(MethodAct));
        System.out.println("Entered in 2nd if condition value is '"+MethodExp +"' : :  '"+MethodAct+"'"   );
      logger.info("LOG:INFO-   Method List box validation for   :'"+j +"' :  '"+MethodAct+"'" );
     
   	  logger.fail("Expected  Name value is not present in  Method listbox  as :   '" + MethodExp +"' Actual Value present in Method Listbox   '"+MethodAct +"'");
    }
   

 	 
 	
 	try {
   	 	
 	   	 WebElement element1;
 	 	

 	   	WebDriverWait wait = new WebDriverWait(driver, 10);
 	   	element1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[.='Back']")));

 	   	element1.click();
 	   logger.info("LOG:IN : Back button clicked ");
 	   
 	   	   	 			}
 	   	   	 			
 	   	   	 			catch(org.openqa.selenium.StaleElementReferenceException ex) {
 	   	   	 			
 	   	   	 			WebElement element1;
 	   	   	 	 	

 	   	   	 	   	WebDriverWait wait = new WebDriverWait(driver, 10);
 	   	   	 	   	element1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[.='Back']")));

 	   	   	 	   	element1.click();
 	   	   	   logger.info("LOG:IN : Back button clicked ");
 	   	   	 				
 	   	   	 			}

 		
 	
 	
 	
 	
 	
 	   
	    	}
	    	
		}
		catch(Exception e) {
			e.getMessage();
		
		
		}
		
		
		
	}




public  void connectorOperationsail (ExtentTest logger) {
	
	
	try {
		
		FileInputStream fs =new FileInputStream(Filepath);
    	HSSFWorkbook ExcelWorkbook =new HSSFWorkbook(fs);
    	HSSFSheet Excelsheet  = ExcelWorkbook.getSheet("operator");
    	int lastrow = Excelsheet.getLastRowNum();
    	String operatorionExp = null;
    	String BeforeRuleExp = null;
    	String AfterRuleExp = null;
    	String ContextURLExp = null;
    	String MethodExp = null;
    	
    	for (int j=1;j<=lastrow;j++) {
    		SoftAssert Assert = new SoftAssert();
    		
    		System.out.println("iteration in ::"+ j);
    		System.out.println("row  value ::"+ lastrow);
    		
    		operatorionExp = ExcelDataProvider.getInputData("operator","operatorcolumn", j);
    		BeforeRuleExp = ExcelDataProvider.getInputData("operator","BeforeRule", j);
    		AfterRuleExp = ExcelDataProvider.getInputData("operator","AfterRule", j);
    		ContextURLExp = ExcelDataProvider.getInputData("operator","ContextURL", j);
    		MethodExp = ExcelDataProvider.getInputData("operator","Method", j);
    		
    		
    		System.out.println("Opetator name from excel ::" + operatorionExp);
    		
    		//Select select = new Select(driver.findElement(By.xpath("//table[@id='ftable']//tr[" + j + "]// td[2]//select[@class='form-control']//option[@selected ='selected']")));
	    	    //WebElement option = select.getFirstSelectedOption();
	    	    String operatorionAct = driver.findElement(By.xpath("(//table[@id='ftable']//tr[" + j + "]// td[2]//select[@class='form-control']//option[@selected ='selected'])")).getText();
	    	    System.out.println("Operator Name in list::" +operatorionAct );
	    	    
	    	   System.out.println("xapth oper::" +driver.findElement(By.xpath("(//table[@id='ftable']//tr[" + j + "]// td[2]//select[@class='form-control']//option[@selected ='selected'])")) );
	    	    
	    	    
	    	   if ( operatorionExp.equalsIgnoreCase(operatorionAct)){
	                 Assert.assertTrue(operatorionExp.equals(operatorionAct));
	                System.out.println("Entered in 1st if condition value is '"+operatorionExp +"' : :  '"+operatorionAct+"'"   );
	            logger.info("LOG:INFO-  Operation List box validation for   :'"+j +"' :  '"+operatorionAct+"'" );
	            logger.pass("Expected Name value is present in Listbox  as:   '" + operatorionExp +"' Actual Value present in Listbox operation '"+operatorionAct +"'");
	           
	        }
	             else {
	            	 //logger.info("Expected APP Name value is not present as :   '" + appname +"' Actual Value present in Sailpoint Name '"+Textboxvalue +"'");
	            	 Assert.assertFalse(operatorionExp.equals(operatorionAct));
	                System.out.println("Entered in 2nd if condition value is '"+operatorionExp +"' : :  '"+operatorionAct+"'"   );
	              logger.info("LOG:INFO-  Operation List box validation for   :'"+j +"' :  '"+operatorionAct+"'" );
	            
	            	  logger.fail("Expected  Name value is not present in listbox operation as :   '" + operatorionExp +"' Actual Value present in Listbox operation  '"+operatorionAct +"'");
	             }
	             //Assert.assertAll();
	    	   
	// Before Rule Check box validation
	 /*
	    	  
	    	   WebElement checkbox1 = driver.findElement(By.xpath("//table[@id='ftable']//tr[" + j + "]// td[5]//input[@type ='checkbox']"));
	   	    	//System.out.println("The checkbox is selection state is - " + checkbox1.isSelected());
	   	    	String BeforeRuleAct = checkbox1.getAttribute("name");
	   	    	System.out.println("checkbox1 beforerule value ::" +BeforeRuleAct);   
    		
	   	    if ( BeforeRuleExp.equalsIgnoreCase(BeforeRuleAct)){
             Assert.assertTrue(BeforeRuleExp.equals(BeforeRuleAct));
            System.out.println("Entered in 1st if condition value is '"+BeforeRuleExp +"' : :  '"+BeforeRuleAct+"'"   );
        logger.info("LOG:INFO-  BeforeRuleCheckbox validation for   :'"+j +"' :  '"+BeforeRuleAct+"'" );
        logger.pass("Expected  value is present in BeforeRuleCheckbox  as:   '" + BeforeRuleExp +"' Actual Value present in BeforeRuleCheckbox '"+BeforeRuleAct +"'");
       
    }
         else {
        	 //logger.info("Expected APP Name value is not present as :   '" + appname +"' Actual Value present in Sailpoint Name '"+Textboxvalue +"'");
        	 Assert.assertFalse(BeforeRuleExp.equals(BeforeRuleAct));
                System.out.println("Entered in 2nd if condition value is '"+BeforeRuleExp +"' : :  '"+BeforeRuleAct+"'"   );
              logger.info("LOG:INFO-  Operation List box validation for   :'"+j +"' :  '"+BeforeRuleAct+"'" );
            
        	  logger.fail("Expected  value in BeforeRuleCheckbox as :   '" + BeforeRuleExp +"' Actual Value present in BeforeRuleCheckbox  '"+BeforeRuleAct +"'");
         }
        
    	
	   // AfterRule Check box
	   	 WebElement checkbox2 = driver.findElement(By.xpath("//table[@id='ftable']//tr[" + j + "]// td[6]//input[@type ='checkbox']"));
	    	//System.out.println("The checkbox is selection state is - " + checkbox1.isSelected());
	    	String AfterRuleAct = checkbox2.getAttribute("name");
	    	System.out.println("checkbox1 beforerule value ::" +AfterRuleAct);   
		
	    if ( AfterRuleExp.equalsIgnoreCase(AfterRuleAct)){
      Assert.assertTrue(AfterRuleExp.equals(AfterRuleAct));
     System.out.println("Entered in 1st if condition value is '"+AfterRuleExp +"' : :  '"+AfterRuleAct+"'"   );
 logger.info("LOG:INFO-  BeforeRuleCheckbox validation for   :'"+j +"' :  '"+AfterRuleAct+"'" );
 logger.pass("Expected  value is present in BeforeRuleCheckbox  as:   '" + AfterRuleExp +"' Actual Value present in BeforeRuleCheckbox '"+AfterRuleAct +"'");

}
  else {
 	 //logger.info("Expected APP Name value is not present as :   '" + appname +"' Actual Value present in Sailpoint Name '"+Textboxvalue +"'");
 	 Assert.assertFalse(AfterRuleExp.equals(AfterRuleAct));
         System.out.println("Entered in 2nd if condition value is '"+AfterRuleExp +"' : :  '"+AfterRuleAct+"'"   );
       logger.info("LOG:INFO-  Operation List box validation for   :'"+j +"' :  '"+AfterRuleAct+"'" );
     
 	  logger.fail("Expected  value in BeforeRuleCheckbox as :   '" + AfterRuleExp +"' Actual Value present in BeforeRuleCheckbox  '"+AfterRuleAct +"'");
  }
	    
	   WebElement btnaction = driver.findElement(By.xpath("//table[@id='ftable']//tr[" + j + "]// td[7]//a[" + j + "]"));
	  btnaction.click();
	 System.out.println("Action button is clicked   ::" );  
	 logger.info("LOG:INFO-  Action Button clicked   :'"+j +"' " );
	logger.pass("Action button is clicked ");
	
	Thread.sleep(5000);
	
	
	
	
	WebElement  text1 = driver.findElement(By.xpath("//input[@id='editForm:contextendpoint']"));
	String ContextURLAct = text1.getAttribute("value");
	System.out.println("Testx value :: " +ContextURLAct);
	
	if ( ContextURLExp.equalsIgnoreCase(ContextURLAct)){
    Assert.assertTrue(ContextURLExp.equals(ContextURLAct));
   System.out.println("Entered in 1st if condition value is '"+ContextURLExp +"' : :  '"+ContextURLAct+"'"   );
logger.info("LOG:INFO-  ContextURL validation for   :'"+j +"' :  '"+ContextURLAct+"'" );
logger.pass("Expected  value is present in ContextURL TextBox  as:   '" + ContextURLExp +"' Actual Value present in ContextURL TextBox as '"+ContextURLAct +"'");

}
else {
	 //logger.info("Expected APP Name value is not present as :   '" + appname +"' Actual Value present in Sailpoint Name '"+Textboxvalue +"'");
	 Assert.assertFalse(ContextURLExp.equals(ContextURLAct));
       System.out.println("Entered in 2nd if condition value is '"+ContextURLExp +"' : :  '"+ContextURLAct+"'"   );
     logger.info("LOG:INFO-  Operation List box validation for   :'"+j +"' :  '"+ContextURLAct+"'" );
   
	  logger.fail("Expected  value in ContextURL TextBox as :   '" + ContextURLExp +"' Actual Value present in ContextURL TextBox  '"+ContextURLAct +"'");
}

	
	
		
    
	String MethodAct=   driver.findElement(By.xpath("(//select[@class='form-control'])[8]//option[@selected ='selected']")).getText();
	 System.out.println("Method in operation::" +MethodAct );
	
	if ( MethodExp.equalsIgnoreCase(MethodAct)){
    Assert.assertTrue(MethodExp.equals(MethodAct));
   System.out.println("Entered in 1st if condition value is '"+MethodExp +"' : :  '"+MethodAct+"'"   );
logger.info("LOG:INFO-  Method List box validation for   :'"+j +"' :  '"+MethodAct+"'" );
logger.pass("Expected Name value is present in Method Listbox  as:   '" + MethodExp +"' Actual Value present in Method Listbox  '"+operatorionAct +"'");

}
else {
	 //logger.info("Expected APP Name value is not present as :   '" + appname +"' Actual Value present in Sailpoint Name '"+Textboxvalue +"'");
	 Assert.assertFalse(operatorionExp.equals(MethodAct));
    System.out.println("Entered in 2nd if condition value is '"+MethodExp +"' : :  '"+MethodAct+"'"   );
  logger.info("LOG:INFO-   Method List box validation for   :'"+j +"' :  '"+MethodAct+"'" );
 
	  logger.fail("Expected  Name value is not present in  Method listbox  as :   '" + MethodExp +"' Actual Value present in Method Listbox   '"+MethodAct +"'");
}


	 
	
	
	WebElement backbutton = driver.findElement(By.xpath("//span[.='Back']"));
		backbutton.click();
		
	
	*/
	
	
	
	   
    	}
    	
	}
	catch(Exception e) {
		e.getMessage();
	
	
	}
	
	
	
}

	
	
	
	public void ConnectionTest(String textvalue,ExtentTest logger) throws Exception {
		
		
		Helper.click(driver, lnconfig,"Click On Configuration tab ",logger);
		Thread.sleep(2000);
		Helper.click(driver, lnsettingcon,"Click On setting  tab ",logger);
		Thread.sleep(2000);
		
		Helper.scrolldown(driver, btntesc, "Scroll Down", logger);
    	
		Helper.waitForWebElementAndClick(driver, testconnect, "Click On TestConnection  button",logger);
    	Thread.sleep(20000);
        Helper.gettextvalue(driver, testsucceful, textvalue, "Testconnection is Succesfully message is displayed", logger);
    	
    	
		
	}
	
	
	
	
    }
    
  
    





