package SailpointPageobject;

import java.io.FileInputStream;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import utili.ExcelDataProvider;
import utili.Helper;

public class ProvisioningManageUserAccess extends BaseClass {
	
	WebDriver driver;

	   
    public ProvisioningManageUserAccess(WebDriver ldriver)
    {
        this.driver=ldriver;


    }
    
    public static By linthreedot = By.xpath("//i[@class='fa fa-list-ul fa-lg']");
    public static By linmanageacces = By.xpath("//span[contains(.,'Manage Access')]");
    public static By linmangeuseracces = By.xpath ("//a[normalize-space()='Manage User Access']");
    public static By btnusersrch = By.xpath("//button[@id='userSearchBtn']");
    public static By btnidentifselect = By.xpath("//button[@class='btn btn-sm btn-rounded v-middle m-r-sm ng-isolate-scope btn-white']/i[@class='fa fa-check']");
    public static By btnfstnext = By.xpath("//span[.='Next']");
    public static By btnfilter = By.xpath("//button[@id='itemsFilterBtn']/span[@class='ng-binding']");
    public static By lssearchedapplication = By.xpath("//ul[@class='dropdown-menu ng-isolate-scope']//a");
    public static By btnfilterapply = By.xpath("//button[@id='itemsFilterPanelApplyBtn']");
    public static By txtusersearchtext = By.xpath("//input[@id='userSearchText']");
    public static By txtEntitlementApplication = By.xpath("(//input[@id='itemsFilterPanelItem1'])[1]");
    
    
    public static By btngrpselect = By.xpath("//button[@aria-label='AD-Cora-Processor']//i[@role='presentation']");
    public static By btnnextgroup = By.xpath("//i[@class='fa fa-chevron-right']");
    
    public static By btnbackgroup = By.xpath("//i[@class='fa fa-chevron-left']");
    
    public static By btnnextadgroup = By.xpath("//button[@id='accessRequestFooterNextBtn']");
    public static By btnsubmitadgroup = By.xpath("//button[@id='submitBtn']");
    
  
    
    public static final  String taskxpath = "//div[@class='list-result-container ng-isolate-scope']//div[@class='panel-heading bg-light lter']//div//strong";
	
    public static final String taskgrpbutton = "//div[@class='list-result-container ng-isolate-scope']//div[@class='panel-heading bg-light lter']//div//button[@ng-click='handleClick()']";
    public static final String taskgrpbutton2 = "//div[@class='list-result-container ng-isolate-scope']//div[@class='panel-heading bg-light lter']//div//button[@ng-click='handleClick()']";
    
    
    public static final String btnapply = "//button[@id='itemsFilterPanelApplyBtn']";
    public static final String adgroupsmore = "//div[@class='list-result-container ng-isolate-scope']//div[@class='panel-heading bg-light lter']";
    public static  final String  pagenameshowing = "(//span[@class='current-page-info ng-binding'])[2]";
    
	
    public void ManageUserProvision(  ExtentTest logger) throws Exception
    {
    	Thread.sleep(3000);
    	Helper.click(driver, linthreedot,"Click On Three Dots Button link ",logger);
    	
    	Helper.click(driver, linmanageacces,"Click On Manage Access  link ",logger);
    	Thread.sleep(3000);
    	
    	Helper.click(driver, linmangeuseracces,"Click On Manage User Access link ",logger);
    	Thread.sleep(5000);
    }
    
    public void EntertheUserDetailsProvision( String Useridforpro, ExtentTest logger) throws Exception
    {
    	Helper.EnterText(driver, txtusersearchtext, Useridforpro, "Enter the Userid in Search User Box", logger);
    	Thread.sleep(4000);
    	Helper.click(driver, btnusersrch,"Click On Search button in Search user box ",logger);
    	
    	Thread.sleep(90000);
    	
    	Helper.click(driver, btnidentifselect,"Click On Select the UserID after search result ",logger);
    	Thread.sleep(3000);
    	
    	Helper.click(driver, btnfstnext,"Click On Next Button After Selected User ID ",logger);
    	
    	Thread.sleep(5000);
    	
    	
    }
    
    public void SearchEntitlementApplication(String Appname,ExtentTest logger) throws Exception {
    	
    	Helper.click(driver, btnfilter,"Click On Search Access Filter ",logger);
    	Thread.sleep(3000);
    	//Helper.scrolldown(driver, btnapply, "Scroll Down", logger);
    	//Thread.sleep(2000);
    	Helper.EnterText(driver, txtEntitlementApplication, Appname, "Enter the Entitlement Application Name ", logger);
    	Thread.sleep(4000);
    	Helper.click(driver, lssearchedapplication,"Click On Searched Entitlement Application  ",logger);
    	Thread.sleep(5000);
    	Helper.click(driver, btnfilterapply,"Click On Searched Entitlement Application  ",logger);
    	Thread.sleep(3000);
    }
    

    public void SelectadGroupfrmEntitlementApp2(ExtentTest logger) {
    		
    		try {
    			
    			FileInputStream fs =new FileInputStream(Filepath);
    	    	HSSFWorkbook ExcelWorkbook =new HSSFWorkbook(fs);
    	    	HSSFSheet Excelsheet  = ExcelWorkbook.getSheet("Provisioning");
    	    	int lastrow = Excelsheet.getLastRowNum();
    	    	String addgroup = null;
    	    
    	    	
    	    	for (int j=1;j<=lastrow;j++) {

    	    		System.out.println("iteration in ::"+ j);
    	    		System.out.println("row  value ::"+ lastrow);
    	    		
    	    		addgroup = ExcelDataProvider.getInputData("Provisioning","AdGroupApp", j);
    	    		
    	    		System.out.println("Group name frm excl"+addgroup);
    	    		
    	    		String[] grouparray = addgroup.split(","); 
    	    		String grp ;
    	    		int arylen =grouparray.length;
    	    		System.out.println("Array lenght::"+arylen);
    	    		
    	    		for(int i=0; i<=arylen; i++)  
    	    			
    	    		{  
    	    		 grp = grouparray[i];
    	    			
    	    		System.out.println("Text from sheet"+grouparray[i]); 
    	    		List<WebElement> ele = driver.findElements(By.xpath(taskxpath));
    	    		List<WebElement> taskgrpele = driver.findElements(By.xpath(taskgrpbutton));
    	    		
    	    		
    	    		int gbtn = taskgrpele.size();
    	    		 System.out.println( "button size" + gbtn);
    	    		 
    	    		
    	    		 int ss = ele.size();
    	    		 System.out.println( "ele size" + ss);
    	    		 
    	    		 
    	    		for (WebElement tss : taskgrpele)
    	    		 //for (int k =1;k<=gbtn;k++)
    	    		{
    	    			//WebElement grupele =ele;
    	    			
    	    			String tasks = tss.getAttribute("aria-label");
        	        	System.out.println("Testx value :: " +tasks);
        	        	System.out.println("group value :: " +grp);
        	        	
        	        	if (tasks.equalsIgnoreCase(grp)) {
        	        		By btngrpselect1 = By.xpath("//button[@aria-label='" + grp + "']//i[@role='presentation']");
            	    		
            	    		Helper.click(driver, btngrpselect1,"Click On Searched Group name  ",logger);
            	    		//grp = grouparray[i+1];
            	    		//System.out.println("grp+1"+grp);
        	        		//break;
        	        		
        	        		
        	        	}
        	        	
    	    		
    	    		}
    	    		}
        	        	
        	        		 System.out.println("Entered else ");
        	        		 
        	        		 String Pagenumber = driver.findElement(By.xpath(pagenameshowing)).getText();    //input string
            	    		 int pagesize =Pagenumber.length();
            	    		 System.out.println("Page Name::"+Pagenumber);
            	    		 System.out.println("Page number::"+pagesize);
            	    		 
            	    		 String pagenum = "";     
            	    		  
            	    		 if (Pagenumber.length() > 17) 
            	    		 {
            	    		     pagenum = Pagenumber.substring(Pagenumber.length() - 2);
            	    		     System.out.println("page num gr ::" +pagenum);
            	    		 } 
            	    		 else
            	    		 {
            	    			 pagenum = Pagenumber.substring(Pagenumber.length() - 1);
            	    			 System.out.println("page num less ::" +pagenum);
            	    		 }
            	    		  
            	    	int pgnumgr = Integer.parseInt(pagenum);
            	    		
        	        		 
        	        		 if (pgnumgr>12) {
        	        			 
        	        			 for ( int m =0;m<=arylen;m++) {
        	        			 String grp2 = grouparray[m];
        	    	    			
        	     	    		System.out.println("Text from sheet"+grouparray[m]); 
        	     	    		
        	        			 
        	        			 Helper.click(driver, btnnextgroup,"Click On Next Group name  ",logger);
        	        			 Thread.sleep(8000);
        	        			 List<WebElement> taskgrnextpage = driver.findElements(By.xpath(taskgrpbutton2));
        	     	    		
        	     	    		
        	     	    		int gbtnext = taskgrnextpage.size();
        	     	    		 System.out.println( "button size next page" + gbtnext);
        	     	    		 
        	     	    		for (WebElement nexte : taskgrnextpage)
        	       	    		 //for (int k =1;k<=gbtn;k++)
        	       	    		{
        	       	    			//WebElement grupele =ele;
        	       	    			
        	       	    			String tasksnext2 = nexte.getAttribute("aria-label");
        	           	        	System.out.println("Testx2 value :: " +tasksnext2);
        	           	        	System.out.println("grop2 value :: " +grp2);
        	           	        	
        	           	        	
        	           	        	if (tasksnext2.equalsIgnoreCase(grp2)) {
        	           	        		By btngrpselect2 = By.xpath("//button[@aria-label='" + grp2 + "']//i[@role='presentation']");
        	               	    		
        	               	    		Helper.click(driver, btngrpselect2,"Click On Searched Group name  ",logger);
        	           	        		
        	               	    		Helper.click(driver, btnbackgroup,"Click On Back button name  ",logger);
        	           	        	}
        	           	        	
        	       	    		}
        	        			 
        	        		 }
        	        		 }
        	        		//btnbackgroup
        	        		//Helper.click(driver, btnnextgroup,"Click On Next Group name  ",logger);
        	        		
        	        	//}
    	    			
    	    	//	}
    	        
    	    		
    	    		
    	    		
    	    
    	    		
    	    		//} 
    	    		
    	    		
    	    
    	    	}
    	
    		}
    		catch(Exception e) {
    			e.getMessage();
    		
    		
    		}
    	    	
    	    	}


public void SelectadGroupfrmEntitlementApp(ExtentTest logger) {
	
	try {
		
		FileInputStream fs =new FileInputStream(Filepath);
    	HSSFWorkbook ExcelWorkbook =new HSSFWorkbook(fs);
    	HSSFSheet Excelsheet  = ExcelWorkbook.getSheet("Provisioning");
    	int lastrow = Excelsheet.getLastRowNum();
    	String addgroup = null;
    
    	
    	for (int j=1;j<=lastrow;j++) {

    		System.out.println("iteration in ::"+ j);
    		System.out.println("row  value ::"+ lastrow);
    		
    		addgroup = ExcelDataProvider.getInputData("Provisioning","AdGroupApp", j);
    		
    		System.out.println("Group name frm excl :::"+addgroup);
    		
    		String[] grouparray = addgroup.split(","); 
    		String grp ;
    		int arylen =grouparray.length;
    		System.out.println("Array lenght::"+arylen);
    	
    		 String showinggrp = driver.findElement(By.xpath(pagenameshowing)).getText();   
    		 int showiggrpsize =showinggrp.length();
    		 System.out.println("Page Name::"+showinggrp);
    		 System.out.println("Page number::"+showiggrpsize);
    		 
    		 String totalgrp = "";     
    		  
    		 if (showinggrp.length() > 18) 
    		 {
    			 totalgrp = showinggrp.substring(showinggrp.length() - 2);
    		     System.out.println("page num gr ::" +totalgrp);
    		 } 
    		 else if (showinggrp.length() > 17) 
    		 {
    			 totalgrp = showinggrp.substring(showinggrp.length() - 2);
    		     System.out.println("page num gr ::" +totalgrp);
    		 } 
    		 else 
    		 {
    			 totalgrp = showinggrp.substring(showinggrp.length() - 1);
    			 System.out.println("page num less ::" +totalgrp);
    		 }
    		  
    		int totalpspagenum ;
    	int totaladgrps = Integer.parseInt(totalgrp);
    	
    	int dividend = totaladgrps, divisor = 12;
    	  
        int quotient = dividend / divisor;
        int remainder = dividend % divisor;
        
        if (remainder==0) {
        	
        	
        	totalpspagenum= quotient ;
            System.out.println("The total page possible = " + totalpspagenum);
        	
        }
        else {
        	
        	totalpspagenum= quotient +1;
            System.out.println("The total page possible = " + totalpspagenum);
        	
        }
  
        System.out.println("The Quotient is = " + quotient);
        System.out.println("The Remainder is = " + remainder);
        System.out.println("The total page possible = " + totalpspagenum);
        
    	//for (int p =1;p<=totalpspagenum;p++) {
    		
    		
    		for(int i=0; i<=arylen; i++)  
    			
    		{  
    		 grp = grouparray[i];
    		 System.out.println("Arraylen::" +arylen);
    			System.out.println("iter::" +i); 
    			System.out.println("Textgrp frm excel::" +grp); 
    		
    	WebElement active_page = driver.findElement(By.xpath("//div[@id='accessItemPager']//li/span"));
    	String pg = active_page.getText();
    	//System.out.println("Active page" +pg); 

    		List<WebElement> taskgrpele = driver.findElements(By.xpath(taskgrpbutton));

    		int gbtn = taskgrpele.size();
    		 System.out.println( "button size" + gbtn);

    		 for (WebElement tss : taskgrpele)
    	    		
     		{
     			String tasks = tss.getAttribute("aria-label");
 	        	System.out.println("Test from page value :: " +tasks);
 	        	System.out.println("group from sheet value :: " +grp);
 	        	if (tasks.equalsIgnoreCase(grp)) {
 	        		
 	        		System.out.println("group are equal  :: " +grp);
 	        		System.out.println("page value grp value :: " +tasks);
 	 	        	
	        		By btngrpselect1 = By.xpath("//button[@aria-label='" + grp + "']//i[@role='presentation']");
    	    		
    	    		Helper.click(driver, btngrpselect1,"Click On Searched Group name  ",logger);
    	    		
    	    		System.out.println("group selected :"+grp);
    	    		//break;
    	    		
	        	}
     		}
    		 

    		//}
    	
    		
      		//Helper.click(driver, btnnextadgroup,"Click On Nextbutton from add group page  ",logger);
      		//Thread.sleep(3000);
    		
    		//Helper.click(driver, btnsubmitadgroup,"Click On Nextbutton from add group page  ",logger);
    		
    		
    		
    		//String pagneno = Integer.toString(p+1);
     		//System.out.println("Pagenuner::"+pagneno);
     		
     		//driver.findElement(By.xpath("//div[@id='accessItemPager']//li//span[normalize-space()='" +pagneno+"']")).click();

    	
    	}
	        		
    		
    
    	}
    		

	}
	catch(Exception e) {
		e.getMessage();
	
	
	}
    	
    	}



public void Netxbutsubmitbtnaddgrp(ExtentTest logger) throws Exception {
	
	System.out.println("netxbutton");
	Helper.click(driver, btnnextadgroup,"Click On Nextbutton from add group page  ",logger);
	Thread.sleep(3000);
	
	
	Helper.click(driver, btnsubmitadgroup,"Click On Nextbutton from add group page  ",logger);
	Thread.sleep(6000);
	
}

}






