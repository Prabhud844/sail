package SailpointPageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class applicationDefinition {
	
	WebDriver driver;
	
	By liapplications = By.xpath("//*[@class='header bg-primary navbar']/ul[1]/li[5]/a[1]");
	By lnAppdefinition = By.xpath("//a[@role='menuitem'][normalize-space()='Application Definition']");
	By txtsearchapp = By.xpath("//input[@id='searchfield-1025-inputEl']");
	By btnsearch = By.xpath("//div[@id='ext-gen1099']");
	By srchresult = By.xpath("//div[normalize-space()='InContactWMUS']");
	
	
	
	public applicationDefinition(WebDriver driver) {
		
		this.driver =driver;
		
		
	}
	
	
	public void applink() {
		driver.findElement(liapplications).click();
	}
	public void appdefintion() {
		driver.findElement(lnAppdefinition).click();;
		
	}
	
	public void appserach(String appsrch) {
		driver.findElement(txtsearchapp).sendKeys(appsrch);
	}
	
	public void btnsearch () {
		driver.findElement(btnsearch).click();

}
	
	public void srchresult() {
		driver.findElement(srchresult).click();
		
	}



}
