package SailpointPageobject;


import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import utili.MailUtil;
import utili.LoggerUtil;
import utili.TestProperties;
import utili.LogListener;
import utili.ReportListener;
import utili.BrowserFactory;
import utili.ConfigDataProvider;
import utili.ExcelDataProvider;
import utili.Helper;
import utili.ReadConfig;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.*;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

//@Listeners({ ReportListener.class, LogListener.class })

public class BaseClass {
	public final static String Filepath = "C:\\Users\\vn52odq\\Sailpoint\\SailpointTesting\\TestData\\TestData.xls";

    public WebDriver driver;
    public ExcelDataProvider excel;
    public ConfigDataProvider config;
    public ExtentReports report;
    public ExtentTest logger;
    String reportPath;
   
    
    //ReadConfig readconfig = new ReadConfig();
    public static Logger loggers;

    @BeforeSuite
    public void setUpSuite()
    {
    	LoggerUtil.log("************************** Test Execution Started ************************************");
		TestProperties.loadAllPropertie();
    	loggers = Logger.getLogger("Sailpoint");
		PropertyConfigurator.configure("log4j.properties");
		
		

        Reporter.log("Setting up reports and Test is getting ready", true);

        excel = new ExcelDataProvider();
        config = new ConfigDataProvider();

        reportPath=System.getProperty("user.dir")+"/Reports/VA_"+Helper.getCurrentDateTime()+".html";

        ExtentHtmlReporter extent=new ExtentHtmlReporter(new File(reportPath));
        report=new ExtentReports();
        report.attachReporter(extent);

        Reporter.log("Setting Done- Test can be started", true);
    }

    @Parameters({"executionBrowser","appURL"})
    @BeforeClass
    public void setup(String browser,String url)
    //public void setup()
    {
    	loggers = Logger.getLogger("Sailpoint");
		PropertyConfigurator.configure("log4j.properties");


        Reporter.log("Trying to start Browser and Getting application ready", true);

       // driver = BrowserFactory.startApplication(driver, config.getBrowser(), config.getStagingURL());
        
       
        driver = BrowserFactory.startApplication(driver, browser,url);

        Reporter.log("Browser and Application is up and running", true);

    }

    @AfterClass
    public void tearDown() {
        //BrowserFactory.quitBrowser(driver);
    }

    @AfterMethod
    public void tearDownMethod(ITestResult result) throws IOException
    {
        Reporter.log("Test is about to end ", true);


        if (result.getStatus() == ITestResult.FAILURE)
        {
            logger.fail("Test Failed ", MediaEntityBuilder.createScreenCaptureFromPath(Helper.captureScreenshot(driver)).build());
        }
        else if(result.getStatus()==ITestResult.SUCCESS)
        {
            logger.pass("Test passed ", MediaEntityBuilder.createScreenCaptureFromPath(Helper.captureScreenshot(driver)).build());

        }

        report.flush();

        Reporter.log("Test Completed >>> Reports Generated", true);

        Reporter.log("Report can be accessed via >>> "+reportPath,true);

    }
    /*@AfterSuite()
    public void wrapAllUp(ITestContext context) {
		int total = context.getAllTestMethods().length;
		int passed = context.getPassedTests().size();
		int failed = context.getFailedTests().size();
		int skipped = context.getSkippedTests().size();
		LoggerUtil.log("Total number of testcases : " + total);
		LoggerUtil.log("Number of testcases Passed : " + passed);
		LoggerUtil.log("Number of testcases Failed : " + failed);
		LoggerUtil.log("Number of testcases Skipped  : " + skipped);
		boolean mailSent = MailUtil.sendMail(total, passed, failed, skipped);
		LoggerUtil.log("Mail sent : " + mailSent);
		LoggerUtil.log("************************** Test Execution Finished ************************************");

    }*/
    
    
    public String captureScreen() throws IOException {
    	TakesScreenshot screen = (TakesScreenshot) driver;
    	File src = screen.getScreenshotAs(OutputType.FILE);
    	String dest ="C://Users//vn52odq//Sailpoint//SailpointTesting//Screenshots//"+getcurrentdateandtime()+".png";
    	File target = new File(dest);
    	FileUtils.copyFile(src, target);
    	return dest;
    	
    
    }
    public	String getcurrentdateandtime(){
    		String str = null;
    		try{
    		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss:SSS");
    		Date date = new Date();
    		str= dateFormat.format(date);
    		str = str.replace(" ", "").replaceAll("/", "").replaceAll(":", "");
    		}
    		catch(Exception e){

    		}
    		return str;
    		}
    		}
    	

