package SailpointPageobject;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import utili.Helper;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class TaskSearchinsetup extends BaseClass  {



    WebDriver driver;

   
    public TaskSearchinsetup(WebDriver ldriver)
    {
        this.driver=ldriver;


    }

    //  //input[@id='tasksSearchField-inputEl']
    
    //Application Definition page UI elements
    public static By  txttaskbox =By.xpath("//input[@placeholder='Search by Task Name']");
    
    @FindBy(xpath="(//a[@role='menuitem'])[22]") WebElement lsetup;
    @FindBy(xpath = "//a[@role='menuitem'][normalize-space()='Tasks']")WebElement lntask;
    //@FindBy(xpath="(//input[@placeholder='Search by Task Name']") WebElement txttaskbox;
    //@FindBy(xpath="(//div[@role='button'])[2]") WebElement btntasksearch;
    //public static final String txttaskbox ="//input[@placeholder='Search by Task Name']";
    public static final String taskserchresultcheck = "//div[@id='gridview-1026']//tbody//tr";
    public static  By btntasksearch = By.xpath("(//div[@role='button'])[2]");
    public static final String scroldowntaskpge = "//span[normalize-space()='Save and Execute']";
    public static By btntasksaveandexecute= By.xpath("//span[normalize-space()='Save and Execute']");
    public static By btnOKaftrsaveandexecute = By.xpath("//span[@id='button-1013-btnInnerEl']");
    public static By lntaskresult = By.xpath("//span[@id='tab-1091-btnInnerEl']");
    public static By txttaskresulttextbox = By.xpath("//input[@id='resultsSearchField-inputEl']");
    public static By btntaskresultDatepicker = By.xpath("(//div[@role='button'])[7]");
    public static By btntaskresultdatetoday = By.xpath("(//span[normalize-space()='Today'])[1]");
    public static By btntaskresulsearchfinal = By.xpath("//span[normalize-space()='Search']");
    public static By textstatustaskresult = By.xpath("//div[@class='textBold successBox']");
    //public static By textprogresstaskresult = By.xpath("(//div[normalize-space()='Completed']");
    
    
    
    
    
    
    
    
    public void ApplicationSearch(ExtentTest logger) throws IOException, InterruptedException
    {
    	Helper.waitForWebElementAndClick(driver, lsetup, "Click On Setup Link to Run Task ",logger);
    	
    	Helper.waitForWebElementAndClick(driver, lntask, "Click On Task  Link in Setup link ",logger);
    	
    	Thread.sleep(5000);
    	////Helper.waitForWebElementAndType(driver,txttaskbox,task,"Enter Task details",logger);
    	//Helper.waitForWebElementAndClick(driver, btnsearch, "Click On Search  button",logger);
        //logger.log(Status.PASS, "Sailpoint App Name"+logger.addScreenCaptureFromPath(captureScreen()));
        
        //
    	
    
    }
    
public  void entertaskintextbox(String task,ExtentTest logger) throws Exception {
    
	
	Helper.EnterText(driver, txttaskbox, task, "Enter the Task Name in Search txt Box", logger);
	
	
	Helper.click(driver, btntasksearch,"Task search button clicked ",logger);
	
	//driver.findElement(By.xpath(btntasksearch)).click();
	
	//logger.log(Status.PASS, "Sailpoint App Name"+logger.addScreenCaptureFromPath(captureScreen()));
    
	
    }
	
   public void taskselectsearchresult (String taskaccount, ExtentTest logger) throws IOException  {
	   //String taskaccount ="InContactWMUS Full Account Aggregation Task";
		int r = driver.findElements(By.xpath("//div[@id='gridview-1026']//tbody//tr")).size();
	
System.out.println("Row value ::" +r);

for ( int i =1; i<=3;i++)
{
	String task = driver.findElement(By.xpath("//div[@id='gridview-1026']//tbody//tr[" + i + "]")).getText();
	
	System.out.println("TaskValue in table ::" + task);
	
	if (task.contains(taskaccount)) {
		System.out.println("Loop entered");
		
		 driver.findElement(By.xpath("//div[@id='gridview-1026']//tbody//tr[" + i + "]")).click();
		logger.log(Status.PASS, "Task Searched and selected  ");
		    
		 break;
	}
	
	else {
		logger.log(Status.FAIL, "Task  is  selected  from search result ");
		
		
	}
}

   }

public void scrolldownpage (ExtentTest logger) {
	Helper.scrolldown(driver, scroldowntaskpge, "Scroll to Task Page to execute", logger);
}
   
  public void executetask(ExtentTest logger) throws Exception {
	  Helper.click(driver, btntasksaveandexecute,"Click on Task Save and Execute button  ",logger);
	  Thread.sleep(3000);
	  Helper.click(driver, btnOKaftrsaveandexecute,"Click on  OK button  after Save and execute",logger);
	  Thread.sleep(3000);
	  Helper.click(driver, lntaskresult,"Click on  Task Result tab",logger);
	  Thread.sleep(3000);
	  
	  
  }
  
  public void enterTaskinTaskresult(String taskaccount, ExtentTest logger) throws Exception {
	  Helper.EnterText(driver, txttaskresulttextbox, taskaccount, "Enter the Task Name in Search txt Box", logger);
	  Thread.sleep(5000);
	  Helper.click(driver, btntaskresultDatepicker,"Click on  DatePicker button",logger);
	  Thread.sleep(10000);
	  Helper.click(driver, btntaskresultdatetoday,"Click on  DatePicker Today button",logger);
	  Thread.sleep(15000);
	  Helper.click(driver, btntaskresulsearchfinal,"Click on  Task Search final button",logger);
	  Thread.sleep(12000);
	  Helper.click(driver, btntaskresulsearchfinal,"Click on  Task Search final button",logger);
	  //Thread.sleep(12000);
	  	
  }
  
  
  
public void taskresultselectedtochecck(String taskaccount, ExtentTest logger) {
	

	int c = driver.findElements(By.xpath("//div[@id='gridview-1069']//tbody/tr/td")).size();
	
	System.out.println("columns value ::" +c);
	
	
	
	
	for ( int j =1; j<=3;j++)
	{
		String taskresult = driver.findElement(By.xpath("//div[@id='gridview-1069']//tbody/tr/td[" + j + "]")).getText();
		
		System.out.println("TaskValue in table ::" + taskresult);
		
		if (taskresult.contains(taskaccount)) {
			System.out.println("Loop entered 2");
			
			 driver.findElement(By.xpath("//div[@id='gridview-1069']//tbody/tr/td[" + j + "]")).click();
			 logger.log(Status.PASS, "Task Status  is   selected from Task Result  ");
			    
			 break;
		}
		
		else {
			logger.log(Status.FAIL, "Task Status not  is  selected  from Task result ");
			
	}
	
}
  
   
}

public   void taskresultvalidation(String sucess,ExtentTest logger) {
	Helper.gettextfromweb(driver, textstatustaskresult,sucess, "Task Status check validation in task result", logger);
	
	//Helper.gettextfromweb(driver, textprogresstaskresult,progess, "Task progress check validation in task result", logger);
	
}






}

