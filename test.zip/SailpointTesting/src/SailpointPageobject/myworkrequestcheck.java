package SailpointPageobject;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import utili.Helper;

public class myworkrequestcheck extends BaseClass {
	
	WebDriver driver;

	   
    public myworkrequestcheck(WebDriver ldriver)
    {
        this.driver=ldriver;


    }
    
    public static By linmywork = By.xpath("//ul[@class='nav navbar-nav navbar-left']/li[3]/a[@href='#']");
    public static By linworkitems = By.xpath("(//a[@target='_self'][normalize-space()='Work Items'])[1]");
    public static By btnfilterwrkitm = By.xpath ("//span[@class='hidden-xs hidden-sm ng-binding']");
    public static By lndropdwnselectreq = By.xpath ("//ul[@class='dropdown-menu ng-isolate-scope']//li//a");
    public static By lndropdwnselectowner = By.xpath ("//ul[@class ='dropdown-menu ng-isolate-scope']//li[@class='ng-scope active']");
  
    
    public static By btnapplywrkit = By.xpath ("(//button[normalize-space()='Apply'])[1]");
    public static By btnforward = By.xpath (" //section[@id='cardList']/section[1]//i[@class='fa fa-share']");
    public static By lndropfrwdreqselct = By.xpath("//li[@class='ng-scope active']//a");
    public static By btnforwardselec = By.xpath("//button[normalize-space()='Forward']");
    public static By btnnotificationicon = By.xpath("//i[@class='fa fa-bell fa-lg']");
    public static By btnapproval = By.xpath("//span[.='Approvals']");
    public static By btapprovallgroup = By.xpath("//button[contains(.,'Approve All')]");
    
    public static By btnapprovalcomplete = By.xpath("//button[@class='btn  btn-info btn-default']");
    
 
  
    
    public static final  String  workitemlist = "//section[@id='cardList']/section//div//span[@ng-if='!expanded']";
    public static By txtrequester = By.xpath("(//input[@id='cardListFilterPanelItem1'])[1]");
    public static By txtowner = By.xpath("//input[@id='workitem_owner_id']");
    public static By txtforwardrequester = By.xpath("//input[@id='ownerNameSuggestBoxWorkItemListForward']");
    public static By txtforwardcomments = By.xpath("//textarea[@id='forwardCommentBox']");
    
	
    public void myworksearch(  ExtentTest logger) throws Exception
    {
    	Thread.sleep(3000);
    	Helper.click(driver, linmywork,"Click On My Work Tab ",logger);
    	Thread.sleep(3000);
    	Helper.click(driver, linworkitems,"Click On Workitem link ",logger);
    	
    	Thread.sleep(3000);
    	Helper.click(driver, btnfilterwrkitm,"Click On Workitemfilter button ",logger);
    }
    
    

    public void Searchworkitemid(String RequesterName,String owner,ExtentTest logger) throws Exception {
    	
    	Helper.EnterText(driver, txtrequester, RequesterName, "Enter the RequesterName  ", logger);
    	Thread.sleep(4000);
    	
    	Helper.click(driver, lndropdwnselectreq,"Click On drop down requester  ",logger);
    	
    	Thread.sleep(5000);

    	Helper.EnterText(driver, txtowner, owner, "Enter the Ownername  ", logger);
    	Thread.sleep(4000);
    	
    	Helper.click(driver, lndropdwnselectowner,"Click On drop down requester  ",logger);
    	
    	Helper.click(driver, btnapplywrkit,"Click On apply   ",logger);
    	Thread.sleep(5000);
    	
    }
    
    
    public void workitemiternation(String username,String RequesterName,ExtentTest logger) throws Exception {
    	
    	List<WebElement> workitemlst = driver.findElements(By.xpath(workitemlist));
		
		
		int wrknum = workitemlst.size();
		 System.out.println( "workitem available" + wrknum);
		 
    	for (int i =1;i<=wrknum;i++) {
    		
    		WebElement wrkit = driver.findElement(By.xpath(" //section[@id='cardList']/section[" + i + "]//div//span[@ng-if='!expanded'] "));
    		System.out.println("workxpath::"+wrkit); 
    		
    		String wrkitemusername = wrkit.getText();
    		 
    		//Manager Approval - Account Changes for User: Annette Knight
    		
    		String managerapproval = "Manager Approval - Account Changes for User: ";
    		 String fullownername = managerapproval + username;
    		 System.out.println(" Full name ::" +fullownername);
    		
    		
    		System.out.println(" wrkitem name ::"+wrkitemusername);
    		
    		String[] usernamewrkit = wrkitemusername.split(":"); 
    		String usname ;
    		
    		usname = usernamewrkit[1].trim();
    		
    		System.out.println("username::"+usname);
    		
    		if (fullownername.equalsIgnoreCase(wrkitemusername)) {
    			
    			System.out.println("Username equal page::"+ wrkitemusername);
    			System.out.println("Username equal parameter::"+ fullownername);
    			
    			WebElement wrki = driver.findElement(By.xpath("//section[@id='cardList']/section[" + i + "]//div//span//div[@class='inline work-item-card-column-data ng-scope']//sp-column-data//span[@ng-if='columnDataCtrl.isFilter()'] "));
    			
    			System.out.println("workitemxpath::"+wrki); 
    			String wrokitem = wrki.getText();
    			
    			System.out.println("workitemid::"+wrokitem);
    			

        		 By btnforwardowner = By.xpath (" //section[@id='cardList']/section[" + i + "]//i[@class='fa fa-share']");
        		
    			Helper.click(driver, btnforwardowner,"Click On forward button   ",logger);
    	    	Thread.sleep(5000);
    	    	
    	    	
    	    	Helper.EnterText(driver, txtforwardrequester, RequesterName, "Enter the Forward RequesterName  ", logger);
    	    	Thread.sleep(4000);
    	    	
    	    	Helper.click(driver, lndropfrwdreqselct,"Click On forward Requestername from list   ",logger);
    	    	Thread.sleep(5000);
    	    	
    	    	Helper.EnterText(driver, txtforwardcomments, "test", "Enter the Forward RequesterName  ", logger);
    	    	Thread.sleep(4000);
    	    	
    	    	Helper.click(driver, btnforwardselec,"Click On forward button   ",logger);

    	    	
    	    	break;
    	
    	
    		}
    		
    		else {
    			System.out.println("Username else equal page"+ usname);
    			System.out.println("Username else equal parameter"+ username);
    			
    			
    		}
    		
    	}
    	
    	
    }
    
    
    public void notificationsearch(  ExtentTest logger) throws Exception
    {
    	Thread.sleep(3000);
    	Helper.click(driver, btnnotificationicon,"Click On Notification icon ",logger);
    	Thread.sleep(3000);
    	Helper.click(driver, btnapproval,"Click On Workitem link ",logger);
    	Thread.sleep(4000);
    	Helper.click(driver, btapprovallgroup,"Click On Approval All button ",logger);
    	Thread.sleep(3000);
    	Helper.click(driver, btnapprovalcomplete,"Click On Approval All button ",logger);
    	
    	
    } 
   
    

   
    
    
    
public void workitemiternationsecondapprove(String username,String RequesterName,String owner,ExtentTest logger) throws Exception {
    	
	 
		String ownerapproval = "Owner Approval - Account Changes for User: ";
		 String fullownername = ownerapproval + username;
		 System.out.println(" Full name ::" +fullownername);
		String ownerlist ="//span[@class='ng-binding ng-scope'][contains(text(),'" + fullownername + "')]";
		 System.out.println(" ownerlist name ::" +ownerlist);
    	List<WebElement> ownerlistitem = driver.findElements(By.xpath(ownerlist));
		 
    	
		
		int ownerwrk = ownerlistitem.size();
		 System.out.println( "workitem available" + ownerwrk);
		 
    	for (int i =1;i<=ownerwrk;i++) {
    		System.out.println("Iteration loop ::"+i); 
    		
    		WebElement wrki = driver.findElement(By.xpath("//section[@id='cardList']/section[" + i + "]//div//span//div[@class='inline work-item-card-column-data ng-scope']//sp-column-data//span[@ng-if='columnDataCtrl.isFilter()'] "));
				
				//System.out.println("workitemid::"+wrki); 
				String wrokitem = wrki.getText();
				
				System.out.println("workitemid above if loop::"+wrokitem);
    		
    		WebElement wrkit = driver.findElement(By.xpath(" //section[@id='cardList']/section[" + i + "]//div//span[@ng-if='!expanded'] "));
    		//System.out.println("workxpath::"+wrkit); 
    		
    		
    		String wrkitemusername = wrkit.getText();
    		
    		System.out.println(" wrkitem name above if loop ::"+wrkitemusername);
    			
    			String ownerid = driver.findElement(By.xpath("//section[@id='cardList']/section[" + i + "]//div//span//div[@class='inline work-item-card-column-data ng-scope']//sp-column-data//span[@ng-if='columnDataCtrl.isSimple()'] ")).getText();
    			
    			System.out.println("idowner above if loop::"+ownerid);

    				 String owneridgroups = ownerid;
    	 	        	//System.out.println("Test owner from page value 2nd :: " +owneridgroups);
    	 	        	//System.out.println("Owner from sheet value  2nd:: " +owner);
    	 	        	
    	 	        	
    	 	       	if (owneridgroups.equalsIgnoreCase(owner)) {
    	 	        		
    	 	        		System.out.println("owner are equal  :: " +owner);
    	 	        		System.out.println("page value owner value  :: " +owneridgroups);
    	 	        		System.out.println("workitemid loop::"+wrokitem);
    	 	        		
    	 	        		
    	 	        		System.out.println("Clikced forward button");
    	 	        		
    	 	        		 By btnforwardowner = By.xpath (" //section[@id='cardList']/section[" + i + "]//i[@class='fa fa-share']");
    	 	        		
    	 	    			Helper.click(driver, btnforwardowner,"Click On forward button   ",logger);
    	 	    	    	Thread.sleep(5000);
    	 	    	    	
    	 	    	    	Helper.EnterText(driver, txtforwardrequester, RequesterName, "Enter the Forward RequesterName  ", logger);
    	 	    	    	Thread.sleep(4000);
    	 	    	    	
    	 	    	    	Helper.click(driver, lndropfrwdreqselct,"Click On forward Requestername from list   ",logger);
    	 	    	    	Thread.sleep(5000);
    	 	    	    	
    	 	    	    	Helper.EnterText(driver, txtforwardcomments, "test", "Enter the Forward RequesterName  ", logger);
    	 	    	    	Thread.sleep(4000);
    	 	    	    	
    	 	    	    	Helper.click(driver, btnforwardselec,"Click On forward button   ",logger);
    	 	    	    	Thread.sleep(2000);

    	     		} 
    	 	       	
    	 	       	else {
    	 	       	System.out.println("owner are  not equal  :: " +owner);
 	        		System.out.println("page value owner value  eles:: " +owneridgroups);
 	        		System.out.println("workitemid loop else::"+wrokitem);
    	 	       	}
    	 	        	
    		}
    		
    		
    		
  
	//} 
	
	/*catch(org.openqa.selenium.StaleElementReferenceException ex) {
		
		
	}*/
    	
  //  
}


public void Notificationmanagerapproval(String username,ExtentTest logger) throws Exception {
	
	Thread.sleep(3000);
	Helper.click(driver, btnnotificationicon,"Click On Notification icon ",logger);
	Thread.sleep(3000);
	Helper.click(driver, btnapproval,"Click On Workitem link ",logger);
	Thread.sleep(4000);
	
	 
	String managerapproval = "Manager Approval - Account Changes for User: ";
	 String fullownername = managerapproval + username;
	 System.out.println(" Full name ::" +fullownername);
	String ownerlist ="//strong[@class='ng-binding'][contains(text(),'" + fullownername + "')]";
	 System.out.println(" ownerlist name ::" +ownerlist);
	List<WebElement> ownerlistitem = driver.findElements(By.xpath(ownerlist));
	 
	
	
	int ownerwrk = ownerlistitem.size();
	 System.out.println( "workitem available" + ownerwrk);
	 
	for (int i =ownerwrk;i>0;i--) {
		System.out.println("Iteration loop ::"+i); 
		
		
		
		WebElement wrki = driver.findElement(By.xpath("//section[@class='wrapper bg-light dker ng-scope']/section[" + i + "]//button[contains(.,'Approve All')]"));
			
			//System.out.println("workitemid::"+wrki); 
			String wrokitem = wrki.getText();
			
			System.out.println("workitemid above if loop::"+wrokitem);
			
			wrki.click();
			
			Thread.sleep(3000);
	    	Helper.click(driver, btnapprovalcomplete,"Click On Approval All button ",logger);
	    	
			Thread.sleep(2000);
			
			
	 	        }

}


public void Notificationownerapproval(String username,String RequesterName,String owner,ExtentTest logger) throws Exception {
	
	Thread.sleep(3000);
	Helper.click(driver, btnnotificationicon,"Click On Notification icon ",logger);
	Thread.sleep(3000);
	Helper.click(driver, btnapproval,"Click On Workitem link ",logger);
	Thread.sleep(4000);
	
	 
	String ownerapproval = "Owner Approval - Account Changes for User: ";
	 String fullownername = ownerapproval + username;
	 System.out.println(" Full name ::" +fullownername);
	String ownerlist ="//strong[@class='ng-binding'][contains(text(),'" + fullownername + "')]";
	 System.out.println(" ownerlist name ::" +ownerlist);
	List<WebElement> ownerlistitem = driver.findElements(By.xpath(ownerlist));
	 
	
	
	int ownerwrk = ownerlistitem.size();
	 System.out.println( "workitem available" + ownerwrk);
	 
	for (int i =ownerwrk;i>0;i--) {
		System.out.println("Iteration loop ::"+i); 
		
		
		
		WebElement wrki = driver.findElement(By.xpath("//section[@class='wrapper bg-light dker ng-scope']/section[" + i + "]//button[contains(.,'Approve All')]"));
			
			//System.out.println("workitemid::"+wrki); 
			String wrokitem = wrki.getText();
			
			//System.out.println("workitemid above if loop::"+wrokitem);
			
			wrki.click();
			
			Thread.sleep(3000);
	    	Helper.click(driver, btnapprovalcomplete,"Click On Approval All button ",logger);
	    	
			Thread.sleep(6000);
			
			
			
			Thread.sleep(5000);
			
			if(driver.findElement(By.xpath("//button[normalize-space()='Later']")).isDisplayed()) {
				
				String completedotherexp = "Later";
				WebElement completewrk = driver.findElement(By.xpath("//button[normalize-space()='Later']"));
				String completedwrkact = completewrk.getText().trim();
				
				System.out.println(" wepage actaul :"+completedwrkact);
				
				if (completedotherexp.contains(completedwrkact)) {
					System.out.println("Eter if loop");
					
					Thread.sleep(3000);
					By newpagelaterbtn = By.xpath("//button[normalize-space()='Later']");
					
					Helper.click(driver, newpagelaterbtn,"Click On later button ",logger);
					
					Thread.sleep(3000);
				}
			}
			
			
			
			
			
		
	 	        }

}


public void Searchworkitemidowner(String RequesterName,ExtentTest logger) throws Exception {
	
	Helper.EnterText(driver, txtrequester, RequesterName, "Enter the RequesterName  ", logger);
	Thread.sleep(4000);
	
	Helper.click(driver, lndropdwnselectreq,"Click On drop down requester  ",logger);
	
	Thread.sleep(5000);

	
	Helper.click(driver, btnapplywrkit,"Click On apply   ",logger);
	Thread.sleep(5000);
	
}



}
