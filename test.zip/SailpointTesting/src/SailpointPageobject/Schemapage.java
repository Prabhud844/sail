package SailpointPageobject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import utili.Helper;

public class Schemapage  extends BaseClass {
	
	WebDriver driver;

	   
    public Schemapage(WebDriver ldriver)
    {
        this.driver=ldriver;


    }
    
    public static By lnschema = By.xpath("//span[.='Schema']");
    public static By btnpreviewaccnt = By.xpath("//div[@id='accountSchemaDiv']//input[@class='primaryBtn']");
    public static By btnclosepreviewacc = By.xpath ("//div[@id ='tool-1206']//img");
    public static By btnpreviewgroup = By.xpath("//div[@id='groupSchemaDiv']//input[@class='primaryBtn']");
    public static By btnclosepreviewgroup = By.xpath("//div[@class='x-tool x-box-item x-tool-default']//img[@class='x-tool-close']");
    
    public static final String txtpreviewgrouptitle = "(//span[@id='connectorDebug-group_header_hd-textEl'])[1]";
    public static final String txtpreviewaccnttitle = "//span[@id='connectorDebug-account_header_hd-textEl']";
    public static  final String  txtaccnativeobjtyp = "(//input[@name='editForm:j_idt561:0:j_idt575'])[1]";
    public static  final String  txtaccdisplyattribut = "(//input[@name='editForm:j_idt561:0:j_idt605'])[1]";
    public static  final String  txtaccideityatrri = "(//input[@name='editForm:j_idt561:0:j_idt579'])[1]";
    public static  final String  tableaccount = "//div[@id='accountSchemaDiv']//tr";
    public static final String tablepreviewaccount = "//div[@id='gridview-1205']/table//tbody/tr";
    public static final String btnpreviewgroupdrp = "//div[@id='groupSchemaDiv']//input[@class='primaryBtn']";
    public static final String txtgroupnativeobjtyp = "(//input[@name='editForm:j_idt561:1:j_idt575'])[1]";
	public static final String txtgroupdisplyattribut =  "(//input[@name='editForm:j_idt561:1:j_idt605'])[1]";
	public static final  String txtgroupideityatrri = "(//input[@name='editForm:j_idt561:1:j_idt579'])[1]";
	public static final String tablepreviewgroup = "//div[@id='gridview-1226']/table//tbody/tr";
 
	
    public void SchemaSearchaccount(String txt1,String txt2,String txt3,  ExtentTest logger) throws Exception
    {
    	Helper.click(driver, lnschema,"Click On Schema Link ",logger);
    	
    	Helper.validatetextbox(driver, txtaccnativeobjtyp, txt1, " Account :Native Object Type Text box", logger);
    	Helper.validatetextbox(driver, txtaccdisplyattribut, txt2, " Account :Native Object Type Text box", logger);
    	Helper.validatetextbox(driver, txtaccideityatrri, txt3, " Account :Native Object Type Text box", logger);
    	
    	
    }
    
    public void SchemaAttributevalidationaccount (ExtentTest logger) {
    	
    	List<WebElement> rows = driver.findElements(By.xpath(tableaccount));
    	int totalrows = rows.size();
    	System.out.println("Row value :"+totalrows);
    	
    	for (int j=6;j<totalrows;j++) {
    		
    		int tbrow = j-4;
    		System.out.println("table row:" +tbrow);
    		
    		String acctTypeAct = driver.findElement(By.xpath("//div[@id='accountSchemaDiv']//tr[" + tbrow + "]/td[4]//select//option[@selected='selected']")).getAttribute("value");
    		System.out.println("Accttype:"+acctTypeAct);
    		
    		String acctTypeExp = "group";
    		
    		if ( acctTypeExp.equalsIgnoreCase(acctTypeAct)){
    	          
    	         System.out.println("Expected Schema Account Type is present in Listbox  as:   '" + acctTypeExp +"' Actual Schema Account Type present in Listbox operation '"+acctTypeAct +"'");
    	         logger.info("LOG:INFO-  Schema Account Type List box validation for   :'"+tbrow +"' :  '"+acctTypeAct+"'" );
 	            logger.pass("Expected Schema Account Type is present in Listbox  as:   '" + acctTypeExp +"' Actual Schema Account Type present in Listbox operation '"+acctTypeAct +"'");
 	           
 	           logger.info("LOG:INFO-  Check the Corresponding Properties value in Account Schema ");
 	           
 	          String acctProperAct = driver.findElement(By.xpath("//div[@id='accountSchemaDiv']//tr[" + tbrow + "]/td[5]//input[@type ='text']")).getAttribute("value");
 	    		System.out.println("acctProperAct:"+acctProperAct);
 	    		
 	    		String acctProperExp = "Managed, Entitlement";
 	    		
 	    		
 	    		if ( acctProperExp.equalsIgnoreCase(acctProperAct)){
 	    	          
 	    	         System.out.println("Expected Schema Properties Text  is present in Textbox  as:   '" + acctProperExp +"' Actual Schema Properties Text present in Textbox  '"+acctProperAct +"'");
 	    	         logger.info("LOG:INFO-  Schema Properties Text box validation for   :'"+tbrow +"' :  '"+acctProperAct+"'" );
 	 	            logger.pass("Expected Schema Properties Text  is present in Text  as:   '" + acctProperExp +"' Actual Schema  Properties Text present in Textbox  '"+acctProperAct +"'");
 	 	           
 	 	            break;
 	 	           
 	    		}
 	    		
 	    		else {
 	    	    	  logger.info("LOG:INFO-  Schema Properties Text box validation for   :'"+tbrow +"' :  '"+acctProperAct+"'" );
 	  	            logger.fail("Expected Schema Properties Text is present in Text box  as:   '" + acctProperExp +"' Actual Schema Account Type present in Textbox  '"+acctProperAct +"'");
 	  	           
 	  	            	System.out.println( " Expected Schema Properties Text is  not present in Textbox " );
 	    	      
 	    	      }
 	    		
 	           
     	
    	 }
    	      
    		
    		
    		
    	}
    	
    	
    	
    	
    }
    
    
public void Schemapreviewvalidationaccount ( String previetagname, ExtentTest logger) throws Exception {
	
	Helper.click(driver, btnpreviewaccnt,"Click On Preview Account button  ",logger);
	
	Thread.sleep(35000);
	
	Helper.gettextvalue(driver, txtpreviewaccnttitle, previetagname, "Schema Account Preview title", logger);
	
    	Thread.sleep(4000);
    	
    	
    	
    			
    			
    	
    
}


public void Schemapreviewtablecheckaccount (ExtentTest logger) throws Exception {
	
	
	
	
	List<WebElement> rows = driver.findElements(By.xpath(tablepreviewaccount));
	
	//Dimension r = driver.findElement(By.xpath(tablepreviewaccount)).getSize();
			int totalrows = rows.size();
	System.out.println("Row value in  :"+totalrows);
	/*
	for (WebElement elm : rows) {
		
		String value = elm.getText();
		System.out.println(" valu ::" + value);
		
	} */
	
	for (int j=2;j<=totalrows;j++) {
		
		for (int c =1;c<=10;c++) {
		
		
		System.out.println("table row:" +j);
		
		String Previewvalueaccount = driver.findElement(By.xpath("//div[@id='gridview-1205']/table//tbody/tr[" + j + "]/td[" + c + "]")).getText();
		System.out.println("Previewvalueaccount:"+Previewvalueaccount);
		
		if (Previewvalueaccount.isBlank()) {
			logger.fail("Schema Account Preview value  not  in table as   :  '"+j +"' :   '"+c +"'  '" +Previewvalueaccount);
			System.out.println("Schema Account Preview value not  in table as   :  '"+j +"' :   '"+c +"'  '" +Previewvalueaccount);
			
		}
		else {
			logger.pass("Schema Account Preview value  in table as   :  '"+j +"' :   '"+c +"'  '" +Previewvalueaccount);
			System.out.println("Schema Account Preview value  in table as   :  '"+j +"' :   '"+c +"'  '" +Previewvalueaccount);
			
			
			
		}
            
           
           
		
	}
	
	}
	Thread.sleep(3000);
	Helper.click(driver, btnclosepreviewacc,"Click On close  preview Account button  ",logger);
	
}


public void SchemaSearchgroup(String txt1,String txt2,String txt3,  ExtentTest logger) throws Exception

{
	Thread.sleep(2000);
	Helper.scrolldown(driver, btnpreviewgroupdrp, "Scroll Down", logger);
	
	
	
	Helper.validatetextbox(driver, txtgroupnativeobjtyp, txt1, " Account :Native Object Type Text box", logger);
	Helper.validatetextbox(driver, txtgroupdisplyattribut, txt2, " Account :Native Object Type Text box", logger);
	Helper.validatetextbox(driver, txtgroupideityatrri, txt3, " Account :Native Object Type Text box", logger);
	
	
	
}

public void Schemapreviewvalidationgroup( String previetagname, ExtentTest logger) throws Exception {
	
	Helper.click(driver, btnpreviewgroup,"Click On Preview Group button  ",logger);
	
	Thread.sleep(35000);
	
	Helper.gettextvalue(driver, txtpreviewgrouptitle, previetagname, "Schema group Preview title  ", logger);
	
    	Thread.sleep(3000);
    	
    		
    
}


public void Schemapreviewtablecheckgroup (ExtentTest logger) throws Exception {
	
	
	
	
	List<WebElement> rows = driver.findElements(By.xpath(tablepreviewgroup));
	
	//Dimension r = driver.findElement(By.xpath(tablepreviewaccount)).getSize();
			int totalrows = rows.size();
	System.out.println("Row value in group  :"+totalrows);
	/*
	for (WebElement elm : rows) {
		
		String value = elm.getText();
		System.out.println(" valu ::" + value);
		
	} */
	
	for (int j=2;j<=totalrows;j++) {
		
		for (int c =1;c<=3;c++) {
		
		
		System.out.println("table row group:" +j);
		
		String Previewvaluegroup = driver.findElement(By.xpath("//div[@id='gridview-1226']/table//tbody/tr[" + j + "]/td[" + c + "]")).getText();
		System.out.println("Previewvalueaccount:"+Previewvaluegroup);
		
		if (Previewvaluegroup.isBlank()) {
			logger.fail("Schema Group Preview value  not  in table as   :  '"+j +"' :   '"+c +"'  '" +Previewvaluegroup);
			System.out.println("Schema Group Preview value not  in table as   :  '"+j +"' :   '"+c +"'  '" +Previewvaluegroup);
			
		}
		else {
			logger.pass("Schema Group Preview value  in table as   :  '"+j +"' :   '"+c +"'  '" +Previewvaluegroup);
			System.out.println("Schema Group Preview value  in table as   :  '"+j +"' :   '"+c +"'  '" +Previewvaluegroup);
			
			
			
		}
            
           
           
		
	}
	
	}
	Thread.sleep(5000);
	Helper.click(driver, btnclosepreviewgroup,"Click On close  preview Group button  ",logger);
	
}





}
