package SailpointTestcase;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import SailpointPageobject.BaseClass;
import SailpointPageobject.LoginPage;
import SailpointPageobject.ProvisioningManageUserAccess;
import SailpointPageobject.myworkrequestcheck;
import utili.ExcelDataProvider;
import utili.Helper;

public class ProvisioningUser extends BaseClass {
	
	
	 
	 	
	//@Parameters({"group","appname","user"})
	 
	 @DataProvider(name ="excel-data")
	  	public Object[][] excelDP() throws IOException{
	        	//We are creating an object from the excel sheet data by calling a method that reads data from the excel stored locally in our system
	        	Object[][] arrObj = getExcelData("C:\\Users\\vn52odq\\git\\repository\\SailpointTesting\\TestData\\","Data.xlsx");
	        	return arrObj;
	  	}
	  	//This method handles the excel - opens it and reads the data from the respective cells using a for-loop & returns it in the form of a string array
	  	public String[][] getExcelData(String fileName, String sheetName){
	        	
	        	String[][] data = null;   	
	  	  	try
	  	  	{
	  	   	FileInputStream fis = new FileInputStream(fileName);
	  	   	XSSFWorkbook wb = new XSSFWorkbook(fis);
	  	   	XSSFSheet sh = wb.getSheet(sheetName);
	  	   	XSSFRow row = sh.getRow(0);
	  	   	int noOfRows = sh.getPhysicalNumberOfRows();
	  	   	int noOfCols = row.getLastCellNum();
	  	   	Cell cell;
	  	   	data = new String[noOfRows-1][noOfCols];
	  	   	
	  	   	for(int i =1; i<noOfRows;i++){
	  		     for(int j=0;j<noOfCols;j++){
	  		    	   row = sh.getRow(i);
	  		    	   cell= row.getCell(j);
	  		    	   data[i-1][j] = cell.getStringCellValue();
	  	   	 	   }
	  	   	}
	  	  	}
	  	  	catch (Exception e) {
	  	     	   System.out.println("The exception is: " +e.getMessage());
	           	}
	        	return data;
	  	}
	 
	 
	 
	
	  	@Test(dataProvider ="excel-data")
    public void ProvisionUserApp(String userid,String username,String managerName,String ApplictionName,String addgroup ) throws Exception {
		
		
		//DataSet++;
		System.out.println("userid are:" +userid);
		System.out.println("username s are:" +username);
		System.out.println("manager are:" +managerName);
		System.out.println("Description Appname are:" +ApplictionName);
		System.out.println("Description group are:" +addgroup);
		
		logger = report.createTest("Login to SailPoint QA");

        LoginPage loginPage = PageFactory.initElements(driver,LoginPage.class);

        logger.info("Starting Application");

        loginPage.loginToApplication(excel.getStringData("Login", 0, 0), excel.getStringData("Login", 0, 1),logger);

        logger.pass("Login Success");
        
        //logger.log(Status.INFO, "Sailpoint Home Page opened"+logger.addScreenCaptureFromPath(captureScreen()));
        logger.log(Status.PASS, "Sailpoint Home Page opened "+logger.addScreenCaptureFromPath(captureScreen()));
        
  
		
		
	    	
	    		System.out.println("Userid::"+userid);
	    		System.out.println("AppName::"+ApplictionName);
	    		System.out.println("addgroup::"+addgroup);
/*
      

        logger = report.createTest("Provisioning User");

        ProvisioningManageUserAccess provisionusr = PageFactory.initElements(driver,ProvisioningManageUserAccess.class);

        logger.info("Starting Provisioning");
        
        provisionusr.ManageUserProvision(logger);
        
        
        provisionusr.EntertheUserDetailsProvision(userid,logger);
        
        logger.log(Status.PASS, "User Details Searched "+logger.addScreenCaptureFromPath(captureScreen()));
        
        logger = report.createTest("Search Entitlement Application");
        
        provisionusr.SearchEntitlementApplication(ApplictionName,logger);
        
        logger.log(Status.PASS, "Search the Entitlement Application "+logger.addScreenCaptureFromPath(captureScreen()));
      
        provisionusr.SelectadGroupfrmEntitlementApp(logger);
        
        provisionusr.Netxbutsubmitbtnaddgrp(logger);
        
       */
       
	    	
        logger = report.createTest("workitem");

        myworkrequestcheck workitem = PageFactory.initElements(driver,myworkrequestcheck.class);

        logger.info("Workitem");
        
        //workitem.myworksearch(logger);
        
        //workitem.Searchworkitemid("Prabhu Dhandapani","Krishnaiah Yella",logger);
        
        //workitem.workitemiternation("Annette Knight","Prabhu Dhandapani",logger);
        
        //workitem.Notificationmanagerapproval("Annette Knight",logger);
        
        //workitem.workitemiternationmanagerapprove("Annette Knight","Prabhu Dhandapani",logger);
        //workitem.Searchworkitemidowner("Prabhu Dhandapani",logger);
        
        //workitem.workitemiternationsecondapprove("Alexandra Blouir","Prabhu Dhandapani","Walmart Alerts Approvers Workgroup",logger);
        
        //workitem.Notificationownerapproval("Alexandra Blouir","Prabhu Dhandapani","Walmart Alerts Approvers Workgroup",logger);
	    	
       
        //}
        
        

	//}
	
	
	//catch(Exception e) { e.getMessage();}
		
	}
}
