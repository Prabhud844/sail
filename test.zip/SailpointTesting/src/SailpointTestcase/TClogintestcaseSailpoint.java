package SailpointTestcase;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import SailpointPageobject.LoginPage;



public class TClogintestcaseSailpoint {
	
	WebDriver driver;
	 
	LoginPage objloginpge;
	
	@BeforeTest
	public void setup() {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\vn52odq\\Sailpoint\\SailpointTesting\\Driver\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.get("https://spt-qa-task-01.lab.wal-mart.com/login.jsf");
	}
	
	
	@Test(priority = 1)
	public void enter_userDetails() {
		/*
		 * objloginpge = new LoginPage(driver); objloginpge.setUserName("QA-vn52odq");
		 * objloginpge.setPassword("Test@123"); objloginpge.clickSubmit();
		 */

}
	
	
}

