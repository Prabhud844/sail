package SailpointTestcase;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;

import SailpointPageobject.BaseClass;
import SailpointPageobject.LoginPage;
import SailpointPageobject.TaskSearchinsetup;

public class TaskExecution extends BaseClass {


    @Test(priority = 1)
    public void TaskSetup() throws Exception {

        logger = report.createTest("Login to SailPoint QA");

        LoginPage loginPage = PageFactory.initElements(driver,LoginPage.class);

        logger.info("Starting Application");

        loginPage.loginToApplication(excel.getStringData("Login", 0, 0), excel.getStringData("Login", 0, 1),logger);

        //driver.findElement(By.xpath("(//a[@role='menuitem'])[22]")).click();
        logger.pass("Login Success");
        logger = report.createTest("Search ApplicationTask in SailPoint Task");

        
        TaskSearchinsetup TaskSearch = PageFactory.initElements(driver, TaskSearchinsetup.class);
        
        logger.info("Moving into application definition page");

        //TaskSearch.selectsetup();
        
        //driver.findElement(By.xpath("(//a[@role='menuitem'])[22]")).click();
        
        TaskSearch.ApplicationSearch( logger);
        TaskSearch.entertaskintextbox(excel.getStringData("App", 0, 2),logger);
        TaskSearch.taskselectsearchresult(excel.getStringData("App", 0, 2),logger);
        
        TaskSearch.scrolldownpage(logger);
        TaskSearch.executetask(logger);
        TaskSearch.enterTaskinTaskresult(excel.getStringData("App", 0, 2),logger);
        TaskSearch.taskresultselectedtochecck(excel.getStringData("App", 0, 2),logger);
        TaskSearch.taskresultvalidation(excel.getStringData("App", 0, 4),logger);

       
       
        //logger.log(Status.INFO, "Sailpoint Home Page opened"+logger.addScreenCaptureFromPath(captureScreen()));
        //logger.log(Status.PASS, "Passed test 2"+logger.addScreenCaptureFromPath(captureScreen()));
        

    }
    
  


    
}
