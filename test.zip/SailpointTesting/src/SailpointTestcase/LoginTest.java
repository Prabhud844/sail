package SailpointTestcase;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;

import SailpointPageobject.BaseClass;
import SailpointPageobject.LoginPage;
import SailpointPageobject.Schemapage;
import SailpointPageobject.applicationSearchinapp;

public class LoginTest extends BaseClass {


    @Test(priority = 1)
    public void loginApp() throws Exception {

        logger = report.createTest("Login to SailPoint QA");

        LoginPage loginPage = PageFactory.initElements(driver,LoginPage.class);

        logger.info("Starting Application");

        loginPage.loginToApplication(excel.getStringData("Login", 0, 0), excel.getStringData("Login", 0, 1),logger);

        logger.pass("Login Success");
        
        //logger.log(Status.INFO, "Sailpoint Home Page opened"+logger.addScreenCaptureFromPath(captureScreen()));
        logger.log(Status.PASS, "Sailpoint Home Page opened "+logger.addScreenCaptureFromPath(captureScreen()));
        
        
        logger = report.createTest("Search App in SailPoint Application Defintion");

        applicationSearchinapp applicationSearchinapp = PageFactory.initElements(driver,applicationSearchinapp.class);

        logger.info("Moving into application definition page");

        //loginPage.loginToApplication(excel.getStringData("Login", 0, 0), excel.getStringData("Login", 0, 1),logger);
        applicationSearchinapp.appsearch(logger);
        applicationSearchinapp.ApplicationSearch(excel.getStringData("App", 0, 0), logger);
        
   
        logger = report.createTest("Application search ");
        applicationSearchinapp.textboxcheck(excel.getStringData("App", 0, 0), logger);
        
        
        
        logger = report.createTest("Application Details check Validation ");
        applicationSearchinapp.checkboxchangeopertaion(logger);
        logger.pass("Application Native Change Operations checkbox validation is completed");
        
        //Thread.sleep(20000);
        
        
      
        logger = report.createTest("Application Configuration setting check  Validation");
        applicationSearchinapp.configurationsettingcheck( logger);
        
        
        applicationSearchinapp.baseurlcheck(excel.getStringData("App", 1, 0), logger);
        
        //logger.pass("Testconnection of application validation is completed");

        logger = report.createTest("application Connector Operation Validation");
        applicationSearchinapp.connectorOperationsail(logger);
        applicationSearchinapp.beforeafterrule(logger);
        applicationSearchinapp.Actionbtncheck(logger);
        
        
        logger = report.createTest("Schemapage Validation");

        Schemapage Schemapage = PageFactory.initElements(driver,Schemapage.class);

       
        Schemapage.SchemaSearchaccount("user", "userName", "userName", logger);
        logger=report.createTest("Moving into Schemapage  Account  page");
        Schemapage.SchemaAttributevalidationaccount(logger);
        logger = report.createTest("Moving into Schemapage  Account Preview  page");
        
        Schemapage.Schemapreviewvalidationaccount("Preview", logger);
        logger = report.createTest("Moving into Schemapage  Account Preview  table page");
        
        Schemapage.Schemapreviewtablecheckaccount(logger);
        
        logger = report.createTest("Moving into Schemapage  Group  page");
        
        Schemapage.SchemaSearchgroup("group", "teamName", "teamId", logger);
        
        
        
        
        logger = report.createTest("Moving into Schemapage  Group Preview  page");
        
        Schemapage.Schemapreviewvalidationgroup("Preview", logger);
        logger = report.createTest("Moving into Schemapage  Group Preview  table page");
        
        Schemapage.Schemapreviewtablecheckgroup(logger);
        
        logger = report.createTest("application Accounts add check  Validation");
        applicationSearchinapp.Accountsaddcheck(logger);
        
        logger = report.createTest("Application TestConnection Check  Validation");
        applicationSearchinapp.ConnectionTest(excel.getStringData("App", 0, 1), logger);
        
        

    }
    
    
    
}
