package utili;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import SailpointPageobject.BaseClass;

import java.io.File;
import java.io.FileInputStream;

public class ExcelDataProvider extends BaseClass {
    XSSFWorkbook wb;
    File src=new File("./TestData/Data.xlsx");

    public ExcelDataProvider()
    {

        //File src=new File("./TestData/Data.xlsx");

        try {
            FileInputStream fis=new FileInputStream(src);

            wb=new XSSFWorkbook(fis);
        }  catch (Exception e) {

            System.out.println("Unable to read Excel File "+e.getMessage());
        }

    }


    public String getStringData(int sheetIndex,int row,int column)
    {
        return wb.getSheetAt(sheetIndex).getRow(row).getCell(column).getStringCellValue();
    }

    public String getStringData(String sheetName,int row,int column)
    {
        return wb.getSheet(sheetName).getRow(row).getCell(column).getStringCellValue();
    }

    public double getNumericData(String sheetName,int row,int column)
    {
        return wb.getSheet(sheetName).getRow(row).getCell(column).getNumericCellValue();
    }
    
    public static  String getInputData(String sheetName,String ColName,int RowNum) {
    	String CellValue ="";
    	FileInputStream file =null;
    	HSSFWorkbook workbook =null;
    	HSSFSheet hssfSheet = null;
    	try {
    		file  =new  FileInputStream(Filepath);
    		workbook = new HSSFWorkbook(file);
    		hssfSheet = workbook.getSheet(sheetName);
    		int ColNum =getcolumnContains(hssfSheet,0,ColName);
    		CellValue =hssfSheet.getRow(RowNum).getCell(ColNum).getStringCellValue();
    	
    	}
    	catch (Exception e) {
    		
    		
    	}
    	return CellValue.trim();
    	
    	
    	
    }
    
    public static int getColumnUsed(HSSFSheet hssfsheetname2) throws Exception
    {
    	int ColumnCount = hssfsheetname2.getRow(0).getLastCellNum();
    	return ColumnCount;
    }
    
    
    public static String getCellData(HSSFSheet hssfsheetname2,int RowNum,int ColNum) throws Exception
    {
    	try {
    		HSSFCell cell = hssfsheetname2.getRow(RowNum).getCell(ColNum);
        	String CellData = cell.getStringCellValue().trim();
        	return CellData;
    		
    	}
    	
    	catch (Exception e) {
    		return"";
    		
    	}
    }
    
    public static int getcolumnContains (HSSFSheet hssfsheetname2, int Rownum, String value) throws Exception 
    {

    int a;
    try {

    int columncount=getColumnUsed (hssfsheetname2);

    for (a=0; a<columncount; a++){

    if (getCellData(hssfsheetname2, Rownum, a).equalsIgnoreCase (value)) {

   
    	break;
    }


    }

    return a;
    }

    catch (Exception e) {

    throw(e);

    }
    
    
    }
    
}
