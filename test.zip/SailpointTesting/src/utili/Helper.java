package utili;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.relevantcodes.extentreports.LogStatus;



import org.openqa.selenium.*;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.List;

public class Helper {

    // Screenshot, alerts,frames, windows, Sync issue, javascript executor

    public static String captureScreenshot(WebDriver driver) {
        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        String screenshotPath = System.getProperty("user.dir") + "/Screenshots/VA_" + getCurrentDateTime()
                + ".png";

        try {

            FileHandler.copy(src, new File(screenshotPath));

            System.out.println("Screenshot captured");


        } catch (IOException e) {

            System.out.println("Unable to capture screenshot " + e.getMessage());
        }

        return screenshotPath;

    }

    public static String getCurrentDateTime() {

        SimpleDateFormat myformat=new SimpleDateFormat("HH_mm_ss_dd_MM_yyyy");

        Date date=new Date();

        return myformat.format(date);

    }

    public static boolean waitForURL(WebDriver driver,String keyword)
    {

        return new WebDriverWait(driver, 30).until(ExpectedConditions.urlContains(keyword));
    }

    public static void acceptAlert(WebDriver driver, By locator, String logInfo)
    {
        new WebDriverWait(driver, 30).until(ExpectedConditions.alertIsPresent()).accept();
        System.out.println("LOG:INFO "+logInfo);
    }

    public static void acceptAlert(WebDriver driver,By locator,int time,String logInfo)
    {
        new WebDriverWait(driver, 30).until(ExpectedConditions.alertIsPresent()).accept();
        System.out.println("LOG:INFO "+logInfo);
    }

    public static void dismissAlert(WebDriver driver,By locator,String logInfo)
    {
        new WebDriverWait(driver, 30).until(ExpectedConditions.alertIsPresent()).dismiss();
        System.out.println("LOG:INFO "+logInfo);
    }

    public static void dismissAlert(WebDriver driver,By locator,int time,String logInfo)
    {
        new WebDriverWait(driver, 30).until(ExpectedConditions.alertIsPresent()).dismiss();
        System.out.println("LOG:INFO "+logInfo);
    }



    public static void waitForMessAndPartialVerify(WebDriver driver,By locator,String expected,String logInfo)
    {

        WebElement element=new WebDriverWait(driver, 30).until(ExpectedConditions.elementToBeClickable(locator));
        String actual=element.getText();
        if(actual.contains(expected))
        {
            System.out.println("LOG:PASS- Message verified");
        }
        else
        {
            System.out.println("LOG:FAIL- Message validation failed");
        }

        System.out.println("LOG:INFO- Waited for message validation");


		/*if(new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.elementToBeClickable(locator)).getText().contains(expected))
		{

		}*/
    }


    public static WebElement waitForWebElement(WebDriver driver,By locator,String logInfo)
    {
        WebElement element=new WebDriverWait(driver, 30).until(ExpectedConditions.elementToBeClickable(locator));
        System.out.println("LOG:INFO-"+logInfo);
        return element;
    }


    public static void waitForWebElementAndType(WebDriver driver, WebElement locator, String textToBeType,
                                                String logInfo, ExtentTest logger)
    {
        new WebDriverWait(driver, 30).until(ExpectedConditions.elementToBeClickable(locator)).sendKeys(textToBeType);
        System.out.println("LOG:INFO-"+logInfo);
        logger.info("LOG:INFO-"+logInfo);
    }

    public static void waitForWebElementAndClick(WebDriver driver,WebElement locator,String logInfo,ExtentTest logger)
    {
        new WebDriverWait(driver,30).until(ExpectedConditions.elementToBeClickable(locator)).click();
        System.out.println("LOG:INFO-"+logInfo);
        logger.info("LOG:INFO-"+logInfo);
    }

    public static void waitForWebElementAndClick(WebDriver driver,WebElement locator,int time,String logInfo,ExtentTest logger)
    {
        new WebDriverWait(driver, 30).until(ExpectedConditions.elementToBeClickable(locator)).click();
        System.out.println("LOG:INFO-"+logInfo);
        logger.info("LOG:INFO-"+logInfo);

    }

//WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
    
    

    public static void waitForSeconds(int second)
    {
        try
        {
            Thread.sleep(second* 1000L);
        } catch (InterruptedException e)
        {
            System.out.println(e);
        }
    }




    public static void verifyBrokenLinkOrImage(String url) throws IOException {
        HttpURLConnection conn=(HttpURLConnection)new URL(url).openConnection();

        conn.connect();

        int code=conn.getResponseCode();

        String serverResponse=conn.getResponseMessage();
        System.out.println("Checking url "+url);
        System.out.println("Code from server is "+code);
        System.out.println("Response from server is "+serverResponse);

        // &&
        // ||

        if(code == 200 || code==301 || code==302)
        {
            System.out.println("Link is working fine");
        }
        else
        {
            System.out.println("Broken link "+url);
        }

    }


    public static void selectValueFromList(WebDriver driver,String xpath,String value)
    {
        List<WebElement> allSugg=driver.findElements(By.xpath(xpath));

        for(WebElement element:allSugg)
        {
            if(element.getText().contains(value))
            {
                System.out.println("LOG:INFO- Element found");
                element.click();
                break;
            }
        }
    }

    public static void selectValueFromListUsingIterator(WebDriver driver,String xpath,String value)
    {
        List<WebElement> allSugg=driver.findElements(By.xpath(xpath));

        for (WebElement element : allSugg) {
            if (element.getText().contains(value)) {
                System.out.println("LOG:INFO- Element found");
                element.click();
                break;
            }
        }

    }
    
  
    
    //code to validate the textbox value
    public static void validatetextbox(WebDriver driver,String xpath,String appname,String logInfo, ExtentTest logger)  {
    	SoftAssert Assert = new SoftAssert();
    	//String  Textboxvalue = new WebDriverWait(driver,30).until(ExpectedConditions.elementToBeClickable(locator)).getText();
    	WebElement  ele = driver.findElement(By.xpath(xpath));
    	String Textboxvalue = ele.getAttribute("value");
    	System.out.println("Testx value :: " +Textboxvalue);
    	
             if ( appname.equalsIgnoreCase(Textboxvalue)){
                 Assert.assertTrue(appname.equals(Textboxvalue));
            logger.info("LOG:INFO-"+logInfo);
            logger.pass("Expected Name value is present  as:   '" + appname +"' Actual Value present in Textbox '"+Textboxvalue +"'");
           
        }
             else {
            	 //logger.info("Expected APP Name value is not present as :   '" + appname +"' Actual Value present in Sailpoint Name '"+Textboxvalue +"'");
            	 Assert.assertFalse(appname.equals(Textboxvalue));
            	 logger.info("LOG:INFO-"+logInfo);
            	  logger.fail("Expected  Name value is not present as :   '" + appname +"' Actual Value present in Textbox '"+Textboxvalue +"'");
             }
             Assert.assertAll();
    }
    
    public static void radiobuttonuncheckvalidation(WebDriver driver,String xpath,String logInfo, ExtentTest logger)  {
    	SoftAssert Assert = new SoftAssert();
    	WebElement radio = driver.findElement(By.xpath(xpath));
    	System.out.println("The radio is selection state is - " + radio.isSelected());
    	logger.info(" Validating the Radio button  " +logInfo);
    	
    	boolean status = radio.isSelected();
		
		
		System.out.println("Checking boolean status:"+status);
		
		//checking condition is true or not.
		if(status)
		{
			
			logger.info("LOG:INFO-"+logInfo);
            logger.fail("Radio button is selected  " +logInfo);
          
			System.out.println(" Radio button is selected  " +logInfo);
		
		}
		
		else
		{
			
			logger.info("LOG:INFO-"+logInfo);
            logger.pass("Radio button is not Checked ." +logInfo);
           
			System.out.println("Radio button is not Checked " +logInfo);
		}
    	
    	
    }
    
    public static void radiobuttoncheckvalidation(WebDriver driver,String xpath,String logInfo, ExtentTest logger)  {
    	SoftAssert Assert = new SoftAssert();
    	WebElement radio = driver.findElement(By.xpath(xpath));
    	System.out.println("The radio is selection state is - " + radio.isSelected());
    	logger.info(" Validating the Radio button  " +logInfo);
    	
    	boolean status = radio.isSelected();
		
		
		System.out.println("Checking boolean status:"+status);
		
		//checking condition is true or not.
		if(status)
		{
			Assert.assertEquals("True", status);
			logger.info("LOG:INFO-"+logInfo);
            logger.pass("Radio button is selected sucessfully " +logInfo);
          
			System.out.println(" Radio button is selected sucessfully " +logInfo);
		
		}
		
		else
		{
			Assert.assertNotEquals("True", status);
			logger.info("LOG:INFO-"+logInfo);
            logger.fail("Radio button is not Checked ." +logInfo);
           
			System.out.println("Radio button is not Checked " +logInfo);
		}
    	
    	
    }
    
    
    public static void checkboxuncheckedvalidation(WebDriver driver,String xpath,String logInfo, ExtentTest logger)  {
    	SoftAssert Assert = new SoftAssert();
    	WebElement checkbox = driver.findElement(By.xpath(xpath));
    	System.out.println("The checkbox is selection state is - " + checkbox.isSelected());
    	logger.info(" Validating the Check box from App Defintion ");
    	
    	boolean status = checkbox.isSelected();
		
		
		System.out.println("Checking boolean status:"+status);
		
		//checking condition is true or not.
		if(status)
		{
			Assert.assertNotEquals("True", status);
			logger.info("LOG:INFO-"+logInfo);
            logger.fail("check box is  Checked at Application Details");
           
			System.out.println("check box is  Checked at Application Details.");
			
			
		}
		
		else
		{
			
			
			Assert.assertEquals("True", status);
			logger.info("LOG:INFO-"+logInfo);
            logger.pass("check box is unchecked  at Application Details");
           
			System.out.println(" check box is unchecked  at Application Details");
			
		}
    	
    	
    }
    
    
    public static void gettextvalue(WebDriver driver,String xpath,String textvalue,String logInfo, ExtentTest logger)  {
    	SoftAssert Assert = new SoftAssert();
    	//String  Textboxvalue = new WebDriverWait(driver,30).until(ExpectedConditions.elementToBeClickable(locator)).getText();
    	WebElement  ele = driver.findElement(By.xpath(xpath));
    	String Textboxvalue = ele.getText();
    	System.out.println("Testx value :: " +Textboxvalue);
    	
             if ( textvalue.equalsIgnoreCase(Textboxvalue)){
                 Assert.assertTrue(textvalue.equals(Textboxvalue));
            logger.info("LOG:INFO-"+logInfo);
            logger.pass(" Expected text  value is   '" + textvalue +"' Actual Text value is '"+Textboxvalue +"'");
           
        }
             else {
            	 //logger.info("Expected APP Name value is not present as :   '" + appname +"' Actual Value present in Sailpoint Name '"+Textboxvalue +"'");
            	 Assert.assertFalse(textvalue.equals(Textboxvalue));
            	 logger.info("LOG:INFO-"+logInfo);
            	 logger.fail(" Expected text  value is   '" + textvalue +"' Actual Text value is '"+Textboxvalue +"'");
             }
             Assert.assertAll();
    }
    
    public static void Webelementclickcheck(WebDriver driver,String xpath,String logInfo, ExtentTest logger)  {
    	SoftAssert Assert = new SoftAssert();
    	WebElement link = driver.findElement(By.xpath(xpath));
    	System.out.println("The Accountname link  - " + link.isEnabled());
    	logger.info(" Validating the Account are added into  Application ");
    	
    	boolean status = link.isEnabled();
		
		
		System.out.println("Checking boolean status:"+status);
		
		//checking condition is true or not.
		if(status)
		{
			Assert.assertEquals("True", status);
			logger.info("LOG:INFO-"+logInfo);
            logger.pass("Link are Enabled and Clicked -"+logInfo);
          
			//System.out.println(" Account link is Enabled and Accounts added with identifier  sucessfully at Application  Account section" );
		
		}
		
		else
		{
			Assert.assertNotEquals("True", status);
			logger.info("LOG:INFO-"+logInfo);
            logger.fail("Link are not Enabled and not Clicked" +logInfo);
           
			//System.out.println("Account link is  not Enabled and Identifier details are not added into Application Acount Section.");
		}
    	
    	
    }
    
    
    
    public static void taskselect2( WebDriver driver,String Accounttask,String logInfo, ExtentTest logger) {
		 
		//String taskaccount ="InContactWMUS Full Account Aggregation Task";
		int r = driver.findElements(By.xpath("//div[@id='gridview-1026']//tbody//tr")).size();
	
		System.out.println("Row value ::" +r);

for ( int i =1; i<=3;i++)
{
	String task = driver.findElement(By.xpath("//div[@id='gridview-1026']//tbody//tr[" + i + "]")).getText();
	
	System.out.println("TaskValue in table ::" + task);
	
	if (task.contains(Accounttask)) {
		System.out.println("Loop entered");
		
		 driver.findElement(By.xpath("//div[@id='gridview-1026']//tbody//tr[" + i + "]")).click();
		 logger.pass("Task search is selected successfully -"+logInfo);
		 break;    
	}
	else
	{
		logger.fail("Task search is not selected "+logInfo);
	}
	  
  }


  }
  
    

    public static  void click (WebDriver driver,By locator,String string, ExtentTest logger) throws Exception {
    	try {
    		WebElement btnElemnent =driver.findElement(locator);
    		btnElemnent.click();
    		logger.log(Status.PASS, "Button is clicked" +string);
    	  
    	}
    	catch (Exception e ) {
    		logger.log(Status.FAIL, "Button is not clicked Exception due to " +e.toString());
    		
    	}
    }
    
    
    public static  void EnterText (WebDriver driver,By locator,String strtxt,String logstring, ExtentTest logger) throws Exception {
    	try {
    		
    		WebElement txtElemnent =driver.findElement(locator);
    		txtElemnent.clear();
    		
    		txtElemnent.sendKeys(strtxt);
    		
    		logger.log(Status.PASS, "text in entered in the text box " +logstring);
    	  
    	}
    	catch (Exception e ) {
    		logger.log(Status.FAIL, "failed to enter the text  i textbox" +e.toString() +logstring);
    		
    	}
    }


    public    String getelementText (WebDriver driver,By locator,String logstring, ExtentTest logger) throws Exception {
    	try {
    		
    		WebElement element =driver.findElement(locator);
    		
    		return element.getText().trim();
    		
    		
    		//logger.log(Status.PASS, "text in entered in the text box " +logstring);
    	  
    	}
    	catch (Exception e ) {
    		logger.log(Status.FAIL, "failed to get the text   from '" +logstring +"' due to this error"+e.toString() );
    		
    	}
		return null;
    }

    
    public  static void scrolldown(WebDriver driver ,String xpath,String logstring, ExtentTest logger) {
    	JavascriptExecutor js = (JavascriptExecutor) driver;
    	
    	try {
    		WebElement Element = driver.findElement(By.xpath(xpath));
        	//Scrolling down the page till the element is found		
        	js.executeScript("arguments[0].scrollIntoView();", Element);
        	logger.log(Status.PASS, "Page is scroll down " +logstring);
      	  
    	}
    	catch (Exception e ) {
    		logger.log(Status.FAIL, "Page is not scroll down '" +logstring +"' due to this error"+e.toString() );
    		

    }
    	
    }

    public static void gettextfromweb(WebDriver driver,By xpath,String textvalue,String logInfo, ExtentTest logger)  {
    	SoftAssert Assert = new SoftAssert();
    	//String  Textboxvalue = new WebDriverWait(driver,30).until(ExpectedConditions.elementToBeClickable(locator)).getText();
    	WebElement  ele = driver.findElement(xpath);
    	String Textboxvalue = ele.getText();
    	System.out.println("Testx value :: " +Textboxvalue);
    	
             if ( textvalue.equalsIgnoreCase(Textboxvalue)){
                 Assert.assertTrue(textvalue.equals(Textboxvalue));
            logger.info("LOG:INFO-"+logInfo);
            logger.pass(" Expected Text value in avilable in    '" + textvalue +"' Actual Text value  '"+Textboxvalue +"' :: '"+logInfo +"'");
           
        }
             else {
            	 //logger.info("Expected APP Name value is not present as :   '" + appname +"' Actual Value present in Sailpoint Name '"+Textboxvalue +"'");
            	 Assert.assertFalse(textvalue.equals(Textboxvalue));
            	 logger.info("LOG:INFO-"+logInfo);
            	 logger.fail(" Expected Text value in avilable in    '" + textvalue +"' Actual Text value  '"+Textboxvalue +"' :: '"+logInfo +"'");
             }
             Assert.assertAll();
    }

	
    
    public static void checkboxcheckedvalidation(WebDriver driver,String xpath,String logInfo, ExtentTest logger)  {
    	SoftAssert Assert = new SoftAssert();
    	WebElement checkbox = driver.findElement(By.xpath(xpath));
    	System.out.println("The checkbox is selection state is - " + checkbox.isSelected());
    	logger.info(" Validating the Check box from App Defintion ");
    	
    	boolean status = checkbox.isSelected();
		
		
		System.out.println("Checking boolean status:"+status);
		
		//checking condition is true or not.
		if(status)
		{
			Assert.assertEquals("True", status);
			logger.info("LOG:INFO-"+logInfo);
            logger.pass("check box is selected sucessfully at Application Details");
          
			System.out.println(" check box is selected sucessfully at Application Details");
		
		}
		
		else
		{
			Assert.assertNotEquals("True", status);
			logger.info("LOG:INFO-"+logInfo);
            logger.fail("check box is not Checked at Application Details.");
           
			System.out.println("check box is not Checked at Application Details.");
		}
    	
    	
    }
    
    
    
    
    
    public void getList_ByID(WebDriver driver,String id_element, int list_index_to_click) {
	    try {
	        WebElement web_el = driver.findElement(By.id(id_element));
	        Select select = new Select(web_el);
	        List<WebElement> option = select.getOptions();
	        option.get(list_index_to_click).getText();
	    } catch (Exception e) {
	        //errors
	    }
	}
	
    public void Textfromlist(WebDriver driver,String xapth, int list_index_to_click) {
	    try {
	    	 Select select = new Select(driver.findElement(By.xpath(xapth)));
	    	    WebElement option = select.getFirstSelectedOption();
	    	    String defaultItem = option.getText();
	    	    System.out.println(defaultItem );
	    } catch (Exception e) {
	        //errors
	    }
	}
   
    

}
    
