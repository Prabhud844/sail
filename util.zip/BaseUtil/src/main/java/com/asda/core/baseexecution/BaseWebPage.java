package com.asda.core.baseexecution;

import com.asda.core.baseexecution.ExecutionConfig.Constants;
import com.asda.core.concurrent.SingleThreadExecutor;
import com.asda.core.enums.BrowserTypeEnum;
import com.asda.core.utils.MigrationUtil;
import com.asda.core.utils.SeleniumWebDriverUtility;
import com.asda.qa.utility.FluentWaitImplicit;
import com.thoughtworks.selenium.Selenium;
import net.lightbody.bmp.BrowserMobProxy;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Locatable;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.time.Duration;
import java.util.List;

/**
 * 
 * Base page, any page extending this should have the Constructor which takes
 * BasePage as a parameter.
 * 
 * @author jkandul
 * 
 */
public class BaseWebPage {

	private static final Logger s_logger = LoggerFactory.getLogger(BaseWebPage.class);
	protected SeleniumWebDriverUtility selWDUtil;
	protected WebDriver driver;
	protected BrowserMobProxy proxyServer;
	protected Selenium selenium;
	private static final String SESSION_START_TIMEOUT_KEY = "SESSION_START_TIMEOUT";
	private static final int SESSION_START_TIMEOUT_DEFAULT = 60;
	protected WebDriverWait wait = null;

	@FindBy(xpath = "(//*[contains(@class,'navigation-menu__text')])[1]")
	private WebElement groceriesMenu;

	private String taxonomyLevel = "//nav[@class='h-nav']/div/ul//span[text()='{0}']";



	// used for visual testing only
	// will be called using super.setName("NAME") from extended classes
	private String visualTestingPageName;

	/**
	 * Constructs a new page by copying over the browser handles.
	 * 
	 * @param driver
	 */
	public BaseWebPage(WebDriver driver) {
		this.driver = driver;
		this.selWDUtil = new SeleniumWebDriverUtility(driver);

	}

	/**
	 * Constructs a new page by copying over the browser handles.
	 * 
	 * @param page
	 */
	public BaseWebPage(BaseWebPage page) {
		try {
			boolean value = BaseFrontEndTest.enablebrowsermobglobal;
			if (value) {
				this.driver = page.driver;
				this.selenium = page.selenium;
				this.selWDUtil = new SeleniumWebDriverUtility(driver);
				this.proxyServer = page.proxyServer;
			} else {
				this.driver = page.driver;
				this.selenium = page.selenium;
				this.selWDUtil = new SeleniumWebDriverUtility(driver);
			}
		} catch (Exception e) {
			s_logger.info("There was an exception. Reseting to default");
			this.driver = page.driver;
			this.selenium = page.selenium;
			this.selWDUtil = new SeleniumWebDriverUtility(driver);
		}

	}

	public BaseWebPage(WebDriver webDriver, BrowserMobProxy proxyServer) {
		this.driver = webDriver;
		this.selWDUtil = new SeleniumWebDriverUtility(webDriver);
		this.proxyServer = proxyServer;
	}

	/**
	 * Returns page instance with WebDriver and Selenium instance.
	 * 
	 * Use this to get an instance during page transition.
	 * 
	 * @param cls
	 * @return
	 */
	public <P extends BaseWebPage> P getPage(Class<P> cls) {
		P pageInstance = null;

		// Search for default constructor to create new instance
		@SuppressWarnings("unchecked")
		Constructor<P>[] contrs = (Constructor<P>[]) cls.getConstructors();
		for (Constructor<P> c : contrs) {
			Class<?>[] paramTypes = c.getParameterTypes();
			if (paramTypes.length == 1 && BaseWebPage.class.isAssignableFrom(paramTypes[0])) {
				try {
					pageInstance = c.newInstance(this);
				} catch (IllegalArgumentException e) {
					s_logger.error("Error constructing page instance", e);
				} catch (SecurityException e) {
					s_logger.error("Error constructing page instance", e);
				} catch (InstantiationException e) {
					s_logger.error("Error constructing page instance", e);
				} catch (IllegalAccessException e) {
					s_logger.error("Error constructing page instance", e);
				} catch (InvocationTargetException e) {
					s_logger.error("Error constructing page instance", e);
				}
			}
		}

		// If object is constructed return the instance
		if (pageInstance != null) {
			return pageInstance;
		}

		// Search for old constructor way if the default doesnt exist.
		try {
			pageInstance = cls.getConstructor(WebDriver.class, Selenium.class).newInstance(driver, selenium);
		} catch (IllegalArgumentException e) {
			s_logger.error("Error constructing page instance", e);
		} catch (SecurityException e) {
			s_logger.error("Error constructing page instance", e);
		} catch (InstantiationException e) {
			s_logger.error("Error constructing page instance", e);
		} catch (IllegalAccessException e) {
			s_logger.error("Error constructing page instance", e);
		} catch (InvocationTargetException e) {
			s_logger.error("Error constructing page instance", e);
		} catch (NoSuchMethodException e) {
			s_logger.error("Error constructing page instance", e);
		}
		return pageInstance;
	}

	private File captureScreenshotAndSaveToFile(String screenshotName, final WebDriver wd) {
		s_logger.info("Capturing screenshot.");
		File screenshot = new SingleThreadExecutor<File>("CaptureScreenShot") {
			@Override
			public File run() {
				return ((TakesScreenshot) wd).getScreenshotAs(OutputType.FILE);
			}
		}.execute(ExecutionConfig.getInstance().getLongValue(SESSION_START_TIMEOUT_KEY, SESSION_START_TIMEOUT_DEFAULT));

		if (screenshot == null) {
			s_logger.error("Error capturing screenshot.");
			return null;
		}

		try {
			s_logger.info("URL of screenshot capture page: " + wd.getCurrentUrl());
		} catch (Exception e) {
			s_logger.info("Unable to capture url of screenshot page ....");
		}

		s_logger.info("Screenshot captured.");
		String logFolderPath = TestExecutionContext.getInstance().getPathToTestLogs();
		StringBuilder sb = new StringBuilder();
		sb.append(logFolderPath).append(screenshotName);
		File screenshotPathInLogsFolder = new File(sb.toString());

		try {
			s_logger.info("Saving screenshot to file:{}", sb);
			FileUtils.copyFile(screenshot, screenshotPathInLogsFolder);
			s_logger.info("Screenshot saved successfully.");
		} catch (IOException e) {
			s_logger.error("Unable to capture screenshot.", e);
		}
		return screenshotPathInLogsFolder;
	}

	/**
	 * Captures screenshot of browser and saves to log folder with the file name
	 * provided.
	 * 
	 * @param screenshotName
	 */
	public void captureScreenshot(String screenshotName) {
		if (!ExecutionConfig.getInstance().captureScreenshotsInFlow()) {
			s_logger.info("Not capturing screeshot as the configuration for {} is set to false",
					Constants.CAPTURE_SCREENSHOTS_IN_FLOW_KEY);
			return;
		}
		captureScreenshotAndSaveToFile(screenshotName, driver);
	}

	/**
	 * Captures screenshot of browser and saves to log folder with the file name
	 * provided.
	 * 
	 * @param screenshotName
	 * @return
	 */
	public File captureScreenshotAndGetFile(String screenshotName) {
		return captureScreenshotAndSaveToFile(screenshotName, driver);
	}

	/**
	 * Captures the screenshot for the web element and save it with the file name.
	 * 
	 * @param element
	 * @param imageName
	 */
	protected void captureScreenshotForWebElement(WebElement element, String imageName) {
		captureScreenshotForWebElement(element, imageName);
	}

	/**
	 * Captures the screenshot for the web element and save it with the file name,
	 * then returns the file.
	 * 
	 * @param element
	 * @param imageName
	 * @return
	 */
	protected File captureScreenshotForWebElementAndGetFile(WebElement element, String imageName) {
		File screen = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		Point p = element.getLocation();
		int width = element.getSize().getWidth();
		int height = element.getSize().getHeight();
		File destFile = null;
		try {
			BufferedImage img = ImageIO.read(screen);
			BufferedImage dest = img.getSubimage(p.getX(), p.getY(), width, height);
			ImageIO.write(dest, "png", screen);
			destFile = new File(TestExecutionContext.getInstance().getPathToTestLogs() + imageName + ".png");
			FileUtils.copyFile(screen, destFile);
		} catch (IOException e) {
			Assert.fail("Unable to capture image for webElement", e);
		}
		return destFile;
	}

	/**
	 * Returns the browserType where test is currently executing
	 * 
	 * @return
	 */
	public BrowserTypeEnum getBrowserType() {
		return TestExecutionContext.getInstance().getBrowserType();
	}

	public SeleniumWebDriverUtility getSelWDUtil() {
		return selWDUtil;
	}

	public void clearCookies() {
		this.selWDUtil.clearCookies();
	}

	public String getTitle() {
		s_logger.info("Getting title of current window.");
		String title = driver.getTitle();
		s_logger.info("Currrent window title: {}", title);
		return driver.getTitle();
	}

	/**
	 * Performs click action on the element
	 * 
	 * @param element
	 * @return
	 */
	protected BaseWebPage click(WebElement element) {
		element.click();
		return this;
	}

	protected void customClick(WebElement element,WebDriver driver, int timeOut){
		FluentWaitImplicit.waitForElementToLoadWithCustomWait(element,driver,timeOut);
		element.click();
	}

	/**
	 * Performs click action on element and waits for any asynchronous calls to
	 * complete.
	 * 
	 * @param element
	 * @return
	 */
	protected BaseWebPage clickAndWaitForAsynchronousCalls(WebElement element) {
		click(element);
		SeleniumWebDriverUtility.waitForAsyncCallToComplete(driver);
		return this;
	}

	/**
	 * Performs click action on the element and waits for page to load completely.
	 * 
	 * @param element
	 * @return
	 */
	protected BaseWebPage clickAndWaitForPageToLoad(WebElement element) {
		click(element);
		waitForPageToLoad();
		return this;
	}

	/**
	 * Scrolls the page by x and y points
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	protected BaseWebPage scrollPage(long x, long y) {
		String script = "scroll(" + x + "," + y + ");";
		s_logger.info("Scrolling page using script: {}", script);
		((JavascriptExecutor) driver).executeScript(script);
		return this;
	}

	/**
	 * Scroll page to bring the element to browser view port.
	 * 
	 * @param element
	 * @return a reference to this object
	 */
	protected BaseWebPage scrollPage(WebElement element) {
		// Scrolling to bring element to view port.
		((Locatable) element).getCoordinates().inViewPort();
		return this;
	}

	/**
	 * Scroll page to bring this element identified by 'by' to browser view port.
	 * 
	 * @param by
	 * @return a reference to this object
	 */
	protected BaseWebPage scrollPage(By by) {
		return scrollPage((By) driver.findElement(by));
	}

	/**
	 * Wait for page to load completely.
	 * 
	 * @return
	 */
	public BaseWebPage waitForPageToLoad() {
		SeleniumWebDriverUtility.waitForPageLoad(driver);
		return this;
	}

	/**
	 * (Many a times, a page loads but without all the elements being displayed).
	 * Wait for the page to load based on an element in the WebPage.
	 *
	 * @return
	 */
	public boolean waitForPageToLoad(WebElement element) {
		SeleniumWebDriverUtility.waitForPageLoad(driver);
		return FluentWaitImplicit.waitForElementToLoadWithCustomWait(element,
				driver, 20);
	}

	/**
	 * Wait for asynchronous calls to complete.
	 * 
	 * @return
	 */
	public BaseWebPage waitForAsynchronousCalls() {
		SeleniumWebDriverUtility.waitForAsyncCallToComplete(driver);
		return this;
	}

	/**
	 * Move the mouse over the given element and return the page object back
	 * 
	 * @param e
	 * @return
	 */
	public BaseWebPage mouseover(WebElement e) {
		Actions builder = new Actions(driver);
		builder.moveToElement(e).perform();
		return this;
	}

	/**
	 * Wait for element to be displayed on the page and return the element back for
	 * chained action
	 * 
	 * @param e
	 * @return
	 */
	public WebElement waitForElementDisplay(WebElement e) {
		final WebElement element = e;
		new WebDriverWait(driver, ExecutionConfig.getInstance().getElementWaitTimeOut())
				.until(new ExpectedCondition<Boolean>() {
					public Boolean apply(WebDriver webDriver) {
						return element.isDisplayed();
					}
				});
		return e;
	}

	/**
	 * clickIfExists.
	 *
	 * @param element MobileElement
	 */
	public boolean isElementVisible(WebElement element, int timeOutInSeconds) {
		try {
			return wait.withTimeout(Duration.ofSeconds(timeOutInSeconds)).
					until(ExpectedConditions.visibilityOf(element)) != null;
		} catch (Exception e) {
			return false;
		}
	}


	/**
	 * Method to get the current browser type where the Test execution starts
	 * 
	 **/
	public BrowserTypeEnum getCurrentBrowser() {
		return TestExecutionContext.getInstance().getBrowserType();
	}

	/**
	 * Returns true if element is visible.
	 * 
	 * @param element
	 * @return isVisible
	 */
	protected boolean isElementVisible(WebElement element) {
		return element != null && element.isDisplayed();
	}

	/**
	 * Returns true if the element at locator exist and is visible.
	 * 
	 * @param locator
	 * @return isVisible
	 */
	protected boolean isElementVisible(By locator) {
		try {
			WebElement e = driver.findElement(locator);
			return isElementVisible(e);
		} catch (NoSuchElementException e) {
			s_logger.info("Element doesn't exist: {}", locator);
		}
		return false;
	}

	/**
	 * Returns the URL that web driver is looking at.
	 * 
	 * @return currentUrl
	 */
	public String getCurrentUrl() {
		return driver.getCurrentUrl();
	}

	/**
	 * Inject external javascript to the current page.
	 * 
	 * @param url - url for the javascript file to be injected to page.
	 */
	protected void injectJavaScriptInPage(String url) {
		String includeScript = String.format("var scriptTag = document.createElement(\"script\");"
				+ " scriptTag.setAttribute(\"type\", \"text/javascript\");"
				+ " scriptTag.setAttribute(\"src\", \"%s\");" + "document.body.appendChild(scriptTag);", url);
		((JavascriptExecutor) driver).executeScript(includeScript);
	}

	/**
	 * Takes a full page screenshot (only used for visual testing)
	 * 
	 */
	public File captureScreenshotAndGetFile() {
		File screen = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		return screen;
	}

	public String getName() {
		return visualTestingPageName;
	}

	public void setName(String name) {
		this.visualTestingPageName = name;
	}

	public BigDecimal round(float d, int decimalPlace) {
		BigDecimal bd = new BigDecimal(Float.toString(d));
		bd = bd.setScale(decimalPlace, BigDecimal.ROUND_HALF_UP);
		return bd;
	}

	public void scrollTo(WebElement element) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].scrollIntoView();", element);
		}catch(Exception e) {
			scrollPage(element);
		}
	}

	public void scrollToAndClick(WebElement element) {
		scrollPage(element);
		customClick(element,driver,10);
	}


	/**
	* Element highlighter code
	* @param element - element in the page you want to highlight
	*/

	public void highLightElement(WebElement element) {
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid blue;');", element);
		try {
			Thread.sleep(1000);
		}
		catch (InterruptedException e) {
			System.out.println(e.getMessage());
		}
		js.executeScript("arguments[0].setAttribute('style','border: solid 2px blue');", element);
	}

	/**
	 * Performs click on an element using JavascriptExecutor
	 * @param element - element in the page on which click operation needs to be performed.
	 * @throws Exception
	 */
	public void jsClick(WebElement element) throws Exception {
		try {
			if (element.isEnabled() && element.isDisplayed()) {
				System.out.println("Clicking on element using java script click");
				highLightElement(element);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
			} else {
				System.out.println("Unable to click on element");
			}
		} catch (StaleElementReferenceException e) {
			System.out.println("Element is not attached to the page document " + e.getStackTrace());
		} catch (NoSuchElementException e) {
			System.out.println("Element was not found in DOM " + e.getStackTrace());
		} catch (Exception e) {
			System.out.println("Unable to click on element " + e.getStackTrace());
		}
	}

	//this method will be used to use dynamic xpaths in page factory model
	public WebElement prepareWebElementWithDynamicXpath (String xpathValue, String substitutionValue ) {
		return driver.findElement(By.xpath(xpathValue.replace("{0}", substitutionValue)));
	}

	//this method will be used to use dynamic xpaths in page factory model
	public WebElement prepareWebElementWithDynamicXpath (String xpathValue ) {
		return driver.findElement(By.xpath(xpathValue));
	}

	public boolean isWebElementDisplayed(WebElement element) {
		s_logger.info("Verifying nutritionalPanel is displayed or not");
		boolean resultFlag = false;
		try {
			resultFlag = element.isDisplayed();
		} catch (NoSuchElementException ignored) {
			resultFlag = false;
		}
		return resultFlag;
	}

	public boolean isWebElementDisplayed(WebElement element, int timeOut) {
		s_logger.info("Verifying nutritionalPanel is displayed or not");
		boolean resultFlag = false;
		try {
			resultFlag = FluentWaitImplicit.waitForElementToLoadWithCustomWait(element,driver,timeOut);
		} catch (Exception e) {
			resultFlag = false;
		}
		return resultFlag;
	}

	//this is the generic navigation method in taxonomy
	public void performGenericNavigation(String navigationStr, Actions actions) {
		String[] indNavigation = navigationStr.split(">");
		customClick(groceriesMenu, driver, 10);
		for (int i = 0; i < indNavigation.length; i++) {
			actions.moveToElement(prepareWebElementWithDynamicXpath(taxonomyLevel, indNavigation[i].trim())).perform();
			MigrationUtil.unconditionalWait(3000); //intentional wait to control the speed
			if (i == indNavigation.length - 1) {
				customClick(prepareWebElementWithDynamicXpath(taxonomyLevel, indNavigation[i].trim()), driver, 10);
			}
		}
	}

	public int WebElementStatus(List<WebElement> elementList) {
		return elementList.size();
	}


}
