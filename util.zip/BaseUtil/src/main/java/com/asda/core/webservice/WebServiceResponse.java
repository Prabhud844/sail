package com.asda.core.webservice;

import org.apache.http.Header;

/**
 * Web Service response holder.
 * 
 * @author jkandul
 *
 */
public class WebServiceResponse {

	private int responseCode;
	private String responseBody;
	private final ResponseHeaders responseHeaders = new ResponseHeaders();
	
	public int getResponseCode() {
		return responseCode;
	}
	void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseXml() {
		return getResponseBody();
	}
	void setResponseXml(String responseXml) {
		setResponseBody(responseXml);
	}
	public ResponseHeaders getResponseHeaders() {
		return responseHeaders;
	}
	void setResponseHeaders(Header[] headers) {
		this.responseHeaders.setResponseHeaders(headers);
	}
	public String getResponseBody() {
		return responseBody;
	}
	void setResponseBody(String responseBody) {
		this.responseBody = responseBody;
	}
}
