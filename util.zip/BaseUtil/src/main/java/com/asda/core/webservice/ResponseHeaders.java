package com.asda.core.webservice;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Container class to hold all response headers.
 * 
 * @author jkandul
 *
 */
public class ResponseHeaders {

	private List<ResponseHeader> responseHeaders;

	public List<ResponseHeader> getResponseHeaders() {
		return Collections.unmodifiableList(responseHeaders);
	}

	/**
	 * Get header value for the corresponding header. 
	 * If header is not found null would be returned.
	 * 
	 * @param name
	 * @return
	 */
	public String getResponseHeaderValue(String name) {
		for (ResponseHeader header : responseHeaders) {
			if (header.getName().equals(name)) {
				return header.getValue();
			}
		}
		return null;
	}

	/**
	 * Get header values for the corresponding header. 
	 * If header is not found empty list would be returned.
	 * 
	 * @param name
	 * @return
	 */
	public List<String> getResponseHeaderValues(String name) {
		List<String> values = new ArrayList<String>();
		for (ResponseHeader header : responseHeaders) {
			if (header.getName().equals(name)) {
				values.add(header.getValue());
			}
		}
		return values;
	}
	
	/**
	 * Get cookie value for the corresponding cookieName. 
	 * Cookie header is being searched by checking for headers with name Set-Cookie and cookie name/value is extracted from it. 
	 * 
	 * @param cookieName
	 * @return
	 */
	public String getCookieValueFromResponseHeader(String cookieName) {
		for (ResponseHeader header : responseHeaders) {
			// Check for all headers which have header name as Set-Cookie.
			if (header.getName().equalsIgnoreCase("Set-Cookie")) {
				String cookieString = header.getValue();
				if(cookieString.indexOf(";") > 0) {
					cookieString = cookieString.substring(0, cookieString.indexOf(";"));
				}
				int delIdx = cookieString.indexOf("=");
				// Check if cookie is same as in request.
				if(delIdx > 0 && cookieString.substring(0, delIdx).equals(cookieName)) {
					if(delIdx+1 < cookieString.length()) {
						return cookieString.substring(delIdx+1);
					} else {
						return ""; // Value is empty.
					}
				}
			}
		}
		return null;
	}
	

	/**
	 * Set the response headers.
	 * 
	 * @param responseHeaders
	 */
	void setResponseHeaders(List<ResponseHeader> responseHeaders) {
		this.responseHeaders = responseHeaders;
	}

	/**
	 * Set response headers. only required details (name & value) from the Header are being presisted.
	 * 
	 * @param headers
	 */
	void setResponseHeaders(Header[] headers) {
		this.responseHeaders = new ArrayList<ResponseHeader>();
		for (int i = 0; i < headers.length; i++) {
			responseHeaders.add(new ResponseHeader(headers[i].getName(), headers[i].getValue()));
		}
	}
	
	@Override
	public String toString() {
		return "Response Headers: " + responseHeaders;
	}

}