package com.asda.core.baseexecution;

import com.asda.core.enums.BrowserTypeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

/**
 * This class holds the information related to currently running test.
 * 
 * Currently it holds the browser in which test is running, and path where logs are saved.
 * 
 * @author jkandul
 *
 */
public class TestExecutionContext {

	private static final Logger s_logger = LoggerFactory.getLogger(TestExecutionContext.class);
	private static final TestExecutionContext s_instance = new TestExecutionContext();
	private static final ThreadLocal<TestExecutionCtx> ctx = new InheritableThreadLocal<TestExecutionCtx>();
	
	/**
	 * Initialize the context with values related to current test
	 * 
	 * @param browser
	 * @param pathToTestLogs
	 * @param relativePathInSuite
	 */
	void initializeContext(BrowserTypeEnum browser, String pathToTestLogs, String relativePathInSuite) {
		clearContext();
		s_logger.info("Initialization test execution context with, browser:{} pathToTestLogs: {} relativePathInSuite:{}", browser, pathToTestLogs, relativePathInSuite);
		ctx.set(new TestExecutionCtx(browser, pathToTestLogs, relativePathInSuite));
	}
	
	void clearContext() {
		ctx.remove();
	}
	
	/**
	 * Returns the instance of this class
	 * 
	 * @return
	 */
	public static TestExecutionContext getInstance() {
		return s_instance;
	}
	
	private class TestExecutionCtx {
		private final BrowserTypeEnum browser;
		private final String pathToTestLogs;
		private final String relativePathInSuite;
		
		public TestExecutionCtx(BrowserTypeEnum browser, String pathToTestLogs, String relativeLogPathInSuite) {
			this.browser = browser;
			this.pathToTestLogs = pathToTestLogs;
			this.relativePathInSuite = relativeLogPathInSuite;
		}

		public BrowserTypeEnum getBrowser() {
			return browser;
		}

		public String getPathToTestLogs() {
			return pathToTestLogs;
		}

		public String getRelativeLogPathInSuite() {
			return relativePathInSuite;
		}

	}
	
	/**
	 * Get the browserType where test is running on.
	 * 
	 * @return
	 */
	public BrowserTypeEnum getBrowserType() {
		return getContext().getBrowser();
	}
	
	/**
	 * Get the full path of folder where logs are saved for this test execution.
	 * 
	 * @return
	 */
	public String getPathToTestLogs() {
		return getContext().getPathToTestLogs();
	}
	
	/**
	 * Get relative path with in the suite for this test execution.
	 * 
	 * @return
	 */
	public String getRelativeLogPathInSuite() {
		return getContext().getRelativeLogPathInSuite();
	}
	
	private TestExecutionCtx getContext() {
		if(ctx.get() == null) {
			s_logger.error("Test execution context not initialized.");
			Assert.fail("Attempting to retrieve context which is not initialized yet.");
		}
		return ctx.get();
	}
}
