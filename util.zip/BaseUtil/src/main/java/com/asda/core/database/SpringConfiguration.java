package com.asda.core.database;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.env.MapPropertySource;


/**
 * @author jkandul
 *
 */
public class SpringConfiguration {

	private static SpringConfiguration s_instance;
	
	private ApplicationContext appContext = null;
	
	private SpringConfiguration(ApplicationContext ctx) {
		appContext = ctx;
	}
	
	public static void init(String environment) {
		Map<String, Object> envMap = new HashMap<String, Object>();
		envMap.put("envPlaceHolder", environment);
		MapPropertySource mockProperty = new MapPropertySource("customProps", envMap);
		ClassPathXmlApplicationContext newContext = new ClassPathXmlApplicationContext();
		newContext.getEnvironment().getPropertySources().addFirst(mockProperty);
		newContext.refresh();
		s_instance =  new SpringConfiguration(newContext);
	}
	
	public static ApplicationContext getApplicationContext() {

		
		return s_instance.appContext;
	}

}
