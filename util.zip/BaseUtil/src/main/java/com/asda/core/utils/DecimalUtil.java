package com.asda.core.utils;

import java.text.DecimalFormat;

public class DecimalUtil {
    public static double getDecimal(double d){
        DecimalFormat df2 = new DecimalFormat("#.##");
        return Double.parseDouble(df2.format(d));
    }
}