package  com.asda.core.reporters.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class TestSummaryInfo {
	private static final Logger s_logger = LoggerFactory
			.getLogger(TestSummaryInfo.class);
//=<Members>================================================================================
	private String testRunID =null;//PRIMARY KEY '2011-03-23_04-01-43-421'
	private String host=null;//
	private String qaEnv=null;//
	private String track=null;//
	private String releaseNumber=null;//
	private String type=null;//
	private String startTime=null;//
	private String endTime=null;//
	private Integer minTestsToExecute=null;
	private String jobUrl;
	private String comments;
	private Integer attemptNumber;
	private String reportInsertion="DB";
	private String appName=null;
	private String tcr_flag="false";
	
//=<Constructors>============================================================================
    public TestSummaryInfo(){
    }
//=<Methods>================================================================================
// Getters---------------------------------------------------------------------------------
    public String getTestRunID(){
		return testRunID;
	}
    public String getReportInsertion(){
		return reportInsertion;
	}
	public String getHost(){
		return host;
	}
	public String getQAEnv(){
		s_logger.info("!!!!!!!!!!!!!!!Returning qa env value" + qaEnv);
		return qaEnv;
	}
	public String getTrack(){
		return track;
	}
	public String getReleaseNumber(){
		return releaseNumber;
	}
	public String getType(){
		return type;
	}
	public String getStartTime(){
	return startTime;
	}	
	public String getEndTime(){
		return endTime;
	}
	
	public String getAppName(){
		return appName;
	}

//setters------------------------------------------------------------------------
	public void setTestRunID(String s){
		testRunID = s;
	}
	public void setReportInsertion(String s){
		reportInsertion = s;
	}
	
	
	public void setHost(String s){
		host = s;
	}
	public void setQAEnv(String s){
		s_logger.info("!!!!!!!!!!!!!!!Setting qa env value" + s);
		qaEnv = s;
	}
	public void setTrack(String s){
		track= s;
	}
	public void setReleaseNumber(String s){
		releaseNumber = s;
	}
	public void setType(String s){
		type =s;
	}
	public void setStartTime(String s){
		startTime = s ;
	}	
	public void setEndTime(String s){
		endTime =s;
	}
	public Integer getMinTestsToExecute() {
		return minTestsToExecute;
	}
	public void setMinTestsToExecute(Integer minTestsToExecute) {
		this.minTestsToExecute = minTestsToExecute;
	}
	public String getJobUrl() {
		return jobUrl;
	}
	public void setJobUrl(String jobUrl) {
				this.jobUrl = jobUrl;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}

	public Integer getAttemptNumber() {
		return attemptNumber;
	}
	public void setAttemptNumber(Integer attemptNumber) {
		this.attemptNumber = attemptNumber;
	}
	
	public void setAppName(String appNameVal) {
		this.appName = appNameVal;
	}

	public String getTcr_flag() {
		return tcr_flag;
	}

	public void setTcr_flag(String tcr_flag) {
		this.tcr_flag = tcr_flag;
	}
}
