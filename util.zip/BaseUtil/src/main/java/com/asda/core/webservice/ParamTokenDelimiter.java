package com.asda.core.webservice;

import com.asda.core.utils.Utility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * 
 * Token delimiter class used in creating request with place holders.
 * 
 * There would be a start delimiter and end delimiter separated by a space.
 * 
 * @author jkandul
 *
 */
public class ParamTokenDelimiter {

	private static final Logger s_logger = LoggerFactory.getLogger(ParamTokenDelimiter.class);
	private static final String DEFAULT_DYNAMIC_PARAM_DELIMITER = "{ }";
	
	/**
	 * Default token delimiter with '{' as start token and '}' as end token. 
	 */
	public static final ParamTokenDelimiter DEFAULT_TOKEN_DELIMITER = new ParamTokenDelimiter("");

	private final String delimiterString;
	private final String startDelimiter;
	private final String endDelimiter;
	
	/**
	 * Start and End token should be separated by a space. <br/><br/>
	 * Eg: <br/>
	 * ParamTokenDelimiter defaultDel = new ParamTokenDelimiter(""); // Uses
	 * "{ }" as delimiter, use ParamTokenDelimiter.DEFAULT_TOKEN_DELIMITER
	 * instead. <br/>
	 * ParamTokenDelimiter atDel = new ParamTokenDelimiter("@# #@");
	 * 
	 * <br/><br/>
	 * Throws IllegalArgumentException if no of tokens is not 2 when split by space.
	 * 
	 * @param delimiterString
	 */
	public ParamTokenDelimiter(String delimiterString) {
		if(Utility.StringUtility.isEmpty(delimiterString)) {
			delimiterString = DEFAULT_DYNAMIC_PARAM_DELIMITER;
		}
		String[] tokens = delimiterString.split(" ");
		if(tokens.length != 2 ) {
			throw new IllegalArgumentException("Invalid param delimieter passed:" + delimiterString);
		}
		this.delimiterString = delimiterString;
		startDelimiter = tokens[0];
		endDelimiter = tokens[1];
	}
	
	public String getDelimiterString() {
		return delimiterString;
	}

	public String getStartDelimiter() {
		return startDelimiter;
	}
	
	public String getEndDelimiter() {
		return endDelimiter;
	}
	
	/**
	 * Identify the tokens in request string based on token delimiter.
	 * 
	 * @param requestString
	 * @param tokenDel
	 * @return
	 */
	public static List<String> getVariables(String requestString, ParamTokenDelimiter tokenDel) {
		List<String> variables = new ArrayList<String>();
		int startIndex = 0;
		int endIndex = requestString.length();
		int i = startIndex;
		int startDelimiterSize = tokenDel.getStartDelimiter().length();
		int endDelimiterSize = tokenDel.getEndDelimiter().length();
		while(i<endIndex) {
			int paramStartIndex = requestString.indexOf(tokenDel.getStartDelimiter(), i);
			if(paramStartIndex < 0 || paramStartIndex >= endIndex) {
				break;
			}
			int paramEndIndex = requestString.indexOf(tokenDel.getEndDelimiter(), paramStartIndex);
			if(paramEndIndex < 0 || paramEndIndex >= endIndex) {
				break; // Invalid format
			}
			String var = requestString.substring(paramStartIndex+startDelimiterSize, paramEndIndex);
			if(!variables.contains(var)) {
				variables.add(var);
			}
			i = paramEndIndex + endDelimiterSize;
		}
		return variables;
	}

	/**
	 * Replaces the tokens in tokenDataMap with corresponding values of map and
	 * returns updated value. If there are unmapped tokens those would be
	 * replaced with empty string.
	 * 
	 * @param inputString
	 * @param tokenDel
	 * @param tokenDataMap
	 * @return
	 */
	public static String getReplacedString(String inputString, ParamTokenDelimiter tokenDel,
			Map<String, String> tokenDataMap) {

		String startDelimiterEscaped = Utility.StringUtility.escapeRegex(tokenDel.getStartDelimiter());
		String endDelimiterEscaped = Utility.StringUtility.escapeRegex(tokenDel.getEndDelimiter());
		for (Entry<String, String> wsKeyValue : tokenDataMap.entrySet()) {
			String key = wsKeyValue.getKey();
			String value = wsKeyValue.getValue();
			if (value == null) {
				value = "";
			} else if (value.contains("$")) {
				value = value.replaceAll("\\$", "\\\\\\$");
			}
			inputString = inputString.replaceAll(startDelimiterEscaped + key + endDelimiterEscaped, value);
		}
		
		s_logger.info("Replaced value: {}", inputString);
		
		// Replacing unmapped dynamic values with empty string.
		List<String> remainingVars =  getVariables(inputString, tokenDel);
		if(remainingVars.size() > 0) {
			s_logger.error("Dynamic placeholders left with out values: {} will be replaced with empty string.", remainingVars);
			for (String key : remainingVars) {
				inputString = inputString.replaceAll(startDelimiterEscaped + key + endDelimiterEscaped, "");
			}	
			s_logger.info("Replaced value after removing unmapped tokens: {}", inputString);
		}
		return inputString;
	}
}
