package com.asda.core.webservice;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.HttpResponseException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.protocol.RequestAcceptEncoding;
import org.apache.http.client.protocol.ResponseContentEncoding;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHttpResponse;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class GenericWebServiceClient {
	
	private final int connectionTimeout;
	private final int socketTimeout;

	/**
	 * Create GenericWebServiceClient with given connection and socket time out.
	 * 
	 * @param connectionTimeout
	 * @param socketTimeout
	 */
	public GenericWebServiceClient(int connectionTimeout, int socketTimeout) {
		this.connectionTimeout = connectionTimeout;
		this.socketTimeout = socketTimeout; 
	}

	/**
	 * Create GenericWebServiceClient with default connection and socket time out.
	 */
	public GenericWebServiceClient() {
		this.connectionTimeout = 60000;
		this.socketTimeout = 60000; 
	}
	
	private static final String HTTP_RESPONSE_ATTR_TAG = "http.response";
	private static final String SOAP_ACTION = "SOAPAction";
	private static final String WS_REQ_CHARSET = "text/xml;charset=utf-8";
	
	private static final String WS_XML_REQ_CHARSET = "application/xml;charset=utf-8";
	private static final String WS_JSON_REQ_CHARSET = "application/json;charset=utf-8";
	
	private static final Logger s_logger = LoggerFactory.getLogger(GenericWebServiceClient.class);

	/**
	 * Trigger SOAP call.
	 * 
	 * Uses empty string for SOAPAction
	 * 
	 * @param serviceUrl
	 * @param requestXml
	 * @param headersMap
	 * @return
	 * @throws WebServiceException
	 */
	public WebServiceResponse invokeSOAPCall(String serviceUrl, String requestXml, Map<String, String> headersMap) throws WebServiceException {
		return invokeSOAPCall(serviceUrl, requestXml, headersMap, "");
	}

	/**
	 * Trigger SOAP call.
	 * 
	 * @param serviceUrl
	 * @param requestXml
	 * @param headersMap
	 * @param soapAction
	 * @return
	 * @throws WebServiceException
	 */
	public WebServiceResponse invokeSOAPCall(String serviceUrl, String requestXml, Map<String, String> headersMap, String soapAction) throws WebServiceException {
		return invokeWebServiceInternal(serviceUrl, requestXml, new HashMap<String, String>(), headersMap, WebServiceType.SOAP, soapAction);
	}

	/**
	 * Invoke web service call based on the WebServiceType passed in.
	 * 
	 * @param serviceUrl
	 * @param requestXml
	 * @param headersMap
	 * @param serviceType
	 * @param postParams
	 * @return
	 * @throws WebServiceException
	 */
	public WebServiceResponse invokeWsCall(String serviceUrl, String requestXml, Map<String, String> headersMap, WebServiceType serviceType, Map<String, String> postParams) throws WebServiceException {
		return invokeWebServiceInternal(serviceUrl, requestXml, postParams, headersMap, serviceType, "");
	}
	
	private WebServiceResponse invokeWebServiceInternal(String serviceUrl, String requestBody, Map<String, String> postParams, Map<String, String> headersMap, WebServiceType serviceType, String soapAction) throws WebServiceException {
		WebServiceResponse soapResponse = new WebServiceResponse();
		try {
			s_logger.info("ServiceURL: " + serviceUrl);
			HttpRequestBase httpMethod = getRequestMethod(serviceUrl, serviceType);
			s_logger.info("Request Body: " + requestBody);
			s_logger.info("Request Body: " + postParams);
			if(serviceType == WebServiceType.SOAP) {
				StringEntity entity = new StringEntity(requestBody);
				entity.setContentType(WS_REQ_CHARSET);
				((HttpPost)httpMethod).setEntity(entity);
				httpMethod.addHeader(SOAP_ACTION, soapAction);
			} else if(serviceType == WebServiceType.PUT_XML) {
				StringEntity entity = new StringEntity(requestBody);
				entity.setContentType(WS_XML_REQ_CHARSET);
				((HttpPut)httpMethod).setEntity(entity);
			} else if(serviceType == WebServiceType.PUT_JSON) {
//				 StringEntity entity =new StringEntity(requestBody,"UTF-8");
//				 entity.setContentType("application/json");
//					((HttpPut)httpMethod).setEntity(entity);
				if(!postParams.isEmpty()) {
					List<BasicNameValuePair> parameters = new ArrayList<BasicNameValuePair>();
					for(Entry<String, String> paramVal : postParams.entrySet()) {
						BasicNameValuePair nameVal = new BasicNameValuePair(paramVal.getKey(), paramVal.getValue());
						parameters.add(nameVal);
					}
					UrlEncodedFormEntity postEntity = new UrlEncodedFormEntity(parameters );
					((HttpPut)httpMethod).setEntity(postEntity);
				}

	        
			} else if(serviceType == WebServiceType.REST_POST_XML) {
				StringEntity entity = new StringEntity(requestBody);
				entity.setContentType(WS_XML_REQ_CHARSET);
				((HttpPost)httpMethod).setEntity(entity);
			} else if(serviceType == WebServiceType.REST_POST_JSON) {
//				StringEntity entity = new StringEntity(requestBody);
//				entity.setContentType(WS_JSON_REQ_CHARSET);
//				((HttpPost)httpMethod).setEntity(entity);				
				if(!postParams.isEmpty()) {
					List<BasicNameValuePair> parameters = new ArrayList<BasicNameValuePair>();
					for(Entry<String, String> paramVal : postParams.entrySet()) {
						BasicNameValuePair nameVal = new BasicNameValuePair(paramVal.getKey(), paramVal.getValue());
						parameters.add(nameVal);
					}
					UrlEncodedFormEntity postEntity = new UrlEncodedFormEntity(parameters );
					((HttpPost)httpMethod).setEntity(postEntity);
				}
			} else if(serviceType == WebServiceType.REST_POST) {
				if(!postParams.isEmpty()) {
					List<BasicNameValuePair> parameters = new ArrayList<BasicNameValuePair>();
					for(Entry<String, String> paramVal : postParams.entrySet()) {
						BasicNameValuePair nameVal = new BasicNameValuePair(paramVal.getKey(), paramVal.getValue());
						parameters.add(nameVal);
					}
					UrlEncodedFormEntity postEntity = new UrlEncodedFormEntity(parameters );
					((HttpPost)httpMethod).setEntity(postEntity);
				}
			}
			
			for (Entry<String, String> header : headersMap.entrySet()) {
				s_logger.info("Req-Header-  " + header.getKey() +  " : " + header.getValue());
				httpMethod.addHeader(header.getKey(), header.getValue());
			}

			// Get HTTP client
			BasicHttpParams params = new BasicHttpParams();
			params.setIntParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, getConnectionTimeout()); // Connection timeout in milliseconds
			params.setIntParameter(CoreConnectionPNames.SO_TIMEOUT, getSocketTimeout()); // Time b/w consecutive packets in milliseconds
			
			HttpClient httpclient = getHttpClient(params);
			HttpContext httpContext = new BasicHttpContext();

			// Execute request
			ResponseHandler<String> response = new BasicResponseHandler() {
				@Override
				public String handleResponse(HttpResponse response) throws IOException {
					StatusLine statusLine = response.getStatusLine();
					if(statusLine.getStatusCode() < 400) {
						return super.handleResponse(response);
					}
					HttpEntity entity = response.getEntity();
					return entity == null ? null : EntityUtils.toString(entity);
				}
			};
			String responseXml = httpclient.execute(httpMethod, response, httpContext);

			// Set response
			BasicHttpResponse baseRes = (BasicHttpResponse) httpContext.getAttribute(HTTP_RESPONSE_ATTR_TAG);
			soapResponse.setResponseCode(baseRes.getStatusLine().getStatusCode());
			soapResponse.setResponseBody(responseXml);
			if (baseRes.getAllHeaders() != null) {
				soapResponse.setResponseHeaders(baseRes.getAllHeaders());
			}
			
			s_logger.info("Response code: {}", soapResponse.getResponseCode());
			s_logger.info("Response Body: {}", soapResponse.getResponseXml());
			s_logger.info("Response headers: {}", soapResponse.getResponseHeaders());
		} catch (UnsupportedEncodingException e) {
			s_logger.info("Error exeucting web service.");
			throw new WebServiceException(e);
		} catch (ClientProtocolException e) {
			s_logger.info("Error exeucting web service.");
			throw new WebServiceException(e);
		} catch (IOException e) {
			s_logger.info("Error exeucting web service.");
			throw new WebServiceException(e);
		}

		return soapResponse;
	}

	private HttpRequestBase getRequestMethod(String serviceUrl, WebServiceType serviceType) {
		if(serviceType == WebServiceType.REST_GET) {
			return new HttpGet(serviceUrl);
		}
		if(serviceType == WebServiceType.REST_DELETE) {
			return new HttpDelete(serviceUrl);
		}
		if(serviceType == WebServiceType.PUT_XML
				|| serviceType == WebServiceType.PUT_JSON
				) {
		
			return new HttpPut(serviceUrl);
			
		}
		if(serviceType == WebServiceType.REST_POST_JSON)
		{
			return new HttpPost(serviceUrl);
		}
		
		if(serviceType == WebServiceType.REST_POST)
		{
			return new HttpPost(serviceUrl);
		}
		return new HttpPost(serviceUrl);
	}
	
	private int getSocketTimeout() {
		return socketTimeout;
	}

	private int getConnectionTimeout() {
		return connectionTimeout;
	}

	private static HttpClient getHttpClient(BasicHttpParams params) throws WebServiceException {
		DefaultHttpClient base = new DefaultHttpClient(params);
		base.addRequestInterceptor(new RequestAcceptEncoding());
		base.addResponseInterceptor(new ResponseContentEncoding());
	    try {
	        SSLContext ctx = SSLContext.getInstance("TLS");
	        X509TrustManager tm = new X509TrustManager() {
	            public void checkClientTrusted(X509Certificate[] xcs, String string) throws CertificateException { }
	 
	            public void checkServerTrusted(X509Certificate[] xcs, String string) throws CertificateException { }
	 
	            public X509Certificate[] getAcceptedIssuers() {
	                return null;
	            }
	        };
	        ctx.init(null, new TrustManager[]{tm}, null);
	        SSLSocketFactory ssf = new SSLSocketFactory(ctx, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
	        ClientConnectionManager ccm = base.getConnectionManager();
	        SchemeRegistry sr = ccm.getSchemeRegistry();
	        sr.register(new Scheme("https", 443, ssf));
	        DefaultHttpClient finalClient = new DefaultHttpClient(ccm, params);
	        finalClient.addRequestInterceptor(new RequestAcceptEncoding());
	        finalClient.addResponseInterceptor(new ResponseContentEncoding());
	        return finalClient;
	    } catch (Exception ex) {
			throw new WebServiceException(ex);
	    }
	}
}