package com.asda.core.enums;

public enum SystemVariableEnum {
	TEST_ENV("test.env"),
	SELENIUM_URL("selenium.url"),
	EXECUTION_TRACK("execution.track"),
	EXECUTION_RELEASE("execution.release"),
	EXECUTION_TYPE("execution.type"),
	JENKINS_ENV_BUILD_URL("BUILD_URL"),
	TEST_RUN_ID("test.runid"),
	TEST_PUBLISH_REPORTS("test.publishreports"),
	IS_FAILED_SUITE_RUN("isFailedSuiteRun"),
	GENERATE_RUN_ID_FILE("generateRunIdFile"),
	SELENIUM_BROWSER("selenium.browser"),
	TEST_REPORTSERVICE("test.ReportService"),
	ISADDCOOKIES("isAddCookies"),
	COOKIEVALUE("cookieValue"),
	APPNAME("appName"),
	TCRFLAG("tcr.flag")
	;

	private final String sysVarName;
	
	SystemVariableEnum(String sysVarNameIn) {
		this.sysVarName = sysVarNameIn;
	}

	public String getSysVarName() {
		return sysVarName;
	}
	
	
}
