package com.asda.core.baseexecution;

import com.asda.core.database.SpringConfiguration;
import com.asda.core.reporters.ReportListener;
import com.asda.core.reporters.beans.ReportThreadLocal;
import com.asda.core.utils.MigrationUtil;
import com.asda.core.utils.SeleniumWebDriverUtility;
import com.asda.qa.environment.EnvironmentConfig;
import com.asda.qa.utility.FluentWaitImplicit;
import com.asda.qa.utility.GeneralUtility;

import java.lang.reflect.Method;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;


/**
 * Base Class for all frontend tests.
 * <p>
 * Takes care of initializing environment configuration and database
 * configuration and starting browser.
 *
 * @author jkandul
 */
public abstract class BaseASDAFrontEndTest extends BaseFrontEndTest {

    private static final Logger s_logger = LoggerFactory.getLogger(BaseASDAFrontEndTest.class);
    private static final Exception NullPointerException = null;
    public static boolean browseApp;
    public static String APP_NAME = null;

    @Override
    protected void initEnvironment(String env) {
        s_logger.info("Initilizing environment {} for tests.", env);
        EnvironmentConfig.initEnvironment(env);
        env = EnvironmentConfig.getInstance().getCurrentEnvironment();
        s_logger.info("Initilizing db environment {} for tests.", env);
        //EnvironmentXpath.xpathInitialization();
        SpringConfiguration.init(env);

    }

    @Override
    @BeforeMethod(alwaysRun = true)
    @Parameters({"selenium.url", "selenium.browser", "islocalrun", "selenium.browser.version", "selenium.platform",
            "selenium.platform.version", "doVideoRecoring", "port", "enableBrowsermob", "isAppium", "ssoAccount",
            "viewPort", "isRecipe", "appName", "isInternalApp", "usePerfUserAgent"})
    public void beforeTest(String seleniumUrl, String browser, @Optional("false") boolean localrun,
                           @Optional("") String browserVersion, @Optional("ANY") String os, @Optional("") String osVersion,
                           @Optional("no") String doVideoRecording, @Optional("1234") int portNo,
                           @Optional("false") boolean enableBrowsermob, @Optional("false") boolean isAppium,
                           @Optional("true") boolean ssoAccount, @Optional("large") String viewPort, @Optional("false") boolean isRecipe,
                           @Optional("false") String appName, @Optional("false") boolean isInternalApp,
                           @Optional("false") String usePerfUserAgent, Method testMethod, ITestContext context, Object[] methodParams)
            throws Exception {
        System.out.println("Environment variables" + seleniumUrl + "----" + browser + "----" + localrun);

        final String cookieValueDelimiter = ":";
        boolean isAddCookies = false;
        String cookiesFromSuiteFile = "";
        APP_NAME = context.getCurrentXmlTest().getParameter("aut.url");
        String cookieValue = "";
        // Boolean flag=true;
        s_logger.info("Calling the super class's beforeTest");
        super.beforeTest(seleniumUrl, browser, localrun, browserVersion, os, osVersion, osVersion, portNo,
                enableBrowsermob, isAppium, ssoAccount, viewPort, isRecipe, appName, isInternalApp, usePerfUserAgent, testMethod, context, methodParams);
        // printSessionId();

 if (isInternalApp)
        {
            String finalUrl =
                    String.format(
                            "https://%1$s:%2$s@%3$s",
                            EnvironmentConfig.getInstance().getAlertUserName(),
                            EnvironmentConfig.getInstance().getAlert(),
                            EnvironmentConfig.getInstance().getHomePageUrl().split("//")[1]);
            getWebDriverHolder().get().get(finalUrl);
        }

        s_logger.info("Completed calling the super class's beforeTest");
        com.asda.qa.utility.SeleniumWebDriverUtility.getJSessionValue(getWebDriverHolder().get());
        try {
            if (!localrun) {
                getRemoteSessionid();
            }
        } catch (Exception e) {
            s_logger.info("Unable to update Sauce session id");
        }
        try {

            try {
                s_logger.info("Checking if requested is recipe site");
                boolean isRecipeUnderTest = Boolean
                        .parseBoolean(context.getSuite().getXmlSuite().getParameter("isRecipe"));
                if (isRecipeUnderTest) {
                    String recipeSiteSpectUrl = EnvironmentConfig.getInstance().getBrowseApp_RecipeSiteSpecUrl();
                    getWebDriverHolder().get().get(recipeSiteSpectUrl);
                    SeleniumWebDriverUtility.waitForPageLoad(getWebDriverHolder().get());
                }
            } catch (Exception ee) {

            }

            s_logger.info("trying to see if we need to add cookie as per the configuration in suite file");
            s_logger.info("Raw isAddCookies string from suite file is::" + context.getSuite().getXmlSuite());

            s_logger.info("values from jenkins -- " + ReportListener.getValueFromSystemProperties("isAddCookies", "")
                    + " cookie value -- " + ReportListener.getValueFromSystemProperties("cookieValue", ""));
            if (Boolean.parseBoolean(ReportListener.getValueFromSystemProperties("isAddCookies", ""))) {
                isAddCookies = Boolean.parseBoolean(ReportListener.getValueFromSystemProperties("isAddCookies", ""));
                cookiesFromSuiteFile = ReportListener.getValueFromSystemProperties("cookieValue", "");
                s_logger.info("Values passed from jenkins isAddCookies --" + isAddCookies + " & cookieValue is -- "
                        + cookiesFromSuiteFile);
            } else {
                s_logger.info("fetching cookie value for suite file");
                isAddCookies = Boolean.parseBoolean(context.getSuite().getXmlSuite().getParameter("isAddCookies"));
                cookiesFromSuiteFile = context.getCurrentXmlTest().getParameter("cookies");
                if (isAddCookies && StringUtils.isEmpty(cookiesFromSuiteFile)) {
                    cookiesFromSuiteFile = context.getSuite().getXmlSuite().getParameter("cookies");
                    s_logger.info(
                            "Cookie from Suite xml file --- " + context.getCurrentXmlTest().getParameter("cookies"));
                }
            }
            if (isAddCookies && cookiesFromSuiteFile.toUpperCase().contains("NAV_UI=TRUE")) {

                browseApp = true;

            }
            s_logger.info("Cookies passed from test xml file is::" + cookiesFromSuiteFile);
            s_logger.info("isAddCookies passed from suite file is::" + isAddCookies);
            try {
                com.asda.qa.utility.FluentWaitImplicit.waitForElemenAndClick(
                        getWebDriverHolder().get().findElement(By.xpath("//*[contains(text(),'Got It')]")),
                        getWebDriverHolder().get(), 5);

            } catch (Exception ele) {
                s_logger.info("Exception while trying to click Cookie Consent...");
            }

            s_logger.info("Checking if addCookies is true so that we can set the cookies");
            if (isAddCookies) {
                s_logger.info("As per parameter it is required to set the cookie");

                if (!cookiesFromSuiteFile.isEmpty() && cookiesFromSuiteFile != null && cookiesFromSuiteFile != "") {
                    s_logger.info("Cookie passed is not empty too. Hence will try set the cookies passed");

                    String[] cookieValueArray = cookiesFromSuiteFile.split(cookieValueDelimiter);

                    for (String eachCookieValue : cookieValueArray) {
                        try {
                            Cookie cookie = getWebDriverHolder().get().manage().getCookieNamed("asdaCookie");
                            getWebDriverHolder().get().manage().deleteCookie(cookie);
                            MigrationUtil.unconditionalWait(1000);
                            s_logger.info("Setting cookie::" + eachCookieValue.split("=")[0] + "="
                                    + eachCookieValue.split("=")[1]);
                            getWebDriverHolder().get().manage().addCookie(
                                    new Cookie(eachCookieValue.split("=")[0], eachCookieValue.split("=")[1]));

                        } catch (Exception e) {
                            MigrationUtil.unconditionalWait(1000);
                            s_logger.info("Setting cookie::" + eachCookieValue.split("=")[0] + "="
                                    + eachCookieValue.split("=")[1]);
                            getWebDriverHolder().get().manage().addCookie(
                                    new Cookie(eachCookieValue.split("=")[0], eachCookieValue.split("=")[1]));
                            cookieValue = eachCookieValue;
                        }
                    }
                    // The page has to be refreshed since in some cases we had
                    // to set the cookie after loading the url
//					if (ssoAccount && context.getSuite().getParameter("test.env").toString().toLowerCase()
//							.matches(".*(qa3|qa4|qa5).*")) {
//						getWebDriverHolder().get().get(EnvironmentConfig.getInstance().getSiteSpectUrl());
//					}
                    s_logger.info("Refreshing the page as the cookie has been added after Base Page is loaded");
                    getWebDriverHolder().get().navigate().refresh();

                    MigrationUtil.unconditionalWait(6000);
                    try {
                        com.asda.qa.utility.FluentWaitImplicit.waitForElemenAndClick(
                                getWebDriverHolder().get()
                                        .findElement(By.xpath("//button[contains(text(),'Accept Cookies')]")),
                                getWebDriverHolder().get(), 5);

                    } catch (Exception ele) {
                        s_logger.info("Exception while trying to click the new Cookie Consent...");
                    }
                    // validate if the code has
                    // flag=com.asda.qa.utility.SeleniumWebDriverUtility.validateCmsCode(cookieValue.replace("=",
                    // "_"),getWebDriverHolder().get());

                } else {
                    s_logger.info("isAddCookies is passed as true, but no cookie value is passed");
                    s_logger.warn("isAddCookies is passed as true, but no cookie value is passed");
                }
            } else {
                s_logger.info("isAddCookies is false. Not adding any cookie");
                s_logger.info("waiting for home page to load");
                // com.asda.qa.page.ASDAAnonymousUserHomePage homepage =
                // getPage(com.asda.qa.page.ASDAAnonymousUserHomePage.class);
//				if (browser.contains("INTERNETEXPLORER_11")) {
//					homepage.waitForElementToBeVisibleInIE(homepage
//							.getPostCodeBtnInHomeIntroContent());
//				} else {
//					homepage.waitForElementToBeVisible(homepage
//							.getPostCodeBtnInHomeIntroContent());
//				}
                s_logger.info("Home Page Loaded");
            }

            s_logger.info("********************************************* jession **********************************");

            com.asda.qa.utility.SeleniumWebDriverUtility.getJSessionValue(getWebDriverHolder().get());
            if (!seleniumUrl.contains("http://qaautomation63.homeoffice.wal-mart.com:4444/wd/hub")) {
                // getWebDriverHolder().get().manage().window().setSize(new
                // Dimension(1920, 1200));
                // s_logger.info("The browser window size is set to 1920 * 1200 to run in saus
                // labs");
                s_logger.info("size" + getWebDriverHolder().get().manage().window().getSize());
                getWebDriverHolder().get().switchTo().defaultContent();
            }

            // logic to click on cookie concent
            GeneralUtility.handleCookieconcent(getWebDriverHolder().get());
//			JavascriptExecutor jse = (JavascriptExecutor) getWebDriverHolder().get();
//			jse.executeScript("document.querySelector(submitCookieConsent());");

            Set<String> windows = getWebDriverHolder().get().getWindowHandles();
            if (windows.size() > 1) {
                // switch to main window
                for (String window : windows) {
                    String windowCurrentUrl = getWebDriverHolder().get().switchTo().window(window).getCurrentUrl();
                    if (windowCurrentUrl.equalsIgnoreCase(getBaseUrl())) {
                        getWebDriverHolder().get().switchTo().window(window);
                        break;
                    }
                }
            }

        } catch (Exception e) {
            s_logger.info("Exception occured when trying to set cookies.Will proceed");
            e.printStackTrace();
        }

    }

    //add specific cookie in the browser and refresh
    public static void addSpecificCookie(String cookieValue) {
        s_logger.info("Setting cookie::" + cookieValue.split("=")[0] + "="
                + cookieValue.split("=")[1]);
        getWebDriverHolder().get().manage().addCookie(
                new Cookie(cookieValue.split("=")[0], cookieValue.split("=")[1]));
        getWebDriverHolder().get().navigate().refresh();
        MigrationUtil.unconditionalWait(5000);
        s_logger.info("cookie set :::" + cookieValue.split("=")[0] + "="
                + cookieValue.split("=")[1]);
    }

    @Override
    protected String getBaseUrl() {
        s_logger.info("******************************* Base Logger :" + EnvironmentConfig.getInstance().getHomePageUrl());
        return EnvironmentConfig.getInstance().getHomePageUrl();
    }

    public void getRemoteSessionid() {
        String Sessionid = ((RemoteWebDriver) getWebDriverHolder().get()).getSessionId().toString();
        ReportThreadLocal.getReportBean().setTestInvType(Sessionid);
    }

}
