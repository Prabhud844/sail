package com.asda.core.utils;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utility {

	private static final Logger s_logger = LoggerFactory.getLogger(Utility.class);
	
	public static class NumberUtility {
		public static boolean isLong(String input) {
			try {
				Long.parseLong(input);
			} catch (NumberFormatException e) {
				return false;
			}
			return true;
		}
		public static boolean isInteger(String input) {
			try {
				Integer.parseInt(input);
			} catch (NumberFormatException e) {
				return false;
			}
			return true;
		}
		
		public static double getDouble(String input) {
			return Double.parseDouble(input);
		}
		
		public static long getLong(String input, long defaultValue) {
			try {
				return Long.parseLong(input);
			} catch (NumberFormatException e) {
				s_logger.error("Invalid number "+input, e);
				return defaultValue;
			}
		}

		public static int getInt(String input, int defaultValue) {
			try {
				return Integer.parseInt(input);
			} catch (NumberFormatException e) {
				s_logger.error("Invalid number "+input, e);
				return defaultValue;
			}
		}

	}
	public static class StringUtility {
		
		/**
		 * Concatenate variable strings and return the same. (null string will be replace with string "null")
		 * 
		 * @param strs
		 * @return
		 */
		public static String concatenateStrings(String... strs) {
			StringBuilder sb = new StringBuilder();
			for(int i = 0; i < strs.length; i++) {
				if(strs[i] == null) {
					sb.append("null");
				} else {
					sb.append(strs[i]);
				}
			}
			return sb.toString();
		}
		
		public static boolean isNotEmpty(String inputString) {
            return inputString != null && inputString.length() != 0 && !inputString.equalsIgnoreCase("null");
        }
		
		public static boolean isEmpty(String inputString) {
            return inputString == null || inputString.length() == 0 || inputString.equalsIgnoreCase("null");
        }
		
		public static String listToString(List<String> list){
			if(list == null || list.isEmpty()){
				return null;
			}
			StringBuffer buf = new StringBuffer();
			for(String str : list){
				if(str != null && str.trim().length() > 0){				
					buf.append(str);
					buf.append(",");
				}
			}
			if(buf.toString().length() > 0){
				return buf.toString();
			}else{
				return null;
			}
		}
		
		public static String mapToString(Map<String, ?> nameValues, Set<String> maskValuesForKeys) {
			if(nameValues == null || nameValues.size() == 0) {
				return null;
			}
			StringBuilder sb = new StringBuilder();
			sb.append("[");
			for(Entry<String, ?> entry : nameValues.entrySet()) {
				sb.append("{").append(entry.getKey()).append("=");
				if(maskValuesForKeys!=null && maskValuesForKeys.contains(entry.getKey())) {
					sb.append("***");
				} else if(entry.getValue() instanceof String) {
					sb.append(entry.getValue());
				} else if (entry.getValue() instanceof String[]){
					sb.append(convertToString((String[])entry.getValue()));
				} else {
					sb.append(entry.getValue().toString());
				}
				sb.append("}").append(",");
			}
			return sb.substring(0, sb.length()-1).concat("]");
		}

		private static String convertToString(String[] stringArray) {
			StringBuilder sb = new StringBuilder();
			sb.append("[");
			for(int i= 0; i < stringArray.length; i ++) {
				sb.append(stringArray[i]);
				if(i!=stringArray.length - 1 ) {
					sb.append(",");
				}
			}
			sb.append("]");
			return sb.toString();
		}
		
		public static boolean isNumeric(String string) {
			try {
				Double.parseDouble(string);
			} catch (Exception e) {
				return false;
			}
			return true;
		}
		
		public static String escapeXmlTagsForHTML(String inputString) {
			Map<String, String> replaceVals = new HashMap<String, String>();
			replaceVals.put("<", "&lt;");
			replaceVals.put(">", "&gt;");
			replaceVals.put("\"", "&quot;");
			return replaceTokens(inputString, replaceVals);
		}

		private static String replaceTokens(String inputString, Map<String, String> replaceVals) {
			String returnString = inputString;
			for(String key : replaceVals.keySet()) {
				returnString = returnString.replaceAll(escapeRegex(key), replaceVals.get(key));
			}
			return returnString;
		}
		
		public static String escapeUnsafeUrlCharacters(String url) {
			Map<String, String> replaceVals = new HashMap<String, String>();
			replaceVals.put(" ", "%20");
			replaceVals.put("\"", "%22");
			replaceVals.put("<", "%3C");
			replaceVals.put(">", "%3E");
			replaceVals.put("#", "%23");
			replaceVals.put("{", "%7B");
			replaceVals.put("}", "%7D");
			replaceVals.put("[", "%5B");
			replaceVals.put("]", "%5D");
			replaceVals.put("|", "%7C");
			return replaceTokens(url, replaceVals);
		}
		
		public static String escapeRegex(String s) {  
		    StringBuilder b = new StringBuilder();  
		    for(int i=0; i<s.length(); ++i) {  
		        char ch = s.charAt(i);  
		        if ("\\.^$|?*+[]{}()".indexOf(ch) != -1)  {
		            b.append('\\').append(ch);  
		        } else {  
		            b.append(ch);
		        }
		    }  
		    return b.toString();  
		} 
		
		public static boolean isVariableName(String s) { 
			return s.matches("[A-Za-z0-9_]*") && !s.matches("[0-9]*");
		}
		
		public static String convert(String s){
			String c;
			c = s.replaceAll("\\\\", "\\\\\\\\");
			return c;
		}

		public static String trim(String str) {
			if(str!=null) {
				return str.trim();
			}
			return null;
		}
		
		/**
		 * Return a non null value. (Empty incase string is null.)
		 * 
		 * @param s
		 * @return
		 */
		public static String getNonNull(String s) {
			if(isEmpty(s)) {
				return "";
			}
			return s;
		}

		private static final String[] s_patternsToRemove = {"Our Price:\\s*", "\\$\\s*", ",","-"};
		private static final String[] s_zeroPattern = {"Free"};

		/**
		 * Normalizes the input string to have only number by removing symbols associated with money.
		 * 
		 * @param money
		 * @return
		 */
		public static String normalizeAndGetMoney(String money) {
			money = money.trim();
			for (int i = 0; i < s_patternsToRemove.length; i++) {
				money = money.replaceAll(s_patternsToRemove[i], "");
			}
			if ((!money.isEmpty()) && money.charAt(0) == '.') {
				money = money.substring(1).trim();
			}
			for (int i = 0; i < s_zeroPattern.length; i++) {
				if(money.equals(s_zeroPattern[i])) {
					money = "0.0";
				}
			}
			return money;
		}
		
		/**
		 * Normalizes the input list of strings to have only number by removing symbols associated with money.
		 * 
		 * @param moneyList
		 * @return
		 */
		public static List<String> normalizeAndGetMoney(List<String> moneyList) {
			List<String> normalizedMoneyList = new ArrayList<String>();
			for(String s : moneyList) {
				normalizedMoneyList.add(normalizeAndGetMoney(s));
			}
			return normalizedMoneyList;
		}
		
		/**
		 * Replace text at all the occurrences and return result.
		 * 
		 * @param sourceText
		 * @param searchText
		 * @param replaceText
		 * @return
		 */
		public static String replaceText(String sourceText, String searchText, String replaceText){
			if(sourceText == null || searchText == null || replaceText == null) {
				s_logger.error("Source: {} SearchText: {} ReplaceText: {}", sourceText, searchText, replaceText);
				s_logger.error("Insufficient data: Null value passed in input.");
				throw new RuntimeException("Insufficient data: Null value passed in input.");
			}
			String resultText = sourceText;
			while(resultText.indexOf(searchText) >= 0) {
				resultText = resultText.replace(searchText, replaceText);
			}
			return resultText;
		}
		
		/**
		 * Generate a random string with start string as 'gen'
		 * 
		 * @return
		 */
		public static String getRandomString(){
			return getRandomString("gen", "");
		}
		
		/**
		 * Generate random string with this prefix and suffix.
		 * 
		 * @param prefix
		 * @param suffix
		 * @return
		 */
		public static String getRandomString(String prefix, String suffix){
			Random randomGenerator = new Random(System.nanoTime() + Thread.currentThread().getId());     
	        int randomInt = randomGenerator.nextInt(99);
	        long startTime = System.nanoTime();
	        String randomString = prefix + Long.valueOf(startTime).toString() + randomInt + suffix;
			return randomString;
		}
		
		/**
		 * Extract string based on the regular expression and return the same.
		 * 
		 * @param sourceString
		 * @param regularExpression
		 * @return
		 */
		public static String extractString(String sourceString, String regularExpression) {
			s_logger.info("Source string: {}", sourceString);
			s_logger.info("Regular Expression: {}", regularExpression);
			if(sourceString == null || regularExpression == null) {
				s_logger.error("Insufficient data: Invalid source / regular expression.");
				throw new RuntimeException("Insufficient data: Invalid data for source string/ regular expression.");
			}
			Pattern p = Pattern.compile(regularExpression);
			Matcher m = p.matcher(sourceString);
			String result = null;
			while(m.find()) {
				result = m.group();
				break;
			}
			s_logger.info("Extracted string: {}", result);
			return result;
		}
	}
	
	public static class ListUtility {
		
		public static boolean sameList(List<String> list1, List<String> list2) {
			if(list1 == list2) {
				return true;
			}
			Set<String> set1 = new HashSet<String>();
			set1.addAll(list1);
			Set<String> set2 = new HashSet<String>();
			set2.addAll(list2);
			if(set1.size() != set2.size()) {
				return false;
			}
			for(String ele1 : set1) {
				if(!set2.contains(ele1)) {
					return false;
				}
			}
			return true;
		}

		public static boolean containsAll(List<String> parent, List<String> child){
			if(parent == null && child == null) return true;
			if(parent == null || child == null) return false;

			if(parent == child) return true;
			if(child.size() > parent.size()) return false;

			List<String> childList = new ArrayList<>(child);
			childList.removeAll(parent);

			return childList.size() == 0;
		}
		
		public static boolean isNotEmpty(List list) {
            return list != null && list.size() != 0;
        }
		
		public static boolean isEmpty(List list) {
            return list == null || list.size() == 0;
        }
		
		public static String getDelimitedString(List<String> stringList, String delimiter) {
			if(isEmpty(stringList)) {
				return "";
			}
			StringBuilder sb = new StringBuilder();
			Iterator<String> itr = stringList.iterator();
			sb.append(itr.next());
			while(itr.hasNext()) {
				sb.append(delimiter).append(itr.next());
			}
			return sb.toString();
		}
		
		public static String getCommaSeperatedString(List<String> stringList) {
			if(isEmpty(stringList)) {
				return "";
			}
			return getDelimitedString(stringList, ",");
		}
		
		public static List<Integer> getIntegerList(String commaSeperatedString) {
			List<String> strList = getList(commaSeperatedString, ",");
			List<Integer> intrList = new ArrayList<Integer>();
			for(String str : strList) {
				try {
					intrList.add(Integer.valueOf(str));
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return intrList;
		}

		
		@SuppressWarnings("unchecked")
		public static List<?> getAsList(String commaSeperatedString, Class<?> dataType) {
			List<String> strList = getList(commaSeperatedString, ",");

			@SuppressWarnings("rawtypes")
			List valuesList = getArrayForClass(dataType);
			for (String str : strList) {
				try {
					valuesList.add(getValue(str, dataType));
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return valuesList;
		}

		public static Object getValue(String str, Class<?> dataTypeClass) throws ParseException {
			if(dataTypeClass == Integer.class) {
				return Integer.valueOf(trim(str));
			}
			if(dataTypeClass == Float.class) {
				return Float.valueOf(trim(str));
			}
			if(dataTypeClass == Long.class) {
				return Long.valueOf(trim(str));
			}
			if(dataTypeClass == BigDecimal.class) {
				if(str.contains(".")) {
					return BigDecimal.valueOf(Double.parseDouble(trim(str)));
				}
				return BigDecimal.valueOf(Long.parseLong(trim(str)));
			}
			if(dataTypeClass == Boolean.class) {
				return Boolean.parseBoolean(trim(str));
			}
			if(dataTypeClass == Date.class) {
				return (new SimpleDateFormat()).parse(trim(str));
			}
			if(dataTypeClass == String.class) {
				return str;
			}
			return null;
		}
		
		private static String trim(String value) {
			if(value!=null) {
				return value.trim();
			}
			return null;
		}
		
		private static List<?> getArrayForClass(Class<?> numberClass) {
			if(numberClass == Integer.class) {
				return new ArrayList<Integer>();
			}
			if(numberClass == Float.class) {
				return new ArrayList<Float>();
			}
			if(numberClass == Long.class) {
				return new ArrayList<Long>();
			}
			if(numberClass == BigDecimal.class) {
				return new ArrayList<BigDecimal>();
			}
			if(numberClass == Boolean.class) {
				return new ArrayList<Boolean>();
			}
			if(numberClass == Date.class) {
				return new ArrayList<Date>();
			}
			if(numberClass == String.class) {
				return new ArrayList<String>();
			}
			return null;
		}
		
		public static List<Object> getObjectList(List<?> list) {
			List<Object> finalList = new ArrayList<Object>();
			for(Object element : list) {
				finalList.add(element);
			}
			return finalList;
		}
		
		public static List<String> getList(String commaSeperatedString) {
			return getList(commaSeperatedString, ",");
		}
		
		public static List<String> getList(String delimitedString, String delimiter) {
			if(StringUtility.isEmpty(delimitedString)) {
				return new ArrayList<String>();
			}
			return Arrays.asList(delimitedString.split(delimiter));
		}
		
		public static List<Date> getDateList(List<String> stringList, String dateFormat) throws ParseException {
			SimpleDateFormat format = new SimpleDateFormat(dateFormat);
			List<Date> dateList = new ArrayList<Date>(stringList.size());
			for(String str : stringList) {
				try {
					dateList.add(format.parse(str));
				} catch (ParseException e) {
					throw e;
				}
			}
			return dateList;
		}
		
		public static List<BigDecimal> getNumberList(List<String> stringList) {
			List<BigDecimal> dateList = new ArrayList<BigDecimal>(stringList.size());
			for(String str : stringList) {
				dateList.add(new BigDecimal(str));
			}
			return dateList;
		}
	}
}
