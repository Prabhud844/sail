package com.asda.core.listener;

import com.asda.core.enums.SystemVariableEnum;
import com.asda.core.reporters.ReportListener;
import com.aventstack.extentreports.Status;
import com.asda.core.reporters.CoverageReportManager;
import com.asda.core.logger.TestLogger;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class CoverageReportListener implements ITestListener {

    public void onStart(ITestContext context) {
        TestLogger.START_TIME = System.currentTimeMillis();
        CoverageReportManager.SUITE_NAME = context.getSuite().getName();
        try{
            CoverageReportManager.SQUAD_NAME = context.getOutputDirectory().split("asdaidc-mma-repo/")[1].split("/")[0];
        }catch(Exception e){
            if(context.getOutputDirectory().contains("/ws/")){
                CoverageReportManager.SQUAD_NAME = context.getOutputDirectory().split("/ws/")[1].split("/")[0];
            }else
                CoverageReportManager.SQUAD_NAME = "NOT SET";
        }
        CoverageReportManager.TEST_ENV = ReportListener.getValueFromSystemProperties(SystemVariableEnum.TEST_ENV.getSysVarName(),
                context.getSuite().getXmlSuite().getParameter("test.env"));
        try{
            String tcrFlag = ReportListener.getValueFromSystemProperties(SystemVariableEnum.TCRFLAG.getSysVarName(),
                    context.getSuite().getXmlSuite().getParameter("tcr.flag"));
            if(null!=tcrFlag) CoverageReportManager.TCR_FLAG = Boolean.parseBoolean(tcrFlag);
            else CoverageReportManager.TCR_FLAG = false;
        }catch (Exception e){CoverageReportManager.TCR_FLAG = false;}
        System.out.println("*** Test Suite " + context.getName() + " started ***");
    }

    public void onFinish(ITestContext context) {
        System.out.println(("*** Test Suite " + context.getName() + " ending ***"));
        if(CoverageReportManager.TCR_FLAG) {
            TestLogger.endTest();
            CoverageReportManager.getInstance().flush();
        }
    }

    public void onTestStart(ITestResult result) {
        System.out.println(("*** Running test method " + result.getMethod().getMethodName() + "..."));
        if(CoverageReportManager.TCR_FLAG)
            TestLogger.startTest(result.getMethod().getMethodName());
    }

    public void onTestSuccess(ITestResult result) {
        System.out.println("*** Executed " + result.getMethod().getMethodName() + " test successfully...");
        if(CoverageReportManager.TCR_FLAG  && null != TestLogger.getTest())
            TestLogger.getTest().log(Status.PASS, "Test passed");
    }

    public void onTestFailure(ITestResult result) {
        System.out.println("*** Test execution " + result.getMethod().getMethodName() + " failed...");
            if(CoverageReportManager.TCR_FLAG && null != TestLogger.getTest()) {
                TestLogger.getTest().log(Status.FAIL, "Test Failed");
                TestLogger.log(false, "Test Failed - Because of Exception");
            }
    }

    public void onTestSkipped(ITestResult result) {
        System.out.println("*** Test " + result.getMethod().getMethodName() + " skipped...");
        if(CoverageReportManager.TCR_FLAG  && null != TestLogger.getTest()) {
            TestLogger.getTest().log(Status.SKIP, "Test Skipped");
            if (result.wasRetried()) TestLogger.removeLastTestFromCoverage(result.getMethod().getMethodName());
        }
    }

    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        System.out.println("*** Test failed but within percentage % " + result.getMethod().getMethodName());
    }
}