package com.asda.core.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.asda.qa.environment.EnvironmentConfig;

/**
 * Container class for USDataBaseType. Initialize this class from spring
 * configuration so that inner class is initialized.
 * 
 * @author jkandul
 *
 */
public class ASDADataBaseTypes {
	private final static Logger s_logger = LoggerFactory.getLogger(ASDADataBaseTypes.class);

	public ASDADataBaseTypes() {
		ASDADataBaseType.s_logger.info("Initilizing class {}", ASDADataBaseType.class);
	}

	/**
	 * Connections for US Databases.
	 * 
	 * Container class is created to enable initializing static fields from
	 * Spring context.
	 * 
	 * @author jkandul
	 *
	 */
	public static class ASDADataBaseType extends DatabaseType {
		private static final Logger s_logger = LoggerFactory.getLogger(ASDADataBaseType.class);

		private ASDADataBaseType(String name, String description) {
			super(name, description);
		}

	}

	/**
	 * Connections for ASDA IAM Databases.
	 * 
	 * Container class is created to enable initializing static fields from
	 * Spring context.
	 * 
	 * @author mranjan
	 *
	 */

	// Connection object
	public static Connection con;

	// Statement object
	private static Statement stmt;

	// Fetch Database URL From Environment Config
	String DB_URL = EnvironmentConfig.getInstance().getDBUrl();

	// Fetch Database User ID From Environment Config
	String DB_USER = EnvironmentConfig.getInstance().getDBUserid();

	// Fetch Database User Password From Environment Config
	String DB_PASSWORD = EnvironmentConfig.getInstance().getDBPwd();

	public void openDBConnect() throws Exception {
		try {
			// Make the database connection
			String dbClass = "oracle.jdbc.driver.OracleDriver";
			Class.forName(dbClass).newInstance();

			// Get connection to DB
			con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

			// Statement object to send the SQL statement to the Database
			stmt = con.createStatement();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public List<String> fetchCustomerInfo(String Uemail) throws SQLException {
		List<String> output = new ArrayList<String>();
		s_logger.info("Customer Email ID: " + Uemail);
		try {
			String query = "select du.id, mu.login, concat(mu.passwd,du.password) as ConcatPWD from atgcust.mtep_user mu, atgcust.dps_user du where mu.user_id = du.id and mu.login ='"
					+ Uemail + "'";
			s_logger.info("Query to Run : " + query);
			// Get the contents of user info table from ASDA DB
			ResultSet res = stmt.executeQuery(query);
			if (res == null) {
				s_logger.info("Email id is not found in DB records :" + Uemail);
			} else {

				// Print the result until all the records are printed
				while (res.next()) {
					s_logger.info("Login ID is :" + res.getString("ID"));
					String custID = res.getString("ID");
					output.add(custID);
					s_logger.info("Email is :" + res.getString("LOGIN"));
					String email = res.getString("LOGIN");
					output.add(email);
					s_logger.info("Concat Password is :" + res.getString("ConcatPWD"));
					String conPWD = res.getString("ConcatPWD");
					output.add(conPWD);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return output;
	}

	public void closeDBconnet() throws Exception {

		// Close DB connection

		if (con != null) {

			s_logger.info("Closing the connection");
			con.close();
			s_logger.info("Closing the Statement");
			stmt.close();

		} else {
			s_logger.info("NO Connection Found");
		}

	}
	
	public void RunMVRefreshProc() throws Exception {

		try {
			String query = "call DBA_UTIL.PROC_REFRESH_ESTRADM_MV('ESTRADM')";
			s_logger.info("Procedure to Run : " + query);
			ResultSet res = stmt.executeQuery(query);
			//String rs = res.getString(0);
			s_logger.info("MV Refresh Completed :");
		}catch (Exception e) {
		e.printStackTrace();
		closeDBconnet();
	}
	}

}
