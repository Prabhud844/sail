package com.asda.core.reporters.beans;


/**
 * @author dneela
 * Class that is used to maintain the report bean instance per thread local
 */
public class ReportThreadLocal {
	
	private static final ThreadLocal <ReportBean> reportBeanThreadLocal = new ThreadLocal <ReportBean>();

	/**
	 * Sets the report bean for the current thread 
	 * @param reportBean
	 */
	public static void setReportBean(ReportBean reportBean) {
		reportBeanThreadLocal.set(reportBean);
	}

	/**
	 * removes the report bean from the current thread
	 */
	public static void unsetReportBean() {
		reportBeanThreadLocal.remove();
	}

	/**
	 * returns the report bean from the current thread
	 * @return
	 */
	public static ReportBean getReportBean() {
		return reportBeanThreadLocal.get();
	}
	
}
