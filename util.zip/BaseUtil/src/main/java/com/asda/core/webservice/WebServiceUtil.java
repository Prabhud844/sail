package com.asda.core.webservice;

import java.util.Map;

/**
 * @author jkandul
 *
 */
public class WebServiceUtil extends BaseWebService {


	/**
	 * Reads the file at the relative path and returns the content of file as string.
	 * 
	 * @param relativePath
	 * @return
	 */
	public String getRequestFromFile(String relativePath) {
		return super.getRequestFromFile(relativePath);
	}
	
	/**
	 * Trigger SOAP call and return web service response.
	 * 
	 * @param url
	 * @param request
	 * @param headers
	 * @return
	 */
	public WebServiceResponse invokeSOAPRequest(String url, String request, Map<String, String> headers) {
		return super.invokeSOAPRequest(url, request, headers);
	}
	
	/**
	 * Trigger SOAP call and return web service response.
	 * 
	 * @param url
	 * @param request
	 * @param headers
	 * @param soapAction
	 * @return
	 */
	public WebServiceResponse invokeSOAPRequest(String url, String request, Map<String, String> headers, String soapAction) {
		return super.invokeSOAPRequest(url, request, headers, soapAction);
	}
	
	/**
	 * Trigger SOAP call after replacing dynamic values in url, request, headers and return response.
	 * 
	 * @param url
	 * @param request
	 * @param headers
	 * @param tokenDelimiter
	 * @param tokenDataMap
	 * @return
	 */
	public WebServiceResponse invokeSOAPRequest(String url, String request, Map<String, String> headers,
                                                ParamTokenDelimiter tokenDelimiter, Map<String, String> tokenDataMap) {
		return super.invokeSOAPRequest(url, request, headers, tokenDelimiter, tokenDataMap);
	}

	/**
	 * Trigger SOAP call after replacing dynamic values in url, request, headers and return response.
	 * 
	 * @param url
	 * @param request
	 * @param headers
	 * @param tokenDelimiter
	 * @param tokenDataMap
	 * @param soapAction
	 * @return
	 */
	public WebServiceResponse invokeSOAPRequest(String url, String request, Map<String, String> headers,
                                                ParamTokenDelimiter tokenDelimiter, Map<String, String> tokenDataMap, String soapAction) {
		return super.invokeSOAPRequest(url, request, headers, tokenDelimiter, tokenDataMap, soapAction);
	}
	
	/**
	 * Trigger REST call with post parameters and return the response.
	 * 
	 * @param url
	 * @param headers
	 * @param postParams
	 * @return
	 */
	public WebServiceResponse invokeRESTPostRequest(String url, Map<String, String> headers, Map<String, String> postParams) {
		return super.invokeRESTPostRequest(url, headers, postParams);
	}

	/**
	 * Trigger REST call with request body and returns the response. 
	 * 
	 * @param url
	 * @param requestBody
	 * @param postParams
	 * @return
	 */
	public WebServiceResponse invokeRESTPostRequest(String url, Map<String, String> headers, String requestBody){
		return super.invokeRESTPostRequest(url, headers, requestBody);
	}

	/**
	 * Trigger REST call with request body and returns the response. 
	 * Replaces dynamic values before triggering call.
	 * 
	 * @param url
	 * @param headers
	 * @param requestBody
	 * @param tokenDelimiter
	 * @param tokenDataMap
	 * @return
	 */
	public WebServiceResponse invokeRESTPostRequest(String url, Map<String, String> headers, String requestBody,
                                                    ParamTokenDelimiter tokenDelimiter, Map<String, String> tokenDataMap, boolean isXmlBody) {
		return super.invokeRESTPostRequest(url, headers, requestBody, tokenDelimiter, tokenDataMap, isXmlBody);
	}

	
	/**
	 * Triggers REST POST with post parameters, all the values with dynamic
	 * place holders would be replace before triggering call.
	 * 
	 * @param url
	 * @param headers
	 * @param postParams
	 * @param tokenDelimiter
	 * @param tokenDataMap
	 * @return
	 */
	public WebServiceResponse invokeRESTPostRequest(String url, Map<String, String> headers,
                                                    Map<String, String> postParams, ParamTokenDelimiter tokenDelimiter, Map<String, String> tokenDataMap) {
		return super.invokeRESTPostRequest(url, headers, postParams, tokenDelimiter, tokenDataMap);
	}
	
	/**
	 * Trigger REST GET call and return service response.
	 * 
	 * @param url
	 * @return
	 */
	public WebServiceResponse invokeRESTGetRequest(String url, Map<String, String> headers) {
		return super.invokeRESTGetRequest(url, headers);
	}

	/**
	 * Trigger REST GET call and return service response, replace dynamic values
	 * in URL before triggering call.
	 * 
	 * @param url
	 * @param tokenDelimiter
	 * @param tokenDataMap
	 * @return
	 */
	public WebServiceResponse invokeRESTGetRequest(String url, Map<String, String> headers, ParamTokenDelimiter tokenDelimiter,
                                                   Map<String, String> tokenDataMap) {
		return super.invokeRESTGetRequest(url, headers, tokenDelimiter, tokenDataMap);
	}
	
	/**
	 * Trigger REST PUT with request body (XMl/JSON (default)) after replacing dynamic values.
	 * 
	 * @param url
	 * @param headers
	 * @param request
	 * @param tokenDelimiter
	 * @param tokenDataMap
	 * @param isXmlBody
	 * @return
	 */
	public WebServiceResponse invokeRESTPutRequest(String url, Map<String, String> headers, String request, ParamTokenDelimiter tokenDelimiter, Map<String, String> tokenDataMap, boolean isXmlBody) {
		return super.invokeRESTPutRequest(url, headers, request, tokenDelimiter, tokenDataMap, isXmlBody);
	}
	
	/**
	 * Trigger REST PUT request with request body (XMl/JSON (default))
	 * 
	 * @param url
	 * @param headers
	 * @param request
	 * @param isXmlBody
	 * @return
	 */
	public WebServiceResponse invokeRESTPutRequest(String url, Map<String, String> headers, String request, boolean isXmlBody) {
		return super.invokeRESTPutRequest(url, headers, request, isXmlBody);
	}
	
	/**
	 * Trigger REST PUT request with request body (XMl/JSON (default))
	 * 
	 * @author mgoel1 (mgoel@walmartlabs.com)
	 * @param url
	 * @param headers
	 * @return
	 */
	public WebServiceResponse invokeRESTDeleteRequest(String url, Map<String, String> headers) {
		return super.invokeRESTDeleteRequest(url, headers);
	}	
	
}
