package com.asda.core.enums;
/**
 * This enum represents the test case repository location.
 * 
 * @author jkandul
 *
 */
public enum TestcaseInventoryEnum {

	QC,
	Jira,
	TestRail,
}
