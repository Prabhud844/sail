package com.asda.core.enums;

/** Defines various types that can be used to find element
 * @author dneela
 *
 */

public enum FindElementByEnum {

	ID("id"),
	LINKTEXT("linkText"),
	PARTIALLINKTEXT("partialLinkText"),
	NAME("name"),
	TAGNAME("tagName"),
	XPATH("xpath"),
	CLASSNAME("className"),
	CSSSELECTOR("cssSelector"),
	;
	
	private final String findElementType;
	
	FindElementByEnum(String findElementType) {
		this.findElementType = findElementType;
	}

	public String getType() {
		return findElementType;
	}
}
