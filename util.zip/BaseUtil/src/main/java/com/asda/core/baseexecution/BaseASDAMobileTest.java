package com.asda.core.baseexecution;

import com.asda.core.annotations.TestInfo;
import com.asda.core.enums.BrowserTypeEnum;
import com.asda.core.reporters.ReportListener;
import com.asda.qa.utility.MobileApiUtils;
import com.google.common.base.Joiner;
import com.saucelabs.common.SauceOnDemandAuthentication;
import com.saucelabs.common.SauceOnDemandSessionIdProvider;
import com.saucelabs.saucerest.SauceREST;
import com.saucelabs.testng.SauceOnDemandAuthenticationProvider;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import io.appium.java_client.AppiumDriver;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSStartScreenRecordingOptions;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.IOSMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.screenrecording.CanRecordScreen;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.SocketUtils;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public abstract class BaseASDAMobileTest extends BaseMobileTest implements SauceOnDemandSessionIdProvider, SauceOnDemandAuthenticationProvider {
    protected final Logger log = LoggerFactory.getLogger(getClass());

    public SauceOnDemandAuthentication authentication = null;

    protected Config globalData;

    protected MobileApiUtils api;

    protected ThreadLocal<SoftAssertions> softAssert = new ThreadLocal<SoftAssertions>();

    private final ThreadLocal<String> sessionId = new ThreadLocal<String>();

    private final ThreadLocal<Boolean> isVideoRecording = new ThreadLocal<Boolean>();

    private final ThreadLocal<String> sauceTCName = new ThreadLocal<String>();

    private final ThreadLocal<String> sauceJob = new ThreadLocal<String>();

    private final ThreadLocal<AppiumDriver> appDriver = new ThreadLocal<AppiumDriver>();

    private final ThreadLocal<WebDriver> webDriver = new ThreadLocal<WebDriver>();

    private final ThreadLocal<ArrayList<String>> testSteps = new ThreadLocal<>();

    private final ThreadLocal<AppiumDriverLocalService> service = new ThreadLocal<AppiumDriverLocalService>();

    private final ThreadLocal<Map<String, String>> testParams = new ThreadLocal<Map<String, String>>();

    private final int APPIUM_SERVER_TIMEOUT = 120;

    private static boolean isLocal;

    private boolean isDevice;

    private String browserName = "";

    private boolean captureVideo;

    private String videosLocation = "";

    /**
     * Clears the thread local cache.
     */
    private void clearThreadLocals() {

        try {
            appDriver.remove();
        } catch (Exception e) {

        }
        try {
            webDriver.remove();
        } catch (Exception e) {

        }
        try {
            isVideoRecording.remove();
        } catch (Exception e) {

        }
        try {
            softAssert.remove();
        } catch (Exception e) {

        }
        try {
            testSteps.remove();
        } catch (Exception e) {

        }
        try {
            sessionId.remove();
        } catch (Exception e) {

        }
        try {
            sauceJob.remove();
        } catch (Exception e) {

        }




    }

    protected void initializeTest(ITestContext test) {

        api = new MobileApiUtils();

        Map<String, String> temp = test.getCurrentXmlTest().getAllParameters();
        String env = temp.get("test.env");

        int timeout = Integer.parseInt(StringUtils.defaultIfEmpty(temp.get("timeOut"), "30"));
        BaseAppPage.TIME_OUT = timeout;
        BaseAppPage.env = env;
       // BaseWebPage.TIME_OUT = timeout;
        globalData = ConfigFactory.parseFile(new File(System.getProperty("user.dir") + "/src/test/resources/common/testdata/" + temp.get("test.env") + ".conf"));

        isLocal = temp.get("islocalrun").equalsIgnoreCase("true");

        isDevice = temp.containsKey("useRealDevice") && temp.get("useRealDevice").equalsIgnoreCase("yes");


        captureVideo = temp.containsKey("captureVideo") && temp.get("captureVideo").equalsIgnoreCase("yes");

        browserName = StringUtils.defaultIfEmpty(temp.get("browserName"), "");


        if (isLocal && captureVideo) {
            videosLocation = System.getProperty("user.dir") + "/VIDEOS-" + ReportListener.TEST_RUN_ID;
        }
        if (isLocal) {
            AppiumDriverLocalService appiumService;
            if (temp.containsKey("appLocation")) {
                log.info("Host is" + temp.get("appiumHost"));
                if (temp.containsKey("appiumHost")) {
                    appiumService = AppiumDriverLocalService.buildService(new AppiumServiceBuilder()
                            .withIPAddress(temp.get("appiumHost")).usingPort(4723)
                            .withStartUpTimeOut(APPIUM_SERVER_TIMEOUT, TimeUnit.SECONDS));
                } else {
                    appiumService = AppiumDriverLocalService.buildService(new AppiumServiceBuilder().
                            usingAnyFreePort().withStartUpTimeOut(APPIUM_SERVER_TIMEOUT, TimeUnit.SECONDS));
                }
                service.set(appiumService);
                service.get().start();
                log.info("Test" + test.getName() + service.get().getUrl().toString());
                temp.put("url", service.get().getUrl().toString());
                test.setAttribute("server", service.get());
/*
                temp.put("url", "http://172.30.111.54:4723/wd/hub");
                test.setAttribute("server", "temp");
*/

            }
        } else {

            String build = test.getSuite().getName() + "_RUNID-" + ReportListener.TEST_RUN_ID;
            temp.put("build", build);

        }

        if (temp.containsKey("upsertJiraOnFailure") && temp.get("upsertJiraOnFailure").equalsIgnoreCase("yes")) {
            test.setAttribute("epicId", StringUtils.defaultIfEmpty(temp.get("epicId"), "ASDAA-8941"));
            test.setAttribute("jiraId", StringUtils.defaultIfEmpty(temp.get("jiraId"), ""));
            test.setAttribute("summary", test.getSuite().getName() + "__" + test.getName() + "_RUNID-" + ReportListener.TEST_RUN_ID);
        }
        if (temp.containsKey("appLocation")) {
            env = env + "_" + StringUtils.defaultIfEmpty(temp.get("platformName"), "") + "_" + StringUtils.defaultIfEmpty(temp.get("platformVersion"), "")
                    + "_" + StringUtils.defaultIfEmpty(temp.get("deviceName"), "");

        }
        env = env + "_" + browserName;
        test.setAttribute("Env", env);
        test.setAttribute("testparams", temp);

    }

    @BeforeMethod(alwaysRun = true)
    protected void initMethod(Method method, ITestContext test, Object[] methodParams, ITestResult result) throws Exception {
        clearThreadLocals();
        super.beforeTest(method, test, BrowserTypeEnum.NONE, methodParams);
        //currentMethodName.set(result.getMethod().getMethodName() + "_" + result.getMethod().getCurrentInvocationCount());
        softAssert.set(new SoftAssertions());
        testSteps.set(new ArrayList<String>());
        testParams.set((Map<String, String>) test.getAttribute("testparams"));

        if (!isLocal) {
            sauceTCName.set(test.getName() + "-" + method.getDeclaringClass().getSimpleName() + "-" + method.getName());
            //getTestParams().put("testCaseName", testCaseName);
            authentication = new SauceOnDemandAuthentication(getTestParams().get("sauceUser"), getTestParams().get("sauceKey"));
        }

    }


    @AfterMethod(alwaysRun = true)
    public void tearDownMethod(ITestResult result, Method testMethod) throws Exception {

        boolean status = result.isSuccess();
        log.info("In TearDown-----> " + result.isSuccess());
        if (!result.isSuccess()) {
            String methodName;
            int itr = result.getMethod().getCurrentInvocationCount();
            if (itr > 1) {
                methodName = result.getMethod().getMethodName() + "_" + itr;
            } else {
                methodName = result.getMethod().getMethodName();
            }
            saveExecutionVideo(methodName);
        }
        if (!isLocal) {
            if (!result.isSuccess()) {
                result.setAttribute("sauceURL", getSauceJob());
            }
            try {
                getAppDriver().executeScript("sauce:job-result=" + (status ? "passed" : "failed"));
            } catch (Exception e) {
                //log.info(ExceptionUtils.getStackTrace(e));
            }
            try {
                ((JavascriptExecutor) getWebDriver()).executeScript("sauce:job-result=" + (status ? "passed" : "failed"));
            } catch (Exception e) {
                //log.info(ExceptionUtils.getStackTrace(e));
            }
        } else {
            result.setAttribute("sauceURL", "");

        }
        try {
            appDriver.get().quit();
        } catch (Exception e) {
            // log.info(ExceptionUtils.getStackTrace(e));
        }
        try {
            webDriver.get().quit();
        } catch (Exception e) {
            //log.info(ExceptionUtils.getStackTrace(e));
        }
        if (!status && result.getTestContext().getAttributeNames().contains("jiraId")) {
            String testSteps = "*Test Steps:*\n" + String.join("\n", getTestSteps()) + "\n";
            List<String> failures = new ArrayList<>();
            for (Throwable t : getSoftAssert().errorsCollected()) {
                failures.add(ExceptionUtils.getMessage(t).replace("ComparisonFailure: ", "").replace("AssertionError: ", ""));
            }
            String errors = "";
            if (failures.size() > 0) {
                errors = "*Failed Validations:*\n" + String.join("\n", failures);
            }
            String comments = getSauceJob() + "\n" + testSteps + "\n" + errors;

            String owner = testMethod.getAnnotation(TestInfo.class).testOwner();

            upsertJira(result, comments, owner);
        }

        super.tearDown(result, testMethod);

    }


    @AfterSuite(alwaysRun = true)
    public void postRunTimeInfo() throws Exception {


        try {
            {
                String fileContent = Joiner.on("\n").withKeyValueSeparator("=").join(runtimeData);
                BufferedWriter writer = new BufferedWriter(new FileWriter(System.getProperty("user.dir") + "/RunTimeInfo-" + ReportListener.TEST_RUN_ID + ".txt"));
                writer.write(fileContent);
                writer.close();
            }
        } catch (Exception e) {
            log.info(ExceptionUtils.getStackTrace(e));
        }

    }

    public AppiumDriver getAppDriver() {
        if (appDriver.get() instanceof AppiumDriver) {
            return appDriver.get();
        } else {
            if (isLocal) {

                if (isDevice) {
                    initLocalDeviceDriver(getTestParams());
                } else {
                    initLocalSimulatorDriver(getTestParams());
                }

            } else {


                initRemoteAppDriver(getTestParams());
            }
            return appDriver.get();
        }

    }

    public WebDriver getWebDriver() {

        if (webDriver.get() instanceof WebDriver) {
            return webDriver.get();
        } else {
            if (isLocal) {

                initLocalWebDriver(getTestParams());
            } else {

                initRemoteWebDriver(getTestParams());
            }
            return webDriver.get();
        }

    }

    private void initRemoteWebDriver(Map<String, String> params) {
        try {
            DesiredCapabilities capabilities = getRemoteWebCapabilities(params);


            String url ="http://boost.prod-grid.wus-prod-aperf2.cluster.k8s.us.walmart.net:80/wd/hub";
            // String url = "https://" + params.get("sauceUser") + ":" + params.get("sauceKey") + "@ondemand.saucelabs.com/wd/hub";
            webDriver.set(new RemoteWebDriver(new URL(url), capabilities));
            String id = ((RemoteWebDriver) getWebDriver()).getSessionId().toString();
            sessionId.set(id);
            log.info("sessionnnnn-->  "+id);
            //sauceJob.set(new SauceREST(params.get("sauceUser"), params.get("sauceKey")).getPublicJobLink(sessionId.get()));
        } catch (Exception e) {

        }

    }


    private void initLocalWebDriver(Map<String, String> params) {
        switch (browserName.toLowerCase().trim()) {

            case "chrome":
                System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/src/main/resources/web/chromedriver");
                WebDriver temp = new ChromeDriver();
                temp.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
                temp.manage().window().maximize();
                webDriver.set(temp);

                break;
            default:
                log.info("Browser not supported");
        }
    }


    public SauceOnDemandAuthentication getAuthentication() {
        return authentication;
    }


    private void initLocalSimulatorDriver(Map<String, String> params) {
        try {
            DesiredCapabilities localCaps = getLocalSimulatorCapabilities(params);
            log.info("capabilities ---------->" + localCaps.toJson().toString());
            String url = params.get("url");
            log.info("url---" + url);
            if (params.get("platformName").equalsIgnoreCase("ios")) {
                AppiumDriver<MobileElement> temp = null;

                temp = new IOSDriver<MobileElement>(new URL(url), localCaps);

                //temp.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
                appDriver.set(temp);
                if (captureVideo) {
                    isVideoRecording.set(true);
                    ((CanRecordScreen) getAppDriver()).startRecordingScreen(new IOSStartScreenRecordingOptions().withVideoType("h264").enableForcedRestart());

                }
                handleiOSLaunchPopups();
            } else {
                AppiumDriver<MobileElement> temp = new AndroidDriver<MobileElement>(new URL(url), localCaps);
                //temp.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
                appDriver.set(temp);
                if (captureVideo) {
                    isVideoRecording.set(true);
                    ((CanRecordScreen) getAppDriver()).startRecordingScreen();
                }
            }
            sauceJob.set("");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

    }

    private void initLocalDeviceDriver(Map<String, String> params) {
        try {
            DesiredCapabilities localCaps = getLocalDeviceCapabilities(params);
            log.info("capabilities ---------->" + localCaps.toJson().toString());
            String url = params.get("url");
            log.info("url---" + url);
            if (params.get("platformName").equalsIgnoreCase("ios")) {
                AppiumDriver<MobileElement> temp = new IOSDriver<MobileElement>(new URL(url), localCaps);
                //temp.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
                appDriver.set(temp);
                if (!videosLocation.isEmpty()) {
                    ((CanRecordScreen) getAppDriver()).startRecordingScreen(new IOSStartScreenRecordingOptions().withVideoType("h264").enableForcedRestart());
                }
                handleiOSLaunchPopups();
            } else {
                AppiumDriver<MobileElement> temp = new AndroidDriver<MobileElement>(new URL(url), localCaps);
                //temp.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
                appDriver.set(temp);
                if (!videosLocation.isEmpty()) {

                    ((CanRecordScreen) getAppDriver()).startRecordingScreen();
                }
            }
            sauceJob.set("");
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    private void initRemoteAppDriver(Map<String, String> params) {
        try {

            DesiredCapabilities localCaps = getRemoteAppCapabilities(params);
            String url = "http://" + params.get("sauceUser") + ":" + params.get("sauceKey") + "@ondemand.saucelabs.com:80/wd/hub";
            log.info("capabilities ---------->" + localCaps.toJson().toString());
            log.info("url :: "+url);

            if (params.get("platformName").equalsIgnoreCase("ios")) {
                AppiumDriver<MobileElement> temp = new IOSDriver<MobileElement>(new URL(url), localCaps);
                //temp.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
                appDriver.set(temp);
                handleiOSLaunchPopups();
            } else {

                AppiumDriver<MobileElement> temp = new AndroidDriver<MobileElement>(new URL(url), localCaps);
                //temp.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
                appDriver.set(temp);
            }
            String id = getAppDriver().getSessionId().toString();
            sessionId.set(id);
            sauceJob.set(new SauceREST(params.get("sauceUser"), params.get("sauceKey")).getPublicJobLink(sessionId.get()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    protected void $(String step) {
        log.info("Executing : {}", step);
        getTestSteps().add(step);
    }

    private void handleiOSLaunchPopups() {
        BaseAppPage common = new BaseAppPage(getAppDriver());
        if (getAppDriver().findElementsByAccessibilityId("Don’t Allow").size()>0){
            common.clickIfExists(common.getElement("accessibility", "Don’t Allow"));
            common.clickIfExists(common.getElement("accessibility", "Ask App not to Track"));
            common.clickIfExists(common.getElement("accessibility", "Continue"));
            common.clickIfExists(common.getElement("accessibility", "Next"));
            common.clickIfExists(common.getElement("accessibility", "Don’t Allow"));
        }
        //ACCEPTING NEW PRIVACY POLICY SCREEN
       else if (getAppDriver().findElementsByAccessibilityId("Ask App not to Track").size()>0) {
            common.clickIfExists(common.getElement("accessibility", "Ask App not to Track"));
            common.clickIfExists(common.getElement("accessibility", "Don’t Allow"));
            common.clickIfExists(common.getElement("accessibility", "Continue"));
            common.clickIfExists(common.getElement("accessibility", "Next"));
            common.clickIfExists(common.getElement("accessibility", "Don’t Allow"));
        }
    }


    private void saveExecutionVideo(String methodName) {
        try {
            if (!videosLocation.isEmpty() && isVideoRecording.get()) {
                String video = ((CanRecordScreen) getAppDriver()).stopRecordingScreen();
                byte[] decodedVideo = Base64.getMimeDecoder().decode(video);
                Path testVideoDir = Paths.get(videosLocation);
                Files.createDirectories(testVideoDir);
                Path testVideoFile = Paths.get(testVideoDir.toString(), String.format("%s.%s", methodName, "mp4"));
                Files.write(testVideoFile, decodedVideo);
                log.info("Wow...watch.." + videosLocation);
            }
        } catch (Exception e) {
            log.info(ExceptionUtils.getStackTrace(e));
        }
    }


    public String getSauceJob() {

        return sauceJob.get();
    }

    public SoftAssertions getSoftAssert() {

        return softAssert.get();
    }

    public String getSessionId() {
        return sessionId.get();
    }

    public ArrayList<String> getTestSteps() {
        return testSteps.get();
    }


    @Override
    public void tearDownTest(ITestContext test) {
        try {
            if (isLocal) {

                AppiumDriverLocalService localServer = (AppiumDriverLocalService) test.getAttribute("server");
                localServer.stop();
            }
        } catch (Exception e) {

        }
    }


    private DesiredCapabilities getRemoteWebCapabilities(Map<String, String> params) {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(CapabilityType.BROWSER_NAME, browserName.toLowerCase());
/*        capabilities.setCapability(CapabilityType.VERSION, "latest");
        capabilities.setCapability(CapabilityType.PLATFORM_NAME, "macOS 10.14");
        capabilities.setCapability("build", params.get("build"));
        capabilities.setCapability("name", sauceTCName.get());*/

        capabilities.setCapability("headless",false);
        capabilities.setCapability("recordVideo",true);
        capabilities.setCapability("pushDestination", "azure");
        capabilities.setCapability("azureAccountName", "lzhuselgrid");
        capabilities.setCapability("azureAccountToken", "jJEgEhaWPliebiBizHV2wZvtOhGuoOGiNp2s06H6uHE2CvrKd4PhAzdySASB0hr/T/ZuyY9ZiOw8pZkvwYuaDw==");
        capabilities.setCapability("azureContainer", "selgrid888");
        ChromeOptions options  = new ChromeOptions();
        List<String> args = new ArrayList<>();
        args.add("--proxy-server=http://proxy.wal-mart.com:9080");
        options.addArguments(args);
        capabilities.setCapability(ChromeOptions.CAPABILITY,options);
        return capabilities;
    }

    private DesiredCapabilities getRemoteAppCapabilities(Map<String, String> testNGParams) {

        DesiredCapabilities capabilities = new DesiredCapabilities();

        capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, testNGParams.get("deviceName"));
        capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, testNGParams.get("platformVersion"));
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, testNGParams.get("platformName"));
        capabilities.setCapability(MobileCapabilityType.APP, testNGParams.get("appLocation"));
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 120);
        capabilities.setCapability("appiumVersion", testNGParams.get("appiumVersion"));
        capabilities.setCapability("build", testNGParams.get("build"));
        capabilities.setCapability("name", sauceTCName.get());
        if (testNGParams.get("platformName").equalsIgnoreCase("ios")) {
            capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "XCUITest");
        } else {
            capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UIAutomator2");

        }

        if (testNGParams.containsKey("enableIdleTime") && testNGParams.get("enableIdleTime").equals("true")) {
            capabilities.setCapability("idleTimeout", 500);
            capabilities.setCapability("maxDuration", 2500);
        }
        return capabilities;
    }

    private DesiredCapabilities getLocalSimulatorCapabilities(Map<String, String> testNGParams) {
        DesiredCapabilities capabilities = new DesiredCapabilities();

        capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, testNGParams.get("deviceName"));
        capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, testNGParams.get("platformVersion"));
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, testNGParams.get("platformName"));
        String appPath = System.getProperty("user.dir").replace("/target","");
        String[] token = appPath.split("/");
        appPath= appPath.replace(token[token.length-1],"");
        capabilities.setCapability(MobileCapabilityType.APP, ""+appPath+""+testNGParams.get("appLocation"));
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 120);
        capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, testNGParams.get("automationName"));
        Boolean b = Boolean.parseBoolean(testNGParams.get("fullReset"));
        capabilities.setCapability(MobileCapabilityType.FULL_RESET, b);
        capabilities.setCapability(MobileCapabilityType.NO_RESET, !b);

        if (testNGParams.get("platformName").equalsIgnoreCase("ios")) {
            capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "XCUITest");
            capabilities.setCapability(IOSMobileCapabilityType.USE_NEW_WDA, Boolean.parseBoolean(testNGParams.get("useNewWDA")));
            int port = SocketUtils.findAvailableTcpPort();
            capabilities.setCapability(IOSMobileCapabilityType.WDA_LOCAL_PORT, port);
            //capabilities.setCapability("udid", testNGParams.get("deviceUDID"));
        } else {
            capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UIAutomator2");
            int port = SocketUtils.findAvailableTcpPort(8200, 8309);
            capabilities.setCapability(AndroidMobileCapabilityType.SYSTEM_PORT, port);
            capabilities.setCapability(AndroidMobileCapabilityType.AVD, testNGParams.get("deviceName"));
            capabilities.setCapability(AndroidMobileCapabilityType.AVD_LAUNCH_TIMEOUT, 300000);
            capabilities.setCapability(AndroidMobileCapabilityType.AVD_READY_TIMEOUT, 300000);
            capabilities.setCapability("uiautomator2ServerLaunchTimeout", 300000);
            capabilities.setCapability(AndroidMobileCapabilityType.APP_WAIT_ACTIVITY, "com.asda.android.*");

        }
        if (testNGParams.containsKey("enableIdleTime") && testNGParams.get("enableIdleTime").equals("true")) {
            capabilities.setCapability("idleTimeout", 500);
            capabilities.setCapability("maxDuration", 2500);
        }
        return capabilities;
    }

    private DesiredCapabilities getLocalDeviceCapabilities(Map<String, String> testNGParams) {
        DesiredCapabilities capabilities = new DesiredCapabilities();

        capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, testNGParams.get("deviceName"));
        //capabilities.setCapability("platformVersion", testNGParams.get("platformVersion"));
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, testNGParams.get("platformName"));
        capabilities.setCapability(MobileCapabilityType.APP, testNGParams.get("appLocation"));
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 120);
        Boolean b = Boolean.parseBoolean(testNGParams.get("fullReset"));
        capabilities.setCapability(MobileCapabilityType.FULL_RESET, b);
        capabilities.setCapability(MobileCapabilityType.NO_RESET, !b);
        if (testNGParams.get("platformName").equalsIgnoreCase("ios")) {
            capabilities.setCapability(IOSMobileCapabilityType.USE_NEW_WDA, Boolean.parseBoolean(testNGParams.get("useNewWDA")));
            capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "XCUITest");
            int port = SocketUtils.findAvailableTcpPort();
            capabilities.setCapability(IOSMobileCapabilityType.WDA_LOCAL_PORT, port);
            capabilities.setCapability(MobileCapabilityType.UDID, testNGParams.get("deviceUDID"));
            capabilities.setCapability(IOSMobileCapabilityType.XCODE_ORG_ID, testNGParams.get("xcodeOrgId"));
            capabilities.setCapability(IOSMobileCapabilityType.XCODE_SIGNING_ID, testNGParams.get("xcodeSigningId"));
        } else {
            capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UIAutomator2");
            int port = SocketUtils.findAvailableTcpPort(8200, 8209);
            capabilities.setCapability("systemPort", port);
            capabilities.setCapability(AndroidMobileCapabilityType.ANDROID_DEVICE_READY_TIMEOUT, 300);
            capabilities.setCapability(AndroidMobileCapabilityType.DEVICE_READY_TIMEOUT, 300);
            capabilities.setCapability("uiautomator2ServerLaunchTimeout", 300000);

        }
        if (testNGParams.containsKey("enableIdleTime") && testNGParams.get("enableIdleTime").equals("true")) {
            capabilities.setCapability("idleTimeout", 500);
            capabilities.setCapability("maxDuration", 2500);
        }
        return capabilities;
    }

    private Map<String, String> getTestParams() {
        return testParams.get();
    }

    protected Config getAPITestData() {
        return ConfigFactory.parseFile(new File(System.getProperty("user.dir").replace("/target","") + "/src/test/resources/api/testdata/" + environment + ".conf"));
    }

    protected Config getWebTestData() {
        return ConfigFactory.parseFile(new File(System.getProperty("user.dir").replace("/target","") + "/src/test/resources/web/testdata/" + environment + ".conf"));
    }

    protected Config getMobileTestData() {
        return ConfigFactory.parseFile(new File(System.getProperty("user.dir").replace("/target","") + "/src/test/resources/mobile/testdata/" + environment + ".conf"));
    }

}
