package com.asda.core.database;


import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public abstract class DatabaseType {
    private static final Set<DatabaseType> allDBs = new HashSet();
    private final String name;
    private final String description;

    public DatabaseType(String name, String description) {
        this.name = name;
        this.description = description;
        if (allDBs.contains(this)) {
            throw new IllegalArgumentException("A db with name: " + name + " is already registered.");
        } else {
            allDBs.add(this);
        }
    }

    public static DatabaseType getDatabaseType(String name) {
        Iterator var1 = allDBs.iterator();

        DatabaseType db;
        do {
            if (!var1.hasNext()) {
                return null;
            }

            db = (DatabaseType)var1.next();
        } while(!db.name.equals(name));

        return db;
    }

    public boolean equals(Object obj) {
        return obj != null && obj instanceof DatabaseType && this.name.equals(((DatabaseType) obj).name);
    }

    public int hashCode() {
        return this.name.hashCode();
    }

    public String toString() {
        return this.name + " - " + this.description;
    }
}
