package com.asda.core.reporters;

import com.asda.core.database.DBConnectionHolder;
import com.asda.core.enums.StatusEnum;
import com.asda.core.enums.SystemVariableEnum;
import com.asda.core.reporters.beans.ReportBean;
import com.asda.core.reporters.beans.ReportThreadLocal;
import com.asda.core.reporters.dao.impl.ReportDaoImpl;
import com.asda.core.reporters.model.TestCaseInfo;
import com.asda.core.reporters.model.TestSummaryInfo;
import com.asda.core.reporters.util.DataProviderIndex;
import com.asda.core.reporters.util.LogsUploadUtility;
import com.asda.core.webservice.BaseWebService;
import com.asda.core.webservice.WebServiceResponse;
import com.googlecode.sardine.util.SardineException;
import org.apache.commons.io.FileDeleteStrategy;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.testng.*;
import org.testng.annotations.Test;
import org.testng.asserts.IAssert;
import org.testng.asserts.IAssertLifecycle;

import java.io.*;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author dneela Implements ITestListener to perform the Test specific
 *         activities Implements ISuiteListener to perform activities before
 *         Suite execution and at the end of suite Execution Implements
 *         IExecutionListener to perform activities before Execution start and
 *         at the end of Execution Implements IConfigurationListner to perform
 *         the activities for each configuration method
 */
public class ReportListener implements ITestListener, IExecutionListener, ISuiteListener, IConfigurationListener, IAssertLifecycle {

	public static Set<String> suitePaths = new HashSet<String>();
	public static boolean logFilesDeleted = false;
	public static boolean htmlFolderDeleted = false;
	public static boolean testRerunAttemptDone = false;

	/*
	 * HACK
	 * 
	 * Waiting on
	 * https://groups.google.com/forum/#!starred/testng-dev/zx5yYSKgLNA to be
	 * resolved properly.
	 * 
	 * If a suite listener is added using annotations it would get registered as
	 * many times as we have test tags in suite.xml
	 * 
	 * This map is to track which osStart is called for which suite. And the
	 * boolean would have a value of true if onFinish is complete for a given
	 * suite.
	 * 
	 * HACK
	 */
	private static final Map<ISuite, Boolean> HACK_suiteListenerStatus = new HashMap<ISuite, Boolean>();

	/*
	 * HACK
	 * 
	 * Same problem mentioned above and additionally separate out the execution
	 * listener from other listeners.
	 * 
	 * HACK
	 */
	public static ThreadLocal<Boolean> HACK_executionListenerStartExecuted = ThreadLocal.withInitial(() -> false);
	private static boolean HACK_executionListenerEndExecuted = false;

	// Determines whether to publish the reports to Report database and Logs
	// server
	public static boolean publishReports = true;

	private static final ThreadLocal<TestCaseInfo> info = new ThreadLocal<TestCaseInfo>() {
		protected TestCaseInfo initialValue() {
			return new TestCaseInfo();
		}
	};

	private String release = "18.3";
	private String execType = "Regression";
	private String track = "UK";
	static int attemptNumber = 1;
	public static boolean isRunDirectoryCreated = false;
	//failed suite run 
	public static String isFailedSuiteRun = "no";
	public static String reporterInserstion="PortalService";
	public static String runDirectoryPath;
	private static boolean isSecondAttempt;
	public static int minTestToExecute=0;

	private static final Logger s_logger = LoggerFactory.getLogger(ReportListener.class);
	private static final Logger s_statusLogger = LoggerFactory.getLogger("STATUS_LOGGER");

	private static ReportDaoImpl rp;
	public static String TEST_RUN_ID;
	public static int randomWait=0;

	private final SimpleDateFormat timeFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	TestSummaryInfo summary;

	public ReportListener() {
		summary = new TestSummaryInfo();
		
	}

	@Override
	public void onTestStart(ITestResult result) {
		s_logger.info("Test started. {}", result.getMethod().getConstructorOrMethod().getMethod().getName());
		ReportBean rbean = ReportThreadLocal.getReportBean();
		s_logger.info("is failed suit value"+ isFailedSuiteRun);
		insertTestStartToReports(rbean);
	}

	/**
	 * Insert test start info to report database.
	 * 
	 * @param rBean
	 */
	private void insertTestStartToReports(ReportBean rBean) {
		// If publish reports is off, return from here.
		if (!ReportListener.publishReports) {
			return;
		}

		if (ReportListener.isSecondAttempt()) {
			s_logger.info(
					"Test Case Run start info adding to Database for attempt 2 for Run " + ReportListener.TEST_RUN_ID);
			isFailedSuiteRun="yes";
		} else {
			s_logger.info(
					"Test Case Run start info adding to Database for attempt 1 for Run " + ReportListener.TEST_RUN_ID);
		}

		try {
			ReportDaoImpl rp = DBConnectionHolder.getJDBCTemplate();
			info.get().setTestRunID(ReportListener.TEST_RUN_ID);
			info.get().setAreaName(rBean.getTestCaseArea());
			info.get().setTestCaseName(rBean.getTestCaseName() + "_" + rBean.getCurrentIndex());
			info.get().setOwner(rBean.getTestCaseOwner());
			info.get().setBrowser(rBean.getBrowser());
			info.get().setQcLocation(rBean.getTestCaseLocation());
			info.get().setStartTime(timeFormatter.format(rBean.getTestStartDate()));
			info.get().setAttemptNumber(attemptNumber);
			info.get().setTicketNumber("");	
			info.get().setDrilldownInfo("");
			info.get().setStatus(StatusEnum.RUNNING);
			info.get().setBrowserMachine(rBean.getBrowserMachine());
			info.get().setTestCaseId(rBean.getTestCaseId());
			info.get().setTestSuiteId(rBean.getTestCaseSuiteId());
			if(isFailedSuiteRun=="yes")
			{
				s_logger.info("inserting test case info details with attemptNumber="+ attemptNumber + "and when failed suite value is " + isFailedSuiteRun);
				rp.update(info);
				//updateTestcaseRunInDB(rBean);
			}
			else if (!ReportListener.testRerunAttemptDone && isFailedSuiteRun=="no" ) {

				try {
					s_logger.info("inserting test case info details with attemptNumber="+ attemptNumber + "and when failed suite value is " + isFailedSuiteRun);
					if(!rp.checkTestcaseExist(info.get().getTestRunID(),info.get().getTestCaseName()))
						rp.insert(info);
				} catch (org.springframework.dao.DuplicateKeyException ex) {
					s_logger.info("Duplicate DB Insertions errors are Supressed");
				}
			}
				 
			 else {
				s_logger.info("inserting test case info details with attemptNumber="+ attemptNumber + "and when failed suite value is " + isFailedSuiteRun);
				rp.update(info);
			}

			s_logger.info("Test Case Run start info added to Database :: " + ReportListener.TEST_RUN_ID);
		} catch (Exception e) {
			s_logger.error("Unable to add Run start info added to Database :: " + ReportListener.TEST_RUN_ID, e);
		}

	}

	@Override
	public void onTestSuccess(ITestResult result) {
	}

	@Override
	public void onTestFailure(ITestResult result) {
		storeExceptionIfExist(result);
	}

	@Override
	public void onTestSkipped(ITestResult result) {
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
	}

	@Override
	public void onStart(ITestContext context) {
		// ReportThreadLocal.unsetReportBean();
		//GeneralUtility.setLooperEnvironmentVariable("TEST_RUN_ID", TEST_RUN_ID);
	}

	@Override
	public void onFinish(ITestContext context) {

	}

	/**
	 * Copy the logs to the report server at the location specified in the bean
	 * ReportBean
	 * 
	 * @param bean
	 *            ReportBean which is extracted from ReportThreadLocal for the
	 *            test case being executed
	 */
	public void copyLogsToRemoteServer(ReportBean bean) {

		try {
			if (ReportListener.isSecondAttempt()) {
				s_logger.info("Copying logs to remote server for Attempt 2 for Run:: " + ReportListener.TEST_RUN_ID);
			} else {
				s_logger.info("Copying logs to remote server for Attempt 1 for Run:: " + ReportListener.TEST_RUN_ID);
			}

			File logFile = bean.getLogFile();
			if (logFile != null) {
				byte[] logFileInBytes = new byte[(int) logFile.length()];
				FileInputStream fileInputStream = new FileInputStream(logFile);
				fileInputStream.read(logFileInBytes);
				fileInputStream.close();
				String remoteLogPath = bean.getLogPath();

				String scriptlogfilename = "scriptLog_1.txt";
				if (ReportListener.isSecondAttempt()) {
					scriptlogfilename = "scriptLog_2.txt";
				}
				try {
					String url = LogsUploadUtility.getInstance().uploadFile(scriptlogfilename, remoteLogPath,
							logFileInBytes, false);
					bean.setLogPath(url);
				} catch (SardineException ex) {
					s_logger.error(
							"Could not upload the log file" + scriptlogfilename + " at location :: " + remoteLogPath,
							ex);
				}
			} else {
				s_logger.info("Did not upload the logs info to file server as log file is null");
			}
		} catch (IOException e) {
			s_logger.error("Could not update logs for this test ", e);
		} catch (NullPointerException e) {
			s_logger.error("changes for handel null pointer", e);
		}
	}

	/**
	 * Updates the execution details of the testcase by getting info from
	 * ReportBean
	 * 
	 * @param rBean
	 *            ReportBean which is extracted from ReportThreadLocal for the
	 *            test case being executed
	 */
	public void updateTestcaseRunInDB(ReportBean rBean) {
		if (ReportListener.isSecondAttempt()) {
			s_logger.info(
					"Test Case Run Details Saving to Database for attempt 2 for Run " + ReportListener.TEST_RUN_ID);
		} else {
			s_logger.info(
					"Test Case Run Details Saving to Database for attempt 1 for Run " + ReportListener.TEST_RUN_ID);
		}

		try {

			rp = DBConnectionHolder.getJDBCTemplate();
			String scriptLogDirPath = rBean.getLogPath();
			if (scriptLogDirPath != null) {
				scriptLogDirPath = scriptLogDirPath.replace("\\", "/");
			}
			info.get().setTestRunID(ReportListener.TEST_RUN_ID);
			info.get().setAreaName(rBean.getTestCaseArea());
			info.get().setTestCaseName(rBean.getTestCaseName() + "_" + rBean.getCurrentIndex());
			info.get().setOwner(rBean.getTestCaseOwner());
			info.get().setBrowser(rBean.getBrowser());
			info.get().setQcLocation(rBean.getTestCaseLocation());
			info.get().setScriptLogDir(scriptLogDirPath);
			Date date = rBean.getTestStartDate();
			String formatedDate = timeFormatter.format(date);
			info.get().setStartTime(formatedDate);
			info.get().setAttemptNumber(attemptNumber);
			try{
			if(!StringUtils.isEmpty(rBean.getTestInvType())){
				info.get().setTicketNumber(rBean.getTestInvType());	
			}else{
				info.get().setTicketNumber("");		
			}
			}catch(Exception e){
				info.get().setTicketNumber("");
			}
			info.get().setStatus((rBean.isSuccess() == true) ? StatusEnum.PASSED : StatusEnum.FAILED);
			info.get().setDrilldownInfo("");
			info.get().setTimeOutMessage("");
			boolean screenshotCaputred = false;
			if (rBean.getScreenshotPath() != null) {
				screenshotCaputred = isScreenshotCaptured(rBean.getScreenshotPath());
			}
			info.get().setIsScreenshotCaptured(screenshotCaputred);
			date = new Date();
			formatedDate = timeFormatter.format(date);
			info.get().setEndTime(formatedDate);
			if (rBean.getStartupExceptionName() != null) {
				info.get().setExceptionName(rBean.getStartupExceptionName());
				info.get().setExceptionErrorMessage(rBean.getStartupExceptionErrorMessage());
			} else {
				info.get().setExceptionName(rBean.getExceptionName());
				info.get().setExceptionErrorMessage(rBean.getExceptionErrorMessage());
			}
			info.get().setDuration(info.get().getStartTime(), info.get().getEndTime());
			//if(isFailedSuiteRun=="yes")
			rp.update(info);

			s_logger.info("Test Case Run Details Saved to Database :: " + ReportListener.TEST_RUN_ID);
		} catch (Exception e) {
			s_logger.error("Test Case Run Details Could not be Saved to Database :: " + ReportListener.TEST_RUN_ID, e);
		}

	}

	/**
	 * This method is called when the execution starts Properties are read from
	 * the feature project if exists and are overridden by the core properties
	 * file Create a run directory name for each run Check if the run is a
	 * second attempt by verifying the run.txt file
	 */
	@Override
	public void onExecutionStart() {
		if (HACK_executionListenerStartExecuted.get()) {
			return;
		}
		HACK_executionListenerStartExecuted.set(true);
		setRunDirectoryFolderName();
		checkIfSecondAttempt();
	}

	/**
	 * Check if the run is a second attempt by verifying the run.txt file
	 */
	private void checkIfSecondAttempt() {
		s_logger.info("Checking if the run is a second attempt");
		String generateRunTxtFile = ReportListener
				.getValueFromSystemProperties(SystemVariableEnum.GENERATE_RUN_ID_FILE.getSysVarName(), "false");
		String isFailedSuiteRunStr = ReportListener
				.getValueFromSystemProperties(SystemVariableEnum.IS_FAILED_SUITE_RUN.getSysVarName(), isFailedSuiteRun);  //check for 
		s_logger.info("#############################################################");
		s_logger.info("isFailedSuiteRun" + isFailedSuiteRun +"##########################" + "isFailedSuiteRunStr" + isFailedSuiteRunStr);
		s_logger.info("#############################################################");
				
		// if(isFailedSuiteRunStr.equalsIgnoreCase("yes") &&
		// generateRunTxtFile.equalsIgnoreCase("false")){
		if (isFailedSuiteRunStr.equalsIgnoreCase("yes")) {
			attemptNumber = 2;
		}
		if (attemptNumber == 2) {
			ReportListener.setSecondAttempt(true);
			s_logger.info("Executing Failed Suite for run " + ReportListener.TEST_RUN_ID);
		}

		boolean runIDExists = false;

		if (generateRunTxtFile.equals("true")) {
			File runFile = null;
			try {
				runFile = new File("run.txt");

				BufferedReader in = new BufferedReader(new FileReader(runFile));
				String runid = in.readLine();
				runid = runid.trim();
				if (runid != null) {
					if (runid.endsWith("_2")) {
						runIDExists = false;
						in.close();
						runFile.delete();
						s_logger.info("Deleted run txt");
					}
					if (runid.endsWith("_1")) {
						String s = runid.substring(runid.length() - 2);
						runid = runid.substring(0, runid.length() - 2).concat("_2");
						// runid=
						// runid.replace(runid.substring(runid.length()-2,
						// runid.length()), "_2");
						ReportListener.TEST_RUN_ID = runid;
						in.close();
						PrintWriter pw = new PrintWriter(new FileWriter(runFile));
						pw.println((ReportListener.TEST_RUN_ID));

						pw.close();
						runIDExists = true;
						ReportListener.isRunDirectoryCreated = true;
						ReportListener.setSecondAttempt(true);
						attemptNumber = 2;
					}
					// else{
					// ReportListener.TEST_RUN_ID = runid.trim().concat("_2");
					// }

				}

				// in.close();
			} catch (FileNotFoundException fe) {
				s_logger.info("File Not Found: run.txt" + fe.getMessage());
			} catch (IOException e) {
				s_logger.info("Could not Read data from run.txt" + e.getMessage());
			}

			if (!runIDExists) {
				try {
					if (!runFile.exists()) {
						runFile.createNewFile();

						PrintWriter pw = new PrintWriter(new FileWriter(runFile));
						ReportListener.TEST_RUN_ID = (ReportListener.TEST_RUN_ID).concat("_1");

						pw.println((ReportListener.TEST_RUN_ID));

						pw.close();
					}
				} catch (FileNotFoundException fe) {
					s_logger.info("File Not Found: run.txt" + fe.getMessage());
				} catch (Exception e) {
					s_logger.info("Could not Write data to run.txt" + e.getMessage());
				}
			}

			if (ReportListener.isSecondAttempt()) {
				s_logger.info("Second Attempt for Failed Testcases for run id " + ReportListener.TEST_RUN_ID);
			} else {
				s_logger.info("Execution Run is First Attempt for Run Id :: " + ReportListener.TEST_RUN_ID);
			}
		}
	}

	/**
	 * Update the summary data with initial run details if the run id is not a
	 * second attempt
	 */
	public void updateInitalSummaryData(ISuite suite, String track,
			String execType, String release, int minTestCount) {

		s_logger.info("inserting / updating summary table...");
		if (suite.getXmlSuite().getParameter("test.ReportService") != null)
			reporterInserstion = ReportListener.getValueFromSystemProperties(
					SystemVariableEnum.TEST_REPORTSERVICE.getSysVarName(),
					suite.getXmlSuite().getParameter("test.ReportService"));
		else {
			s_logger.info("Report service type is not mentioned in the suite file. Hence adding default value as PortalService");
			reporterInserstion = ReportListener
					.getValueFromSystemProperties(
							SystemVariableEnum.TEST_REPORTSERVICE
									.getSysVarName(), "PortalService");
		}
	s_logger.info("reporter insertion methods" +reporterInserstion);
		if (publishReports) {
			try {
				boolean summaryInserted = false;
				rp = DBConnectionHolder.getJDBCTemplate();

				if(isFailedSuiteRun=="no")
				 	summaryInserted = true;

				if (rp.getRunIdCount(ReportListener.TEST_RUN_ID)==0) {
                    s_logger.info("This is first run");
					summary.setTestRunID(ReportListener.TEST_RUN_ID);
					setValuesInSummary(summary, suite, track, execType, release, minTestCount, attemptNumber);
					if(summaryInserted==true)
						//addRandomWait();
					rp.insert(summary);
					s_logger.info("Adding initial data in Summary table for test run id :: " + summary.getTestRunID());

				} else {
					s_logger.info("This is second run");
					TestSummaryInfo s = rp.findSummary(ReportListener.TEST_RUN_ID);
					int attemptNumberInDb = s.getAttemptNumber();
					s_logger.info("@@@@@@@@@@@@attemptNumberInDb" + attemptNumberInDb);

					// Commented by Bramesh as No action needed to update the minimum test cases while re-running
                    // with the same test run ID
					/*if(attemptNumberInDb==1)
					{
						//addRandomWait();
					//call update
						//getRunIdCount(summary.getTestRunID());
						rp.getMinTestExecuteValue(summary.getTestRunID());
						rp.updateMinimumTestToExecute(summary);
					}*/
					if (attemptNumberInDb == 2) {
						ReportListener.testRerunAttemptDone = true;
					}
					s.setAttemptNumber(attemptNumber);
					if (s.getStartTime() == null) {
						s_logger.info("start time found to be null in attempt number" + attemptNumber);
						summaryInserted = true;
					}

					if (summaryInserted) {
						s.setStartTime(timeFormatter.format(new Date()));
						s.setHost(getIpAddress());
						s.setReleaseNumber(release);
						s.setType(execType);
						s.setMinTestsToExecute(minTestCount);
						s.setJobUrl(getValueFromSystemProperties(
								SystemVariableEnum.JENKINS_ENV_BUILD_URL.getSysVarName(), null));

						rp.updateSummaryStartTime(s);//gto be commented
					}
					else {
					    // Commented by Bramesh as comment is not valid anymore

						/*StringBuilder sb = new StringBuilder();
						sb.append(getNonNullString(s.getComments()));
						sb.append(String.format("%s: %s\n", "Host", s.getHost()));
						sb.append(String.format("%s: %s\n", "Environment", s.getQAEnv()));
						sb.append(String.format("%s: %s\n", "Track", s.getTrack()));
						sb.append(String.format("%s: %s\n", "ReleaseNumber", s.getReleaseNumber()));
						sb.append(String.format("%s: %s\n", "Type", s.getType()));
						sb.append(String.format("%s: %s\n", "StartTime", s.getStartTime()));
						sb.append(String.format("%s: %s\n", "EndTime", s.getEndTime()));
						sb.append(String.format("%s: %s\n", "MinTestsToExecute", s.getMinTestsToExecute()));
						sb.append(String.format("%s: %s\n", "JobUrl", s.getJobUrl()));
						sb.append("================================================================\n");
						setValuesInSummary(s, suite, track, execType, release, minTestCount, attemptNumber);
						s.setComments(sb.toString()); // Update comments*/
						s.setEndTime(null); // Update end to null
						rp.updateFullSummary(s);
					}

					summary = s; // Override the value.
				}
			} catch (Exception e) {
				s_logger.error("Could not insert the Summary info in report database " + e.getMessage(), e);
			}
		} else {
			s_logger.info("Publish Report is set to No");
		}

	}

	private void setValuesInSummary(TestSummaryInfo s, ISuite suite, String track, String execType, String release,
			int minTestCount, int attemptNumber) {
		s.setHost(getIpAddress());
		s.setQAEnv(ReportListener.getValueFromSystemProperties(SystemVariableEnum.TEST_ENV.getSysVarName(),
				suite.getXmlSuite().getParameter("test.env")));//changed env
		s.setTrack(track);
		s.setReleaseNumber(release);
		s.setType(execType);
		s.setStartTime(timeFormatter.format(new Date()));
		s.setMinTestsToExecute(minTestCount);
		s.setJobUrl(getValueFromSystemProperties(SystemVariableEnum.JENKINS_ENV_BUILD_URL.getSysVarName(), null));
		s.setAttemptNumber(attemptNumber);
		s.setAppName(getValueFromSystemProperties(SystemVariableEnum.APPNAME.getSysVarName(), 
				"Local"));

		String tcrFlag = getValueFromSystemProperties(SystemVariableEnum.TCRFLAG.getSysVarName(),
				suite.getXmlSuite().getParameter("tcr.flag"));
		if(null!=tcrFlag)s.setTcr_flag(tcrFlag);
		else s.setTcr_flag("false");
	}

	private String getNonNullString(String input) {
		if (input == null) {
			return "";
		}
		return input;
	}

	/**
	 * Executed at the end of the execution
	 */
	@Override
	public void onExecutionFinish() {
		if (HACK_executionListenerEndExecuted) {
			return;
		}
		HACK_executionListenerEndExecuted = true;
		if (ReportListener.publishReports) {
			try {
				rp = DBConnectionHolder.getJDBCTemplate();
				summary.setEndTime(timeFormatter.format(new Date()));
				rp.update(summary);
				s_logger.info("Updated data in Summary table for test run id :: {}", ReportListener.TEST_RUN_ID);
			} catch (Exception e) {
				s_logger.error("Could not update the Summary info in report database " + e.getMessage(), e);
			}
		}
		if (ReportListener.publishReports) {
			try {
				s_logger.info("***********Starting SYNC API********************");
				BaseWebService service = new BaseWebService();
				WebServiceResponse res = new WebServiceResponse();
				HashMap<String, String> header = new HashMap<String, String>();
				HashMap<String, String> postParam = new HashMap<String, String>();
				s_logger.info("Starting syncRunCountApi");
				String url = "http://testburst.walmart.com/getData?testid1="
						+ ReportListener.TEST_RUN_ID;
				res = service.invokeRESTPutRequestNew(url, header, postParam, false);
			} catch (Exception ee) {
				s_logger.error("**********Could not sync run count************** "
						+ ee);
			}
		} else {
			s_logger.info("publish report is false. Not firing sync api");
		}

	}

	/**
	 * Create a run directory name for each run
	 */
	protected final static void setRunDirectoryFolderName() {
		s_logger.info("Creating the run directory for current run");
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss-SSS");
		ReportListener.TEST_RUN_ID = df.format(new Date());
		ReportListener.TEST_RUN_ID = getValueFromSystemProperties(SystemVariableEnum.TEST_RUN_ID.getSysVarName(),
				ReportListener.TEST_RUN_ID);
		s_logger.info("Run ID :: " + ReportListener.TEST_RUN_ID);
	}

	public static void deleteHtmlFolder(String htmlFolderPath) throws IOException {
		File htmlfolder = new File(htmlFolderPath);
		htmlfolder.setWritable(true);
		FileDeleteStrategy.FORCE.delete(htmlfolder);
		s_logger.info("Deleted the html folder at location :: " + htmlfolder);
		htmlFolderDeleted = true;
	}

	public static void deleteSuiteLogFiles(String path) throws IOException {
		File fin = new File(path);
		List<String> folderList = new ArrayList<String>();
		File[] listOfFiles = fin.listFiles();

		if (listOfFiles != null) {
			for (File file : fin.listFiles()) {
				if (file.isDirectory() || file.getName().equals("allTestsLog.log")
						|| file.getName().equals("status.log") || file.getName().equals("testSpecific.log")) {
					folderList.add(file.getAbsolutePath());
				}
			}

			if (folderList.size() > 0) {
				s_logger.info("Deleting the Test Folders in Suite Directory at path :: " + path);
			}

			for (String folder : folderList) {
				File folderDir = new File(folder);
				folderDir.setWritable(true);
				FileDeleteStrategy.FORCE.delete(folderDir);
				s_logger.info("Deleted the test folder at location :: " + folderDir);
			}
		}

		logFilesDeleted = true;
	}

	/**
	 * Executed at the beginning of the suite execution and creates a run
	 * directory and sets testOutputDir in MDC
	 */
	@Override
	public void onStart(ISuite suite) {

		if (HACK_suiteListenerStatus.containsKey(suite)) {
			return;
		} else {
			HACK_suiteListenerStatus.put(suite, false);
		}

		String outputDir = suite.getOutputDirectory();
		String htmlFolderDir = new File(outputDir).getParent() + "/html";

		if (htmlFolderDeleted == false) {
			try {
				deleteHtmlFolder(htmlFolderDir);
			} catch (IOException e) {
				s_logger.info("Unable to delete html folder at location" + htmlFolderDir);
			}
		}

		if (logFilesDeleted == false) {
			try {
				deleteSuiteLogFiles(outputDir);
			} catch (IOException e) {
				s_logger.info("Unable to delete old files");
			}
		}

		String publishReportsParamVal = suite.getXmlSuite().getParameter("test.publishreports");
		s_logger.info("publishReportsParamVal :: " + publishReportsParamVal);

		if (publishReportsParamVal == null) {
			publishReportsParamVal = "no";
		}



		String publishReports = getValueFromSystemProperties(SystemVariableEnum.TEST_PUBLISH_REPORTS.getSysVarName(),
				publishReportsParamVal);




		s_logger.info("publishReports :: " + publishReports);

        ReportListener.publishReports = publishReports.equalsIgnoreCase("yes");
		s_logger.info("ReportListener.publishReports :: " + ReportListener.publishReports);
       
		String runDirPath = suite.getOutputDirectory();
		suitePaths.add(runDirPath);

		runDirectoryPath = runDirPath;
		s_logger.info("Run direcotry path :: " + runDirectoryPath);

		MDC.put("testOutputDir", runDirectoryPath);
		s_logger.info("Test Output Directory set to MDC :: " + runDirectoryPath);

		String releaseFromSuite = suite.getXmlSuite().getParameter("execution.release");
		if (releaseFromSuite != null && (!releaseFromSuite.equals(""))) {
			this.release = releaseFromSuite;
		}

		String execTypeFromSuite = suite.getXmlSuite().getParameter("execution.type");
		if (execTypeFromSuite != null && (!execTypeFromSuite.equals(""))) {
			this.execType = execTypeFromSuite;
		}

		String trackFromSuite = suite.getXmlSuite().getParameter("execution.track");
		if (trackFromSuite != null && (!trackFromSuite.equals(""))) {
			this.track = trackFromSuite;
		}

		this.release = ReportListener.getValueFromSystemProperties(SystemVariableEnum.EXECUTION_RELEASE.getSysVarName(),
				this.release);
		this.track = ReportListener.getValueFromSystemProperties(SystemVariableEnum.EXECUTION_TRACK.getSysVarName(),
				this.track);
		/*-------------------------------------------------------------------*/
		/*
		 * this.execType =
		 * ReportListener.getValueFromSystemProperties(SystemVariableEnum.
		 * EXECUTION_TYPE.getSysVarName(), this.execType);
		 */

		// Hack to accommodate Check-Out in reports - remove the below try/catch
		// block when test is done.
		try {

			String isNewCheckout = suite.getXmlSuite().getParameter("isNewCheckout");

			if (isNewCheckout.contains("true")) {
				this.execType = ReportListener
						.getValueFromSystemProperties(SystemVariableEnum.EXECUTION_TYPE.getSysVarName(), "Check-Out");
			} else {
				this.execType = ReportListener
						.getValueFromSystemProperties(SystemVariableEnum.EXECUTION_TYPE.getSysVarName(), this.execType);
			}
		} catch (Exception ignored) {
			this.execType = ReportListener
					.getValueFromSystemProperties(SystemVariableEnum.EXECUTION_TYPE.getSysVarName(), this.execType);
		}
		/*-------------------------------------------------------------------*/
		
		int minTestCount = suite.getAllMethods().size();
		s_logger.info(
				"Tests to be executed in this run {} (min tests, tests from factories, data provider may increase this): {}",
				ReportListener.TEST_RUN_ID, minTestCount);
		s_statusLogger.info(
				"Tests to be executed in this run {} (min tests, tests from factories, data provider may increase this): {}",
				ReportListener.TEST_RUN_ID, minTestCount);

		updateInitalSummaryData(suite, this.track, this.execType, this.release, minTestCount);
	}

	@Override
	public void onFinish(ISuite suite) {
		
	}

	/**
	 * Checks whether screenshot is captured and saved to file server
	 * 
	 * @param screenshotPath
	 * @return isSSCaptured
	 */
	private boolean isScreenshotCaptured(String screenshotPath) {
		String screenshotfilename = "screenshot_for_attempt_2.jpg";
		if (ReportListener.isSecondAttempt()) {
			screenshotfilename = "screenshot_for_attempt_2.jpg";
		}
		boolean isSSCaptured = false;
		try {
			isSSCaptured = LogsUploadUtility.getInstance().isFileExists(screenshotPath + "/" + screenshotfilename);
		} catch (Exception e) {
			s_logger.info("Could not verify whether screenshot" + screenshotfilename + " is captured or not at path "
					+ screenshotPath + " " + e.getMessage());
		}
		return isSSCaptured;

	}

	/**
	 * Gets the current index of data set if data provider is used
	 * 
	 * @param result
	 * @return
	 */
	public static String getCurrentDataIndex(ITestResult result) {
		String currentIndex = "1";
		String dataProvider = result.getMethod().getConstructorOrMethod().getMethod().getAnnotation(Test.class)
				.dataProvider();
		if (dataProvider != null && (!dataProvider.equals(""))) {
			try {
				Object[] parameters = result.getParameters();
				return getCurrentDataIndex(currentIndex, parameters);
			} catch (Exception e) {
				s_logger.debug("Cannot cast non Integer values");
			}
		}
		return currentIndex;
	}

	/**
	 * Get current index from parameters if there is any.
	 * 
	 * @param defaultIndex
	 * @param parameters
	 * @return
	 */
	public static String getCurrentDataIndex(String defaultIndex, Object[] parameters) {
		if (parameters.length == 0) {
			return defaultIndex;
		}
		Object lastParamInDP = parameters[parameters.length - 1];
		if (parameters.length > 1) {
			Object secondlastvalue = parameters[parameters.length - 2];
			String svalue = null;

			if (lastParamInDP instanceof DataProviderIndex) {
				int dataIndex = ((DataProviderIndex) lastParamInDP).getIndex();
				if (null != secondlastvalue) {
					svalue = String.valueOf(secondlastvalue);
					if (svalue.contains("addInfo")) {
						svalue = "_" + svalue.substring(svalue.indexOf("_") + 1);
						return dataIndex + svalue;
					} else
						return String.valueOf(dataIndex);
				}

			} else {
				return defaultIndex;
			}
		}
		else if (lastParamInDP instanceof DataProviderIndex) {
			int dataIndex = ((DataProviderIndex) lastParamInDP).getIndex();
			return String.valueOf(dataIndex);
		} else {
			return defaultIndex;
		}
		return defaultIndex;
	}

	/**
	 * Copies the screenshot file to remote server
	 * 
	 * @param bean
	 *            Bean fetched from ReportThreadLocal
	 */
	private void copyScreenshotToRemoteServer(ReportBean bean) {
		try {
			s_logger.info("Copying screenshots to remote server for Attempt :: " + attemptNumber + "  for Run:: "
					+ ReportListener.TEST_RUN_ID);
			String screenshotFilePath = bean.getScreenshotPath();
			File screenshot = bean.getScreenshot();
			if (screenshot != null) {
				byte[] fileInBytes = new byte[(int) screenshot.length()];
				FileInputStream fileInputStream = new FileInputStream(screenshot);
				fileInputStream.read(fileInBytes);
				fileInputStream.close();
				String screenshotfilename = "screenshot_for_attempt_2.jpg";
				if (ReportListener.isSecondAttempt()) {
					screenshotfilename = "screenshot_for_attempt_2.jpg";
				}
				try {
					String url = LogsUploadUtility.getInstance().uploadFile(screenshotfilename, screenshotFilePath,
							fileInBytes, true);
					bean.setScreenshotPath(url);
				} catch (SardineException ex) {
					s_logger.error("Could not upload the log file" + screenshotfilename + " at location :: "
							+ screenshotFilePath, ex);
				}
			} else {
				s_logger.info("Did not upload the screenshot info to file server as screenshot is null");
			}
		} catch (Exception e) {
			s_logger.error("Could not copy the screenshot to Remote Server" + bean.getScreenshotPath(), e);
		}
	}

	/**
	 * Will be executed every time a configuration method execution is success
	 */
	@Override
	public void onConfigurationSuccess(ITestResult itr) {
		s_logger.info("On success of configuration method.");
		saveLogsAndScreenshots(itr);
	}

	/**
	 * Will be executed every time a configuration method execution is failed
	 */
	@Override
	public void onConfigurationFailure(ITestResult itr) {
		s_logger.error("Exception in configuration method.", itr.getThrowable());
		saveLogsAndScreenshots(itr);
	}

	/**
	 * Will be executed every time a configuration method execution is skipped
	 */
	@Override
	public void onConfigurationSkip(ITestResult itr) {
		s_logger.info("On skip of configuration method: {}.", itr.getMethod());
		saveLogsAndScreenshots(itr);
	}

	/**
	 * Helper method that checks whether test is finished, whether to publish
	 * reports or not and if the results are already updated to database Calls
	 * the appropriate methods to copy logs, screenshots and update results to
	 * database if all conditions pass
	 * 
	 * @param itr
	 */
	private void saveLogsAndScreenshots(ITestResult itr) {
		storeExceptionIfExist(itr);
		ReportBean rBean = ReportThreadLocal.getReportBean();
		if (rBean != null) {
			if (rBean.isTestFinished() && (rBean.isResultsUpdatedToDB() == false)
					&& ReportListener.publishReports == true) {
				copyScreenshotToRemoteServer(rBean);
				copyLogsToRemoteServer(rBean);
				updateTestcaseRunInDB(rBean);
				rBean.setResultsUpdatedToDB(true);
			}
		}
	}

	/**
	 * Capture the exception info in testResult and store in ReportBean.
	 * 
	 * @param testResult
	 */
	private void storeExceptionIfExist(ITestResult testResult) {
		ReportBean rBean = ReportThreadLocal.getReportBean();
		// Exception during test case execution. Set this info in ReportBean so
		// that it carried to reports.
		if (rBean != null && testResult.getThrowable() != null) {
			rBean.setExceptionName(testResult.getThrowable().getClass().getSimpleName());
			String message = testResult.getThrowable().getMessage();

			// If no detailed message is found try to get to the class name,
			// method and line from trace and use it instead.
			if (message == null) {
				StackTraceElement[] stackTrace = testResult.getThrowable().getStackTrace();
				if (stackTrace != null & stackTrace.length > 0) {
					message = testResult.getThrowable().getClass().getName() + " - " + stackTrace[0].getClassName()
							+ "." + stackTrace[0].getMethodName() + " at line " + stackTrace[0].getLineNumber();
				}
			}
			rBean.setExceptionErrorMessage(message);
		}
	}

	/**
	 * getter of isSecondAttempt
	 * 
	 * @return isSecondAttempt
	 */
	public static boolean isSecondAttempt() {
		return isSecondAttempt;
	}

	/**
	 * Setter of isSecondAttempt
	 * 
	 * @param isSecondAttempt
	 */
	public static void setSecondAttempt(boolean isSecondAttempt) {
		ReportListener.isSecondAttempt = isSecondAttempt;

	}

	/**
	 * Helper method that returns the ip address of the machine whether the test
	 * is being executed
	 *
	 * @return ipAddress
	 */
	private String getIpAddress() {
		InetAddress ip;
		try {
			ip = InetAddress.getLocalHost();
			s_logger.info("Current IP address : {}", ip.getHostAddress());
			return ip.toString();
		} catch (UnknownHostException e) {
			s_logger.error("Could not fetch ip address", e);
		}
		return null;

	}

	/**
	 * Checks if the values is inputed through command as a system property and
	 * overrides the values in suite.xml file
	 * 
	 * @param key
	 *            parameter key
	 * @param defaultValue
	 *            value of the parameter
	 * @return returns the value from the command input if given
	 */
	// public static String getValueFromSystemProperties(String key, String
	// defaultValue) {
	// String value = System.getProperty(key);
	// // if(value == null || value.equals("null")) {
	// // value = System.getenv(key);
	//
	// if(value == null || value.equals("null")) {
	// return defaultValue;
	// } else {
	// s_logger.debug("Using overridden value for {} as {} from env vars.", key,
	// value);
	// }
	// return null;
	// }
	// // } else {
	// // s_logger.debug("Using overridden value for {} as {} from system
	// properties.", key, value);
	// // }
	// //
	// // return value; // Use override value if exist from system property.
	// //
	// // }

	public static String getValueFromSystemProperties(String key, String defaultValue) {
		try {
			
			String value = System.getProperty(key);
			if (value == null || value.equals("null")) {
				value = System.getenv(key);
				if (value == null || value.equals("null") || value.contains(key) || value.isEmpty()) {
					
					return defaultValue;
				} else {
					s_logger.debug("Using overridden value for {} as {} from env vars.", key, value);
				}
			} else {
				s_logger.debug("Using overridden value for {} as {} from system properties.", key, value);
			}

			return value; // Use override value if exist from system property.
		} catch (Exception e) {
			return defaultValue;
		}

	}

	public String getRelease() {
		return release;
	}

	public void setRelease(String release) {
		this.release = release;
	}

	public String getExecType() {
		return execType;
	}

	public void setExecType(String execType) {
		this.execType = execType;
	}

	public String getTrack() {
		return track;
	}

	public void setTrack(String track) {
		this.track = track;
	}

	protected void intializeReportProperties() {
	}

	@Override
	public void executeAssert(IAssert<?> assertCommand) {
		System.out.println("executeAssert");
	}

	@Override
	public void onAssertSuccess(IAssert<?> assertCommand) {
		System.out.println("onAssertSuccess");
	}

	@Override
	public void onAssertFailure(IAssert<?> assertCommand, AssertionError ex) {
		System.out.println("onAssertFailure");
	}

	@Override
	public void onBeforeAssert(IAssert<?> assertCommand) {
		System.out.println("onBeforeAssert");
	}

	@Override
	public void onAfterAssert(IAssert<?> assertCommand) {
		System.out.println("onAfterAssert");
	}
}
