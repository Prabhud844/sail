package com.asda.core.listener;

import com.asda.core.reporters.ReportListener;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.MDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.*;
import org.testng.xml.XmlSuite;
import org.uncommons.reportng.HTMLReporter;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * @author dneela
 * 
 */

public class ScreenshotHTMLReporter extends HTMLReporter implements ITestListener {
	
	private static final Logger s_logger = LoggerFactory.getLogger(ScreenshotHTMLReporter.class);

	/**
	 * Adding the script log path and screenshot to the html report being generated when test fails
	 */
    public void onTestFailure(ITestResult tr) {
        try {        
        	
        	String suiteName = tr.getTestContext().getSuite().getName();
        	String ssLogPath = suiteName+"/"+getScreenshotLogPath();
        	String invocationCount = ReportListener.getCurrentDataIndex(tr);
        	String screenshot ="screenshot_"+invocationCount+".png";
        	String sspath =ssLogPath+"//"+screenshot;
        	String logPath = ssLogPath+"/testSpecific.log";
        	

        	Reporter.log("<p style='color:red'> Script Log: <a href='" + logPath + "' target='_blank' >testSpecific.log</a></p>");
        	Reporter.log("<p style='color:red'> Screenshot: <a href='" + sspath + "' target='_blank' >" + screenshot + "</a></p>");
            
           
    
        } catch (Exception e) {
			System.out.println("error generating screenshot: "+e);
        }
	}
    /**
     * Adding the script log path to the html report being generated when test is success
     */
	@Override
	public void onTestSuccess(ITestResult result) {
		String suiteName = result.getTestContext().getSuite().getName();
    	String ssLogPath = suiteName+"/"+getScreenshotLogPath();
		String logPath = ssLogPath+"//testSpecific.log";
		Reporter.log("<p style='color:red'> Script Log: <a href='" + logPath + "' target='_blank' >testSpecific.log</a></p>");
	}


	@Override
	public void onTestStart(ITestResult iTestResult) {
	    // Attempt to count invocations of a DataProvider-instrumented test
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub		
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub		
	}

	@Override
	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub		
	}

	@Override
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub		
	}
	/**
	 * Generating html report and copying the html directory to run directory
	 */
	@Override
	public void generateReport(List<XmlSuite> xmlSuites,
            List<ISuite> suites,
            String outputDirectoryName){
		super.generateReport(xmlSuites, suites, outputDirectoryName);
		copyReportToRunDirectory();
		
	}
	
	/**
	 * returns the screenshot and log folder path
	 * @return
	 */
	private String getScreenshotLogPath(){		
		String ssLogPath = 	MDC.get("testCaseId")+"";
		return ssLogPath;
		}
	/**
	 * Copies the html report to run directory
	 */
	private void copyReportToRunDirectory(){
		
		//Create a new run id direcotry if doesnt exists
		s_logger.info("Run direcotry path :: "+ ReportListener.runDirectoryPath);
		if(! ReportListener.isRunDirectoryCreated){
			String runTime = ""+ReportListener.TEST_RUN_ID;
			
			String outputDirectory = new File((String) MDC.get("testOutputDir")).getParent();
			File f = new File(outputDirectory+"/"+runTime);
			
			boolean fileCreated = f.mkdirs();
			
			if(fileCreated)
			ReportListener.isRunDirectoryCreated = true;
			
		}
		
		String baseDir = (String) MDC.get("testOutputDir");
		String outputDirectory = new File(baseDir).getParent();
		String srcDir = outputDirectory + "/html";

		baseDir = outputDirectory +"/"+ReportListener.TEST_RUN_ID;
		File sourceDir = new File(srcDir);

		File destDir = new File(baseDir);

		
		
		//Copies the suite directories to html directory
		for(String path :ReportListener.suitePaths){
			String outDir = new File((String) MDC.get("testOutputDir")).getParent()+ "/html";
			
			File sourceDirectory = new File(path);	

			File destinationDir = new File(outDir);

			if(destinationDir.exists() && sourceDirectory.exists() ){
				try {
					FileUtils.copyDirectoryToDirectory(sourceDirectory, destinationDir);
				} catch (IOException e) {
					s_logger.debug("Could not copy Suite folder to html directory " + destinationDir );
					e.printStackTrace();
				}
			}else{
				s_logger.debug("Suite Directory or html Directory is missing");
			}
			
		}
		
		//Copies html direcotry to run directory
		if(destDir.exists() && sourceDir.exists() ){
			try {
				FileUtils.copyDirectoryToDirectory(sourceDir, destDir);

			} catch (IOException e) {
				s_logger.debug("Could not copy html folder to run directory " + destDir );
				e.printStackTrace();
			}
		}else{
			s_logger.debug("Source Directory or Run Directory is missing");
		}		
	}
	
	
	
  }
