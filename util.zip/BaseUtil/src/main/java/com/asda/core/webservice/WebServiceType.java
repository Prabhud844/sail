package com.asda.core.webservice;

public enum WebServiceType {

	SOAP(1, "SOAP"),
	REST_GET(2, "REST_GET"),
	REST_POST(3, "REST_POST (params)"),
	REST_POST_XML(4, "REST_POST_XML (body)"),
	PUT_XML(5, "PUT_XML"),
	PUT_JSON(6, "PUT_JSON"),
	REST_DELETE(7, "REST_DELETE"),
	REST_POST_JSON(8, "REST_POST_JSON (body)"),
	;
	
	private final int id;
	private final String name;
	WebServiceType(int id, String name) {
		this.id = id;
		this.name = name;
	}
	
	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public static WebServiceType getById(int id) {
		for(WebServiceType wsType : values()) {
			if(wsType.getId() == id) {
				return wsType;
			}
		}
		return null;
	}
}
