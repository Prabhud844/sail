package com.asda.core.utils;

import com.asda.core.baseexecution.ExecutionConfig;
import com.asda.core.enums.FindElementByEnum;
import com.google.common.base.Function;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nullable;
import java.util.List;

/**
 * @author dneela
 * 
 */

public class SeleniumWebDriverUtility {

	private static final Logger s_logger = LoggerFactory
			.getLogger(SeleniumWebDriverUtility.class);

	private final WebDriver driver;
	private static long PAGE_LOAD_TIMEOUT = 60;
	private static long ELEMENT_WAIT_TIMEOUT = 60;
	private static final long PAGE_LOAD_TIMEOUT_IN_MILLI_SECS;
	private static final long ELEMENT_WAIT_TIMEOUT_IN_MILLI_SECS;

	static {
		PAGE_LOAD_TIMEOUT = ExecutionConfig.getInstance().getLongValue(
				"PAGE_LOAD_TIMEOUT", PAGE_LOAD_TIMEOUT);
		ELEMENT_WAIT_TIMEOUT = ExecutionConfig.getInstance().getLongValue(
				"ELEMENT_WAIT_TIMEOUT", ELEMENT_WAIT_TIMEOUT);
		PAGE_LOAD_TIMEOUT_IN_MILLI_SECS = PAGE_LOAD_TIMEOUT * 1000;
		ELEMENT_WAIT_TIMEOUT_IN_MILLI_SECS = ELEMENT_WAIT_TIMEOUT * 1000;
	}

	public SeleniumWebDriverUtility(WebDriver driverIn) {
		if (driverIn == null) {
			throw new RuntimeException("Invalid browser instance");
		}
		driver = driverIn;
	}

	/**
	 * Wait for page to load completely.
	 * 
	 * @throws InterruptedException
	 */
	public void waitForPageLoad() throws InterruptedException {
		waitForPageLoad(driver);
	}

	/**
	 * Wait for page to load completely.
	 * 
	 * @param driver
	 */
	public static void waitForPageLoad(WebDriver driver) {
		try {
			new WebDriverWait(driver, PAGE_LOAD_TIMEOUT)
					.until(new Function<WebDriver, Boolean>() {
						//@Override
						public Boolean apply(@Nullable WebDriver input) {
							if (input == null) {
								return false;
							}
							Object resp = ((JavascriptExecutor) input)
									.executeScript("return document.readyState=='complete'");
                            return resp instanceof Boolean && ((Boolean) resp);
                        }
					});
		} catch (Exception e) {
			s_logger.info("Exception waiting for page to load: {}", e);
		}
	}

	public void clearCookies() {
		driver.manage().deleteAllCookies();
	}

	public void clearCookie(String cookieName) {
		driver.manage().deleteCookieNamed(cookieName);
	}

	public void clearCookie(Cookie cookie) {
		driver.manage().deleteCookie(cookie);
	}

	public boolean isCookiePresent(String cookieName) {
		return driver.manage().getCookieNamed(cookieName).getName() != null;

	}

	public String getCookie(String cookieName) {
		return driver.manage().getCookieNamed(cookieName).getName();
	}

	public void open(String url) {
		driver.get(url);
	}

	public String getPageTitle() {
		return driver.getTitle();
	}

	public String getCurrentUrl() {
		return driver.getCurrentUrl();
	}

	public String getPageSource() {
		return driver.getPageSource();
	}

	public void click(FindElementByEnum findElementBy, String locator) {
		WebElement element = findelement(findElementBy, locator);
		element.click();
	}

	public void selectRadioOption(FindElementByEnum findElementBy,
								  String locator) {
		WebElement element = findelement(findElementBy, locator);
		element.click();
	}

	public void selectDropDownValue(WebElement element, String value) {
		Select droplist = new Select(element);
		droplist.selectByVisibleText(value);
	}

	public void selectDropDownByIndex(WebElement element, int index) {
		Select droplist = new Select(element);
		droplist.selectByIndex(index);
	}

	public void check(FindElementByEnum findElementBy, String locator) {
		click(findElementBy, locator);
	}

	public void uncheck(FindElementByEnum findElementBy, String locator) {
		click(findElementBy, locator);
	}

	public void type(FindElementByEnum findElementBy, String locator,
			String text) {
		WebElement element = findelement(findElementBy, locator);
		element.sendKeys(text);
	}

	public String getText(FindElementByEnum findElementBy, String locator) {
		WebElement element = findelement(findElementBy, locator);
		return element.getText();
	}

	public void clickAndWaitForPageToLoad(FindElementByEnum findElementBy,
			String locator) throws InterruptedException {
		click(findElementBy, locator);
		waitForPageLoad();
	}

	public boolean isTextPresent(String text) {

		try {
			String locator = "//*[contains(.,'" + text + "')]";
			findelement(FindElementByEnum.XPATH, locator);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	public boolean isTextPresent(String text, long timeOutInMilliSec) {
		try{
			WebDriverWait webDriverWait = new WebDriverWait(driver, timeOutInMilliSec);
			return webDriverWait.until(ExpectedConditions.visibilityOf(findelement(FindElementByEnum.XPATH, "//*[contains(.,'" + text + "')]"))).isDisplayed();
		}catch (Exception ex){
			return false;
		}
	}

	public boolean isElementPresent(FindElementByEnum findElementBy,
			String locator) {
		try {
            return findelement(findElementBy, locator).isDisplayed();
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	public void selectWindow(String nameOrHandle) {
		driver.switchTo().window(nameOrHandle);
	}

	public void selectFrame(String frameNameOrId) {
		String windowHandle = driver.getWindowHandle();
		driver.switchTo().window(windowHandle);
		driver.switchTo().frame(frameNameOrId);
	}

	public String selectWindowWithTitle(String winTitle) {
		String parentWindowHandle = driver.getWindowHandle(); // save the
																// current
																// window
																// handle.
		WebDriver popup = null;
		for (String winHandle : driver.getWindowHandles()) {
			popup = driver.switchTo().window(winHandle);
			if (popup.getTitle().equals(winTitle)) {
				break;
			}

		}
		return parentWindowHandle;
	}

	public void selectParentWindow() {
		driver.switchTo().defaultContent();
	}

	public boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException ex) {
			return false;
		}

	}

	public String getAlert() {
		return driver.switchTo().alert().getText();
	}

	public void acceptAlert() {
		driver.switchTo().alert().accept();
	}

	public void closeAlert() {
		driver.switchTo().alert().dismiss();
	}

	public boolean isElementExist(FindElementByEnum findElementBy,
			String locator, long timeout) {
		try{
			WebDriverWait webDriverWait = new WebDriverWait(driver, timeout);
			return webDriverWait.until(ExpectedConditions.visibilityOf(findelement(findElementBy,locator))).isDisplayed();
		}catch (Exception ex){
			return false;
		}
	}

	public void doubleClick(FindElementByEnum findElementBy, String locator) {
		WebElement element = findelement(findElementBy, locator);
		Actions action = new Actions(driver);
		action.doubleClick(element);
		action.perform();
	}

	public void click(WebElement elementIn) {
		final WebElement element = elementIn;
		new WebDriverWait(driver, SeleniumWebDriverUtility.ELEMENT_WAIT_TIMEOUT)
				.until(new ExpectedCondition<Boolean>() {
					public Boolean apply(WebDriver webDriver) {
						return element.isDisplayed();
					}
				});

		element.click();
	}

	public void waitForElementDisplay(WebElement elementIn) {
		final WebElement element = elementIn;
		new WebDriverWait(driver, SeleniumWebDriverUtility.ELEMENT_WAIT_TIMEOUT)
				.until(new ExpectedCondition<Boolean>() {
					public Boolean apply(WebDriver webDriver) {
						return element.isDisplayed();
					}
				});
	}

	public void close() {
		driver.close();
	}

	public void mouseOver(WebElement element) {
		Actions builder = new Actions(driver);
		builder.moveToElement(element).perform();
	}

	public boolean isChecked(WebElement element) {
		return element.isSelected();
	}

	public void refreshPage() {
		driver.navigate().refresh();
	}

	public void browserBack() {
		driver.navigate().back();
	}

	public String getSelectedOption(WebElement element) {
		Select select = new Select(element);
		return select.getFirstSelectedOption().getText();
	}

	public int getSelectedIndex(WebElement element) {
		Select select = new Select(element);
		List<WebElement> elements = select.getOptions();
		int index = 0;
		for (int i = 0; i < elements.size(); i++) {
			if (element.isSelected()) {
				index = i + 1;
			}
		}
		return index;
	}

	public boolean isEditable(WebElement element) {
		return element.isEnabled();
	}

	public Object executeJavaScript(String script) {
		JavascriptExecutor js = null;
		if (driver instanceof JavascriptExecutor) {
			js = (JavascriptExecutor) driver;
		}
		return (js).executeScript(script);
	}

	public void windowMaximize() {
		driver.manage().window().maximize();
	}

	public WebElement findelement(FindElementByEnum findElementBy,
			String locator) {
		WebElement element = null;

		if (findElementBy == FindElementByEnum.ID) {
			element = driver.findElement(By.id(locator));
		} else if (findElementBy == FindElementByEnum.LINKTEXT) {
			element = driver.findElement(By.linkText(locator));
		} else if (findElementBy == FindElementByEnum.PARTIALLINKTEXT) {
			element = driver.findElement(By.partialLinkText(locator));
		} else if (findElementBy == FindElementByEnum.NAME) {
			element = driver.findElement(By.name(locator));
		} else if (findElementBy == FindElementByEnum.TAGNAME) {
			element = driver.findElement(By.tagName(locator));
		} else if (findElementBy == FindElementByEnum.XPATH) {
			element = driver.findElement(By.xpath(locator));
		} else if (findElementBy == FindElementByEnum.CLASSNAME) {
			element = driver.findElement(By.className(locator));
		} else if (findElementBy == FindElementByEnum.CSSSELECTOR) {
			element = driver.findElement(By.cssSelector(locator));
		}

		return element;

	}

	/**
	 * Wait for asynchronous calls on page to complete.
	 * 
	 * @param driver
	 */
	public static void waitForAsyncCallToComplete(WebDriver driver) {
		MigrationUtil.unconditionalWait(1000);
		if (!(driver instanceof JavascriptExecutor)) {
			s_logger.error("Not a javascript executor.");
		}
		final JavascriptExecutor scriptExecutor = (JavascriptExecutor) driver;
		try {
			if ((Boolean) scriptExecutor
					.executeScript("return !(typeof jQuery === 'undefined')")) {
				long activeThreads = (Long) scriptExecutor
						.executeScript("return jQuery.active");
				s_logger.info("ActiveThreads: {}", activeThreads);
				if (activeThreads > 0) {
					s_logger.info("Waiting for JQ Req to complete");
					WebDriverWait wait = new WebDriverWait(driver,
							ELEMENT_WAIT_TIMEOUT);
					wait.until(new ExpectedCondition<Boolean>() {
						public Boolean apply(WebDriver webDriver) {
							return (Boolean) scriptExecutor
									.executeScript("return jQuery.active == 0");
						}
					});
					s_logger.info("Complete JQ req");
				}
			}
		} catch (Throwable t) {
			s_logger.error("Unable to check Async (JQuery) calls status", t);
		}

		try {
			if ((Boolean) scriptExecutor
					.executeScript("return !(typeof dojo === 'undefined')")) {
				int activeThreads = (Integer) scriptExecutor
						.executeScript("return dojo.io.XMLHTTPTransport.inFlight.length");
				s_logger.info("ActiveThreads: {}", activeThreads);
				if (activeThreads > 0) {
					s_logger.info("Waiting for DOJO Req to complete");
					WebDriverWait wait = new WebDriverWait(driver,
							ELEMENT_WAIT_TIMEOUT);
					wait.until(new ExpectedCondition<Boolean>() {
						public Boolean apply(WebDriver webDriver) {
							return (Boolean) scriptExecutor
									.executeScript("return dojo.io.XMLHTTPTransport.inFlight.length == 0");
						}
					});
					s_logger.info("Complete DOJO req");
				}
			}
		} catch (Throwable t) {
			s_logger.error("Unable to check Async (JQuery) calls status", t);
		}
	}

	/**
	 * Clicks on a specific element. Checks if element is click able before
	 * performing action.
	 * 
	 * @param locator
	 * @param webDriver
	 */
	public static void click(String locator, WebDriver webDriver) {
		By by = convertToBy(locator);
		s_logger.info("Waiting to see if element is clickable: {}", locator);
		new WebDriverWait(webDriver, ELEMENT_WAIT_TIMEOUT)
				.until(ExpectedConditions.elementToBeClickable(by));
		s_logger.info("Waiting complete. Preforming click.");
		webDriver.findElement(by).click();
		waitForAsyncCallToComplete(webDriver);
	}

	/**
	 * Convert legacy locator to By to use with webDriver.
	 * 
	 * @param locator
	 * @return
	 */
	private static By convertToBy(String locator) {
		By by = null;
		if (locator.startsWith("css=")) {
			by = By.cssSelector(locator.replace("css=", ""));
		} else if (locator.startsWith("name=")) {
			by = By.name(locator.substring("name=".length()));
		} else if (locator.startsWith("id=")) {
			by = By.id(locator.substring("id=".length()));
		} else if (locator.startsWith("link=")) {
			by = By.linkText(locator.substring("link=".length()));
		} else if (locator.startsWith("/")) {
			by = By.xpath(locator);
		} else {
			by = By.id(locator);
		}
		return by;
	}

	/**
	 * mouseOver element identified by xpath.
	 * 
	 * @param webDriver
	 * @param xpath
	 */
	public static void mouseOver(WebDriver webDriver, String xpath) {
		Actions builder = new Actions(webDriver);
		builder.moveToElement(webDriver.findElement(By.xpath(xpath))).perform();
	}

	public static void clickButtons(WebDriver webDriver, List<String> locators) {
		for (String locator : locators) {
			click(locator, webDriver);
		}
	}

	/**
	 * Print the current page url on logs.
	 */
	public static void logCurrentPageUrl(WebDriver driver) {
		s_logger.info("In Page: {}", driver.getCurrentUrl());
	}

	/**
	 * set cookie values
	 * 
	 * @param cookie
	 */
	public void setCookie(Cookie cookie) {
		driver.manage().addCookie(cookie);
		s_logger.info(" Cookie Name : {}, Value : {}, Domain : {}, Path : {}",
				cookie.getName(), cookie.getValue(), cookie.getDomain(),
				cookie.getPath());
	}

}
