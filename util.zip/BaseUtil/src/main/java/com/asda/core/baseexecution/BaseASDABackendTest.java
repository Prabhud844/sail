//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.asda.core.baseexecution;

import com.asda.core.enums.BrowserTypeEnum;

import java.lang.reflect.Method;

import com.asda.core.database.SpringConfiguration;
import com.asda.qa.environment.EnvironmentConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public abstract class BaseASDABackendTest extends BaseTest {
    public BaseASDABackendTest() {
    }

    private static final Logger s_logger = LoggerFactory.getLogger(BaseASDABackendTest.class);

    @Override
    protected void initEnvironment(String env) {
        s_logger.info("Initilizing environment {} for tests.", env);
        EnvironmentConfig.initEnvironment(env);
        s_logger.info("Initilizing db environment {} for tests.", env);
        SpringConfiguration.init(env);
    }

    @BeforeMethod(
            alwaysRun = true
    )
    public void beforeTest(Method testMethod, ITestContext context, Object[] methodParams) throws Exception {
        super.beforeTest(testMethod, context, BrowserTypeEnum.NONE, methodParams);
    }

    @AfterMethod(
            alwaysRun = true
    )
    public void tearDown(ITestResult result, Method testMethod) throws Exception {
        super.tearDown(result, testMethod);
    }
}
