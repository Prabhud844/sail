package com.asda.core.webservice;

import com.asda.core.baseexecution.ExecutionConfig;
import com.asda.core.utils.FileReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/**
 * This class is base class for all web service tests. Provides the
 * functionality to trigger different types of web service calls.
 * 
 * @author jkandul
 */
public class BaseWebService {

	private static final Logger s_logger = LoggerFactory.getLogger(BaseWebService.class);
	public static int WEB_SERVICES_CONN_TIME_OUT = 60; 
	
	static{
		WEB_SERVICES_CONN_TIME_OUT = ExecutionConfig.getInstance().getIntValue("WEB_SERVICES_CONN_TIME_OUT", WEB_SERVICES_CONN_TIME_OUT);
	}
	/**
	 * Reads the file at the relative path and returns the content of file as string.
	 * 
	 * @param relativePath
	 * @return
	 */
	protected String getRequestFromFile(String relativePath) {
		return FileReader.getInstance().readFileFromClassPath(relativePath);
	}
	
	/**
	 * Trigger SOAP call and return web service response.
	 * 
	 * @param url
	 * @param request
	 * @param headers
	 * @return
	 */
	protected WebServiceResponse invokeSOAPRequest(String url, String request, Map<String, String> headers) {
		
		s_logger.info("Target url: {}", url);
		s_logger.info("Request: {}", request);
		s_logger.info("Headers :{}", headers);
		
		GenericWebServiceClient client = new GenericWebServiceClient(WEB_SERVICES_CONN_TIME_OUT * 1000, WEB_SERVICES_CONN_TIME_OUT * 1000);
		try {
			WebServiceResponse result = client.invokeWsCall(url, request, headers, WebServiceType.SOAP, new HashMap<String, String>());
			return result;
		} catch (WebServiceException e) {
			s_logger.error("Error invoking service", e);
			Assert.fail("Error invoking webservice", e);
		}
		return null;
	}

	/**
	 * Trigger SOAP call and return web service response.
	 * 
	 * @param url
	 * @param request
	 * @param headers
	 * @param soapAction
	 * @return
	 */
	protected WebServiceResponse invokeSOAPRequest(String url, String request, Map<String, String> headers, String soapAction) {
		
		s_logger.info("Target url: {}", url);
		s_logger.info("Request: {}", request);
		s_logger.info("Headers :{}", headers);
		s_logger.info("SOAP Action :{}", soapAction);
		
		GenericWebServiceClient client = new GenericWebServiceClient(WEB_SERVICES_CONN_TIME_OUT * 1000, WEB_SERVICES_CONN_TIME_OUT * 1000);
		try {
			WebServiceResponse result = client.invokeSOAPCall(url, request, headers, soapAction);
			return result;
		} catch (WebServiceException e) {
			s_logger.error("Error invoking service", e);
			Assert.fail("Error invoking webservice", e);
		}
		return null;
	}

	/**
	 * Trigger SOAP call after replacing dynamic values in url, request, headers and return response.
	 * 
	 * @param url
	 * @param request
	 * @param headers
	 * @param tokenDelimiter
	 * @param tokenDataMap
	 * @return
	 */
	protected WebServiceResponse invokeSOAPRequest(String url, String request, Map<String, String> headers,
			ParamTokenDelimiter tokenDelimiter, Map<String, String> tokenDataMap) {
		// Update dynamic values in URL
		url = ParamTokenDelimiter.getReplacedString(url, tokenDelimiter, tokenDataMap);

		// Update dynamic values in request
		request = ParamTokenDelimiter.getReplacedString(request, tokenDelimiter, tokenDataMap);

		// Update dynamic values in header parameters
		updateDynamicValuesInMap(headers, tokenDelimiter, tokenDataMap);

		return invokeSOAPRequest(url, request, headers);
	}
	
	/**
	 * Trigger SOAP call after replacing dynamic values in the request and return the response.
	 * 
	 * @param url
	 * @param request
	 * @param headers
	 * @param tokenDelimiter
	 * @param tokenDataMap
	 * @param soapAction
	 * @return
	 */
	protected WebServiceResponse invokeSOAPRequest(String url, String request, Map<String, String> headers,
			ParamTokenDelimiter tokenDelimiter, Map<String, String> tokenDataMap, String soapAction) {
		// Update dynamic values in URL
		String modifiedUrl = ParamTokenDelimiter.getReplacedString(url, tokenDelimiter, tokenDataMap);

		// Update dynamic values in request
		request = ParamTokenDelimiter.getReplacedString(request, tokenDelimiter, tokenDataMap);

		// Update dynamic values in header parameters
		updateDynamicValuesInMap(headers, tokenDelimiter, tokenDataMap);

		return invokeSOAPRequest(modifiedUrl, request, headers, soapAction);
	}

	/**
	 * Trigger REST call with post parameters and return the response.
	 * 
	 * @param url
	 * @param headers
	 * @param postParams
	 * @return
	 */
	
	public WebServiceResponse invokeRESTPostRequest(String url, Map<String, String> headers, Map<String, String> postParams) {
		
		s_logger.info("Target url: {}", url);
		s_logger.info("Post params: {}", postParams);
		s_logger.info("Headers :{}", headers);
		
		GenericWebServiceClient client = new GenericWebServiceClient(WEB_SERVICES_CONN_TIME_OUT * 1000,WEB_SERVICES_CONN_TIME_OUT * 1000);
		try {
			WebServiceResponse result = client.invokeWsCall(url, "", headers, WebServiceType.REST_POST, postParams);
			return result;
		} catch (WebServiceException e) {
			s_logger.error("Error invoking service", e);
			//Assert.fail("Error invoking webservice", e);
		}
		return null;
	}

	/**
	 * Trigger REST call with request body (XML) and returns the response. 
	 * 
	 * @param url
	 * @param headers
	 * @param requestBody
	 * @return
	 */
	protected WebServiceResponse invokeRESTPostRequest(String url, Map<String, String> headers, String requestBody) {
		return invokeRESTPostRequest(url, headers, requestBody, true);
	}

	/**
	 * Trigger REST call with request body (XML)/ (JSON) and returns the response. 
	 * 
	 * @param url
	 * @param headers
	 * @param requestBody
	 * @param isXmlBody
	 * @return
	 */
	protected WebServiceResponse invokeRESTPostRequest(String url, Map<String, String> headers, String requestBody, boolean isXmlBody) {
		s_logger.info("Target url: {}", url);
		s_logger.info("Request: {}", requestBody);
		s_logger.info("Headers :{}", headers);
		WebServiceType wsType = WebServiceType.REST_POST_XML;
		if(!isXmlBody) {
			wsType = WebServiceType.REST_POST_JSON;
		}
		s_logger.info("Request Body Type :{}", wsType);

		GenericWebServiceClient client = new GenericWebServiceClient(WEB_SERVICES_CONN_TIME_OUT * 1000,WEB_SERVICES_CONN_TIME_OUT * 1000);
		try {
			WebServiceResponse result = client.invokeWsCall(url, requestBody, headers, wsType, new HashMap<String, String>());
			return result;
		} catch (WebServiceException e) {
			s_logger.error("Error invoking service", e);
			Assert.fail("Error invoking webservice", e);
		}
		return null;
	}

	
	/**
	 * Trigger REST call with request body (XML)/(JSON) and returns the response. 
	 * Replaces dynamic values before triggering call.
	 * 
	 * @param url
	 * @param headers
	 * @param requestBody
	 * @param tokenDelimiter
	 * @param tokenDataMap
	 * @return
	 */
	protected WebServiceResponse invokeRESTPostRequest(String url, Map<String, String> headers, String requestBody,
			ParamTokenDelimiter tokenDelimiter, Map<String, String> tokenDataMap, boolean isXmlBody) {
		// Update dynamic values in URL
		url = ParamTokenDelimiter.getReplacedString(url, tokenDelimiter, tokenDataMap);

		// Update dynamic values in requestBody
		requestBody = ParamTokenDelimiter.getReplacedString(requestBody, tokenDelimiter, tokenDataMap);

        // Update dynamic values in header parameters
		updateDynamicValuesInMap(headers, tokenDelimiter, tokenDataMap);

		return invokeRESTPostRequest(url, headers, requestBody, isXmlBody);
		
	}

	/**
	 * Triggers REST POST with post parameters, all the values with dynamic
	 * place holders would be replace before triggering call.
	 * 
	 * @param url
	 * @param headers
	 * @param postParams
	 * @param tokenDelimiter
	 * @param tokenDataMap
	 * @return
	 */
	protected WebServiceResponse invokeRESTPostRequest(String url, Map<String, String> headers,
			Map<String, String> postParams, ParamTokenDelimiter tokenDelimiter, Map<String, String> tokenDataMap) {

		// Update dynamic values in URL
		url = ParamTokenDelimiter.getReplacedString(url, tokenDelimiter, tokenDataMap);

		// Update dynamic values in post parameters
		updateDynamicValuesInMap(postParams, tokenDelimiter, tokenDataMap);

		// Update dynamic values in header parameters
		updateDynamicValuesInMap(headers, tokenDelimiter, tokenDataMap);

		return invokeRESTPostRequest(url, headers, postParams);
	}
	
	/**
	 * Trigger REST GET call and return service response.
	 * 
	 * @param url
	 * @return
	 */
	protected WebServiceResponse invokeRESTGetRequest(String url, Map<String, String> headers) {
		s_logger.info("Target url: {}", url);
		s_logger.info("Headers :{}", headers);
		GenericWebServiceClient client = new GenericWebServiceClient(WEB_SERVICES_CONN_TIME_OUT * 1000,WEB_SERVICES_CONN_TIME_OUT * 1000);
		try {
			WebServiceResponse result = client.invokeWsCall(url, "", headers, WebServiceType.REST_GET, new HashMap<String, String>());
			return result;
		} catch (WebServiceException e) {
			s_logger.error("Error invoking service", e);
			Assert.fail("Error invoking webservice", e);
		}
		return null;
	}

	/**
	 * Trigger REST GET call and return service response, replace dynamic values
	 * in URL before triggering call.
	 * 
	 * @param url
	 * @param tokenDelimiter
	 * @param tokenDataMap
	 * @return
	 */
	protected WebServiceResponse invokeRESTGetRequest(String url, Map<String, String> headers, ParamTokenDelimiter tokenDelimiter,
			Map<String, String> tokenDataMap) {
		
		// Update dynamic values in URL
		url = ParamTokenDelimiter.getReplacedString(url, tokenDelimiter, tokenDataMap);

		// Update dynamic values in header parameters
		updateDynamicValuesInMap(headers, tokenDelimiter, tokenDataMap);
		
		return invokeRESTGetRequest(url, headers);
	}

	/**
	 * Update values in requestParams map with dynamic place holders from tokenDataMap.
	 *   
	 * @param requestParams
	 * @param tokenDelimiter
	 * @param tokenDataMap
	 */
	private void updateDynamicValuesInMap(Map<String, String> requestParams, ParamTokenDelimiter tokenDelimiter,
			Map<String, String> tokenDataMap) {
		for (Entry<String, String> entry : requestParams.entrySet()) {
			String modifiedValue = ParamTokenDelimiter.getReplacedString(entry.getValue(), tokenDelimiter, tokenDataMap);
			entry.setValue(modifiedValue);
		}
	}
	
	/**
	 * Trigger REST PUT with request body (XMl/JSON (default)) after replacing dynamic values.
	 * 
	 * @param url
	 * @param headers
	 * @param request
	 * @param tokenDelimiter
	 * @param tokenDataMap
	 * @param isXmlBody
	 * @return
	 */
	protected WebServiceResponse invokeRESTPutRequest(String url, Map<String, String> headers, String request, ParamTokenDelimiter tokenDelimiter, Map<String, String> tokenDataMap, boolean isXmlBody) {
		// Update dynamic values in URL
		url = ParamTokenDelimiter.getReplacedString(url, tokenDelimiter, tokenDataMap);

		// Update dynamic values in header parameters
		updateDynamicValuesInMap(headers, tokenDelimiter, tokenDataMap);
		
		// Update dynamic values in request
		request = ParamTokenDelimiter.getReplacedString(request, tokenDelimiter, tokenDataMap);
		
		return invokeRESTPutRequest(url, headers, request, isXmlBody);
	}

	/**
	 * Trigger REST PUT request with request body (XMl/JSON (default))
	 * 
	 * @param url
	 * @param headers
	 * @param request
	 * @param isXmlBody
	 * @return
	 */
	
	public WebServiceResponse invokeRESTPutRequest(String url, Map<String, String> headers, String request, boolean isXmlBody) {
		s_logger.info("Target url: {}", url);
		s_logger.info("Headers :{}", headers);
		s_logger.info("Request Body:{}", request);
		WebServiceType reqType = WebServiceType.PUT_JSON;
		if(isXmlBody) {
			reqType = WebServiceType.PUT_XML;
		}
		GenericWebServiceClient client = new GenericWebServiceClient(WEB_SERVICES_CONN_TIME_OUT * 1000,WEB_SERVICES_CONN_TIME_OUT * 1000);
		try {
			WebServiceResponse result = client.invokeWsCall(url, "", headers, reqType, new HashMap<String, String>());
			return result;
		} catch (WebServiceException e) {
			s_logger.error("Error invoking service", e);
			Assert.fail("Error invoking webservice", e);
		}
		return null;
	}
	
	/**
	 * Trigger REST DELETE call and return service response.
	 *
	 * @author mgoel1 (mgoel@walmartlabs.com)
	 * @param url
	 * @param headers
	 * @return
	 */
	protected WebServiceResponse invokeRESTDeleteRequest(String url, Map<String, String> headers) {
		s_logger.info("Target url: {}", url);
		s_logger.info("Headers :{}", headers);
		GenericWebServiceClient client = new GenericWebServiceClient(WEB_SERVICES_CONN_TIME_OUT * 1000,WEB_SERVICES_CONN_TIME_OUT * 1000);
		try {
			WebServiceResponse result = client.invokeWsCall(url, "", headers, WebServiceType.REST_DELETE, new HashMap<String, String>());
			return result;
		} catch (WebServiceException e) {
			s_logger.error("Error invoking service", e);
			Assert.fail("Error invoking webservice", e);
		}
		
		return null;
	}
	
	
	/**
	 * Trigger REST PUT request with request body (XMl/JSON (default))
	 * 
	 * @param url
	 * @param headers
	 * @param isXmlBody
	 * @return
	 */
	public WebServiceResponse invokeRESTPutRequestNew(String url, HashMap<String, String> headers, HashMap<String, String> postParams, boolean isXmlBody) {
		s_logger.info("Target url: {}", url);
		s_logger.info("Headers :{}", headers);
//		s_logger.info("Request Body:{}", request);
		WebServiceType reqType = WebServiceType.PUT_JSON;
		if(isXmlBody) {
			reqType = WebServiceType.PUT_XML;
		}
		GenericWebServiceClient client = new GenericWebServiceClient(WEB_SERVICES_CONN_TIME_OUT * 1000,WEB_SERVICES_CONN_TIME_OUT * 1000);
		try {
		
			WebServiceResponse result = client.invokeWsCall(url, "", headers, reqType, postParams);
			return result;
		} catch (WebServiceException e) {
			s_logger.error("Error invoking service", e);
			Assert.fail("Error invoking webservice", e);
		}
		return null;
	}
	
}
