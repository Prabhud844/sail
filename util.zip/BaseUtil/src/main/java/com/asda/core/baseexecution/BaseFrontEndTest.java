package com.asda.core.baseexecution;

import com.asda.core.annotations.TestInfo;
import com.asda.core.baseexecution.ExecutionConfig.Constants;
import com.asda.core.concurrent.SingleThreadExecutor;
import com.asda.core.enums.BrowserTypeEnum;
import com.asda.core.enums.SystemVariableEnum;
import com.asda.core.reporters.ReportListener;
import com.asda.core.reporters.beans.ReportBean;
import com.asda.core.reporters.beans.ReportThreadLocal;
import com.asda.core.utils.MigrationUtil;
import com.asda.core.utils.PropertiesReader;
import com.asda.core.utils.Utility.StringUtility;
import com.asda.core.webservice.WebServiceResponse;
import com.asda.core.webservice.WebServiceUtil;
import com.asda.qa.environment.EnvironmentConfig;
import io.appium.java_client.remote.MobileCapabilityType;
import io.github.bonigarcia.wdm.WebDriverManager;
import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.client.ClientUtil;
import net.lightbody.bmp.proxy.CaptureType;
import org.json.JSONObject;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver.Timeouts;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.ProfilesIni;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.remote.*;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.internal.BaseTestMethod;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.*;

/**
 * Base class for all front end tests. Takes care of starting/stopping the
 * browser. <br>
 * <br>
 * Looks for the below parameter while starting any test method.<br>
 * &nbsp; selenium.url <br>
 * &nbsp; selenium.browser - Required but defaults to FireFox if match not
 * found.<br>
 * &nbsp;&nbsp;&nbsp; Applicable values - {chrome, internetexplorer7,
 * internetexplorer8, internetexplorer9, android, ipad, safari, firefox}<br>
 * &nbsp; islocalrun - Defaults to false<br>
 * <br>
 * 
 * @author jkandul
 * 
 */
public abstract class BaseFrontEndTest extends BaseTest {

	private static final String SCRIPT_TIMEOUT_KEY = "SCRIPT_TIMEOUT";
	private static final String PAGE_LOAD_TIMEOUT_KEY = "PAGE_LOAD_TIMEOUT";
	private static final String ELEMENT_WAIT_TIMEOUT_KEY = "ELEMENT_WAIT_TIMEOUT";
	private static final String FIREFOX_PROFILE_NAME = "FIREFOX_PROFILE_NAME";
	private static final String SESSION_START_TIMEOUT_KEY = "SESSION_START_TIMEOUT";
	private static final String APPIUM_VERSION = PropertiesReader.getGlobalPOMProperties("io.appium.server.version");
	private static final String SELENIUM_VERSION = PropertiesReader.getGlobalPOMProperties("org.seleniumhq.selenium.version");


	private static long PAGE_LOAD_TIMEOUT = 60;
	private static long SCRIPT_TIMEOUT = 60;
	private static long ELEMENT_WAIT_TIMEOUT = 60;
	private static final int SESSION_START_TIMEOUT_DEFAULT = 360;

	private static final Logger s_logger = LoggerFactory.getLogger(BaseFrontEndTest.class);
	private static final Logger s_statusLogger = LoggerFactory.getLogger("STATUS_LOGGER");

	private static final ThreadLocal<WebDriver> webDriverHolder = new InheritableThreadLocal<WebDriver>();
	private static final ThreadLocal<Exception> startupException = new InheritableThreadLocal<Exception>();
	private static final ThreadLocal<BrowserMobProxy> proxyServer = new InheritableThreadLocal<BrowserMobProxy>();

	private static Date startTime;
	private static Date endTime;

	public static String duration;

	public static boolean enablebrowsermobglobal;
	public static boolean isAppiummobglobal;
	public static boolean SSO_account;
	public static boolean SSO_login;
	public static String viewPortConfig = "large";
	private static boolean enablePerfUserAgent = false;
	private static boolean uploadSauce = true;

	protected abstract String getBaseUrl();

	/**
	 * Returns page instance with WebDriver and Selenium instance.
	 * 
	 * @param cls
	 * @return
	 */

	protected <P extends BaseWebPage> P getPage(Class<P> cls) {
		if (enablebrowsermobglobal) {
			BaseWebPage bp = new BaseWebPage(webDriverHolder.get(), proxyServer.get());
			return bp.getPage(cls);
		} else {
			BaseWebPage bp = new BaseWebPage(webDriverHolder.get());
			return bp.getPage(cls);
		}
	}

	@BeforeMethod(alwaysRun = true)
	@Parameters({ "selenium.url", "selenium.browser", "islocalrun", "selenium.browser.version", "selenium.platform",
			"selenium.platform.version", "doVideoRecoring", "port", "enableBrowsermob", "ssoAccount", "viewPort",
			"isRecipe", "appName" , "usePerfUserAgent"})
	public void beforeTest(String seleniumUrl, String browser, @Optional("false") boolean localrun,
			@Optional("") String browserVersion, @Optional("ANY") String os, @Optional("") String osVersion,
			@Optional("no") String doVideoRecording, @Optional("1234") int portNo,
			@Optional("false") boolean enableBrowsermob, @Optional("false") boolean isAppium,
			@Optional("true") boolean ssoAccount, @Optional("large") String viewPort, @Optional("false") boolean isRecipe,
			@Optional("") String appName,@Optional("false") boolean isInternalApp, @Optional("false") String usePerfUserAgent, Method testMethod, ITestContext context, Object[] methodParams)
			throws Exception {
		clearThreadLocals();
		seleniumUrl = ReportListener.getValueFromSystemProperties(SystemVariableEnum.SELENIUM_URL.getSysVarName(),
				seleniumUrl); // Hub
								// url
								// try
								// getting
								// from
								// System
								// properties
								// first.
		String browserValue = ReportListener
				.getValueFromSystemProperties(SystemVariableEnum.SELENIUM_BROWSER.getSysVarName(), browser);
		BrowserTypeEnum browserType = BrowserTypeEnum.getBrowserType(browserValue, BrowserTypeEnum.FIREFOX);
		super.beforeTest(testMethod, context, browserType, methodParams);
		String baseUrl;
		if (!isRecipe) {
			baseUrl = getBaseUrl();

		} else {
			baseUrl = EnvironmentConfig.getInstance().getBrowseApp_RecipeSiteSpecUrl();
		}
		enablePerfUserAgent = null == usePerfUserAgent || !usePerfUserAgent.equalsIgnoreCase("false");

		try {
			if (enableBrowsermob) {
				s_logger.info("Browsermob is true. Starting setup with proxy");
				setUp(seleniumUrl, browserType, baseUrl, localrun, browserVersion, os, osVersion, doVideoRecording,
						portNo, ssoAccount, viewPort,isInternalApp,context);
				enablebrowsermobglobal = enableBrowsermob;

			} else {
				s_logger.info("Browsermob is false. Not starting with proxy");
				// Add sitespec suffix only if SSOphase2
				if (ssoAccount) {
//					baseUrl = baseUrl + "?SS_PREVIEW_EXP=2018_OCT_12_0800BST&990050:30u3YdLi"; // Have
					// this
					// baseUrl = EnvironmentConfig.getInstance().getSiteSpectUrl(); // reading
					// dynamically,
					// this
					// is
					// only
					// temp
					// in
					// 18.9
					// QA4
				}
				setUp(seleniumUrl, browserType, baseUrl, localrun, browserVersion, os, osVersion, doVideoRecording,
						isAppium, ssoAccount, viewPort,isInternalApp,context);
				enablebrowsermobglobal = enableBrowsermob;
			}
			DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
			startTime = new Date();
			// Setting sso_login
			try {
				JavascriptExecutor js = (JavascriptExecutor) getWebDriverHolder().get();
				String sp1 = (String) js.executeScript("return ACCELERATOR.APP.SITECONFIG.MODEL.get('sp_phase1')");
				SSO_login = Boolean.valueOf(sp1);
			} catch (Exception ignored) {
				SSO_login = true;
			}
			if (ssoAccount) {
				SSO_account = ssoAccount;
			}
		} catch (Exception e) {
			s_logger.error("Error starting browser", e);
			// Set the exception in TLC and use it
			startupException.set(e);
			if (ssoAccount) {
				SSO_account = ssoAccount;
			}
		}
	}

	/**
	 * Returns the browser type where this test is executing on.
	 * 
	 * @return
	 */
	public BrowserTypeEnum getCurrentBrowser() {
		return TestExecutionContext.getInstance().getBrowserType();
	}

	/**
	 * If true browser cache will be cleared after home page is loaded.
	 * 
	 * @return
	 */
	public boolean clearBrowserCookiesOnTestStart() {
		return false;
	}

	/**
	 * Clears the thread local cache.
	 */
	private void clearThreadLocals() {
		startupException.remove();
		webDriverHolder.remove();
	}

	@BeforeMethod
	private void setUp(String seleniumUrl, BrowserTypeEnum browserType, String baseUrl, boolean localrun,
			String browserVersion, String os, String osVersion, String doVideoRecording, int portNo, boolean ssoAccount,
			String viewPort,boolean isInternalApp,ITestContext context) {
		WebDriver webDriver = null;
		BrowserMobProxy proxy = new BrowserMobProxyServer();
		proxy.setTrustAllServers(true);
		proxy.setHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT);
//		List<String> allowUrlPatterns = new ArrayList<String>();
//		allowUrlPatterns.add("https?://.*(asda.com)+.*");
//		allowUrlPatterns.add("https?://.*(.js).*");
//		allowUrlPatterns.add("https?://.*(.js)");
//		allowUrlPatterns.add("https?://.*(.css)*");
//		allowUrlPatterns.add("https?://.*(.jsp)*");
//		allowUrlPatterns.add("https?://.*(.com)*+/*(.jsp)");
//		allowUrlPatterns.add("https?://.*(.com)");
//		allowUrlPatterns.add("https?://.*(.net)");
//		allowUrlPatterns.add("https://*");
//		allowUrlPatterns.add("https?://*");
//		//allowUrlPatterns.add("https://groceries-qa2.asda.com/*");
//
//		proxy.whitelistRequests(allowUrlPatterns, 404);

		proxy.start();
		Proxy seleniumProxy = null;
		try {
			String hostIp = Inet4Address.getLocalHost().getHostAddress();
			seleniumProxy = ClientUtil.createSeleniumProxy(proxy, Inet4Address.getLocalHost());
			seleniumProxy.setHttpProxy(hostIp + ":" + proxy.getPort());
			seleniumProxy.setSslProxy(hostIp + ":" + proxy.getPort());
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}


		String enableIdleTime = context.getCurrentXmlTest().getParameter("enableIdleTime").equals(null)
								? ""
								: context.getCurrentXmlTest().getParameter("enableIdleTime");

		final DesiredCapabilities desiredCapabilities = getDesiredCapabilities(browserType, browserVersion, os,
				osVersion, seleniumProxy,isInternalApp, enableIdleTime);

		if (browserType == BrowserTypeEnum.HEADLESS) {
			webDriver = getLocalBrowser(browserType, desiredCapabilities);
		} else if (localrun && isInternalApp) {
			webDriver = getLocalBrowserForAgatha(browserType, desiredCapabilities);
		}
		else if (localrun) {
			webDriver = getLocalBrowser(browserType, desiredCapabilities);
		}else { // Remote session
			System.out.println("printing :" + seleniumUrl);
			RemoteWebDriver rdriver = startRemoteSession(seleniumUrl, desiredCapabilities);
			SessionId sid = rdriver.getSessionId();
			webDriver = new Augmenter().augment(rdriver);
			logRemoteSystemInfo(sid, seleniumUrl);
		}

		// Set Driver and Selenium instance in ThreadLocalCache
		webDriverHolder.set(webDriver);
		proxyServer.set(proxy);

		setTimeouts(browserType, webDriver);

		// Maximize for non-tablet browsers.
		if (maximizeWindowOnStart() && !browserType.isTablet() && browserType != BrowserTypeEnum.SAFARIIPAD) {
			webDriver.manage().window().maximize();
		}

		loadBasePage(baseUrl, webDriver);

		if (doVideoRecording.equalsIgnoreCase("yes") && (!localrun)) {
			WebServiceUtil wsutil = new WebServiceUtil();

			try {
				WebServiceResponse resp = wsutil.invokeRESTGetRequest(
						"http://" + ReportThreadLocal.getReportBean().getBrowserMachine() + ":9998/rec/start",
						new HashMap<String, String>());
				if (resp.getResponseCode() != 200) {
					return;
				}

			} catch (Exception e) {
				s_logger.info("Unable to start video capturing, service might be down on machine: "
						+ ReportThreadLocal.getReportBean().getBrowserMachine());
				s_statusLogger.info("Unable to start video capturing, service might be down on machine :"
						+ ReportThreadLocal.getReportBean().getBrowserMachine());
			}

		}

		// Clear all cookies on startup if needed
		if (clearBrowserCookiesOnTestStart()) {
			s_logger.info("Clearing browser cookies on startup");
			webDriver.manage().deleteAllCookies();
			s_logger.info("Reloading home page after cookies are cleared");
			loadBasePage(baseUrl, webDriver);
		}

	}

	@BeforeMethod
	private void setUp(String seleniumUrl, BrowserTypeEnum browserType, String baseUrl, boolean localrun,
			String browserVersion, String os, String osVersion, String doVideoRecording, boolean isAppium,
			boolean ssoAccount, String viewPort,boolean isInternalApp,ITestContext context) {

		s_logger.info("Starting test for Browser: {}, version: {} on OS: {}", browserType, browserVersion, os);
		if (localrun) {
			s_logger.info("Starting browser in same machine directly");
		} else {
			s_logger.info("Starting browser in at Hub url {}", seleniumUrl);
		}
		if (isAppium) {
			isAppiummobglobal = isAppium;
		}

		String enableIdleTime = context.getCurrentXmlTest().getParameter("enableIdleTime")==null
				? ""
				: context.getCurrentXmlTest().getParameter("enableIdleTime");

		WebDriver webDriver = null;
		final DesiredCapabilities desiredCapabilities = getDesiredCapabilities(browserType, browserVersion, os,
				osVersion, isAppium, viewPort,localrun,isInternalApp,enableIdleTime);
		s_logger.info("Desired Capabilities : {}", desiredCapabilities);
		if (browserType == BrowserTypeEnum.HEADLESS) {
			webDriver = getLocalBrowser(browserType, desiredCapabilities);
		} else if (localrun && isInternalApp) {
			webDriver = getLocalBrowserForAgatha(browserType, desiredCapabilities);
		} else if (localrun) {
			webDriver = getLocalBrowser(browserType, desiredCapabilities);
		} else { // Remote session
			MutableCapabilities sauceOptions = new MutableCapabilities();
			//desiredCapabilities.setCapability("sauce:options",sauceOptions);
			RemoteWebDriver rdriver = startRemoteSession(seleniumUrl, desiredCapabilities);
			SessionId sid = rdriver.getSessionId();
			webDriver = new Augmenter().augment(rdriver);
			logRemoteSystemInfo(sid, seleniumUrl);
		}

		// Set Driver and Selenium instance in ThreadLocalCache
		webDriverHolder.set(webDriver);

		setTimeouts(browserType, webDriver);

		// Maximize for non-tablet browsers.
		if (maximizeWindowOnStart() && !browserType.isTablet() && browserType != BrowserTypeEnum.SAFARIIPAD
				&& !isAppium) {
			webDriver.manage().window().maximize();
		}

		loadBasePage(baseUrl, webDriver);

		if (doVideoRecording.equalsIgnoreCase("yes") && (!localrun)) {
			WebServiceUtil wsutil = new WebServiceUtil();

			try {
				WebServiceResponse resp = wsutil.invokeRESTGetRequest(
						"http://" + ReportThreadLocal.getReportBean().getBrowserMachine() + ":9998/rec/start",
						new HashMap<String, String>());
				if (resp.getResponseCode() != 200) {
					return;
				}

			} catch (Exception e) {
				s_logger.info("Unable to start video capturing, service might be down on machine: "
						+ ReportThreadLocal.getReportBean().getBrowserMachine());
				s_statusLogger.info("Unable to start video capturing, service might be down on machine :"
						+ ReportThreadLocal.getReportBean().getBrowserMachine());
			}

		}

		// Clear all cookies on startup if needed
		if (clearBrowserCookiesOnTestStart()) {
			s_logger.info("Clearing browser cookies on startup");
			webDriver.manage().deleteAllCookies();
			s_logger.info("Reloading home page after cookies are cleared");
			loadBasePage(baseUrl, webDriver);
		}

	}

	/**
	 * Create desired capabilities for web/mobile browsers based on browser and OS combination.
	 * 
	 * @param browserType
	 * @param browserVersion
	 * @param os
	 * @param osVersion
	 * @return
	 */
	private DesiredCapabilities getDesiredCapabilities(BrowserTypeEnum browserType, String browserVersion, String os,
			String osVersion, boolean isAppium, String viewPort, Boolean localrun, Boolean isInternalApp,String enableIdleTime) {
		DesiredCapabilities desiredCapabilities;
		String browserVersionLocal = browserVersion;
		// Saucelabs
		String testCaseName = ReportThreadLocal.getReportBean().getTestCaseName();
		String testCaseArea = ReportThreadLocal.getReportBean().getTestCaseArea();
		String testRunId = ReportListener.TEST_RUN_ID;

		// Browser type
		if (browserType == BrowserTypeEnum.CHROME) {
			ChromeOptions options = new ChromeOptions();
			if(enablePerfUserAgent)
				options.addArguments("--user-agent=asda-uk-selenium-automation-agent");
			desiredCapabilities = new DesiredCapabilities(options);
			// Commented by Bramesh to fix the invalid browser
			/*if(localrun){
			    try {
					System.out.println("Adding ModHeader.crx") ;
                    options.addExtensions(new File(getClass().getClassLoader().getResource("ModHeader.crx").getPath()));
                }catch(Exception e){
			        System.out.println("Failed to add ModHeader.crx :: "+e.getLocalizedMessage()) ;
                }
			}*/
			if(!localrun){
				desiredCapabilities.setCapability(CapabilityType.PLATFORM_NAME,Platform.WIN10);
			}
			desiredCapabilities.setCapability("screenResolution", "1280x1024");
			// desiredCapabilities.setCapability("tunnelIdentifier",
			// "dmzsaucetunnel_722417202405224");
//			desiredCapabilities.setCapability("parentTunnel", "WalmartMaster");
			desiredCapabilities.setCapability("acceptSslCerts", "true");
			desiredCapabilities.setCapability("trustAllSSLCertificates", "true");
			desiredCapabilities.setCapability("maxDuration", 900);
			desiredCapabilities.setCapability("commandTimeout", 300);
			desiredCapabilities.setCapability("idleTimeout", 90);
			desiredCapabilities.setCapability("extendedDebugging", "true");
			options.addArguments("--allow-insecure-localhost");
			options.addArguments("--ignore-certificate-errors");
			desiredCapabilities.setCapability(ChromeOptions.CAPABILITY, options);
			desiredCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			desiredCapabilities.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);

			// desiredCapabilities.setCapability("capturePerformance", "true");

			browserVersionLocal = "latest";
			// desiredCapabilities = DesiredCapabilities.chrome();
			// desiredCapabilities.setCapability("platform", "OS X 10.11");
			// desiredCapabilities.setCapability("version", "52.0");
//			System.getProperties().put("http.proxyHost", "sysproxy.wal-mart.com");
//			System.getProperties().put("http.proxyPort", "8080");
//			System.getProperties().put("https.proxyHost", "sysproxy.wal-mart.com");
//			System.getProperties().put("https.proxyPort", "8080");
//			System.setProperty("http.proxyUser", "rnarya4");
//			System.setProperty("http.proxyPassword", "Jan@2019");
			viewPortConfig = viewPort;

		}
		else if (browserType == BrowserTypeEnum.CHROME_PERF) {
			ChromeOptions options = new ChromeOptions();
			if(enablePerfUserAgent)
				options.addArguments("--user-agent=asda-uk-selenium-automation-agent");
			desiredCapabilities = new DesiredCapabilities(options);
			if(localrun){
				try {
					options.addExtensions(new File(getClass().getClassLoader().getResource("ModHeader.crx").getPath()));
				}catch(Exception e){
					System.out.println("Failed to add ModHeader.crx :: "+e.getLocalizedMessage()) ;
				}
			}
			if(!localrun){
				desiredCapabilities.setCapability(CapabilityType.PLATFORM_NAME,Platform.WIN10);
			}

			desiredCapabilities.setCapability("screenResolution", "1280x1024");
			// desiredCapabilities.setCapability("tunnelIdentifier",
			// "dmzsaucetunnel_722417202405224");
//			desiredCapabilities.setCapability("parentTunnel", "WalmartMaster");
			desiredCapabilities.setCapability("acceptSslCerts", "true");
			desiredCapabilities.setCapability("trustAllSSLCertificates", "true");
			desiredCapabilities.setCapability("maxDuration", 900);
			desiredCapabilities.setCapability("commandTimeout", 300);
			desiredCapabilities.setCapability("idleTimeout", 90);
			desiredCapabilities.setCapability("extendedDebugging", "true");
			desiredCapabilities.setCapability(ChromeOptions.CAPABILITY, options);
			desiredCapabilities.setCapability("capturePerformance", "true");

			browserVersionLocal = "latest";
			// desiredCapabilities = DesiredCapabilities.chrome();
			// desiredCapabilities.setCapability("platform", "OS X 10.11");
			// desiredCapabilities.setCapability("version", "52.0");
//			System.getProperties().put("http.proxyHost", "sysproxy.wal-mart.com");
//			System.getProperties().put("http.proxyPort", "8080");
//			System.getProperties().put("https.proxyHost", "sysproxy.wal-mart.com");
//			System.getProperties().put("https.proxyPort", "8080");
//			System.setProperty("http.proxyUser", "rnarya4");
//			System.setProperty("http.proxyPassword", "Jan@2019");
			viewPortConfig = viewPort;

		}

		else if (browserType == BrowserTypeEnum.CHROMEGRID) {
			uploadSauce = false;
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--allow-insecure-localhost");
			options.addArguments("--no-sandbox");
			options.addArguments("--disable-dev-shm-usage");
			desiredCapabilities = new DesiredCapabilities(options);
			desiredCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			desiredCapabilities.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
			desiredCapabilities.setCapability(ChromeOptions.CAPABILITY, options);

		}
		else if (browserType == BrowserTypeEnum.INTERNET_EXPLORER) {
			desiredCapabilities = new DesiredCapabilities(new InternetExplorerOptions());
		} else if (browserType == BrowserTypeEnum.INTERNET_EXPLORER_7) {
			desiredCapabilities = new DesiredCapabilities(new InternetExplorerOptions());
			browserVersionLocal = "7";
		} else if (browserType == BrowserTypeEnum.INTERNET_EXPLORER_8) {
			desiredCapabilities = new DesiredCapabilities(new InternetExplorerOptions());
			browserVersionLocal = "8";
		} else if (browserType == BrowserTypeEnum.INTERNET_EXPLORER_9) {
			desiredCapabilities = new DesiredCapabilities(new InternetExplorerOptions());
			browserVersionLocal = "9";
		} else if (browserType == BrowserTypeEnum.INTERNET_EXPLORER_10) {
			desiredCapabilities = new DesiredCapabilities(new InternetExplorerOptions());
			browserVersionLocal = "10";
		}
		else if (browserType == BrowserTypeEnum.INTERNET_EXPLORER_11) {
			desiredCapabilities = new DesiredCapabilities(new InternetExplorerOptions());
			desiredCapabilities.setCapability(CapabilityType.PLATFORM_NAME, "Windows 10");
			desiredCapabilities.setCapability("screenResolution", "1280x1024");
			desiredCapabilities.setCapability(CapabilityType.BROWSER_VERSION, "11.285");

			desiredCapabilities.setCapability("maxDuration", 900);
			desiredCapabilities.setCapability("commandTimeout", 400);
			desiredCapabilities.setCapability("idleTimeout", 100);

			desiredCapabilities.setCapability("extendedDebugging", "true");

//			browserVersionLocal = "11.143";
//			desiredCapabilities.setCapability("ignoreProtectedModeSettings", true);
//			desiredCapabilities.setCapability("ie.ensureCleanSession", true);
//			desiredCapabilities.setCapability("enableElementCacheCleanup", true);
//			desiredCapabilities.setCapability("ignoreZoomSetting", true);
//			desiredCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
//					true);
//			desiredCapabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			browserVersionLocal = "11.285";
			desiredCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
					true);
			desiredCapabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);

		}
		else if (browserType == BrowserTypeEnum.ANDROID_Tab) {
			desiredCapabilities = DesiredCapabilities.android(); //
			desiredCapabilities.setCapability("appiumVersion", APPIUM_VERSION);
			desiredCapabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Samsung Galaxy Tab A 10 GoogleAPI Emulator");
			desiredCapabilities.setCapability("deviceOrientation", "portrait");
			desiredCapabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");
			desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "7.0");
			desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
			viewPortConfig = viewPort;
		}
		else if (browserType == BrowserTypeEnum.ANDROID) {
			desiredCapabilities = DesiredCapabilities.android();
			desiredCapabilities.setCapability("appiumVersion", APPIUM_VERSION);
			desiredCapabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Emulator");
			desiredCapabilities.setCapability("deviceOrientation", "portrait");
			desiredCapabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");
			desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "8.0");
			desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
			viewPortConfig = viewPort;
		}
		else if (browserType == BrowserTypeEnum.IPAD) {
			desiredCapabilities = DesiredCapabilities.ipad();
			viewPortConfig = viewPort;
		}
		else if (!isAppium && browserType == BrowserTypeEnum.SAFARI) {
			desiredCapabilities = new DesiredCapabilities(new SafariOptions());
			desiredCapabilities.setCapability(CapabilityType.PLATFORM_NAME, "macOS 10.14");
			desiredCapabilities.setCapability("screenResolution", "2048x1536");
//			desiredCapabilities.setCapability("seleniumVersion", SELENIUM_VERSION);
			desiredCapabilities.setCapability("cleanSession", true);
			desiredCapabilities.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
			SafariOptions safariOptions = new SafariOptions();
			desiredCapabilities.setCapability(SafariOptions.CAPABILITY, safariOptions);
			browserVersionLocal = "latest";

		}
		else if (browserType == BrowserTypeEnum.SAFARIIPAD) {
//			desiredCapabilities = DesiredCapabilities.safari();
//			desiredCapabilities.setCapability("platform", "OS X 10.11");
//			desiredCapabilities.setCapability("screenResolution", "1024x768");
//			desiredCapabilities.setCapability("seleniumVersion", SELENIUM_VERSION);
//			desiredCapabilities.setCapability("cleanSession", true);
//			desiredCapabilities.setCapability("javascriptEnabled", true);
//			SafariOptions safariOptions = new SafariOptions();
//			desiredCapabilities.setCapability(SafariOptions.CAPABILITY, safariOptions);
//			browserVersionLocal = "9.0";
			desiredCapabilities = DesiredCapabilities.iphone();
			desiredCapabilities.setCapability("appiumVersion", APPIUM_VERSION);
			desiredCapabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "iPad (5th generation) Simulator");
			desiredCapabilities.setCapability("deviceOrientation", "portrait");
			desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "11.2");
			desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
			desiredCapabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "Safari");

			desiredCapabilities.setCapability("maxDuration", 900);
			desiredCapabilities.setCapability("commandTimeout", 300);
			desiredCapabilities.setCapability("idleTimeout", 90);

			viewPortConfig = viewPort;
		}
		else if (browserType == BrowserTypeEnum.HEADLESS) {
			desiredCapabilities = DesiredCapabilities.htmlUnit();
		} else if (browserType == BrowserTypeEnum.PHANTOMJS) {
			desiredCapabilities = DesiredCapabilities.phantomjs();
		}
		else if (browserType == BrowserTypeEnum.MacFireFox) {
			desiredCapabilities = new DesiredCapabilities(new FirefoxOptions());
			desiredCapabilities.setCapability(CapabilityType.PLATFORM_NAME,Platform.MAVERICKS);
			FirefoxProfile prof = new FirefoxProfile();
			prof.setPreference("browser.startup.homepage", "about:blank");
			prof.setPreference("startup.homepage_welcome_url", "about:blank");
			prof.setPreference("startup.homepage_welcome_url.additional", "about:blank");
			// desiredCapabilities.setCapability("screenResolution", "1280x1024");
			browserVersionLocal = "latest";

		}
		else if (browserType == BrowserTypeEnum.ChromeFireFox) {
			desiredCapabilities = new DesiredCapabilities(new FirefoxOptions());
			desiredCapabilities.setBrowserName("chrome");
			desiredCapabilities.setCapability(CapabilityType.BROWSER_NAME,"chrome");
			desiredCapabilities.setCapability(CapabilityType.PLATFORM_NAME,Platform.YOSEMITE);
			desiredCapabilities.setCapability("screenResolution", "1280x1024");

		}
		else if (isAppium && browserType == BrowserTypeEnum.SAFARI) {
			desiredCapabilities = DesiredCapabilities.iphone();

			desiredCapabilities.setCapability("appiumVersion", APPIUM_VERSION);
//			desiredCapabilities.setCapability("deviceName", "iPhone 7 Simulator");
//			desiredCapabilities.setCapability("deviceOrientation", "portrait");
//			desiredCapabilities.setCapability("platformVersion", "11.2");
//			desiredCapabilities.setCapability("platformName", "iOS");
//			desiredCapabilities.setCapability("browserName", "Safari");
			desiredCapabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone 6s Simulator");
			desiredCapabilities.setCapability("deviceOrientation", "portrait");
			desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "10.0");
			desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
			desiredCapabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "Safari");

			desiredCapabilities.setCapability("maxDuration", 900);
			desiredCapabilities.setCapability("commandTimeout", 300);
			desiredCapabilities.setCapability("idleTimeout", 90);

			viewPortConfig = viewPort;
		}

		else { // browserType == BrowserTypeEnum.FIREFOX
			desiredCapabilities = new DesiredCapabilities(new FirefoxOptions());
			if(!localrun){
				desiredCapabilities.setCapability(CapabilityType.PLATFORM_NAME,Platform.WIN10);
			}
			// desiredCapabilities.setCapability("screenResolution", "1280x1024");

			desiredCapabilities.setCapability("maxDuration", 900);
			desiredCapabilities.setCapability("commandTimeout", 300);
			desiredCapabilities.setCapability("idleTimeout", 90);

			browserVersionLocal = "latest";
		}

		// Clean session for IE browser.
		if (browserType.isInternetExplorer()) {
			if (startWithCleanSession()) {
				desiredCapabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
			}
		}

		// Browser version
		desiredCapabilities.setCapability(CapabilityType.BROWSER_VERSION,browserVersionLocal);

		// Saucelabs test parameters
		if(!isInternalApp){
			MutableCapabilities sauceMutableCapabilities = new MutableCapabilities();
			sauceMutableCapabilities.setCapability("name", testCaseName);
			sauceMutableCapabilities.setCapability("seleniumVersion", SELENIUM_VERSION);
			sauceMutableCapabilities.setCapability("tags", testCaseArea);
			try{
				sauceMutableCapabilities.setCapability("screenResolution", desiredCapabilities.getCapability("screenResolution").toString());
			}catch (Exception ex){
				s_logger.debug("screenResolution desired capability not found! - setting to default value 1280x1024");
				sauceMutableCapabilities.setCapability("screenResolution", "1280x1024");
			}
			desiredCapabilities.setCapability("sauce:options", sauceMutableCapabilities);
		}else{
			desiredCapabilities.setCapability("name", testCaseName);
			desiredCapabilities.setCapability("seleniumVersion", SELENIUM_VERSION);
			desiredCapabilities.setCapability("tags", testCaseArea);
		}
		desiredCapabilities.setCapability("build", testRunId);
		desiredCapabilities.setCapability("idleTimeout", 90);

		// OS
		// Platform platform = identifyPlatform(os, osVersion);

		// s_logger.info("Request os: {}, version: {}, identifed platform: {}",os, osVersion, platform);
		// desiredCapabilities.setPlatform(platform );
		if (isInternalApp) {
			Map<String, Object> map = desiredCapabilities.asMap();
			HashMap<String, Object> newMap = new HashMap<>();
			//creating new map from desired capabilities immutable map
			newMap.putAll(map);
			if(!localrun){
				String pName = desiredCapabilities.getCapability(CapabilityType.PLATFORM_NAME).toString();
				newMap.remove(CapabilityType.PLATFORM_NAME);
				newMap.put("platform",pName);
			}
			String bVersion = desiredCapabilities.getCapability(CapabilityType.BROWSER_VERSION).toString();
			newMap.remove(CapabilityType.BROWSER_VERSION);
			desiredCapabilities = new DesiredCapabilities(newMap);
			desiredCapabilities.setVersion(bVersion);
		  	desiredCapabilities.setCapability("tunnelIdentifier", testRunId);
		}
		if (enableIdleTime.equalsIgnoreCase("true")) {
			desiredCapabilities.setCapability("idleTimeout", 500);
			desiredCapabilities.setCapability("maxDuration", 2500);
		}
		// desiredCapabilities.setCapability("tunnelIdentifier","dmzsaucetunnel_722417202405224");
		return desiredCapabilities;
	}

	/**
	 * Create desired capabilities based on browser and OS combination.
	 * 
	 * @param browserType
	 * @param browserVersion
	 * @param os
	 * @param osVersion
	 * @param isInternalApp
	 * @return
	 */
	private DesiredCapabilities getDesiredCapabilities(BrowserTypeEnum browserType, String browserVersion, String os,
													   String osVersion, Proxy proxy, boolean isInternalApp,String enableIdleTime) {
		DesiredCapabilities desiredCapabilities;
		String browserVersionLocal = browserVersion;

		// Browser type
		if (browserType == BrowserTypeEnum.CHROME) {
			// System.setProperty("java.net.preferIPv4Stack" , "true");
			desiredCapabilities = new DesiredCapabilities(new ChromeOptions());
			desiredCapabilities.setCapability(CapabilityType.PROXY, proxy);
			desiredCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			desiredCapabilities.setCapability(CapabilityType.SUPPORTS_NETWORK_CONNECTION, true);
			// desiredCapabilities.setPlatform(Platform.WIN8_1);
			// desiredCapabilities.setCapability("screenResolution",
			// "1280x1024");

			// desiredCapabilities = DesiredCapabilities.chrome();
			// desiredCapabilities.setCapability("platform", "OS X 10.11");
			// desiredCapabilities.setCapability("version", "52.0");

			desiredCapabilities.setCapability("maxDuration", 900);
			desiredCapabilities.setCapability("commandTimeout", 300);
			desiredCapabilities.setCapability("idleTimeout", 90);
			desiredCapabilities.setCapability("extendedDebugging", "true");

		} else if (browserType == BrowserTypeEnum.INTERNET_EXPLORER) {
			desiredCapabilities = new DesiredCapabilities(new InternetExplorerOptions());
		} else if (browserType == BrowserTypeEnum.INTERNET_EXPLORER_7) {
			desiredCapabilities = new DesiredCapabilities(new InternetExplorerOptions());
			browserVersionLocal = "7";
		} else if (browserType == BrowserTypeEnum.INTERNET_EXPLORER_8) {
			desiredCapabilities = new DesiredCapabilities(new InternetExplorerOptions());
			browserVersionLocal = "8";
		} else if (browserType == BrowserTypeEnum.INTERNET_EXPLORER_9) {
			desiredCapabilities = new DesiredCapabilities(new InternetExplorerOptions());
			browserVersionLocal = "9";
		} else if (browserType == BrowserTypeEnum.INTERNET_EXPLORER_10) {
			desiredCapabilities = new DesiredCapabilities(new InternetExplorerOptions());
			browserVersionLocal = "10";
		} else if (browserType == BrowserTypeEnum.INTERNET_EXPLORER_11) {
			desiredCapabilities = new DesiredCapabilities(new InternetExplorerOptions());
			desiredCapabilities.setCapability(CapabilityType.PLATFORM_NAME, "Windows 10");
			desiredCapabilities.setCapability("screenResolution", "1280x1024");

//			desiredCapabilities.setCapability("ignoreProtectedModeSettings", true);
//			browserVersionLocal = "11.143";

			browserVersionLocal = "11.285";
			desiredCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
					true);
			desiredCapabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
		} else if (browserType == BrowserTypeEnum.ANDROID) {
			desiredCapabilities = DesiredCapabilities.android();

		} else if (browserType == BrowserTypeEnum.IPAD) {
			desiredCapabilities = DesiredCapabilities.ipad();
		} else if (browserType == BrowserTypeEnum.SAFARI) {
			desiredCapabilities = new DesiredCapabilities(new SafariOptions());
			desiredCapabilities.setCapability(CapabilityType.PLATFORM_NAME, "macOS 10.14");
			desiredCapabilities.setCapability(CapabilityType.BROWSER_VERSION, "12.0");
			desiredCapabilities.setCapability("screenResolution", "2048x1536");
			desiredCapabilities.setCapability("seleniumVersion", SELENIUM_VERSION);
			desiredCapabilities.setCapability("cleanSession", true);
			desiredCapabilities.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
//			SafariOptions safariOptions = new SafariOptions();
//			desiredCapabilities.setCapability(SafariOptions.CAPABILITY, safariOptions);
			// browserVersionLocal = "12.0";

		} else if (browserType == BrowserTypeEnum.SAFARIIPAD) {
			desiredCapabilities = new DesiredCapabilities(new SafariOptions());
			desiredCapabilities.setCapability(CapabilityType.PLATFORM_NAME, "OS X 10.11");
			desiredCapabilities.setCapability("screenResolution", "1024x768");
			desiredCapabilities.setCapability("seleniumVersion", SELENIUM_VERSION);
			desiredCapabilities.setCapability("cleanSession", true);
			desiredCapabilities.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
			SafariOptions safariOptions = new SafariOptions();
			desiredCapabilities.setCapability(SafariOptions.CAPABILITY, safariOptions);
			browserVersionLocal = "9.0";

		} else if (browserType == BrowserTypeEnum.HEADLESS) {
			desiredCapabilities = DesiredCapabilities.htmlUnit();
		} else if (browserType == BrowserTypeEnum.PHANTOMJS) {
			desiredCapabilities = DesiredCapabilities.phantomjs();
		} else if (browserType == BrowserTypeEnum.MacFireFox) {
			desiredCapabilities = new DesiredCapabilities(new FirefoxOptions());
			desiredCapabilities.setCapability(CapabilityType.PLATFORM_NAME,Platform.MAVERICKS);
			FirefoxProfile prof = new FirefoxProfile();
			prof.setPreference("browser.startup.homepage", "about:blank");
			prof.setPreference("startup.homepage_welcome_url", "about:blank");
			prof.setPreference("startup.homepage_welcome_url.additional", "about:blank");
			// desiredCapabilities.setCapability("screenResolution", "1280x1024");
			browserVersionLocal = "latest";

		} else if (browserType == BrowserTypeEnum.ChromeFireFox) {
			desiredCapabilities = new DesiredCapabilities(new FirefoxOptions());
			desiredCapabilities.setBrowserName("chrome");
			desiredCapabilities.setCapability(CapabilityType.PLATFORM_NAME,Platform.YOSEMITE);
			desiredCapabilities.setCapability("screenResolution", "1280x1024");

		}

		else { // browserType == BrowserTypeEnum.FIREFOX
			desiredCapabilities = new DesiredCapabilities(new FirefoxOptions());
			desiredCapabilities.setCapability(CapabilityType.PROXY, proxy);
			desiredCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			// desiredCapabilities.setPlatform(Platform.WIN8_1);
			// desiredCapabilities.setCapability("screenResolution",
			// "1280x1024");
			// browserVersionLocal = "40";
		}

		// Clean session for IE browser.
		if (browserType.isInternetExplorer()) {
			if (startWithCleanSession()) {
				desiredCapabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
			}
		}

		// Browser version
		desiredCapabilities.setCapability(CapabilityType.BROWSER_VERSION,browserVersionLocal);

		// OS
		// Platform platform = identifyPlatform(os, osVersion);

		// s_logger.info("Request os: {}, version: {}, identifed platform: {}",
		// os, osVersion, platform);
		// desiredCapabilities.setPlatform(platform );
		desiredCapabilities.setCapability("seleniumVersion", SELENIUM_VERSION);
		// desiredCapabilities.setCapability("tunnelIdentifier",
		// "dmzsaucetunnel_722417202405224");
		if (enableIdleTime.equalsIgnoreCase("true")) {
			desiredCapabilities.setCapability("idleTimeout", 500);
			desiredCapabilities.setCapability("maxDuration", 2500);
		}
		return desiredCapabilities;
	}

	/**
	 * Applicable for Safari & IE Browser alone at this point.
	 * 
	 * Default implementation is to remove history, cookies and any temporary
	 * storage.
	 * 
	 * Sub classes can override this to start with existing session information.
	 * 
	 * Firefox/Chrome always start with clean session.
	 * 
	 * @return
	 */
	protected boolean startWithCleanSession() {
		return true;
	}

	/**
	 * Return platform based on OS & version.
	 * 
	 * @param os
	 * @param osVersion
	 * @return
	 */
	private Platform identifyPlatform(String os, String osVersion) {
		if (Platform.ANY.toString().equals(os)) {
			return Platform.ANY;
		}
		return Platform.extractFromSysProperty(os, osVersion);
	}

	/**
	 * Create an instance of WebDriver in the current system.
	 * 
	 * @param browserType
	 * @param desiredCapabilities
	 * @return
	 */
	private WebDriver getLocalBrowser(final BrowserTypeEnum browserType,
									  final DesiredCapabilities desiredCapabilities) {
		WebDriver webDriver;

		// Create local web driver instance
		if (browserType == BrowserTypeEnum.CHROME) {
			WebDriverManager.chromedriver().setup();
			webDriver = new ChromeDriver(new ChromeOptions().merge(desiredCapabilities));
			Calendar date = Calendar.getInstance();
			long t= date.getTimeInMillis();
			Date afterAdding20Mins=new Date(t + (20 * 60000));
			Cookie qaAccess = new Cookie("qa_access", "true", "asda.com","/",afterAdding20Mins);

//			webDriver.get("chrome-extension://jciacimpfapbkckkegdfngcnbdpabaoi/add.html?qaToken=4nmsww3cwe5054hq8l9jvnnao0fczc");
			webDriver.get("https://www-qa.asda.com/login?redirect_uri=https://groceries-qa.asda.com/&request_origin=gi");
			webDriver.manage().addCookie(qaAccess);
			webDriver.get("https://www-qa.asda.com/login?redirect_uri=https://groceries-qa.asda.com/&request_origin=gi");

		} else if (browserType == BrowserTypeEnum.INTERNET_EXPLORER_7
				|| browserType == BrowserTypeEnum.INTERNET_EXPLORER_8
				|| browserType == BrowserTypeEnum.INTERNET_EXPLORER_9
				|| browserType == BrowserTypeEnum.INTERNET_EXPLORER_10
				|| browserType == BrowserTypeEnum.INTERNET_EXPLORER_11) {

			WebDriverManager.iedriver().setup();
			webDriver = new InternetExplorerDriver(new InternetExplorerOptions().merge(desiredCapabilities));
		} else if (browserType == BrowserTypeEnum.ANDROID) {
			throw new RuntimeException("Android is not supported in current Selenium Version");
		} else if (browserType == BrowserTypeEnum.IPAD) {
			try {
				throw new RuntimeException("IPAD is not supported in current Selenium Version");
			} catch (Exception e) {
				s_logger.error("Unable to start ipad driver");
				throw new RuntimeException(e);
			}
		} else if (browserType == BrowserTypeEnum.SAFARI) {
			/*
			WebDriverManager.safaridriver().setup();
			webDriver = new SafariDriver(new SafariOptions().merge(desiredCapabilities));*/
			webDriver = new SafariDriver(desiredCapabilities);
		} else if (browserType == BrowserTypeEnum.HEADLESS) {
			webDriver = new HtmlUnitDriver(desiredCapabilities);
		} else if (browserType == BrowserTypeEnum.PHANTOMJS) {
			webDriver = new PhantomJSDriver(desiredCapabilities);
		} else { // browserType == BrowserTypeEnum.FIREFOX
			FirefoxOptions options = new FirefoxOptions();
			String profileName = ExecutionConfig.getInstance().getValue(FIREFOX_PROFILE_NAME, null);
			if (StringUtility.isNotEmpty(profileName)) {
				FirefoxProfile profile = getFireFoxProfile(profileName);
				if(profile==null)
					profile = new FirefoxProfile();
				if(enablePerfUserAgent)
					profile.setPreference("general.useragent.override", "asda-uk-selenium-automation-agent");
				options.setProfile(profile);
			}
			WebDriverManager.firefoxdriver().setup();
			webDriver = new FirefoxDriver(options);
		}

		return webDriver;
	}

	/**
	 * Create an instance of WebDriver in the current system.
	 *
	 * @param browserType
	 * @param desiredCapabilities
	 * @return
	 */
	private WebDriver getLocalBrowserForAgatha(final BrowserTypeEnum browserType,
									  final DesiredCapabilities desiredCapabilities) {
		WebDriver webDriver;

		// Create local web driver instance
		if (browserType == BrowserTypeEnum.CHROME) {
			WebDriverManager.chromedriver().setup();
			webDriver = new ChromeDriver(new ChromeOptions().merge(desiredCapabilities));
		} else if (browserType == BrowserTypeEnum.INTERNET_EXPLORER_7
				|| browserType == BrowserTypeEnum.INTERNET_EXPLORER_8
				|| browserType == BrowserTypeEnum.INTERNET_EXPLORER_9
				|| browserType == BrowserTypeEnum.INTERNET_EXPLORER_10
				|| browserType == BrowserTypeEnum.INTERNET_EXPLORER_11) {
			WebDriverManager.iedriver().setup();
			webDriver = new InternetExplorerDriver(new InternetExplorerOptions().merge(desiredCapabilities));
		} else if (browserType == BrowserTypeEnum.ANDROID) {
			throw new RuntimeException("Android is not supported in current Selenium Version");
		} else if (browserType == BrowserTypeEnum.IPAD) {
			try {
				throw new RuntimeException("IPAD is not supported in current Selenium Version");
			} catch (Exception e) {
				s_logger.error("Unable to start ipad driver");
				throw new RuntimeException(e);
			}
		} else if (browserType == BrowserTypeEnum.SAFARI) {
			webDriver = new SafariDriver(new SafariOptions().merge(desiredCapabilities));
		} else if (browserType == BrowserTypeEnum.HEADLESS) {
			webDriver = new HtmlUnitDriver(desiredCapabilities);
		} else if (browserType == BrowserTypeEnum.PHANTOMJS) {
			webDriver = new PhantomJSDriver(desiredCapabilities);
		} else { // browserType == BrowserTypeEnum.FIREFOX
			FirefoxOptions options = new FirefoxOptions();
			String profileName = ExecutionConfig.getInstance().getValue(FIREFOX_PROFILE_NAME, null);
			if (StringUtility.isNotEmpty(profileName)) {
				FirefoxProfile profile = getFireFoxProfile(profileName);
				if(profile==null)
					profile = new FirefoxProfile();
				if(enablePerfUserAgent)
					profile.setPreference("general.useragent.override", "asda-uk-selenium-automation-agent");
				options.setProfile(profile);
			}
			WebDriverManager.firefoxdriver().setup();
			webDriver = new FirefoxDriver(options);
		}

		return webDriver;
	}
	/**
	 * Start remote selenium session at hub url.
	 * 
	 * Throws runtime exception if session is not started with in required time.
	 * 
	 * @param seleniumHubUrl
	 * @param desiredCapabilities
	 * @return
	 */
	private RemoteWebDriver startRemoteSession(final String seleniumHubUrl,
			final DesiredCapabilities desiredCapabilities) {
		RemoteWebDriver wd = new SingleThreadExecutor<RemoteWebDriver>("StartRemoteBrowserSession") {
			@Override
			public RemoteWebDriver run() {
				try {
					return new RemoteWebDriver(new URL(seleniumHubUrl), desiredCapabilities);
				} catch (MalformedURLException e) {
					throw new RuntimeException("Error in URL", e);
				}
			}

			public RemoteWebDriver onAnyException(Exception e, String taskName) {
				s_logger.error("Error starting remote session", e);
				throw new RuntimeException("Error starting remote session", e);
			}

		}.execute(ExecutionConfig.getInstance().getLongValue(SESSION_START_TIMEOUT_KEY, SESSION_START_TIMEOUT_DEFAULT),
				ExecutionConfig.getInstance().getIntValue(Constants.RETRY_ATTEMPTS_TO_START_SESSION_KEY,
						Constants.RETRY_ATTEMPTS_TO_START_SESSION_DEFAULT),
				ExecutionConfig.getInstance().getLongValue(Constants.WAIT_TIME_BETWEEN_RETRIES_FOR_SESSION_START_KEY,
						Constants.WAIT_TIME_BETWEEN_RETRIES_FOR_SESSION_START_DEFAULT));
		return wd;
	}

	/**
	 * Load base page with a timeout of max page load time.
	 * 
	 * @param baseUrl
	 * @param webDriver
	 */
	private void loadBasePage(final String baseUrl, final WebDriver webDriver) {
		ExecutorService exec = Executors.newSingleThreadExecutor();
		Boolean result = false;
		try {
			result = exec.submit(new Callable<Boolean>() {
				@Override
				public Boolean call() throws Exception {
					try {
						webDriver.get(baseUrl);
						if (enablebrowsermobglobal) {
							webDriver.navigate().refresh();
							MigrationUtil.unconditionalWait(6000);
						}
						return true;
					} catch (Exception e) {
						s_logger.error(
								"Error loading start url. Continuing further as it might be taking more time only for this page.",
								e);
						return false;
					}
				}
			}).get(PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			s_logger.error(
					"Error loading start url. Continuing further as it might be taking more time only for this page.",
					e);
		} catch (ExecutionException e) {
			s_logger.error(
					"Error loading start url. Continuing further as it might be taking more time only for this page.",
					e);
		} catch (TimeoutException e) {
			s_logger.error(
					"Error loading start url. Continuing further as it might be taking more time only for this page.",
					e);
		}
		if (result) {
			s_logger.info("Start url loaded successfully.");
		} else {
			@SuppressWarnings("unused")
			Boolean res = new SingleThreadExecutor<Boolean>("CaptureScreenShot") {
				@Override
				public Boolean run() {
					((JavascriptExecutor) webDriver).executeScript("window.stop();");
					return true;
				}
			}.execute(SCRIPT_TIMEOUT);

		}

	}

	/**
	 * Log remote system info to logs.
	 * 
	 * @param sid
	 * @param seleniumUrl
	 */
	private void logRemoteSystemInfo(SessionId sid, String seleniumUrl) {
		WebServiceUtil wsutil = new WebServiceUtil();
		String baseUrl = seleniumUrl.substring(0, seleniumUrl.indexOf("/wd/hub"));
		try {
			WebServiceResponse resp = wsutil.invokeRESTGetRequest(baseUrl + "/grid/api/testsession?session=" + sid,
					new HashMap<String, String>());
			if (resp.getResponseCode() != 200) {
				return;
			}

			JSONObject json = new JSONObject(resp.getResponseBody());
			String proxy = (String) json.get("proxyId");
			String ip = proxy.substring(proxy.indexOf("://") + 3, proxy.lastIndexOf(":"));
			InetAddress i = InetAddress.getByName(ip);
			s_logger.info("Browser opened on machine: {} - {}", i.getHostName(), proxy);
			s_statusLogger.info("Browser opened on machine: {} - {}", i.getHostName(), proxy);
			ReportThreadLocal.getReportBean().setBrowserMachine(i.getHostName());
		} catch (Throwable e) {
			ReportThreadLocal.getReportBean().setBrowserMachine("unknown");
			s_logger.info("Unable to capture machine where browser is opened.");
			s_statusLogger.info("Unable to capture machine where browser is opened.");
		}

	}

	/**
	 * Get timeouts from configuration and set the same in WebDriver and selenium
	 * instance.
	 * 
	 * @param browserType
	 * @param webDriver
	 */
	private void setTimeouts(BrowserTypeEnum browserType, WebDriver webDriver) {
		Timeouts t = webDriver.manage().timeouts();

		// pageLoadTimeOut and scriptTimeout are read from execution.properties
		// property file
		if (browserType != BrowserTypeEnum.SAFARI && browserType != BrowserTypeEnum.SAFARIIPAD) {
			try {

				PAGE_LOAD_TIMEOUT = ExecutionConfig.getInstance().getLongValue(PAGE_LOAD_TIMEOUT_KEY,
						PAGE_LOAD_TIMEOUT);
				ELEMENT_WAIT_TIMEOUT = ExecutionConfig.getInstance().getLongValue(ELEMENT_WAIT_TIMEOUT_KEY,
						ELEMENT_WAIT_TIMEOUT);
				SCRIPT_TIMEOUT = ExecutionConfig.getInstance().getLongValue(SCRIPT_TIMEOUT_KEY, SCRIPT_TIMEOUT);
			} catch (Exception e) {
				s_logger.error("Could not parse the timeouts from properties file" + e.getMessage());
			}
			t.implicitlyWait(ELEMENT_WAIT_TIMEOUT, TimeUnit.SECONDS);
			t.setScriptTimeout(SCRIPT_TIMEOUT, TimeUnit.SECONDS);

			if (browserType == BrowserTypeEnum.FIREFOX) {
				// This function not implemented for chrome/android/ipad.
				t.pageLoadTimeout(PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
			}
		}

	}

	/**
	 * Maximize window on start of the test.
	 * 
	 * @return
	 */
	protected boolean maximizeWindowOnStart() {
		return true;
	}

	@AfterMethod(alwaysRun = true)
	public void captureScreenShot(ITestResult result, Method testMethod) {
		TestInfo methodAnnotation = testMethod.getAnnotation(TestInfo.class);
		String currentIndex = ReportListener.getCurrentDataIndex(result);
		String invType = methodAnnotation.testcaseInvType().name();

		String testCaseId = methodAnnotation.testId();
		try {
			BaseTestMethod bm = (BaseTestMethod) result.getMethod();
			Field f = bm.getClass().getSuperclass().getDeclaredField("m_methodName");
			f.setAccessible(true);
			f.set(bm, bm.getMethodName() + "<br>Test Case ID : " + testCaseId + "<br>Test Case Inventory: " + invType);
		} catch (Exception ex) {
			s_logger.error("Error setting method name in html logs.", ex);
		}

		if (result.isSuccess()) {
			s_logger.info("{}:{} is successful.", testMethod.getDeclaringClass(), testMethod.getName());
			return;
		} else if (result.getStatus() == ITestResult.SKIP) {
			s_logger.info("{}:{} is skipped.", testMethod.getDeclaringClass(), testMethod.getName());
			return;
		} else if (startupException.get() != null) {
			// Start up exception.
			ReportBean rBean = ReportThreadLocal.getReportBean();
			rBean.setStartupExceptionName(startupException.get().getClass().getSimpleName());
			rBean.setStartupExceptionErrorMessage(startupException.get().getMessage());
			s_logger.info("Startup error.");
			return;
		}
		s_logger.info("{}:{} failed.", testMethod.getDeclaringClass(), testMethod.getName());

		// If driver instance is null test didn't start, do not attempt to
		// capture screenshot.
		if (webDriverHolder.get() == null) {
			s_logger.info("Test didnt even start. Skiping screenshot capture.");
			return;
		}
		s_logger.info("Current Index ::" + currentIndex);
		String screenshotName = "screenshot_" + currentIndex + ".png";

		File screenshot = getPage(BaseWebPage.class).captureScreenshotAndGetFile(screenshotName);
		if (screenshot == null) {
			return;
		}

		String testLogRelativePath = TestExecutionContext.getInstance().getRelativeLogPathInSuite();

		if (testLogRelativePath.indexOf("[") != -1) {
			String getSuiteFileName = testLogRelativePath.substring(testLogRelativePath.indexOf("[") + 1,
					testLogRelativePath.indexOf("]"));
			String suiteName = testLogRelativePath.substring(testLogRelativePath.indexOf("/") + 1);
			suiteName = getSuiteFileName + "/" + suiteName;
			testLogRelativePath = suiteName;
			s_logger.debug("Running failed test case for Suite" + testLogRelativePath);
		}

		String screenshotFilePath = ReportListener.TEST_RUN_ID + "/" + testLogRelativePath;

		if (ReportListener.isSecondAttempt()) {
			screenshotFilePath += "/" + "attempt2";
		}

		// Save the screenshot details to the current report bean in Thread
		// local
		ReportBean rBean = ReportThreadLocal.getReportBean();
		rBean.setScreenshot(screenshot);
		rBean.setScreenshotPath(screenshotFilePath);
		ReportThreadLocal.setReportBean(rBean);

	}

	public void updateSauce(ITestResult result, WebDriver driverInstance) {
		 s_logger.info("************** Updating Saucelabs about Test Status******************");
		 ((JavascriptExecutor) driverInstance).executeScript("sauce:job-result=" + (result.isSuccess() ? "passed" : "failed"));
		 s_logger.info("Updated Saucelabs. Status is " + result.isSuccess());
	}

	@AfterMethod(alwaysRun = true, dependsOnMethods = { "captureScreenShot" })
	@Parameters({ "islocalrun", "doVideoRecoring", "enableBrowsermob" })
	public void tearDown(@Optional("false") boolean localrun, @Optional("no") String doVideoRecording,
			@Optional("false") boolean enableBrowsermob, ITestResult result, Method testMethod) throws Exception {
		endTime = new Date();
		calDuration(startTime, endTime);
		super.tearDown(result, testMethod);
		final WebDriver wd = webDriverHolder.get();

		if (!result.isSuccess() && localrun
				&& ExecutionConfig.getInstance().getBoolean("LEAVE_BROWSER_OPEN_ON_ERROR", false)) {
			s_logger.info("Not quitting browser as configure is set not to close.");
			return;
		}

		if (!localrun && uploadSauce) {
			if (!result.isSuccess() || result.isSuccess()) {
				updateSauce(result, wd);
			}
		}
		if (webDriverHolder.get() != null) {
			s_logger.info("Quitting session: {} from class:{}", webDriverHolder.get(), this);

			Boolean isSuccess = new SingleThreadExecutor<Boolean>("QuitBrowserSession") {
				@Override
				public Boolean run() {
					try {
						s_logger.info("Quitting browser sesson...******************");
						wd.quit();
					} catch (Exception e) {
						e.printStackTrace();
					}
					return true;
				}
			}.execute(ExecutionConfig.getInstance().getLongValue(SESSION_START_TIMEOUT_KEY,
					SESSION_START_TIMEOUT_DEFAULT));
			if (isSuccess != null && isSuccess) {
				s_logger.error("Browser closed successfully.");
			} else {
				s_logger.error("Error closing browser.");
			}
		} else {
			s_logger.info("Browser is null so not closing browser.");
		}
		s_logger.info("Complete test on this thread.");
		if (doVideoRecording.equalsIgnoreCase("yes") && (!localrun)) {
			WebServiceUtil wsutil = new WebServiceUtil();

			try {
				WebServiceResponse resp;
				resp = wsutil.invokeRESTGetRequest(
						"http://" + ReportThreadLocal.getReportBean().getBrowserMachine() + ":9998/rec/save/"
								+ ReportListener.TEST_RUN_ID + "_" + ReportThreadLocal.getReportBean().getTestCaseId()
								+ "_" + ReportThreadLocal.getReportBean().getCurrentIndex(),
						new HashMap<String, String>());
				resp = wsutil.invokeRESTGetRequest(
						"http://" + ReportThreadLocal.getReportBean().getBrowserMachine() + ":9998/rec/stop",
						new HashMap<String, String>());
				if (resp.getResponseCode() != 200) {
					return;
				} else {
					s_logger.info("Video saved on box : " + ReportThreadLocal.getReportBean().getBrowserMachine());
				}

			} catch (Exception e) {
				s_logger.info("Unable to stop video capturing, service might be down on machine: "
						+ ReportThreadLocal.getReportBean().getBrowserMachine());
				s_statusLogger.info("Unable to stop video capturing, service might be down on machine :"
						+ ReportThreadLocal.getReportBean().getBrowserMachine());
			}

		}
	}

	/**
	 * Return the real cause for this test failure.
	 */
	@Override
	protected Throwable getRealCause(ITestResult result) {
		if (startupException.get() != null) {
			return startupException.get();
		}
		return super.getRealCause(result);
	}

	public static ThreadLocal<WebDriver> getWebDriverHolder() {
		return webDriverHolder;
	}

	public static ThreadLocal<BrowserMobProxy> getProxyserverHolder() {
		return proxyServer;
	}

	/**
	 * Get the FireFox profile instance. If not found return null.
	 * 
	 * @param strProfileName desired profile name
	 * @return FirefoxProfile object
	 */
	private FirefoxProfile getFireFoxProfile(String strProfileName) {
		ProfilesIni profilesIni = new ProfilesIni();
		FirefoxProfile profile = profilesIni.getProfile(strProfileName);
		if (profile == null) {
			return null;
		}
		s_logger.info("Loading " + strProfileName + " profile for firefox");
		// added to avoid ssl certificate error page
		profile.setAcceptUntrustedCertificates(true);
		profile.setAssumeUntrustedCertificateIssuer(false);
		return profile;
	}

	private void calDuration(Date d1, Date d2) {
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		try {

			long diff = d2.getTime() - d1.getTime();
			long diffSeconds = diff / 1000 % 60;
			long diffMinutes = diff / (60 * 1000) % 60;
			long diffHours = diff / (60 * 60 * 1000) % 24;
			long diffDays = diff / (24 * 60 * 60 * 1000);
			duration = "))))))))))))))))))))))))))" + diffHours + "h:" + diffMinutes + "m:" + diffSeconds + "s";

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
