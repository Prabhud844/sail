package com.asda.core.reporters;

import com.asda.core.logger.TestLogger;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Protocol;
import com.aventstack.extentreports.reporter.configuration.Theme;

import java.io.File;

public class CoverageReportManager {

    private static ExtentReports extent;
    private static final String reportFileName = "Test-Automation-Coverage-Report"+".html";
    private static final String fileSeperator = System.getProperty("file.separator");
    private static final String reportFilepath = TestLogger.class.getResource("/").getPath().replace("test-classes","");
    private static final String reportFileLocation =  reportFilepath +fileSeperator+ reportFileName;
    public static String SUITE_NAME = "SUITE_NAME";
    public static String SQUAD_NAME = "SQUAD_NAME";
    public static String TEST_ENV = "NOT_SET";
    public static boolean TCR_FLAG = false;

    public static ExtentReports getInstance() {
        if (extent == null)
            createInstance();
        return extent;
    }

    //Create an extent report instance
    public static ExtentReports createInstance() {
        String fileName = getReportPath(reportFilepath);

        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(fileName);
        htmlReporter.config().setTestViewChartLocation(ChartLocation.BOTTOM);
        htmlReporter.config().setChartVisibilityOnOpen(true);
        htmlReporter.config().setTheme(Theme.STANDARD);
        htmlReporter.config().setDocumentTitle(SQUAD_NAME + " Report");
        htmlReporter.config().setEncoding("utf-8");
        htmlReporter.config().setReportName(SQUAD_NAME + " - " + SUITE_NAME);
        htmlReporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");
        htmlReporter.config().setProtocol(Protocol.HTTPS);
        htmlReporter.config().setCSS("css-string");
        htmlReporter.config().setJS("js-string");

        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        //Set environment details
        extent.setSystemInfo("OS", System.getProperty("os.name"));
        extent.setSystemInfo("Test Environment", TEST_ENV);
        return extent;
    }

    //Create the report path
    private static String getReportPath (String path) {
        File testDirectory = new File(path);
        if (!testDirectory.exists()) {
            if (testDirectory.mkdir()) {
                System.out.println("Directory: " + path + " is created!" );
                return reportFileLocation;
            } else {
                System.out.println("Failed to create directory: " + path);
                return System.getProperty("user.dir");
            }
        } else {
            System.out.println("Directory already exists: " + path);
        }
        return reportFileLocation;
    }

}
