package  com.asda.core.reporters.model;
import java.text.SimpleDateFormat;

import com.asda.core.enums.StatusEnum;

public class TestCaseInfo {
	//=<Members>================================================================================
	private String testRunID =null; //  ex)  PRIMARY KEY   '2011-03-23_04-01-43-421'
	private static String startTime=null;  // ex) '2011-03-23 04:20:50'
	private String endTime=null;	// ex) '2011-03-23 04:20:50'
	private String duration=null;
	private String testCaseName=null; // PRIMARY KEY  ex)'FrontendTesting\Sasi\test.xml'
	private String attemptNumber="0"; // If success at first attempt, the number will be '1'
	private String	browser=null; // 
	private String owner=null;  
	private String qcLocation=null;  
	
    private StatusEnum status=null;  // Status Enum
    
    private String testCaseId=null;
    private String testSuiteId=null;
    
    private String	areaName=null;//Testing AREA JBERT categories  BackendTesting(BE),"FrontendTesting/SystemTesting"(ST), and "FrontendTesting"(FE)
    private String scriptLogDir=null ; // Script residing location.
    private String isScreenshotCaptured=null; // 
    private String exceptionName=null;
    private String exceptionErrorMessage=null;
    private String timedOutMessage=null;
    private String drilldownInfo=null;
    private String ticketNumber= "";
    private String browserMachine = null; // Remote machine where browser is opened.
//=<Constructors>============================================================================
    public TestCaseInfo(){
    }
    
//=<Methods>================================================================================
// Getters---------------------------------------------------------------------------------
    public String getTestRunID(){
		return testRunID;
	}
	public String getStartTime(){
	return startTime;
	}	
	public String getEndTime(){
		return endTime;
	}
	public String getDuration(){
		return duration;
	}
	public String getTestCaseName(){
		return testCaseName;
	}
	public String getAttemptNumber(){
		return attemptNumber;
	}
	public String getBrowser(){
		return browser;
 }
	public String getOwner(){
		return owner;
	}
	public String getQcLocation(){
		return qcLocation;//QC path.
	}
	public StatusEnum getStatus(){
		return status;
	}
	public String getAreaName(){
		return areaName;
	}
	public String getScriptLogDir(){
		return scriptLogDir;
	}
	public String getIsScreenshotCaptured(){ 
		return isScreenshotCaptured;
	}
	public String getExceptionName(){
		return exceptionName;
	}
	public String getExceptionErrorMessage(){
		return exceptionErrorMessage;
	}
	public String getTimeOutMessage(){
		return timedOutMessage;
	}
	public String getDrilldownInfo(){
		return drilldownInfo;
	}
	public String getTicketNumber(){
		return ticketNumber;
	}
//setters------------------------------------------------------------------------
	public void setTestRunID(String s){
		testRunID = s;
	}
	public void setStartTime(String s){
		startTime = s ;
	}	
	public void setEndTime(String s){
		endTime =s;
	}
	public void setDuration(String startTime,String endTime){
				duration = calDuration(startTime, endTime);
				System.out.println(duration);
	}
	public void setTestCaseName(String s){
		testCaseName = s;
	}
	public void setAttemptNumber(int i){
		attemptNumber = Integer.toString(i);
	}
	public void setBrowser(String s){
		browser = s;
 }
	public void setOwner(String s){
		owner = s;
	}
	public void setQcLocation(String s){
		qcLocation = convert(s);
	}
	public void setStatus(StatusEnum s){
		status =s;
	}
	public void setAreaName(String s){
		areaName = s;
	}
	public void setScriptLogDir(String s){
		scriptLogDir = convert(s);
	}
	public void setIsScreenshotCaptured(boolean s){ 
		if(s){
			isScreenshotCaptured = "1";
		}
		if(!s){
		isScreenshotCaptured = "0";
		}
	}
	public void setExceptionName(String s){
		exceptionName =s ;
	}
	public void setExceptionErrorMessage(String s){
		exceptionErrorMessage = s;
	}
	public void setTimeOutMessage(String s){
		timedOutMessage = s ;
	}
	public void setDrilldownInfo(String s){
		drilldownInfo =s;
	}
	public void setTicketNumber(String s){
		ticketNumber =s;
	}
	
	private String convert(String s){             
		String c;                                 
		c = s.replaceAll("\\\\", "\\\\\\\\");     
		return c;                                 
		                                          
	}

	public String getBrowserMachine() {
		return browserMachine;
	}

	public void setBrowserMachine(String browserMachine) {
		this.browserMachine = browserMachine;
	}

	public String getTestCaseId() {
		return testCaseId;
	}

	public void setTestCaseId(String testCaseId) {
		this.testCaseId = testCaseId;
	}

	public String getTestSuiteId() {
		return testSuiteId;
	}

	public void setTestSuiteId(String testSuiteId) {
		this.testSuiteId = testSuiteId;
	}  
	
	public String calDuration(String startTime,String endTime)
	{

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			//Date sdate=formatter.parse(startTime);
			long diff = formatter.parse(startTime).getTime() -formatter.parse(endTime).getTime();
			long diffSeconds = diff / 1000 % 60;
			long diffMinutes = diff / (60 * 1000) % 60;
			long diffHours = diff / (60 * 60 * 1000) % 24;
			long diffDays = diff / (24 * 60 * 60 * 1000);
		//   s_logger.info(diffHours+":"+diffMinutes+":"+diffSeconds);
			return (diffHours+":"+diffMinutes+":"+diffSeconds).replace("-", "");
			
		 } catch (Exception e) {
			return null;
		 }

	  }

	
}
