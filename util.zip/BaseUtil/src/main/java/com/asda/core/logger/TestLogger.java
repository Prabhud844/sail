package com.asda.core.logger;

import com.asda.qa.data.Constants;
import com.asda.qa.utility.GeneralUtility;
import com.asda.qa.utility.JsonUtil;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.asda.core.reporters.CoverageReportManager;
import org.json.JSONObject;
import org.json.simple.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class TestLogger extends CoverageReportManager {
    static Map<Integer, ExtentTest> extentTestMap = new HashMap<>();
    static Map<String, List<String>> coverageTestMap = Collections.synchronizedMap(new LinkedHashMap<>());
    static HashMap<String, String> methodVsTestNameMap = new HashMap<>();
    static Set<String> testKeys = null;
    static String lastTestCase = "";
    public static long START_TIME;
    static long END_TIME;

    static ExtentReports extent = CoverageReportManager.getInstance();
    private static final Logger s_logger = LoggerFactory.getLogger(TestLogger.class);

    public static synchronized ExtentTest getTest() {
        return extentTestMap.get((int) Thread.currentThread().getId());
    }

    public static synchronized void log(String step) {
        s_logger.info(step);
        if(CoverageReportManager.TCR_FLAG) {
            String threadId = String.valueOf((int) Thread.currentThread().getId());
            coverageTestMap.get(getTest().getModel().getStartTime().hashCode() + "#" + getTest().getModel().getHierarchicalName()+"-"+getTest().getModel().getID() + "#" + threadId).add(step+"#info");
            TestLogger.getTest().log(Status.INFO, step);
        }
    }

    public static synchronized void log(boolean status, String step) {
        s_logger.info(step);
        Status stepStatus;
        String step_status="info";
        if (status) {
            stepStatus = Status.PASS;
            step_status = "pass";
        } else{
            stepStatus = Status.FAIL;
            step_status = "fail";
        }
        if(CoverageReportManager.TCR_FLAG) {
            String threadId = String.valueOf((int) Thread.currentThread().getId());
            coverageTestMap.get(getTest().getModel().getStartTime().hashCode() + "#" + getTest().getModel().getHierarchicalName()+"-"+getTest().getModel().getID() + "#" + threadId).add(step+"#"+step_status);
            TestLogger.getTest().log(stepStatus, step);
        }
    }

    public static synchronized void TestName(String tname) {
        if(CoverageReportManager.TCR_FLAG) {
            methodVsTestNameMap.put(extentTestMap.get((int) Thread.currentThread().getId()).getModel().getHierarchicalName()
                    +"-"+extentTestMap.get((int) Thread.currentThread().getId()).getModel().getID(), tname);
            extentTestMap.get((int) Thread.currentThread().getId()).getModel().setName(tname);
        }
    }

    public static synchronized void endTest() {
        END_TIME = System.currentTimeMillis();
        if(CoverageReportManager.TCR_FLAG) createCoverageReport();
        extent.flush();
    }

    private static void createCoverageReport() {
        System.out.println("******************** ->->-> START - Generating Coverage Report <-<-<- *******************");
        String reportFileName = "Automation_Test_Coverage_Report"+".html";
        //String cssFileName = "css_style"+".css";
        String fileSeperator = System.getProperty("file.separator");
        String reportFileLocation =  TestLogger.class.getResource("/").getPath().replace("/test-classes","") + "CoverageReport" + fileSeperator + reportFileName;
        String coverageJsonFileLocation =  TestLogger.class.getResource("/").getPath().replace("/test-classes","") + "CoverageReport" + fileSeperator + "coverage_json.json";
        //String cssFileLocation =  TestLogger.class.getResource("/").getPath().replace("test-classes","") + "CoverageReport" + fileSeperator + cssFileName;
        String statusIcon = "check-circle";
        String color = "green";
        JSONObject coverageJson = new JSONObject();
        String row_template = "\t\t\t\t<tr><td> <<step_no>>   </td><td> <<step_value>> </td> <td><i class='fas fa-<<icon_type>>' style='color:<<icon_color>>'></i></td> </tr>\n";
        int counter = 1;
        String divs = "";
        System.out.println("Coverage Report PATH:"+ reportFileLocation);
        try {
            for (Map.Entry<String, List<String>> entry : coverageTestMap.entrySet()) {
                JSONArray stepArray = new JSONArray();
                String key = entry.getKey();
                List<String> steps = entry.getValue();
                int row_counter = 1;
                String[] testDetails = key.split("#");
                String testName = methodVsTestNameMap.get(testDetails[1]);
                if(null == testName) testName = testDetails[1];
                String barColor = "collapse";
                String row = "";
                for (String each_row : steps) {
                    String[] stepInfo = each_row.split("#");

                    String step_json = Constants.JSON_COVERAGE_TEMPLATE.replaceAll("<<step_name>>", stepInfo[0])
                            .replaceAll("<<step_status>>", stepInfo[1]);
                    stepArray.add(JsonUtil.convertStringToJsonObject(step_json));

                    statusIcon = getIconNameFromStatus(stepInfo[1]);
                    if (statusIcon.equals("dot-circle")) barColor = "collapse_failed";
                    color = getColorNameFromStatus(stepInfo[1]);
                    row = row + row_template.replace("<<step_no>>", "STEP: " + row_counter++)
                            .replace("<<step_value>>", stepInfo[0])
                            .replace("<<icon_type>>", statusIcon)
                            .replace("<<icon_color>>", color);
                }

                coverageJson.put(testName, stepArray);

                divs = divs + Constants.COVERAGE_EACH_PANEL_HTML_CODE
                        .replace("<<class_name>>", barColor)
                        .replace("<<testcase_name>>", testName)
                        .replace("<<row_num>>", String.valueOf(counter++))
                        .replace("<<put_your_row_here>>", row);
            }

            String duration;
            double diff = (END_TIME - START_TIME) / 1000;
            if (diff > 90.0)
                duration = (int) diff / 60 + " mins";
            else
                duration = (int) diff + " secs";
            GeneralUtility.writeFile(reportFileLocation, Constants.COVERAGE_HTML_FRAME_MAIN
                    .replace("<<SQUAD_NAME>>", CoverageReportManager.SQUAD_NAME.replaceAll("_", " "))
                    .replace("<<SUIT_NAME>>", CoverageReportManager.SUITE_NAME)
                    .replace("<<TEST_ENV>>", CoverageReportManager.TEST_ENV)
                    .replace("<<EXE_DURATION>>", duration)
                    .replace("<<TOTAL_NO_TCs>>", String.valueOf(coverageTestMap.size()))
                    .replace("<<ADD_YOUR_DIV_PANEL_HERE>>", divs)
            );
            //Writing to coverage JSON
            GeneralUtility.writeFile(coverageJsonFileLocation, coverageJson.toString());

        }catch (Exception e){
            System.out.println("ERROR: FAILED TO GENERATE COVERAGE REPORT!!!");
            e.printStackTrace();
        }
//        GeneralUtility.writeFile(cssFileLocation, Constants.COVERAGE_HTML_REPORT_CSS_TEMPLATE);
        System.out.println("******************** ->->-> END - Generating Coverage Report <-<-<- *******************");
    }

    private static String getIconNameFromStatus(String status) {
        switch (status){
            case "info":
            case "pass":
                return "check-circle";
            case "fail":
            case "skip":
                return "dot-circle";
        }
        return "exclamation-circle";
    }

    private static String getColorNameFromStatus(String status) {
        switch (status){
            case "info":
//                return "blank";
                return "green";
            case "pass":
                return "green";
            case "fail":
                return "red";
        }
        return "blank";
    }

    public static synchronized ExtentTest startTest(String testName) {
        String expendedTestName =  testName;
        if(!testName.trim().contains(" ")) expendedTestName = expandTestName(testName);
        ExtentTest test = extent.createTest(testName);
        String threadId = String.valueOf((int) Thread.currentThread().getId());
        extentTestMap.put((int) Thread.currentThread().getId(), test);
        String key = test.getModel().getStartTime().hashCode() + "#" + test.getModel().getHierarchicalName()
                + "-" + test.getModel().getID() + "#" + threadId;
        coverageTestMap.put(key, new ArrayList<>());
        lastTestCase = key;
        testKeys = coverageTestMap.keySet();
        TestName(expendedTestName);
        return test;
    }

    private static String expandTestName(String tName){
        String sen = "";
        String[] r = tName.split("(?=\\p{Upper})");
        r[0] = r[0].substring(0, 1).toUpperCase() + r[0].substring(1);
        for(String each: r)
            sen = sen + " " + each;

        return sen.trim();
    }

    public static void removeLastTestFromCoverage(String testname) {
        try {
            if (null == testKeys) testKeys = coverageTestMap.keySet();
            for (String each : testKeys) {
                if (each.contains(testname)) {
                    coverageTestMap.remove(each);
                }
            }
        }catch (Exception e){}
    }
}
