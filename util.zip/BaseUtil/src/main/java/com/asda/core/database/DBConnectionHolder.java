package com.asda.core.database;

import com.asda.core.reporters.dao.impl.ReportDaoImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DBConnectionHolder {
	static ApplicationContext beanContext = new ClassPathXmlApplicationContext("ReportBeans.xml");
	private static ReportDaoImpl dao = null;
	
	public static ReportDaoImpl getJDBCTemplate(){
		if (dao==null){
			dao = (ReportDaoImpl) beanContext.getBean("dao");
		}
		return dao;
	}
}