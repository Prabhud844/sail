package com.asda.core.enums;

/**
 * This enum represents the list of browser supported currently.
 *
 * @author jkandul
 *
 */
public enum BrowserTypeEnum {

    NONE("none"), FIREFOX("FIREFOX"), CHROMEGRID("CHROMEGRID"), CHROME("CHROME"), SAFARI("SAFARI"),
    INTERNET_EXPLORER_11("INTERNETEXPLORER_11"), INTERNET_EXPLORER_10("internetexplorer10"),
    INTERNET_EXPLORER_9("internetexplorer9"), INTERNET_EXPLORER_8("internetexplorer8"),
    INTERNET_EXPLORER_7("internetexplorer7"), INTERNET_EXPLORER("internetexplorer"), SAFARIIPAD("SAFARIIPAD"),
    MacFireFox("MACFIREFOX"), ANDROID_Tab("ANDROID_Tab", true), ChromeFireFox("MACCHROME"), ANDROID("ANDROID", true),
    IPHONE("iphone"), PHANTOMJS("phantomjs"), IPAD("ipad", true), HEADLESS("headless"),CHROME_PERF("CHROME_PERF");

    private final String browserName;
    private final boolean isTablet;

    BrowserTypeEnum(String browserName) {
        this(browserName, false);
    }

    BrowserTypeEnum(String browserName, boolean isTablet) {
        this.browserName = browserName;
        this.isTablet = isTablet;
    }

    public String getBrowserName() {
        return browserName;
    }

    public boolean isTablet() {
        return isTablet;
    }

    /**
     * Returns the matching BrowserTypeEnum for browserName. If no matching browser
     * is found defaultBrowsreType is returned.
     *
     * @param browserName
     * @param defaultBrowserType
     * @return
     */
    public static BrowserTypeEnum getBrowserType(String browserName, BrowserTypeEnum defaultBrowserType) {
        for (BrowserTypeEnum b : values()) {
            if (b.getBrowserName().equalsIgnoreCase(browserName)) {
                return b;
            }
        }
        return defaultBrowserType;
    }

    /**
     * Returns true if the browser is one of internet explorer browsers.
     *
     * @return
     */
    public boolean isInternetExplorer() {
        return this == INTERNET_EXPLORER_10 || this == INTERNET_EXPLORER_9 || this == INTERNET_EXPLORER_8
                || this == INTERNET_EXPLORER_7;
    }

}
