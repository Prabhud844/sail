package com.asda.core.webservice;

public class WebServiceException extends Exception {
    private static final long serialVersionUID = 683375222642263400L;

    public WebServiceException(Exception e) {
        super(e);
    }
}
