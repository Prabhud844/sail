package com.asda.core.baseexecution;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.asda.core.utils.Utility;
import com.asda.core.utils.Utility.NumberUtility;

/**
 * Used to read and initialize the execution properties
 * @author dneela
 *
 */
public class ExecutionConfig {
	private static final Logger s_logger = LoggerFactory.getLogger(ExecutionConfig.class);
	
	//Map that is used to maintain the key values of properties
	private static final Map<String,String> executionProps = new HashMap<String, String>();
	private static ExecutionConfig s_instance;
	
	private final Properties execProperties;
	
	
	private ExecutionConfig(){
		execProperties = new Properties();
		try {
			execProperties.load(ExecutionConfig.class.getClassLoader().getResourceAsStream("execution.properties"));
		} catch (IOException e) {
			throw new RuntimeException("Unable to load execution properties file", e);
		}
		initializeProps();
	}
	
	/**
	 * Initialize the execution properties with the props given as input
	 */
	public ExecutionConfig(Properties props){
		
		execProperties = props;
		initializeProps();
	}
	
	/**
	 * Method that is used to read the properties and save in the map
	 */
	public void initializeProps(){
		s_logger.debug("Intializing the properties read from the execution");
				Set<Object> keySet = execProperties.keySet();
				Iterator<Object> itr = keySet.iterator();
				
				while(itr.hasNext()){
					String key = (String) itr.next();
					executionProps.put(key,execProperties.getProperty(key));
				}		
	}
	/**
	 * returns the instance of the Execution config
	 */
	public static ExecutionConfig getInstance() {
		if(s_instance == null){
			s_instance =  new ExecutionConfig();
			return s_instance;
		}
		return s_instance;
	}
	
	/**
	 * Returns the execution props map
	 */
	public Map<String,String> getExecutionProps(){
		return executionProps;		
	}
	
	public String getValue(String propertyKey, String defaultValue) {
		if(Utility.StringUtility.isNotEmpty(executionProps.get(propertyKey))) {
			return executionProps.get(propertyKey);
		}
		return defaultValue;
	}
	
	public long getLongValue(String propertyKey, long defaultValue) {
		return NumberUtility.getLong(executionProps.get(propertyKey), defaultValue);
	}
	
	public int getIntValue(String propertyKey, int defaultValue) {
		return NumberUtility.getInt(executionProps.get(propertyKey), defaultValue);
	}
	
	/**
	 * Returns boolean value of property.
	 * 
	 * @param propertyKey
	 * @param defaultValue
	 * @return
	 */
	public boolean getBoolean(String propertyKey, boolean defaultValue) {
		if(Utility.StringUtility.isNotEmpty(executionProps.get(propertyKey))) {
			return Boolean.parseBoolean(executionProps.get(propertyKey));
		}
		return defaultValue;
	}
	
	/**
	 * Returns a boolean whether to capture the screenshot or not based on the properties.
	 * 
	 * @return
	 */
	public boolean captureScreenshotsInFlow() {
		return getBoolean(Constants.CAPTURE_SCREENSHOTS_IN_FLOW_KEY, Constants.CAPTURE_SCREENSHOTS_IN_FLOW_DEFAULT);
	}
	
	/**
	 * Returns the element wait timeout configured in properties
	 * 
	 * @return
	 */
	public long getElementWaitTimeOut() {
		return getLongValue(Constants.ELEMENT_WAIT_TIMEOUT_KEY, Constants.ELEMENT_WAIT_TIMEOUT_DEFAULT);
	}
	
	/**
	 * Constants read from properites used for configuring the tests.
	 * 
	 * @author jkandul
	 */
	public interface Constants {
		String SCRIPT_TIMEOUT_KEY = "SCRIPT_TIMEOUT";
		String PAGE_LOAD_TIMEOUT_KEY = "PAGE_LOAD_TIMEOUT";
		String ELEMENT_WAIT_TIMEOUT_KEY = "ELEMENT_WAIT_TIMEOUT";
		String FIREFOX_PROFILE_NAME_KEY = "FIREFOX_PROFILE_NAME";
		String SESSION_START_TIMEOUT_KEY = "SESSION_START_TIMEOUT";
		String CAPTURE_SCREENSHOTS_IN_FLOW_KEY = "CAPTURE_SCREENSHOTS_IN_FLOW";
		String RETRY_ATTEMPTS_TO_START_SESSION_KEY = "RETRY_ATTEMPTS_TO_START_SESSION";
		String WAIT_TIME_BETWEEN_RETRIES_FOR_SESSION_START_KEY = "WAIT_TIME_BETWEEN_RETRIES_FOR_SESSION_START";

		long PAGE_LOAD_TIMEOUT_DEFAULT = 60;
		long SCRIPT_TIMEOUT_DEFAULT = 60;
		long ELEMENT_WAIT_TIMEOUT_DEFAULT = 60;
		int SESSION_START_TIMEOUT_DEFAULT = 60;
		boolean CAPTURE_SCREENSHOTS_IN_FLOW_DEFAULT = false;
		int RETRY_ATTEMPTS_TO_START_SESSION_DEFAULT = 1;
		long WAIT_TIME_BETWEEN_RETRIES_FOR_SESSION_START_DEFAULT = 10;
	}
	
}

