package com.asda.core.utils;

import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import net.sf.json.JSON;
import net.sf.json.JSONSerializer;
import org.json.JSONObject;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.nio.charset.StandardCharsets;

/**
 * Converts JSON to XML and XML to JSON
 * @author kmehta
 *
 */
@SuppressWarnings("restriction")
public class XMLJSONConvertors {

	private final static Logger s_logger = LoggerFactory.getLogger(Utility.class);

	/**
	 * Converts JSON string to XML
	 * Example:
	 * String json = "{ \"store\": {\"book\": [{ \"category\": \"reference\",\"author\": \"Nigel Rees\", \"title\": \"Sayings of the Century\", \"price\": 8.95 },      { \"category\": \"fiction\",        \"author\": \"Evelyn Waugh\",        \"title\": \"Sword of Honour\",        \"price\": 12.99,       \"isbn\": \"0-553-21311-3\"      }    ],    \"bicycle\": {      \"color\": \"red\",      \"price\": 19.95    }  }}";
	 * @param jsonStr
	 * @return
	 * @throws Exception
	 */
	public String JSONToXMLConverter(String jsonStr) throws Exception{
		String XMLString = null;
		s_logger.info("Converting Json To XML");
		try{
			net.sf.json.xml.XMLSerializer serializer = new net.sf.json.xml.XMLSerializer();
			JSON json = JSONSerializer.toJSON(jsonStr);
			String xml = serializer.write(json);
			xml = formatXml(xml);
			//XMLString = Utility.StringUtility.escapeXmlTagsForHTML(xml);
			s_logger.info("XML String: " + XMLString);
//			return parseXml(new ByteArrayInputStream(XMLString.getBytes("UTF-8")));
			return xml;
		}catch(Exception e){
			throw new Exception("Cannot Convert Json To XML", null);
			
		}
	}

	/**
	 * Converts XML string to JSON
	 * Example:
	 * String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><important-data certified=\"true\" processed=\"true\"> <timestamp>232423423423</timestamp><authors><author><firstName>Tim</firstName><lastName>Leary</lastName></author></authors><title>Flashbacks</title><shippingWeight>1.4 pounds</shippingWeight><isbn>978-0874778700</isbn></important-data>";
	 * @param XMLStr
	 * @return
	 * @throws Exception
	 */
	public String XMLToJsonConverter(String XMLStr) throws Exception {
		s_logger.info("Converting XML To Json");
		try{
			JSONObject jsonObject = XML.toJSONObject(XMLStr);
			s_logger.info("JSON String: " + jsonObject.toString(2));
			return jsonObject.toString();
		}catch(Exception e){
			throw new Exception("Cannot Convert XML to Json", null);
			
		}
	}
	
	/**
	 * @param xmlString
	 * @return
	 */
	private String formatXml(String xmlString) {
		try {
			Document x = parseXml(new ByteArrayInputStream(xmlString.getBytes(StandardCharsets.UTF_8)));
			OutputFormat format = new OutputFormat();
			// format.setLineWidth(0);
			format.setIndenting(true);
			format.setIndent(2);
			Writer out = new StringWriter();
			XMLSerializer ser = new XMLSerializer (out,format);
			ser.serialize(x);
			return out.toString();
		} catch (UnsupportedEncodingException e) {
			// Ignore
		} catch (IOException e) {
			// Ignore
		} catch (Exception e) {
			// Ignore
		}
		return xmlString; // Default string
	}

	/**
	 * @param ioStream
	 * @return
	 * @throws Exception
	 */
	private Document parseXml(InputStream ioStream) throws Exception {
		Document doc = null;
		if (ioStream == null) {
			return doc;
		}

		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		try {
			DocumentBuilder db = dbf.newDocumentBuilder();
			doc = db.parse(ioStream);
		} catch (ParserConfigurationException e) {
			throw new Exception(e);
		} catch (SAXException e) {
			throw new Exception(e);
		} catch (IOException e) {
			throw new Exception(e);
		} catch (Throwable te) {
			throw new Exception(te);
		}
		return doc;
	}
}
