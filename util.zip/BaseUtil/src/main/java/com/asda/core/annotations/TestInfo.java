package com.asda.core.annotations;


import com.asda.core.enums.TestPriorityEnum;
import com.asda.core.enums.TestcaseInventoryEnum;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


/**
 * This annotation captures the test case information associated with every test.
 * 
 * This information will be used during execution to publish reports. 
 * 
 * @author jkandul
 *
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface TestInfo {

	/**
	 * Test case inventory Type.
	 * 
	 * @return
	 */
	TestcaseInventoryEnum testcaseInvType() default TestcaseInventoryEnum.Jira;
	
	/**
	 * Test case location in this inventory.
	 * @return
	 */
	String testLocation() default "ASDAGroceries";
	
	/**
	 * Unique identifier for this test.
	 * @return
	 */
	String testId();
	
	/**
	Test case Area in this inventory.
	 * @return 
	 */
	String testArea();
	
	/**
	Test case Owner, person who is automating the test case
	 * @return
	 */
	String testOwner();
	
	TestPriorityEnum priority();
	/**
	 * Test Suite Id in Test Rail, optional parameter
	 * @return
	 */

	String testSuiteId() default "";
}

