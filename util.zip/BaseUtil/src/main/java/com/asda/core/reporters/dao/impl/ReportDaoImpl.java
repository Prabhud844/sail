package com.asda.core.reporters.dao.impl;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Properties;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.asda.core.reporters.dao.ReportDao;
import com.asda.core.reporters.model.TestCaseInfo;
import com.asda.core.reporters.model.TestSummaryInfo;
import com.asda.core.webservice.BaseWebService;
import com.asda.core.webservice.WebServiceResponse;
import com.asda.core.reporters.ReportListener;

public class ReportDaoImpl implements ReportDao {

	private static final int ERROR_MESSAGE_MAX_LENGTH = 1800;
	private JdbcTemplate jdbcTemplateObject;
	private Properties m_properties;

	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
		m_properties = new Properties();
		try {
			m_properties.load(getClass().getClassLoader().getResourceAsStream("portalService.properties"));
		} catch (IOException e) {
			s_logger.error("portalService.properties not found {}", e);
		}
	}

	private static final Logger s_logger = LoggerFactory.getLogger(ReportListener.class);

	@Override
	public void insert(TestSummaryInfo summary) {
		s_logger.info("reporterInserstion for$$$$$$$$$$$$$ summary insert"
				+ ReportListener.reporterInserstion);
		WebServiceResponse res = new WebServiceResponse();

		if (ReportListener.reporterInserstion.equalsIgnoreCase("DB")) {
			insertTestSummaryDB(summary);
		} else {
			HashMap<String, String> header = new HashMap<String, String>();
			HashMap<String, String> postParam = new HashMap<String, String>();
			postParam.put("testRunID", summary.getTestRunID());
			postParam.put("environment", summary.getQAEnv());
			postParam.put("track", summary.getTrack());
			postParam.put("startTime", summary.getStartTime());
			postParam.put("minTestsToExecute",
					String.valueOf(summary.getMinTestsToExecute()));
			postParam.put("attemptNumber",
					String.valueOf(summary.getAttemptNumber()));
			postParam.put("type", summary.getType());
			postParam.put("appName", summary.getAppName());

			if(summary.getTcr_flag().equalsIgnoreCase("true")) {

				String coverageReportUrl = "http://dfw-obj-100.storage.cloud.wal-mart.com/swift/v1/looper-prod/reports/";

				if(! (summary.getJobUrl()==null)){
					if (summary.getJobUrl().contains("ci.falcon"))
						coverageReportUrl = "http://dfw-obj-torbit-103.storage.cloud.wal-mart.com/swift/v1/looper-prod1/reports/";
					else if(summary.getJobUrl().contains("ci.electrode"))
						coverageReportUrl = "http://dfw-obj-torbit-103.storage.cloud.wal-mart.com/swift/v1/looper-electrode/reports/";
					else if(summary.getJobUrl().contains("ci.mobile"))
						coverageReportUrl = "http://dfw-obj-torbit-103.storage.cloud.wal-mart.com/swift/v1/looper-mobile/reports/";

					// Bramesh Needs to update the cloud URL for all the looper instance.

				}

				postParam.put("jobUrl", summary.getJobUrl()==null ? summary.getJobUrl() :
						coverageReportUrl+""+ summary.getJobUrl().replaceAll("/job/", "/").split("walmart.com/")[1] +
								"CoverageReport/Automation_Test_Coverage_Report.html");

				postParam.put("host", summary.getHost());
			}

			BaseWebService service = new BaseWebService();
			s_logger.info("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&"
					+ "using report service"
					+ ReportListener.reporterInserstion + postParam);
			if (ReportListener.reporterInserstion
					.equalsIgnoreCase("PortalService"))
				try {
					res = service.invokeRESTPostRequest(
							m_properties.getProperty("insertSummary"),
							header, postParam);
					if (res == null
							|| !res.getResponseBody().contains("Success"))
						insertTestSummaryDB(summary);
				} catch (Exception ele) {
					insertTestSummaryDB(summary);
				}
		}
	}
	
	public void insertTestSummaryDB(TestSummaryInfo summary)
	{
		String sql = "INSERT INTO summary (TestRunID, Host, Environment, Track, ReleaseNumber, Type, StartTime, MinTestsToExecute, JobUrl, AttemptNumber,appName) values (?,?,?,?,?,?,?,?,?,?,?)";
		jdbcTemplateObject.update(sql,
                summary.getTestRunID(), summary.getHost(), summary.getQAEnv(),
                summary.getTrack(), summary.getReleaseNumber(), summary.getType(), summary.getStartTime(),
                summary.getMinTestsToExecute(), summary.getJobUrl(), summary.getAttemptNumber(), summary.getAppName());
		s_logger.info("$$$$$$$$$$$$$ inserting data insert summary" + "      "+ summary.getTestRunID()+ "      "+ summary.getHost()+ "      "+ summary.getQAEnv() + "      "+
				summary.getTrack()+ "      "+ summary.getReleaseNumber()+ "      "+ summary.getType()+ "      "+ summary.getStartTime()+ "      "+
				summary.getMinTestsToExecute()+ "      "+ summary.getJobUrl()+ "      "+ summary.getAttemptNumber()+ "      "+ summary.getAppName());
	}

	@Override
	public void update(TestSummaryInfo summary) {
		s_logger.info("reporterInserstion for$$$$$$$$$$$$$ summary update"
				+ ReportListener.reporterInserstion);
		WebServiceResponse res = new WebServiceResponse();
		if (ReportListener.reporterInserstion.equalsIgnoreCase("DB"))
			updateSummaryDB(summary);
		else {
			s_logger.info("update summary table 1@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
			HashMap<String, String> header = new HashMap<String, String>();
			HashMap<String, String> postParam = new HashMap<String, String>();
			postParam.put("testRunID", summary.getTestRunID());
			postParam.put("endTime", summary.getEndTime());
			BaseWebService service = new BaseWebService();
			try {
				res = service.invokeRESTPutRequestNew(
						m_properties.getProperty("updateSummary"), header,
						postParam, false);
				if (res == null || !res.getResponseBody().contains("Success"))
					updateSummaryDB(summary);
			} catch (Exception ele) {
				updateSummaryDB(summary);
			}
		}

	}
	
	public void updateSummaryDB(TestSummaryInfo summary){
		String sql = "UPDATE summary" + " set EndTime=? WHERE TestrunID=?";
		jdbcTemplateObject.update(sql, summary.getEndTime(), summary.getTestRunID());
		s_logger.info("$$$$$$$$$$$$$ Update summary" + "      "+ summary.getTestRunID()+ "      "+  summary.getEndTime());
	}

	public int getRunIdCount(String runId){
		String sql = "Select count(*) from summary " + "WHERE TestrunID='"+runId+"'";
		int count= Integer.parseInt(String.valueOf(jdbcTemplateObject.queryForObject(sql,Integer.class)));
		s_logger.info("runIdCOunt for run id "+runId +": "+count);
		return count;
		
	}
	
	public void getMinTestExecuteValue(String runId){
		String sql = "select MinTestsToExecute from summary where TestRunID='"+runId+"'";
		ReportListener.minTestToExecute=Integer.parseInt
				(String.valueOf(jdbcTemplateObject.queryForObject(sql,Integer.class)));
		s_logger.info("minmum test to execute"+ ReportListener.minTestToExecute);
	
	}
	
	@Override
	public void insert(ThreadLocal<TestCaseInfo> info) {
		s_logger.info("reporterInserstion for$$$$$$$$$$$$$ testcase insert"
				+ ReportListener.reporterInserstion);
		WebServiceResponse res = new WebServiceResponse();
		if (ReportListener.reporterInserstion.equalsIgnoreCase("DB")) {
			insertTestCaseDB(info);
		} else {
			HashMap<String, String> header = new HashMap<String, String>();
			HashMap<String, String> postParam = new HashMap<String, String>();
			postParam.put("testRunID", info.get().getTestRunID());
			postParam.put("AreaName", info.get().getAreaName());
			postParam.put("TestCaseId", info.get().getTestCaseId());
			postParam.put("TestCaseSuiteId", info.get().getTestSuiteId());
			postParam.put("testcaseName", info.get().getTestCaseName());
			postParam.put("testcaseStatus", info.get().getStatus().toString());
			postParam.put("scriptLogPath", info.get().getScriptLogDir());
			postParam.put("startTime", info.get().getStartTime());
			postParam.put("attemptNumber", info.get().getAttemptNumber());
			postParam.put("screenshotCaptured", info.get()
					.getIsScreenshotCaptured());
			postParam.put("owner", info.get().getOwner());
			postParam.put("browser", info.get().getBrowser());
			postParam.put("browserMachine", info.get().getBrowserMachine());

			BaseWebService service = new BaseWebService();
			try {
				res = service.invokeRESTPostRequest(
						m_properties.getProperty("insertTestCase"),
						header, postParam);
				if (res == null || !res.getResponseBody().contains("Success"))
					insertTestCaseDB(info);
			} catch (Exception ele) {
				insertTestCaseDB(info);
			}

		}

		s_logger.info("******************** db insert information **************"
				+ "   ,    "
				+ info.get().getTestRunID()
				+ "   ,    "
				+ info.get().getTestCaseId()
				+ "   ,    "
				+ info.get().getTestSuiteId()
				+ "   ,    "
				+ info.get().getTestCaseName()
				+ "   ,    "
				+ info.get().getAttemptNumber()
				+ "   ,    "
				+ info.get().getBrowser()
				+ "   ,    "
				+ info.get().getOwner()
				+ "   ,    "
				+ info.get().getQcLocation()
				+ "   ,    "
				+ info.get().getAreaName()
				+ "   ,    "
				+ info.get().getTicketNumber()
				+ "   ,    "
				+ info.get().getStartTime()
				+ "   ,    "
				+ info.get().getStatus().toString()
				+ "   ,    "
				+ ""
				+ "   ,    " + info.get().getBrowserMachine());
	}

	public void insertTestCaseDB(ThreadLocal<TestCaseInfo> info)
	{
		String sql = "INSERT INTO testcase (TestRunID,TestCaseId, TestCaseSuiteId, TestcaseName, AttemptNumber, Browser, Owner, PathToTestcaseInQualityCenter,AreaName, TicketNo, StartTime, TestcaseStatus, ScriptLogPath, BrowserMachine) VALUES "
				+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		jdbcTemplateObject.update(sql,
                info.get().getTestRunID(), info.get().getTestCaseId(), info.get().getTestSuiteId(),
                info.get().getTestCaseName(), info.get().getAttemptNumber(), info.get().getBrowser(),
                info.get().getOwner(), info.get().getQcLocation(), info.get().getAreaName(),
                info.get().getTicketNumber(), info.get().getStartTime(), info.get().getStatus().toString(), "",
                info.get().getBrowserMachine());
		s_logger.info("$$$$$$$$$$$$$Insert test case" + info.get().getTestRunID()+ "      "+ info.get().getTestCaseId()+ "      "+ info.get().getTestSuiteId()+ "      "+
				info.get().getTestCaseName()+ "      "+ info.get().getAttemptNumber()+ "      "+ info.get().getBrowser()+ "      "+
				info.get().getOwner()+ "      "+ info.get().getQcLocation()+ "      "+ info.get().getAreaName()+ "      "+
				info.get().getTicketNumber()+ "      "+ info.get().getStartTime()+ "      "+ info.get().getStatus().toString()+ "      "+ ""+ "      "+
				info.get().getBrowserMachine());
	}
	
	@Override
	public void update(ThreadLocal<TestCaseInfo> info) {
		s_logger.info("reporterInserstion for$$$$$$$$$$ testcase update" + ReportListener.reporterInserstion);
		WebServiceResponse res=new WebServiceResponse();
		String errorMessage = escapeQuotes(info.get().getExceptionErrorMessage());
		if (isNotEmpty(errorMessage) && errorMessage.length() > ERROR_MESSAGE_MAX_LENGTH) {
			errorMessage = errorMessage.substring(0, ERROR_MESSAGE_MAX_LENGTH);
		}
		String scriptLog=info.get().getScriptLogDir();
		if(scriptLog==null)
			scriptLog="";
	
		if(ReportListener.reporterInserstion.equalsIgnoreCase("DB"))
			updateTestCaseDB(info,errorMessage,scriptLog);
		
		else{	
		       HashMap<String,String> header = new HashMap<String,String>();
               HashMap<String,String> postParam= new HashMap<String,String>();
               postParam.put("startTime", info.get().getStartTime());
               postParam.put("endTime", info.get().getEndTime());
               postParam.put("screenshotCaptured", info.get().getIsScreenshotCaptured());
               postParam.put("testcaseStatus", info.get().getStatus().toString());
               postParam.put("exceptionName", info.get().getExceptionName());
               postParam.put("exceptionErrorMessage", errorMessage);               
               postParam.put("timedOutMessage", info.get().getTimeOutMessage());
               postParam.put("drilldownInfo", info.get().getDrilldownInfo());
               postParam.put("scriptLogPath", scriptLog);
               postParam.put("longLink",info.get().getTicketNumber());
               postParam.put("testRunID", info.get().getTestRunID());
               postParam.put("testcaseName", info.get().getTestCaseName());   
               postParam.put("duration", info.get().getDuration());
               postParam.put("attemptNumber", info.get().getAttemptNumber());
               postParam.put("AreaName", info.get().getAreaName());

		BaseWebService service = new BaseWebService();
		try{
			res=service.invokeRESTPutRequestNew(m_properties.getProperty("updateTestCase"),header,postParam,false);
			 if(res==null|| !res.getResponseBody().contains("Success"))
				 updateTestCaseDB(info,errorMessage,scriptLog);
		}
		catch(Exception ele)
		{
			updateTestCaseDB(info,errorMessage,scriptLog);
		}
}
			
	}

	public void updateTestCaseDB(ThreadLocal<TestCaseInfo> info,String errorMessage, String scriptLog)
	{
		String sql = "UPDATE testcase set StartTime=?,EndTime=?, ScreenshotCaptured=?, TestcaseStatus=?, ExceptionName=?, ExceptionErrorMessage=?, TimedOutMessage=?, DrilldownInfo=?, ScriptLogPath=?, LongLink=?, AttemptNumber=? WHERE TestrunID=? and TestcaseName=?";
		jdbcTemplateObject.update(sql,
                info.get().getStartTime(),info.get().getEndTime(),
                "1",
                info.get().getStatus().toString(), info.get().getExceptionName(), errorMessage,
                info.get().getTimeOutMessage(), info.get().getDrilldownInfo(),
                scriptLog,
                info.get().getTicketNumber(),
                info.get().getAttemptNumber(),info.get().getTestRunID(), info.get().getTestCaseName());
		
		s_logger.info("$$$$$$$$$$$$$ Update test case"+ info.get().getStartTime()+  info.get().getEndTime()+ "      "+ 
				info.get().getIsScreenshotCaptured()+ "      "+
				info.get().getStatus().toString()+ "      "+ info.get().getExceptionName()+ "      "+ errorMessage+ "      "+
				info.get().getTimeOutMessage()+ "      "+ info.get().getDrilldownInfo()+ "      "+ 
				info.get().getScriptLogDir()+ "      "+
				info.get().getTicketNumber()+ "      "+ info.get().getTestRunID()+ "      "+ info.get().getTestCaseName()+ "      "+
			info.get().getAttemptNumber());
	}
	
	private String escapeQuotes(String inputString) {
		if (isNotEmpty(inputString)) {
			int i = 0;
			StringBuilder sb = new StringBuilder();
			while (inputString.indexOf("'", i) > -1) {
				int newIndex = inputString.indexOf("'", i);
				sb.append(inputString, i, newIndex);
				sb.append("\\'");
				i = newIndex + 1;
			}
			if (i < inputString.length()) {
				sb.append(inputString.substring(i));
			}
			return sb.toString();
		}
		return inputString;
	}

	public boolean checkRunExist(String runId) throws Exception {

		String sql = "Select count(*) from summary where testrunid ='" + runId + "'";
		try{
		int count = jdbcTemplateObject.queryForObject(sql,Integer.class);

            return count > 0;
		}catch(Exception ee){
			return false;
		}
	}
	
	public boolean checkTestcaseExist(String runId, String testCaseName) throws Exception {

		String sql = "Select count(*) from testcase where testrunid ='" + runId + "'" +"and testcasename='"+testCaseName+"'";
		try{
		int count = jdbcTemplateObject.queryForObject(sql,Integer.class);

            return count > 0;
		}catch(Exception ee){
			return false;
		}
	}

	public static boolean isNotEmpty(String inputString) {
        return inputString != null && inputString.length() != 0 && !inputString.equalsIgnoreCase("null");
    }

	@Override
	public TestSummaryInfo findSummary(String runId) {
        String sql = "select * from summary where testrunid = '"+runId+"'";
		TestSummaryInfo summary = jdbcTemplateObject.queryForObject(sql,
				new RowMapper<TestSummaryInfo>() {
					@Override
					public TestSummaryInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
						TestSummaryInfo s = new TestSummaryInfo();
						s.setTestRunID(rs.getString("TESTRUNID"));
						s.setHost(rs.getString("HOST"));
						s.setQAEnv(rs.getString("ENVIRONMENT"));
						s.setTrack(rs.getString("TRACK"));
						s.setReleaseNumber(rs.getString("RELEASENUMBER"));
						s.setType(rs.getString("TYPE"));
						s.setStartTime(rs.getString("STARTTIME"));
						s.setEndTime(rs.getString("ENDTIME"));
						s.setMinTestsToExecute(rs.getInt("MINTESTSTOEXECUTE"));
						s.setJobUrl(rs.getString("JOBURL"));
						s.setAttemptNumber(rs.getInt("ATTEMPTNUMBER"));
						return s;
					}
				});
		return summary;
	}

	@Override
	public void updateFullSummary(TestSummaryInfo summary) {
		s_logger.info("reporterInserstion for$$$$$$$$$$ summary update" + ReportListener.reporterInserstion);
		if(ReportListener.reporterInserstion=="DB")
		{
			updateFullSummaryDB(summary);
		}
		
		else{
			WebServiceResponse res=new WebServiceResponse();
			HashMap<String,String> header = new HashMap<String,String>();
			HashMap<String,String> postParam = new HashMap<String,String>();
		//	//	postParam.put("Content-Type", "application/json");
			postParam.put("testRunID", summary.getTestRunID());
			postParam.put("startTime", summary.getStartTime());
			postParam.put("endTime", summary.getEndTime());
			postParam.put("startTime", summary.getStartTime());
			postParam.put("type", summary.getType());
			postParam.put("minTestsToExecute", String.valueOf(summary.getMinTestsToExecute()));
			postParam.put("attemptNumber", summary.getType());
			BaseWebService service = new BaseWebService();
			try{
				res=service.invokeRESTPutRequestNew(m_properties.getProperty("updateSummary"),header,postParam,false);
			 if(res==null || !res.getResponseBody().contains("Success"))
				 updateFullSummaryDB(summary);
		}
		catch(Exception ele)
		{
			updateFullSummaryDB(summary);
		}
	}
				
	}
	

	public void updateMinimumTestToExecute(TestSummaryInfo summary) {
		s_logger.info("reporterInserstion for$$$$$$$$$$ summary miniCout to" );
		 
		int count=0;
		String mintestCase,sql;
		sql = "UPDATE summary set  MinTestsToExecute =? WHERE TestrunID=?";
		try{
			
			count=ReportListener.minTestToExecute;
			s_logger.info(sql+"$$$$$"+count );
			s_logger.info("min Count value "+count );
		}
		catch(Exception ele)
		{
			s_logger.info("min Count ",summary.getMinTestsToExecute());
			s_logger.info(sql+"$$$$$ exception"+count +"//n"+ ele);
		}
//		if(count!=0)
//		{
		jdbcTemplateObject.update(sql,
                count,
                summary.getTestRunID());
	     s_logger.info("update minimum cout  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@" + count);
			
//		}
//		else
//		{
//			sql = "UPDATE summary set MinTestsToExecute =? WHERE TestrunID=?";
//			  jdbcTemplateObject.update(sql,
//		 				new Object[] { summary.getMinTestsToExecute(),
//		 						summary.getTestRunID() });
//		}
	 		
	 		
	 			
	}
	
     public void updateFullSummaryDB(TestSummaryInfo summary)
     {
    	 String sql = "UPDATE summary set Host=?, Environment=?, Track=?, ReleaseNumber=?, Type=?,  EndTime=?, JobUrl=?, comments=?, AttemptNumber =? WHERE TestrunID=?";
 		jdbcTemplateObject.update(sql,
                summary.getHost(), summary.getQAEnv(), summary.getTrack(), summary.getReleaseNumber(),
                summary.getType(),summary.getEndTime(),
                summary.getJobUrl(), summary.getComments(), summary.getAttemptNumber(),
                summary.getTestRunID());
 		s_logger.info("update summary table 2@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
 		s_logger.info("$$$$$$$$$$$$$ 2Update test case"+ summary.getHost()+ "      "+ summary.getQAEnv()+ "      "+ summary.getTrack()+ "      "+ summary.getReleaseNumber()+ "      "+
 				summary.getType()+ "      "+summary.getEndTime()+ "      "+
 				summary.getJobUrl()+ "      "+ summary.getComments()+ "      "+ summary.getAttemptNumber()+ "      "+
 				summary.getTestRunID());
     }
	@Override
	public void updateSummaryStartTime(TestSummaryInfo summary) {
		s_logger.info("reporterInserstion for$$$$$$$$$$ summary update" + ReportListener.reporterInserstion);
		if(ReportListener.reporterInserstion.equalsIgnoreCase("DB"))
		{
			updateSummaryStartTimeDB(summary);
		}
		else{
			
			WebServiceResponse res=new WebServiceResponse();
			HashMap<String,String> header = new HashMap<String,String>();
				HashMap<String,String> postParam = new HashMap<String,String>();
		////	//	postParam.put("Content-Type", "application/json");
			postParam.put("testRunID", summary.getTestRunID());
			//postParam.put("startTime", summary.getStartTime());
				//postParam.put("type", summary.getType());
				//postParam.put("minTestsToExecute", String.valueOf(summary.getMinTestsToExecute()));
			postParam.put("attemptNumber", summary.getType());
				BaseWebService service = new BaseWebService();
				try{
					res=service.invokeRESTPutRequestNew(m_properties.getProperty("updateSummary"),header,postParam,false);
					 if(res==null || !res.getResponseBody().contains("Success"))
						 updateSummaryStartTimeDB(summary);
				}
				catch(Exception ele)
				{
					updateSummaryStartTimeDB(summary);
				}
		}
	}
	
	public void updateSummaryStartTimeDB(TestSummaryInfo summary)
	{

		//String sql = "UPDATE summary set Host=?,  ReleaseNumber=?, Type=?, StartTime=?,  MinTestsToExecute=?, JobUrl=?, AttemptNumber =? WHERE TestrunID=?";
		String sql = "UPDATE summary set Host=?,  ReleaseNumber=?, Type=?, JobUrl=?, AttemptNumber =? WHERE TestrunID=?";
	
		jdbcTemplateObject.update(sql,
                summary.getHost(), summary.getReleaseNumber(), summary.getType(),
                summary.getJobUrl(), summary.getAttemptNumber(),
                summary.getTestRunID());
		s_logger.info("update summary table 3@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		s_logger.info("$$$$$$$$$$$$$ Update test summary"+ summary.getHost()+ "      "+ summary.getReleaseNumber()+ "      "+ summary.getType()+ "      "+ 
				 summary.getJobUrl()+ "      "+ summary.getAttemptNumber()+ "      "+
				summary.getTestRunID() );
		
	}

	@Override
	public void insertSummaryRunId(TestSummaryInfo summary) {
		String sql = "INSERT INTO summary (TestRunID, Environment, Track) values (?,?,?)";
		jdbcTemplateObject.update(sql,
                summary.getTestRunID(), summary.getQAEnv(), summary.getTrack());

	}

	@Override
	public void updateTestCaseReRunDetails(ThreadLocal<TestCaseInfo> info) {
		String sql = "UPDATE testcase set StartTime=?   WHERE TestrunID=? and TestcaseName=? and AttemptNumber=?";
		jdbcTemplateObject.update(sql, info.get().getStartTime(), info.get().getTestRunID(),
                info.get().getTestCaseName(), info.get().getAttemptNumber());

	}
}
