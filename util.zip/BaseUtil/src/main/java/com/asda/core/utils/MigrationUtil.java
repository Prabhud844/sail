package com.asda.core.utils;

import com.asda.core.utils.Utility.ListUtility;
import com.asda.core.utils.Utility.StringUtility;
import com.asda.core.webservice.ParamTokenDelimiter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;

/**
 * Utility methods. 
 * 
 * Mainly used by migrated tests.
 * 
 * @author jkandul
 *
 */
public class MigrationUtil {

	private static final Logger s_logger = LoggerFactory.getLogger(MigrationUtil.class);
	private static final SimpleDateFormat s_smallFormat = new SimpleDateFormat("MM/dd/yyyy");
	private static final SimpleDateFormat s_longFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
	static {
		s_longFormat.setLenient(false);
		s_smallFormat.setLenient(false);
	}
	
	
	/**
	 * Result input is result set map from DB. Key is column name and value is value. 
	 * In case of cursor value is List<Map<String, Object>> where string is the parameter name in function.
	 * 
	 * outputMapping is a Map with key as column name and value as parameter name(s) in function.
	 * 
	 * Result would be a Map with key as function parameter name and value is value from DB.
	 * 
	 * @param result
	 * @param outputMapping
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, String> createOutputMap(Map<String, Object> result, Map<String, List<String>> outputMapping) {
		Map<String, String> convertedResult = new HashMap<String, String>();
		for(Entry<String, List<String>> entry : outputMapping.entrySet()) {
			Object value = result.get(entry.getKey());
			if(value instanceof List) {
				if(((List<Map<String, Object>>)value).size() > 0) {
					for(Entry<String, Object> e : ((List<Map<String, Object>>)value).get(0).entrySet()) {
						convertedResult.put(e.getKey(), convertToString(e.getValue()));
					}
				}
			} else {
				convertedResult.put(entry.getValue().get(0), convertToString(value));
			}
		}
		return convertedResult;
	}

	public static List<String> getList(String... strings) {
		List<String> result = new ArrayList<String>();
		for(String s : strings) {
			result.add(s);
		}
		return result;
	}
	
	private static String convertToString(Object value) {
		return String.valueOf(value);
	}
	
	public static Integer getInteger(String str) {
		if(str!=null) {
			try {
				return Integer.parseInt(StringUtility.trim(str));
			} catch (NumberFormatException e) {
				s_logger.error("Invalid Integer: {}", str);
			}
		}
		return null;
	}
	
	public static Float getFloat(String str) {
		if(str!=null) {
			try {
				return Float.parseFloat(StringUtility.trim(str));
			} catch (NumberFormatException e) {
				s_logger.error("Invalid Float: {}", str);
			}
		}
		return null;
	}
	
	public static BigDecimal getBigDecimal(String str) {
		if(str!=null) {
			try {
				return new BigDecimal(StringUtility.trim(str));
			} catch (NumberFormatException e) {
				s_logger.error("Invalid BigDecimal: {}", str);
			}
		}
		return null;
	}
	
	public static String getString(String str) {
		return str;
	}
	
	public static Boolean getBoolean(String str) {
		return Boolean.parseBoolean(StringUtility.trim(str));
	}

	public static Long getLong(String str) {
		if(str!=null) {
			try {
				return Long.valueOf(StringUtility.trim(str));
			} catch (NumberFormatException e) {
				s_logger.error("Invalid Long: {}", str);
			}
		}
		return null;
	}
	
	public static Date getDate(String str) {
		if(str!=null) {
			try {
				return parseAndGetDate(StringUtility.trim(str));
			} catch (ParseException e) {
				s_logger.error("Invalid Date: {}", str);
			}
		}
		return null;
	}
	
	public static Timestamp getTimestamp(String str) {
		if(str!=null) {
			try {
				return Timestamp.valueOf(StringUtility.trim(str));
			} catch (Exception e) {
				s_logger.error("Invalid Timestamp: {}", str);
			}
		}
		return null;
	}
	
	private static Date parseAndGetDate(String value) throws ParseException {
		Date d = null;
		try {
			d = s_smallFormat.parse(value);
		} catch (ParseException e1) {
			try {
				d = s_longFormat.parse(value);
			} catch (ParseException e) {
				s_logger.info("Invalid value passed for date. Should be in format MM/dd/yyyy or MM/dd/yyyy HH:mm:ss but found with value :"
						+ value);
				throw e;
			}
		}
		return d;
	}
	
	/**
	 * DONOT use this. wait for a specific condition.
	 * 
	 * Wais for 3 sec.
	 * 
	 */
	public static void unconditionalWait() {
		unconditionalWait(3000);
	}

	/**
	 * DONOT use this. wait for a specific condition.
	 * 
	 * @param millis
	 */
	public static void unconditionalWait(long millis) {
		//s_logger.info("Waiting for {} sec", millis/1000);
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			s_logger.error("", e);
		}
	//	s_logger.info("Waiting complete moving to next step.");
	}

	/**
	 * Split string by , and get value at position specified.
	 * 
	 * @param commaSeperatedString
	 * @param pos
	 * @return
	 */
	public static String splitStringByCommaGetValueAsPos(String commaSeperatedString, String pos) {
		Integer position = getInteger(pos);
		List<String> splitList = ListUtility.getList(commaSeperatedString);
		if(splitList.size() >= position) {
			return splitList.get(position - 1);
		}
		return null;
	}
	
	/**
	 * Split string by delimiter and get value at position specified.
	 * 
	 * @param commaSeperatedString
	 * @param pos
	 * @return
	 */
	public static String splitStringByDelimiterGetValueAsPos(String commaSeperatedString, String delimiter, String pos) {
		Integer position = getInteger(pos);
		List<String> splitList = ListUtility.getList(commaSeperatedString, delimiter);
		if(splitList.size() >= position) {
			return splitList.get(position - 1);
		}
		return null;
	}
	
	public static Object getConvertedValue(String value, String toType) {
		if(value == null) {
			s_logger.info("Null value passed");
			return null;
		}
		if(toType.equalsIgnoreCase("LONG")) {
			if(value.contains(",")) {
				return ListUtility.getAsList(value, Long.class);
			}
			return getLong(value);
		} else if (toType.equalsIgnoreCase("Integer")) {
			if(value.contains(",")) {
				return ListUtility.getIntegerList(value);
			}
			return getInteger(value);			
		} else if (toType.equalsIgnoreCase("BOOLEAN")) {
			if(value.contains(",")) {
				return ListUtility.getAsList(value, Boolean.class);
			}
			return getBoolean(value);
		} else if (toType.equalsIgnoreCase("FLOAT")) {
			if(value.contains(",")) {
				return ListUtility.getAsList(value, Float.class);
			}
			return getFloat(value);
		} else if (toType.equalsIgnoreCase("BIGDECIMAL")) {
			if(value.contains(",")) {
				return ListUtility.getAsList(value, BigDecimal.class);
			}
			return getBigDecimal(value);
		} else if (toType.equalsIgnoreCase("STRING")) {
			if(value.contains(",")) {
				return ListUtility.getList(value);
			}
			return value;
		} else if (toType.equalsIgnoreCase("DATE")) {
			try {
				if(value.contains(",")) {
					List<String> stList = ListUtility.getList(value);
					List<Date> dtlist = new ArrayList<Date>();
					for(String dtString : stList) {
						dtlist.add(parseAndGetDate(dtString));
					}
					return dtlist;
				}
				return parseAndGetDate(value);
			} catch (ParseException e) {
				s_logger.info("Invalid value passed for date value: {}" + value);
			}
		} else if (toType.equalsIgnoreCase("TIMESTAMP")) {
			try {
				return Timestamp.valueOf(value);
			} catch (IllegalArgumentException e) {
				s_logger.info("Invalid value passed for timestamp. Should be in format yyyy-MM-dd hh:mm:ss[.f...]. but with value: {}" + value);
				throw e;
			}
		}
		return value; // Default return string.
	}
	
	/**
	 * This is a wrapper method for Migration Code which will call XMLJSONConverter.java to convert xml to json.
	 * 
	 * @param XMLStr
	 * @return Json 
	 */
	public  static String converterXmlToJson(String XMLStr){
		XMLJSONConvertors convertors  = new XMLJSONConvertors();
		String jsonVar ="";
		try {
			jsonVar = convertors.XMLToJsonConverter(XMLStr);
		} catch (Exception e) {
			new RuntimeException("Unable to convert XML to Json");
		}
		return jsonVar;
	} 
	
	/**
	 * This is a wrapper method for Migration Code which will call XMLJSONConverter.java to convert json to xml.
	 *  
	 * @param jsonStr
	 * @return xml
	 */
	public static String convertJsonToXml(String jsonStr){
		XMLJSONConvertors convertors  = new XMLJSONConvertors();
		String xml ="";
		try {
			xml = convertors.JSONToXMLConverter(jsonStr);
		} catch (Exception e) {
			new RuntimeException("unable to convert JSON to xml");
		}
		return xml;
	}
	
	/**
	 * Returns list of values based on the range.
	 * If range is "1-5" returns List(5) with values 1 to 5.
	 * 
	 * @param rangeString
	 * @return
	 */
	public static List<String> getListFromRange(String rangeString) {
		String[] ranges = rangeString.split("-");
		if(ranges.length != 2) {
			throw new RuntimeException("Invalid data provided for range: " + rangeString);
		}
		int startRange = Integer.valueOf(ranges[0]);
		int endRange = Integer.valueOf(ranges[1]);
		List<String> rangeValues = new ArrayList<String>();
		for(int i = startRange; i <= endRange; i++) {
			rangeValues.add(String.valueOf(i));
		}
		return rangeValues;
	}

	/**
	 * Replace dynamic place holders in locators with values.
	 * 
	 * Checks if values have range string and would add that many locators.
	 * 
	 * @param locator
	 * @param dynamicValues
	 * @return
	 */
	public static List<String> getLocatorsForIndexedValues(String locator, Map<String, String> dynamicValues) {
		List<String> placeHolders = ParamTokenDelimiter.getVariables(locator, ParamTokenDelimiter.DEFAULT_TOKEN_DELIMITER);
		List<String> locators = new ArrayList<String>();
		
		// Create a map of locator token and actual value.
		Map<String, String> xpathTokenValueMap = new HashMap<String, String>();
		for(String token : placeHolders) {
			String value = dynamicValues.get(token);
			xpathTokenValueMap.put(token, value);
		}
		
		// Look at the value and replace it in all locators.
		for(Entry<String, String> keyValue : xpathTokenValueMap.entrySet()) {
			String key = keyValue.getKey();
			String value = keyValue.getValue();
			if(value.contains("-")) {
				List<String> rangeValues = getListFromRange(value);
				List<String> newXpathList = new ArrayList<String>();
				for(String rangeVal : rangeValues) {
					for(int i = 0; i<locators.size(); i++) {
						String xp = locators.get(i).replaceAll("\\{" + key + "\\}", rangeVal);
						newXpathList.add(xp);
					}	
				}
				locators = newXpathList;
			} else {
				for(int i = 0; i<locators.size(); i++) {
					String valueAfterEscapeRegex = StringUtility.escapeRegex(value);
					String xp = locators.get(i).replaceAll("\\{" + key + "\\}", valueAfterEscapeRegex);
					locators.set(i, xp);
				}
			}
		}
		return locators;
	}

}
