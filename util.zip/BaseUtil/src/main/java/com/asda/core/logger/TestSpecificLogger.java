package com.asda.core.logger;

import org.apache.log4j.FileAppender;
import org.apache.log4j.MDC;
import org.apache.log4j.spi.LoggingEvent;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * This is an extension of FileAppender to redirect the log statements to a separate file per test.
 * 
 * It uses the data from MDC to identify the file to be redirected to.
 * 
 * @author jkandul
 * 
 */
public class TestSpecificLogger extends FileAppender {
	private String basePath;
	private String specificPath;
	private String logFileName;
	private final Map<String, FileAppender> map = new HashMap<String, FileAppender>();

	@Override
	public synchronized void doAppend(LoggingEvent event) {
		String basePath = (String) MDC.get(getBasePath());
		String specificPath = (String) MDC.get(getSpecificPath());

		if (basePath == null || logFileName == null) {
			super.doAppend(event);
			return;
		}
		String key = null;
		if(specificPath==null) {
			key = "default";
		} else {
			key = specificPath;
		}
		if (!map.containsKey(key)) {
			StringBuilder sb = new StringBuilder();
			sb.append(basePath);
			if (!(basePath.endsWith("/") || basePath.endsWith("\\"))) {
				sb.append("/");
			}
			if(specificPath !=null) {
				sb.append(specificPath).append("/");
			}
			sb.append(logFileName);
			try {
				FileAppender fileAppender = new FileAppender(layout, sb.toString());
				map.put(key, fileAppender);
			} catch (IOException e) {
			}
		}
		FileAppender ap = map.get(key);
		if (ap != null) {
			ap.doAppend(event);
		} else {
			super.append(event);
		}
	}

	@Override
	public void close() {
		for (Iterator<FileAppender> iter = map.values().iterator(); iter.hasNext();) {
			FileAppender appender = iter.next();
			appender.close();
		}
		super.close();
	}

	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}

	public String getBasePath() {
		return basePath;
	}

	public void setSpecificPath(String specificPath) {
		this.specificPath = specificPath;
	}

	public String getSpecificPath() {
		return specificPath;
	}

	public void setLogFileName(String logFileName) {
		this.logFileName = logFileName;
	}

	public String getLogFileName() {
		return logFileName;
	}
}