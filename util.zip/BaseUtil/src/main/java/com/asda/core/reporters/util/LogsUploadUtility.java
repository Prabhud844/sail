package com.asda.core.reporters.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.googlecode.sardine.Sardine;
import com.googlecode.sardine.SardineFactory;
import com.googlecode.sardine.util.SardineException;

/**
 * @author dneela
 *
 */
public class LogsUploadUtility {

	private static final LogsUploadUtility s_instance = new LogsUploadUtility();
	private static final Logger s_logger = LoggerFactory.getLogger(LogsUploadUtility.class);
	private static Properties m_properties;

	private static final SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
	private static final SimpleDateFormat monthFormat = new SimpleDateFormat("MM");
	private static final SimpleDateFormat dayFormat = new SimpleDateFormat("dd");

	private LogsUploadUtility() {
		try {
			m_properties = new Properties();
			m_properties.load(getClass().getClassLoader().getResourceAsStream("remotefileserver.properties"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			s_logger.error("File Not found", e);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			s_logger.error("Unable to read properties file.", e);
		}
	}

	public static LogsUploadUtility getInstance() {
		return s_instance;
	}

	public void fireAzureService(String filename, String remotePath	, byte[] data, boolean isSnapshot) {
		
		String baseUrl = m_properties.getProperty("logupload.posturl");
		HttpClient httpclient = HttpClients.createDefault();
		org.json.JSONObject json = new org.json.JSONObject();

		if(!isSnapshot) {
			baseUrl = baseUrl.concat("/azure/uploadLogs/");
			String str_logs = new String(data);
			json.put("path", remotePath);
			json.put("fileName", filename);
			json.put("logs", str_logs);
		} else {
			baseUrl = baseUrl.concat("/azure/uploadScreenshot/");			
			json.put("path", remotePath);
			json.put("screenShot", data);			
		}
		
		try {
			
			String JSON_STRING = json.toString();
			HttpPost httppost = new HttpPost(baseUrl);
			httppost.setEntity(new StringEntity(JSON_STRING, ContentType.APPLICATION_JSON));
			 HttpResponse response = httpclient.execute(httppost);
			 String responseString = new BasicResponseHandler().handleResponse(response);

			 if(!isSnapshot) {
				 s_logger.info("Azure Logs upload service response is " + responseString);
			 }else {
				 s_logger.info("Azure Screenshot upload service response is " +responseString);
			 }
			
		} catch (Exception e) {
			s_logger.info(e.getMessage());
			e.printStackTrace();
		}
		
	}

	
	public String uploadFile(String fileName, String url, byte[] fileInBytes, boolean isScreenshot) throws SardineException {
		String fileDir = "";
		String fileUrl = url;
		String baseUrl = m_properties.getProperty("logupload.posturl");

		List<String> dirHierarchy = new ArrayList<String>();
		Date date = new Date();
		dirHierarchy.add(yearFormat.format(date));
		dirHierarchy.add(monthFormat.format(date));
		dirHierarchy.add(dayFormat.format(date));
		dirHierarchy.add(fileUrl);
		String dirPath = getDelimitedString(dirHierarchy, "/");

		fileUrl = dirPath;	

		try {
		fireAzureService(fileName, fileUrl,fileInBytes, isScreenshot);		
		
		} catch (Exception e) {
			System.out.println(e);
			// Fallback to parent folder with out any dates.
//			s_logger.error("Using default folder for uplaoding screenshot", e);
//			fileUrl = baseUrl + fileName;
		}

		//fileUrl = baseUrl + dirPath;
		fileUrl = fileUrl.replace("\\", "/");
		fileDir = fileUrl;
//		fileUrl = fileUrl + "/" + fileName;

//		Sardine sardine = getSardine();
//
//		try {
//			sardine.put(baseUrl, fileInBytes);
//		} catch (SardineException se) {

//		}
		return fileDir;
	}

	/** ----- Below method is unused as we are not using webdav anymore -----
	 * Checks if folder exists or not by checking for default file.
	 * 
	 * If default file is not present folder is created along with default file.
	 * 
	 * @param sardine
	 * @param baseUrl
	 * @param directories
	 * @throws FolderCreationException
	 */
	public void checkAndCreateDirecotry(String directoryPath) throws IOException {
		String baseUrl = m_properties.getProperty("logupload.posturl");
		Sardine sardine = getSardine();
		directoryPath = directoryPath.replace("\\", "/");
		List<String> directories = getList(directoryPath, "/");
		String dirBaseUrl = baseUrl;
		for (String directory : directories) {
			try {
				dirBaseUrl += directory + "/";

				String defaultImageUrl = dirBaseUrl + "1.gif";
				boolean isFileEixist = false;
				try {
					isFileEixist = sardine.exists(defaultImageUrl);
				} catch (IOException e) {
					throw e;
				}
				if (!isFileEixist) {

					sardine.createDirectory(dirBaseUrl);

					byte[] data = { 1 };
					try {
						sardine.put(defaultImageUrl, data);
					} catch (IOException e) {
						throw e;
					}
				}
			} catch (IOException e) {
				s_logger.error("unable to create folder in webdav " + dirBaseUrl);
			}

		}
	}

	private Sardine getSardine() throws SardineException {

		Sardine sardine;

		String remoteUser = LogsUploadUtility.getInstance().getLoadProperties().getProperty("logupload.user");
		String remotePassword = LogsUploadUtility.getInstance().getLoadProperties().getProperty("logupload.password");

		try {

			sardine = SardineFactory.begin(remoteUser, remotePassword);

		} catch (SardineException e) {
			// TODO Auto-generated catch block
			s_logger.error("Cannot Create Sardine Object", e);
			throw e;
		}
		return sardine;
	}

	public boolean isFileExists(String filePath) throws SardineException {
//		Sardine sardine = getSardine();
//		filePath = filePath.replace("\\", "/");
//		return sardine.exists(filePath);
		
		boolean isFileExist = false;
		String baseUrl =  m_properties.getProperty("logupload.posturl").concat("/azure/isFileExist");
		HttpClient httpclient = HttpClients.createDefault();
		org.json.JSONObject json = new org.json.JSONObject();
		json.put("path", filePath);
		
		String JSON_STRING = json.toString();
		HttpPost httppost = new HttpPost(baseUrl);
		httppost.setEntity(new StringEntity(JSON_STRING, ContentType.APPLICATION_JSON));
		HttpResponse response;
		try {
			response = httpclient.execute(httppost);
			 String responseString = new BasicResponseHandler().handleResponse(response);
			s_logger.info(responseString);
			if(response.getStatusLine().getStatusCode() == 200) {
				isFileExist = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			s_logger.info(e.getMessage());
		}
		return isFileExist;
	}

	public Properties getLoadProperties() {
		return m_properties;
	}

	private List<String> getList(String delimitedString, String delimiter) {
		if (isEmpty(delimitedString)) {
			return new ArrayList<String>();
		}
		return Arrays.asList(delimitedString.split(delimiter));
	}

	private boolean isEmpty(String inputString) {
        return inputString == null || inputString.length() == 0 || inputString.equalsIgnoreCase("null");
    }

	public static boolean isEmpty(List list) {
        return list == null || list.size() == 0;
    }

	public static String getDelimitedString(List<String> stringList, String delimiter) {
		if (isEmpty(stringList)) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		Iterator<String> itr = stringList.iterator();
		sb.append(itr.next());
		while (itr.hasNext()) {
			sb.append(delimiter).append(itr.next());
		}
		return sb.toString();
	}
}
