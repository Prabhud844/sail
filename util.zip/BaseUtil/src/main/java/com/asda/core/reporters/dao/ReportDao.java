package com.asda.core.reporters.dao;

import javax.sql.DataSource;

import com.asda.core.reporters.model.TestCaseInfo;
//import com.asda.core.report.model.TestSummaryInfo;
import com.asda.core.reporters.model.TestSummaryInfo;

public interface ReportDao {

	 void setDataSource(DataSource ds);
	 
	 void insert(TestSummaryInfo summary);
	 
	 void update(TestSummaryInfo summary);
	 
	 void insert(ThreadLocal<TestCaseInfo> info);
	 
	 void updateTestCaseReRunDetails(ThreadLocal<TestCaseInfo> info);
	 
	 void update(ThreadLocal<TestCaseInfo> info);
	 
	 TestSummaryInfo findSummary(String runId);

	 void updateFullSummary(TestSummaryInfo summary);
	 
	 void updateSummaryStartTime(TestSummaryInfo summary);
	 
	 void insertSummaryRunId(TestSummaryInfo summary);

}
