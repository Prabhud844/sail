package com.asda.core.enums;
public enum StatusEnum {
	NORUN,
	TIMED_OUT,
	BLOCKED,
	RUNNING,
	PASSED,
	FAILED,
	ERROR,
	PROBLEM
}