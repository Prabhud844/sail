package com.asda.core.reporters.beans;

import java.io.File;
import java.util.Date;

/**
 * Report Bean is used to hold the test case details during execution
 * @author dneela
 * 
 */
public class ReportBean {
	
	private File screenshot;
	private boolean isSuccess;
	private String currentIndex;	
	private String screenshotPath;
	private String logPath;
	private String testCaseDirPath;
	private File logFile;
	private boolean isTestFinished;
	private String browser;	
	private String testCaseName;
	private String testCaseLocation;
	private String testCaseId;
	private String testCaseOwner;
	private String testCaseArea;	
	private String testInvType;
	private Date testStartDate;
	private Date testEndDate;
	private int attemptNumber;
	private boolean resultsUpdatedToDB;
	private String exceptionName = null;
	private String exceptionErrorMessage = null;

	private String startupExceptionName = null;
	private String startupExceptionErrorMessage = null;
	private String browserMachine = "localhost"; // Remote machine where browser is opened.
	private String testCaseSuiteId;

	public String getCurrentIndex() {
		return currentIndex;
	}
	public void setCurrentIndex(String currentIndex) {
		this.currentIndex = currentIndex;
	}
	public File getScreenshot() {
		return screenshot;
	}
	public void setScreenshot(File screenshot) {
		this.screenshot = screenshot;
	}
	public boolean isSuccess() {
		return isSuccess;
	}
	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}
	public String getScreenshotPath() {
		return screenshotPath;
	}
	public void setScreenshotPath(String screenshotPath) {
		this.screenshotPath = screenshotPath;
	}
	public String getLogPath() {
		return logPath;
	}
	public void setLogPath(String logPath) {
		this.logPath = logPath;
	}
	public String getTestCaseDirPath() {
		return testCaseDirPath;
	}
	public void setTestCaseDirPath(String testCaseDirPath) {
		this.testCaseDirPath = testCaseDirPath;
	}
	public File getLogFile() {
		return logFile;
	}
	public void setLogFile(File logFile) {
		this.logFile = logFile;
	}
	public boolean isTestFinished() {
		return isTestFinished;
	}
	public void setTestFinished(boolean isTestFinished) {
		this.isTestFinished = isTestFinished;
	}
	public String getBrowser() {
		return browser;
	}
	public void setBrowser(String browser) {
		this.browser = browser;
	}
	public String getTestCaseName() {
		return testCaseName;
	}
	public void setTestCaseName(String testCaseName) {
		this.testCaseName = testCaseName;
	}
	public String getTestCaseLocation() {
		return testCaseLocation;
	}
	public void setTestCaseLocation(String testCaseLocation) {
		this.testCaseLocation = testCaseLocation;
	}
	public String getTestCaseId() {
		return testCaseId;
	}
	public void setTestCaseId(String testCaseId) {
		this.testCaseId = testCaseId;
	}
	public String getTestCaseOwner() {
		return testCaseOwner;
	}
	public void setTestCaseOwner(String testCaseOwner) {
		this.testCaseOwner = testCaseOwner;
	}
	public String getTestCaseArea() {
		return testCaseArea;
	}
	public void setTestCaseArea(String testCaseArea) {
		this.testCaseArea = testCaseArea;
	}
	public String getTestInvType() {
		return testInvType;
	}
	public void setTestInvType(String testInvType) {
		this.testInvType = testInvType;
	}
	public Date getTestStartDate() {
		return testStartDate;
	}
	public void setTestStartDate(Date testStartDate) {
		this.testStartDate = testStartDate;
	}
	public Date getTestEndDate() {
		return testEndDate;
	}
	public void setTestEndDate(Date testEndDate) {
		this.testEndDate = testEndDate;
	}
	public int getAttemptNumber() {
		return attemptNumber;
	}
	public void setAttemptNumber(int attemptNumber) {
		this.attemptNumber = attemptNumber;
	}
	public boolean isResultsUpdatedToDB() {
		return resultsUpdatedToDB;
	}
	public void setResultsUpdatedToDB(boolean resultsUpdatedToDB) {
		this.resultsUpdatedToDB = resultsUpdatedToDB;
	}
	public String getExceptionName() {
		return exceptionName;
	}
	public void setExceptionName(String exceptionName) {
		this.exceptionName = exceptionName;
	}
	public String getExceptionErrorMessage() {
		return exceptionErrorMessage;
	}
	public void setExceptionErrorMessage(String exceptionErrorMessage) {
		this.exceptionErrorMessage = exceptionErrorMessage;
	}	
	public String getStartupExceptionName() {
		return startupExceptionName;
	}
	public void setStartupExceptionName(String startupExceptionName) {
		this.startupExceptionName = startupExceptionName;
	}
	public String getStartupExceptionErrorMessage() {
		return startupExceptionErrorMessage;
	}
	public void setStartupExceptionErrorMessage(String startupExceptionErrorMessage) {
		this.startupExceptionErrorMessage = startupExceptionErrorMessage;
	}
	public String getBrowserMachine() {
		return browserMachine;
	}
	public void setBrowserMachine(String browserMachine) {
		this.browserMachine = browserMachine;
	}
	public String getTestCaseSuiteId() {
		return testCaseSuiteId;
	}
	public void setTestCaseSuiteId(String testCaseSuiteId) {
		this.testCaseSuiteId = testCaseSuiteId;
	}
}
