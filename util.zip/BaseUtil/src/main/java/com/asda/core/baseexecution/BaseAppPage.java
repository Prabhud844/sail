package com.asda.core.baseexecution;

import com.asda.core.logger.TestLogger;
import com.asda.core.utils.MigrationUtil;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static io.appium.java_client.touch.offset.PointOption.point;

public class BaseAppPage<T extends BaseAppPage<T>> {

    public static int TIME_OUT = 40;

    public static String env = "PQA";

    protected final AppiumDriver driver;

    protected final Logger log = LoggerFactory.getLogger(getClass());

    public boolean isAndroid;

    public boolean isPhone;

    protected WebDriverWait wait = null;
    private static String USER_DIR = System.getProperty("user.name"); // user dir


    public BaseAppPage(final AppiumDriver driver) {


        this.isAndroid = driver.getPlatformName().equalsIgnoreCase("android");
        if (isAndroid) {
            String temp = ((Map<String, String>) driver.getCapabilities().getCapability("desired")).get("deviceName").toLowerCase();
            this.isPhone = driver.manage().window().getSize().getWidth() < 1500 || !StringUtils.containsAny(temp, "tab", "nexus_10_api_27");
            //log.info("is it Phone"+isPhone+"");

        } else {
            String temp = driver.getCapabilities().getCapability("deviceName").toString().toLowerCase();
            this.isPhone = !StringUtils.contains(temp, "ipad");
            //log.info("is it Phone"+isPhone+"");
        }

        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(30)), this);
        this.wait = new WebDriverWait(driver, TIME_OUT);
        this.driver = driver;
    }

    protected AppiumDriver getDriver() {
        return this.driver;
    }

    /**
     * click.
     *
     * @param element MobileElement
     */
    public void click(MobileElement element) {
    if(isAndroid)
        wait.until(ExpectedConditions.elementToBeClickable(element)).click();
    else
    {
        pause(2000);
        element.click();
    }

    }

    /**
     * tap using the elements location.
     *
     * @param element String
     */
    protected void tap(MobileElement element) {

        int startX = element.getLocation().getX();
        int addition = (int) (element.getSize().height * 0.5);
        int endX = startX + addition;
        int startY = element.getLocation().getY();
        new TouchAction(getDriver()).tap(point(endX, startY)).perform();
    }

    /**
     * clickIfExists.
     *
     * @param element element
     */
    public void clickIfExists(MobileElement element) {
        try {

            if (element != null) {
                wait.until(ExpectedConditions.elementToBeClickable(element)).click();

            } else {
                log.info("Element Not found hence ignored.");
            }
        } catch (Exception e) {
            log.info(ExceptionUtils.getStackTrace(e));
        }
    }

    /**
     * type.
     *
     * @param element element
     * @param text    String
     */
    public void type(MobileElement element, String text) {

//        wait.until(ExpectedConditions.elementToBeClickable(element)).sendKeys(text);
        wait.until(ExpectedConditions.elementToBeClickable(element));
        click(element);
        getDriver().getKeyboard();
        element.sendKeys(text);

    }

    /**
     * clear the field.
     *
     * @param element element
     */
    public void clear(MobileElement element) {

        wait.until(ExpectedConditions.elementToBeClickable(element)).clear();

    }

    /**
     * get the text of the given element.
     *
     * @param element element
     */
    public String getText(MobileElement element) {

        if (isAndroid) {
            return element.getText();
        } else {
            String tag = element.getTagName();
            if (tag.equalsIgnoreCase("XCUIElementTypeStaticText") || tag.equalsIgnoreCase("XCUIElementTypeButton")) {
                try{
                    return element.getText();
                }catch (NoSuchElementException nse){
                    return element.getAttribute("label");
                }

            } else {

                return element.findElements(By.xpath(".//XCUIElementTypeStaticText")).get(0).getText();
            }
        }
    }

    /**
     * get the value of the given attribute.
     *
     * @param element  element
     * @param attrName String
     */
    public String getAttribute(MobileElement element, String attrName) {

        return element.getAttribute(attrName);

    }

    public List<String> getTextFromElements(List<MobileElement> elements) {
        List<String> collectionOfText = new ArrayList<>();

        for (MobileElement m : elements) {
            if (isElementVisible(m, 5)) {
                collectionOfText.add(getText(m));
            }
        }

        return collectionOfText;
    }

    /**
     * type and then press enter.
     *
     * @param element element
     * @param text    String
     */
    public void typeAndPressEnter(MobileElement element, String text) {

        if (isAndroid) {
            wait.until(ExpectedConditions.elementToBeClickable(element)).sendKeys(text);
            AndroidDriver a = (AndroidDriver) getDriver();
            a.pressKey(new KeyEvent(AndroidKey.ENTER));
        } else {
            try{
                wait.until(ExpectedConditions.elementToBeClickable(element)).sendKeys(text + "\n");
            }catch(WebDriverException wde){
                log.info("Got WebDriverException : {} & {}", wde.getMessage(), wde.getAdditionalInformation());
//                getDriver().getKeyboard();
//                wait.until(ExpectedConditions.elementToBeClickable(element)).sendKeys(text + "\n");
                wde.printStackTrace();
                IOSDriver i = (IOSDriver) getDriver();
                i.getKeyboard().sendKeys(text + "\n");
            }
        }
    }

    /**
     * check ig the given text is visible on the screen.
     *
     * @param expected String
     */
    public boolean isTextVisible(String expected) {

        try {
            String attribute = isAndroid ? "text" : "label";
            return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(translate(@" + attribute + ", 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),\"" + expected.toLowerCase() + "\")]"))) != null;

        } catch (Exception e) {
            return false;
        }
    }

    /**
     * check ig the given text is visible on the screen.
     *
     * @param text String
     */
    public MobileElement getElementWithText(String text) {

        try {
            String attribute = isAndroid ? "text" : "label";
            return getVisibleElement(getBy("xpath", "//*[contains(translate(@" + attribute + ", 'ABCDEFGHIJKLMNOPQRSTUVWXYZ ', 'abcdefghijklmnopqrstuvwxyz'),'" + StringUtils.deleteWhitespace(text.toLowerCase()) + "')]"));

        } catch (Exception e) {
            return null;
        }
    }

    public MobileElement getElementWithTextCaseSensitive(String text) {
        try {
            String attribute = isAndroid ? "text" : "label";
            return getVisibleElement(getBy("xpath", "//*[contains(@" + attribute + ",'" + text + "')]"));
        } catch (Exception e) {
            return null;
        }
    }
    public WebElement getElementFromText(String text) {
        try {
            String attribute = isAndroid ? "text" : "label";
            return driver.findElement(By.xpath("//*[contains(@" + attribute + ",'" + text + "')]"));
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * check ig the given text is visible on the screen.
     *
     * @param expected String
     */
    public boolean isTextVisible(String expected, int TimeOutinSeconds) {
        try {
            String attribute = isAndroid ? "text" : "label";
            return wait.withTimeout(Duration.ofSeconds(TimeOutinSeconds)).
                    until(ExpectedConditions.visibilityOfElementLocated(
                            By.xpath("//*[contains(translate(@" + attribute + ", 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),\""
                                    + expected.toLowerCase() + "\")]"))) != null;

        } catch (Exception e) {
            return false;
        }
    }

    /**
     * get the clickable element
     *
     * @param element MobileElement
     */
    public MobileElement getClickableElement(MobileElement element) {
        MobileElement temp = (MobileElement) wait.until(ExpectedConditions.elementToBeClickable(element));
        return temp;

    }

    /**
     * verify the attribute value
     *
     * @param attrname String
     * @param expected String
     */
    public void verifyAttributeValue(MobileElement element, String attrname, String expected) {
        String actual = getAttribute(element, attrname);
        boolean b = actual.contains(expected) || actual.matches(expected);
        Assert.assertTrue(b, "Expected :" + expected + " Actual :" + actual);
    }

    /**
     * wait for the given number of seconds.
     *
     * @param milliseconds int
     */
    public void pause(int milliseconds) {
        if (!isAndroid) {
            milliseconds = milliseconds * 2;
        }
        try {
            log.info("Waiting for {} seconds", milliseconds / 1000);
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    /**
     * swipeElementTo the given co-ordinates.
     *
     * @param element element
     * @param endX    int
     * @param endY    int
     */
    public void scrollToRelativeLocation(MobileElement element, int endX, int endY) {
        MobileElement temp = null;
        int startX = 0;
        int startY = 0;
        startX = element.getLocation().getX();
        startY = element.getLocation().getY();
        log.info("Swiping to " + startX + ":" + startY + ":" + (startX + endX) + ":" + (startY + endY));
        swipe(startX, startY, startX + endX, startY + endY);
    }

    /**
     * pressEnter.
     */
    public void pressEnter() {
        if (isAndroid) {
            AndroidDriver a = (AndroidDriver) getDriver();
            a.pressKey(new KeyEvent(AndroidKey.ENTER));
        } else {
            getDriver().getKeyboard().pressKey(Keys.ENTER);
        }
    }

    /**
     * pressKeycode . Works only with android OS.
     *
     * @param keyNumber element
     */
    public void pressKeycode(int keyNumber) {
        if (isAndroid) {
            AndroidDriver a = (AndroidDriver) getDriver();
            switch (keyNumber) {
                case 187:
                    a.pressKey(new KeyEvent(AndroidKey.APP_SWITCH));
                case 66:
                    a.pressKey(new KeyEvent(AndroidKey.ENTER));
                case 4:
                    a.pressKey(new KeyEvent(AndroidKey.BACK));
            }
        } else {
            log.info("Not Implemented for ios");
        }
    }

    /**
     * getTestData. To be implemented.
     *
     * @param reference String
     */
    public String getTestData(String reference) {
        Config data = ConfigFactory.parseFile(new File(System.getProperty("user.dir") + "/src/test/resources/mobile/testdata/" + env + ".conf"));
        return data.getString(reference);
    }

    /**
     * scrollDownToElement. To be implemented.
     *
     * @param fromElement element
     */
    public MobileElement scrolltoElement(MobileElement fromElement, MobileElement toelement, String direction) {
        try {
            MobileElement temp = null;

            for (int i = 0; i < 5; i++) {
                temp = getVisibleElement(toelement);
                if (temp == null || !temp.isDisplayed()) {
                    scroll(fromElement, direction);
                } else {
                    break;
                }

            }
            return temp;
        } catch (Exception e) {
            e.printStackTrace();
            return null;

        }

    }
    public void scrolltoElement(int startX,int startY,int endX,int endY,MobileElement toelement) {
        try {
            MobileElement temp = null;

            for (int i = 0; i < 5; i++) {
                temp = getVisibleElement(toelement);
                if (temp == null || !temp.isDisplayed()) {
                    swipe(startX, startY, endX, endY);
                } else {
                    break;
                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public MobileElement scrolltoElement(MobileElement fromElement, MobileElement toelement, String direction, double scrollby) {
        try {
            MobileElement temp = null;

            for (int i = 0; i < 5; i++) {
                temp = getVisibleElement(toelement);
                if (temp == null || !temp.isDisplayed()) {
                    scroll(fromElement, direction, scrollby);
                } else {
                    break;
                }

            }
            return temp;
        } catch (Exception e) {
            e.printStackTrace();
            return null;

        }

    }

    public boolean scroll(MobileElement relatedElement, String direction, double scrollby) {
        if (scrollby <= 0.0d || scrollby >= 1.0d) return scroll(relatedElement, direction);
        try {
            log.info("Scrolling to the By:{} : {}", scrollby, direction);
            Rectangle value = null;
            value = relatedElement.getRect();
            Dimension size = driver.manage().window().getSize();
            int startX = 0, endX = 0, startY = 0, endY = 0;
            switch (direction.toLowerCase()) {
                case "up":
                    startX = endX = value.getX() + value.getWidth() - 1;//(int) (size.width / 2.1);
                    startY = value.getY() + value.getHeight() + 60;//(int) (size.height * 0.21);
                    //startY = startY > size.height ? size.height - 50 :startY;
                    endY = (int) (size.height * scrollby);
                    break;
                case "down":
                    startX = endX = value.getX() + value.getWidth() - 1;//(int) (size.width / 2.1);
                    startY = (int) (size.height * scrollby);
                    endY = value.getY() + value.getHeight() + 60;//(int) (size.height * 0.21);
                    break;
                case "left":
                    startX = value.getX() + value.getWidth() + 30;// (int) (size.width * 0.1);
                    endX = (int) (size.width * scrollby);
                    startY = endY = value.getY() + value.getHeight() - 5;//(int) (size.height / 2.1);
                    break;
                case "right":
                    startX = (int) (size.width * scrollby);
                    endX = value.getX() + value.getWidth() + 30;//(int) (size.width * 0.1);
                    startY = endY = value.getY() + value.getHeight() - 5;//(int) (size.height / 2.1);
                    break;
            }

            log.info("Swiping to " + startX + ":" + startY + ":" + endX + ":" + endY);
            swipe(startX, startY, endX, endY);

        } catch (Exception e) {
            log.info("Scroll failed : {}", e.getMessage());
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean scroll(MobileElement relatedElement, String direction) {

        try {
            log.info("Scrolling to the : {}", direction);
            Rectangle value = null;
            value = relatedElement.getRect();
            Dimension size = driver.manage().window().getSize();
            int startX = 0, endX = 0, startY = 0, endY = 0;
/*            switch (direction.toLowerCase()) {
                case "up":
                    startX = endX = value.getX();//(int) (size.width / 2.1);
                    startY = (int) (size.height * 0.21);
                    endY = (int) (size.height * 0.8);
                    break;
                case "down":
                    startX = endX = value.getX();//(int) (size.width / 2.1);
                    startY = (int) (size.height * 0.8);
                    endY = (int) (size.height * 0.21);
                    break;
                case "left":
                    startX = value.getX()+value.getWidth()+5;// (int) (size.width * 0.1);
                    endX = (int) (size.width * 0.9);
                    startY = endY = value.getY();//(int) (size.height / 2.1);
                    break;
                case "right":
                    startX = (int) (size.width * 0.9);
                    endX = (int) (size.width * 0.1);
                    startY = endY = value.getY();//(int) (size.height / 2.1);
                    break;
            }*/

            switch (direction.toLowerCase()) {
                case "up":
                    startX = endX = value.getX() + value.getWidth() - 1;//(int) (size.width / 2.1);
                    startY = value.getY() + value.getHeight() + 60;//(int) (size.height * 0.21);
                    endY = (int) (size.height * 0.8);
                    break;
                case "down":
                    startX = endX = value.getX() + value.getWidth() - 1;//(int) (size.width / 2.1);
                    startY = (int) (size.height * 0.8);
                    endY = value.getY() + value.getHeight() + 60;//(int) (size.height * 0.21);
                    break;
                case "left":
                    startX = value.getX() + value.getWidth() + 30;// (int) (size.width * 0.1);
                    endX = (int) (size.width * 0.8);
                    startY = endY = value.getY() + value.getHeight() - 5;//(int) (size.height / 2.1);
                    break;
                case "right":
                    startX = (int) (size.width * 0.8);
                    endX = value.getX() + value.getWidth() + 30;//(int) (size.width * 0.1);
                    startY = endY = value.getY() + value.getHeight() - 5;//(int) (size.height / 2.1);
                    break;
            }

            log.info("Swiping to " + startX + ":" + startY + ":" + endX + ":" + endY);
            swipe(startX, startY, endX, endY);

        } catch (Exception e) {
            log.info("Scroll failed : {}", e.getMessage());
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean scrollToText(String text) {
        try {
            if (isAndroid) {
                ((AndroidDriver) getDriver()).findElementByAndroidUIAutomator("new UiScrollable("
                        + "new UiSelector().scrollable(true)).scrollIntoView("
                        + "new UiSelector().textContains(\"" + text + "\"));");
            } else {
                JavascriptExecutor js = driver;
                HashMap scrollObject = new HashMap<>();
                scrollObject.put("predicateString", "value == '" + text + "'");
                js.executeScript("mobile: scroll", scrollObject);

               /* RemoteWebElement parent = (RemoteWebElement) driver.findElement(By.className("XCUIElementTypeTable")

                ); //identifying the parent Table
                String parentID = parent.getId();
                HashMap<String, String> scrollObject = new HashMap<String, String>();
                scrollObject.put("element", parentID);

// Use the predicate that provides the value of the label attribute

                scrollObject.put("predicateString", "label == '" + text + "'");
                driver.executeScript("mobile:scroll", scrollObject);  // scroll to the target element*/
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }

    public void scrollToTextIniOS(String text) {
        JavascriptExecutor js = driver;
        HashMap scrollObject = new HashMap<>();
        scrollObject.put("predicateString", "value == '" + text + "'");
        js.executeScript("mobile: scroll", scrollObject);
    }

    /**
     * Scroll to a given element by element
     * @param element WebElement
     */
    public void ScrollToElementByElement(WebElement element) {
        HashMap scrollObject = new HashMap();
        scrollObject.put("predicateString", "value == '" + element + "'");
        scrollObject.put("direction", "down");
        driver.executeScript("mobile:scroll", scrollObject);
    }

    public boolean scrollToText(MobileElement fromElement, String text, String direction) {
        try {

            for (int i = 0; i < 10; i++) {
                //int time = isAndroid?5:15;
                if (isTextVisible(text, 5)) {
                    return true;
                }
                scroll(fromElement, direction);

            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }

    public boolean scrollToText(MobileElement fromElement, String text, String direction, double scrollby) {
        try {

            for (int i = 0; i < 10; i++) {
                //int time = isAndroid?5:15;
                if (isTextVisible(text, 5)) {
                    return true;
                }
                scroll(fromElement, direction, scrollby);

            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }

    public boolean scrollToTextWithPagination(MobileElement fromElement, String text, String direction, double scrollby) {
        try {

            for (int i = 0; i < 10; i++) {
                //int time = isAndroid?5:15;
                if (isTextVisible(text, 5)) {
                    return true;
                }
                scroll(fromElement, direction, scrollby);
                MigrationUtil.unconditionalWait(5000);
            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }

    public boolean scrollBetweenElementsToFindText(MobileElement fromElement, MobileElement toElement, String text) {
        try {

            int startX = toElement.getLocation().getX() + toElement.getSize().getWidth();
            int startY = toElement.getLocation().getY() + toElement.getSize().getHeight();
            int endX = fromElement.getLocation().getX() + toElement.getSize().getWidth();
            int endY = fromElement.getLocation().getY() + toElement.getSize().getHeight();

            for (int i = 0; i < 10; i++) {
                //int time = isAndroid?5:15;
                if (isTextVisible(text, 5)) {
                    return true;
                }
                swipe(startX, startY, endX, endY);

            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }

    public boolean scrollRelativelyToFindText(MobileElement fromElement, int relX, int relY, String text) {
        try {


            int endX = fromElement.getLocation().getX() + fromElement.getSize().getWidth();
            int endY = fromElement.getLocation().getY() + fromElement.getSize().getHeight();
            int startX = endX + relX;
            int startY = endY + relY;

            for (int i = 0; i < 10; i++) {
                //int time = isAndroid?5:15;
                if (isTextVisible(text, 5)) {
                    return true;
                }
                swipe(startX, startY, endX, endY);

            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }

    /**
     * swipe the given co-ordinates.
     *
     * @param fromX int
     * @param fromY int
     * @param toX   int
     * @param toY   int
     */
    public void swipe(int fromX, int fromY, int toX, int toY) {
        // final value depends on your app and could be greater
        final int ANIMATION_TIME = 200; // ms
        final int PRESS_TIME = 500; // ms
        TouchAction action = new TouchAction(this.driver);
        action.press(PointOption.point(fromX,fromY))
                .waitAction(new WaitOptions().withDuration(Duration.ofMillis(PRESS_TIME))) //you can change wait durations as per your requirement
                .moveTo(PointOption.point(toX, toY))
                .release()
                .perform();
        // always allow swipe action to complete
        try {
            Thread.sleep(ANIMATION_TIME);
        } catch (InterruptedException e) {
            // ignore
        }
    }

    public void scrollTo(MobileElement element,String direction){
        int counter = 0;
        while (counter < 20 && (!isElementVisible(element, 5))){
            int halfHeight = driver.manage().window().getSize().height / 2;
            int halfWidth = driver.manage().window().getSize().width / 2;
            if(direction.equalsIgnoreCase("down"))
                swipe(halfWidth, halfHeight, halfWidth, 10);
            else if(direction.equalsIgnoreCase("up")) {
                log.info("Swiping to " + halfWidth + ":" + halfHeight );
                swipe(halfWidth, halfHeight, halfWidth, halfHeight*2);
            }
            counter++;
        }

    }

    /*
     *<p> This method helps to swipe on an element in desired direction </p>
     *
     * @param element on which swipe actions needs to be performed
     * @param direction in which swipe action must be performed example : {up,down,left,right}
     *
     * @author deepika
     */
    public void swipe(MobileElement element, String direction) {
        HashMap<String, String> swipeObject = new HashMap<String, String>();
        String elementId = element.getId();
        swipeObject.put("element", elementId);
        swipeObject.put("direction", direction);
        getDriver().executeScript("mobile:swipe", swipeObject);
    }

    /**
     * get the element
     *
     * @param strategy String
     * @param locator  String
     */
    public MobileElement getElement(String strategy, String locator) {
        try {
            MobileElement temp = (MobileElement) wait.until(ExpectedConditions.presenceOfElementLocated(getBy(strategy, locator)));
            return temp;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * get the element
     *
     * @param strategy String
     * @param locator  String
     */
    public MobileElement getVisibleElement(String strategy, String locator) {
        try {

            MobileElement temp = (MobileElement) wait.until(ExpectedConditions.visibilityOfElementLocated(getBy(strategy, locator)));
            return temp;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * clickIfExists.
     *
     * @param element MobileElement
     */
    public boolean isElementVisible(MobileElement element, int timeOutInSeconds) {
        try {
            return wait.withTimeout(Duration.ofSeconds(timeOutInSeconds)).
                    until(ExpectedConditions.visibilityOf(element)) != null;

        } catch (Exception e) {
            return false;
        }
    }

    /**
     * get the visible element
     *
     * @param element MobileElement
     */
    public MobileElement getVisibleElement(MobileElement element) {
        try {
            return (MobileElement) wait.
                    until(ExpectedConditions.visibilityOf(element));

        } catch (Exception e) {
            return null;
        }
    }

    /**
     * get the visible element
     *
     * @param by By
     */
    public MobileElement getVisibleElement(By by) {
        try {
            return (MobileElement) wait.until(ExpectedConditions.visibilityOfElementLocated(by));
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * get the By reference.
     *
     * @param strategy String
     * @param locator  String
     */
    private By getBy(String strategy, String locator) {
        List<WebElement> elements = null;
        By by = null;
        try {
            switch (strategy.toLowerCase()) {
                case "id":
                    by = MobileBy.id(locator);
                    break;
                case "accessibility":
                    by = MobileBy.AccessibilityId(locator);
                    break;
                case "name":
                    by = MobileBy.name(locator);
                    break;
                case "xpath":
                    by = MobileBy.xpath(locator);
                    break;
                default:
            }
        } catch (Exception e) {
        }
        return by;
    }

    public List<MobileElement> getElements(String strategy, String locator) {
        try {

            List<MobileElement> temp = getDriver().findElements(strategy, locator);
            return temp;
        } catch (Exception e) {
            return null;
        }
    }

    public void waitAndClick(MobileElement element, int timeOutInSeconds) {
        wait.withTimeout(Duration.ofSeconds(timeOutInSeconds))
                .until(ExpectedConditions.refreshed(
                        ExpectedConditions.elementToBeClickable(element)));
        element.click();
    }

    public boolean validateStringHasInteger(String str){
        String tmpStr="";
        boolean hasInteger=true;
        if(str == null || str.isEmpty()) {
            return false;
        }
        for(char c:str.toCharArray()){
            if(Character.isDigit(c)){
                tmpStr+=c;
            }
        }
        if(tmpStr.length()<1){
            hasInteger=false;
        }
        TestLogger.log(
                "This is the value of integer found in title :::"
                        + tmpStr);
        return hasInteger;
    }

    public void killAndReopenAndroidApp(AppiumDriver driver) {
        if(isAndroid) {
            driver.closeApp();
            try{
                driver.runAppInBackground(Duration.ofSeconds(5));
            }catch (Exception e){
                e.printStackTrace();
            }finally{
                driver.activateApp("com.asda.android");
            }
        }
    }

    public void killAndReopeniOSApp(AppiumDriver driver) {
        if(!isAndroid) {
            driver.closeApp();
            try {
                driver.runAppInBackground(Duration.ofSeconds(5));
            }catch(Exception e) {
                e.printStackTrace();
            }finally {
                driver.launchApp();
            }
        }
    }

    /**
     * This method is Android only method
     * @param element
     * @param start_x :: x coordinates to start with
     * @param start_y :: y coordinates to start with
     * @param end_x :: x coordinates to end with
     * @param end_y :: y coordinates to end with
     * @param speed :: speed value
     */
    public void swipeUpOrDownWithADB(MobileElement element, String start_x, String start_y, String end_x, String end_y,
                                            String speed) {
        try {
            int i = 0;
            boolean status=isElementVisible(element,5);
            while (!status && i < 10) {
                adbScroller(start_x, start_y, end_x, end_y, speed);
                status=isElementVisible(element,5);
                if (status) {
                    break;
                }
                i++;
            }
            if (!status) {
                Assert.fail("element still not found after" + i + "attempts");
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    // This method is Android only method
    public static void adbScroller(String start_x, String start_y, String end_x, String end_y, String speed)
            throws IOException {
        String ADB_COMMAND[] = new String[] { "/Users/" + USER_DIR + "/Library/Android/sdk/platform-tools/adb", "shell",
                "input", "swipe", start_x, start_y, end_x, end_y, speed };
        Runtime.getRuntime().exec(ADB_COMMAND);
    }

    //this method will be used to use dynamic xpaths in page factory model
    public MobileElement prepareMobileElementWithDynamicXpath(String xpathValue,String substitutionValue) {
        return (MobileElement) wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathValue.replace("valueToReplace", substitutionValue))));
    }


}
