package com.asda.core.concurrent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.*;

/**
 * Single Thread executor returns the value from run method if successful otherwise null.
 * 
 * To handle the exceptions yourself or to get notified on exceptions override the onAnyException, onTimeoutException, onExecutionException methods.
 * 
 * @author jkandul
 *
 */
public abstract class SingleThreadExecutor<T> implements Callable<T> {

	public static final Logger s_logger = LoggerFactory.getLogger(SingleThreadExecutor.class);
	
	private final String taskName;
	
	public SingleThreadExecutor(String taskName) {
		this.taskName = taskName;
	}
	
	@Override
	public T call() throws Exception {
		return run();
	}
	
	public T execute(long timeOutInSec) {
		return executeInternal(timeOutInSec, false);
	}

	/**
	 * Execute the implementation to return result up to retry attempts.
	 * 
	 * Process will wait for waitTimeBeforeRetry between retry attempts.
	 * 
	 * @param timeOutInSec
	 * @param retryCount
	 * @param waitTimeBeforeRetry
	 * @return
	 */
	public T execute(long timeOutInSec, int retryCount, long waitTimeBeforeRetry) {
		int maxRetryCount = retryCount > 0 ? retryCount : 1;
		for (int retryAttempt = 1; retryAttempt <= maxRetryCount; retryAttempt++) {
			s_logger.info("Executing task {} attempt no: {}", taskName, retryAttempt);
			boolean skipException = (retryAttempt < maxRetryCount);
			T returnValue = executeInternal(timeOutInSec, skipException);
			if(returnValue != null) {
				return returnValue;
			}
			try {
				s_logger.info("Sleeping before next retry.");
				Thread.sleep(waitTimeBeforeRetry * 1000);
				s_logger.info("Sleeping complete, moving to next retry.");
			} catch (InterruptedException e) {
				s_logger.info("Interrupted while sleeping to retry. Continue further");
			}
		}
		return null;
	}

	private T executeInternal(long timeOutInSec, boolean skipException) {
		ExecutorService es = Executors.newSingleThreadExecutor();
		try {
			return es.submit(this).get(timeOutInSec, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			if(!skipException) {
				return onInterruptedException(e);
			}
		} catch (ExecutionException e) {
			if(!skipException) {
				return onExecutionException(e);
			}
		} catch (TimeoutException e) {
			if(!skipException) {
				return onTimeoutException(e);
			}
		}
		return null;
	}

	public T onInterruptedException(InterruptedException e) {
		return onAnyException(e, taskName);
	}

	public T onTimeoutException(TimeoutException e) {
		return onAnyException(e, taskName);
	}

	public T onExecutionException(ExecutionException e) {
		return onAnyException(e, taskName);
	}

	public T onAnyException(Exception e, String taskName) {
		s_logger.error("Task " + taskName + " not completed, found exception:", e);
		return null;
	}
	
	/**
	 * Run and return the status of execution.
	 * 
	 * @return
	 */
	public abstract T run();
	
}
