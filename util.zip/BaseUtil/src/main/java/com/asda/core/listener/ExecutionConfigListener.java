package com.asda.core.listener;

import com.asda.core.baseexecution.ExecutionConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.IExecutionListener;

import java.util.Properties;


/**
 * @author dneela
 * Execution config listener which implements the IExecutionListener
 * Used to override the property values in the coretest
 * 
 */
public class ExecutionConfigListener implements IExecutionListener {
	private static final Logger s_logger = LoggerFactory.getLogger(ExecutionConfigListener.class);
	
	private final Properties trackexecProperties = new Properties();
	
	/**
	 * Executed in the beginning of the execution
	 * Reads the local execution.propeties file and overrides the properties in coretest
	 */
	@Override
	public void onExecutionStart() {
		ExecutionConfig.getInstance();
		
		s_logger.debug("Executing the onExecutionStart method and overriding the properties in executionlocal.properties");	
		try {
			trackexecProperties.load(ExecutionConfigListener.class.getClassLoader().getResourceAsStream("executionlocal.properties"));
			new ExecutionConfig(trackexecProperties);
		} catch (Exception e) {
			s_logger.error("Could not read properties from executionlocal.properties");
			e.printStackTrace();			
		}	
	}

	/**
	 * Executed at the end of the execution
	 */
	@Override
	public void onExecutionFinish() {
				
	}
}
