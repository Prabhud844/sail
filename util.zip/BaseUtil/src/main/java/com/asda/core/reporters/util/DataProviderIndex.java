package com.asda.core.reporters.util;
import org.apache.commons.lang3.StringUtils;

public class DataProviderIndex{
	public int index;
	public String sku_id;
	
	public DataProviderIndex(int index){
		this.index = index;
	}
	public DataProviderIndex(String sku_id){
		this.sku_id = sku_id;
	}

	public int getIndex() {
		return index;
	}
	public String getSkuId() {
		return sku_id;
	}

	public void setIndex(int index) {
		this.index = index;
	}
	
	public void setSkuId(String sku_id) {
		this.sku_id = sku_id;
	}
	
	
	@Override
	public String toString() {
		if(!StringUtils.isEmpty(sku_id)) {
			return "DataSetId: " + sku_id;
		}else {
			return "DataSetId: " + index;
		}	
	}
	
}