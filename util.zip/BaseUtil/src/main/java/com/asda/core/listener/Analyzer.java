package com.asda.core.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestResult;
import org.testng.util.RetryAnalyzerCount;


/**
 * @author dneela
 * 
 */
public class Analyzer extends RetryAnalyzerCount {
	private static final Logger s_logger = LoggerFactory.getLogger(Analyzer.class);
    //private int count = 0;
    
    //ThreadLocal<Integer> count = new ThreadLocal<Integer>();
    
    private static final ThreadLocal<Integer> count = new ThreadLocal<Integer>() {
        protected synchronized Integer initialValue() {
            return new Integer(0);
        }
    };
    
    private final int MAX_COUNT = 1;
    
    public Analyzer() {
        setCount(MAX_COUNT);
    }

    @Override
    public boolean retryMethod(ITestResult result) {
    	
    	int localcount = count.get();
        if ( localcount < MAX_COUNT) {
            System.out.println(Thread.currentThread().getName()+"Error in " + result.getName() + " with status "
                    + result.getStatus() + " Retrying " + count + " times");
            
            s_logger.debug(Thread.currentThread().getName()+"Error in " + result.getName() + " with status "
                    + result.getStatus() + " Retrying " + count + " times");
            
            s_logger.debug("Retrying with Parameters"+ result.getParameters().toString());
            
            count.set(localcount +1);
            return true;
        }
        return false;
    	
        
    }
}
