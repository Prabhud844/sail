package com.asda.core.webservice;

/**
 * Container class for holding Header info.
 * 
 * @author jkandul
 *
 */
public class ResponseHeader {

	private final String name;
	private final String value;

	public ResponseHeader(String name, String value) {
		this.name = name;
		this.value = value;
	}
	
	public String getValue() {
		return value;
	}
	public String getName() {
		return name;
	}
	
	@Override
	public String toString() {
		return "{" + name +":" + value + "}";
	}
	
}
