package com.asda.core.listener;

import com.asda.core.baseexecution.ExecutionConfig;
import com.asda.core.baseexecution.BaseASDABackendTest;
import com.asda.core.baseexecution.BaseFrontEndTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.IAnnotationTransformer;
import org.testng.annotations.ITestAnnotation;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

/**
 * 
 * Sets the time out when added to the listeners list.
 * 
 * Reads configuration from ExecutionConfig for properties FE_TEST_MAX_EXECUTION_TIME and BE_TEST_MAX_EXECUTION_TIME and set to FrontEnd and BackEnd tests respectively.
 * 
 * This change is applied only if the annotation has default timeout. 
 * 
 * @author jkandul
 *
 */
public class TimeoutUpdater implements IAnnotationTransformer {

	private static final String BE_TEST_MAX_EXECUTION_TIME = "BE_TEST_MAX_EXECUTION_TIME";
	private static final String FE_TEST_MAX_EXECUTION_TIME = "FE_TEST_MAX_EXECUTION_TIME";
	private static final Logger s_logger = LoggerFactory.getLogger(TimeoutUpdater.class);
	private static final long DEFAULT_TIMEOUT = 0; 
	
	@SuppressWarnings("rawtypes")
	@Override
	public void transform(ITestAnnotation annotation, Class testClass, Constructor testConstructor, Method testMethod) {
		Class containingClass = getContainingClass(testClass, testConstructor, testMethod);
		long currentTimeout = annotation.getTimeOut();
		
		// Special time out is set do not override.
		if(currentTimeout != DEFAULT_TIMEOUT) {
			return;
		}
		
		if(containingClass == null) {
			s_logger.error("Unable to identify test class.");
		} else if(BaseFrontEndTest.class.isAssignableFrom(containingClass)) {
			updateTimeoutInAnnotation(annotation, FE_TEST_MAX_EXECUTION_TIME, containingClass);
		} else if (BaseASDABackendTest.class.isAssignableFrom(containingClass)) {
			updateTimeoutInAnnotation(annotation, BE_TEST_MAX_EXECUTION_TIME, containingClass);
		} else {
			s_logger.debug("Unknown test class {} timeout is not changed.", containingClass);
		}
		
	}

	/**
	 * Get time out configuration from config file and update annotation with the same.
	 *  
	 * @param annotation
	 * @param key
	 * @param containingClass 
	 */
	@SuppressWarnings("rawtypes")
	private void updateTimeoutInAnnotation(ITestAnnotation annotation, String key, Class containingClass) {
		long maxExecutionTime = ExecutionConfig.getInstance().getLongValue(key, 0) * 1000;
		if(maxExecutionTime > 0) {
			s_logger.debug("Setting time out {} for class {}", maxExecutionTime, containingClass);
			annotation.setTimeOut(maxExecutionTime);
		}
	}

	/**
	 * Return the container class of this annotation (annotation can be for class, constructor or method).
	 * 
	 * @param testClass
	 * @param testConstructor
	 * @param testMethod
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	private Class getContainingClass(Class testClass, Constructor testConstructor, Method testMethod) {
		if(testClass != null) {
			return testClass;
		} else if (testConstructor != null) {
			return testConstructor.getClass();
		} else {
			return testMethod.getDeclaringClass();
		}
	}

}
