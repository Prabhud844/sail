package com.asda.core.baseexecution;

import java.io.File;
import java.lang.reflect.Method;
import java.util.Date;

import com.asda.core.reporters.beans.ReportBean;
import com.asda.core.reporters.beans.ReportThreadLocal;
import com.asda.qa.environment.EnvironmentConfig;
import com.asda.core.reporters.util.DataProviderIndex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;

import com.asda.core.enums.BrowserTypeEnum;
import com.asda.core.annotations.TestInfo;
import com.asda.core.enums.SystemVariableEnum;
import com.asda.core.reporters.FailedSuiteGenerator;
import com.asda.core.reporters.ReportListener;
import com.asda.core.reporters.util.DataProviderIndex;



/**
 * @author dneela
 * 
 */
@Listeners({com.asda.core.listener.ScreenshotHTMLReporter.class,org.uncommons.reportng.JUnitXMLReporter.class,ReportListener.class,FailedSuiteGenerator.class, com.asda.core.listener.CoverageReportListener.class})

public abstract class BaseTest {

	private static final Logger s_logger = LoggerFactory.getLogger(BaseTest.class);
	private static final Logger s_statusLogger = LoggerFactory.getLogger("STATUS_LOGGER");

	@BeforeSuite(alwaysRun=true)
	@Parameters({"test.env"})
	public void initSuite(String env,ITestContext context) throws Exception {
		env = env.toUpperCase();
		System.setProperty("org.uncommons.reportng.escape-output", "false");
		s_logger.info("Setting Output dir [" + Thread.currentThread().getId()+"] " + context.getOutputDirectory());
		env = ReportListener.getValueFromSystemProperties(SystemVariableEnum.TEST_ENV.getSysVarName(), env); // test.env is parameter from suite file and can be passed as jvm arg as well.
		s_logger.info("!!!!!!!!!!!Test environment for this run is : "+ env);
		initEnvironment(env);
		String fqdnURL = System.getProperty("aut.url");
		if(fqdnURL != null && !(fqdnURL.equalsIgnoreCase("null")) && !(fqdnURL.isEmpty())) {
			s_logger.info("FQDN url :: " + fqdnURL);
			EnvironmentConfig.getInstance().setApplicationBaseUrl(System.getProperty("appName"), fqdnURL.trim());
		}
	}

	/**
	 * Initialize the test setting the path where logs should go and set values to update reports dashboard.
	 * 
	 * @param testMethod
	 * @param context
	 * @param browserType
	 * @param methodParams
	 * @throws Exception
	 */
	public void beforeTest(Method testMethod, ITestContext context, BrowserTypeEnum browserType, Object[] methodParams) throws Exception {
		TestInfo methodAnnotation = testMethod.getAnnotation(TestInfo.class);
		
		StringBuilder sb = new StringBuilder();
		sb.append(testMethod.getDeclaringClass() + ":" + testMethod.getName());
		if (methodAnnotation != null) {
			String browserPath = "";
			if (browserType != BrowserTypeEnum.NONE) {
				browserPath = "/" + browserType.getBrowserName();
			}
			String dataSetIndex = ReportListener.getCurrentDataIndex(null, methodParams);
			String dataSetIndexPath = "";
			if(dataSetIndex != null) {
				dataSetIndexPath = String.format("/dataset%s", dataSetIndex);
			}
			String testIdLogPath = methodAnnotation.testId() + browserPath + dataSetIndexPath;
			MDC.put("testCaseId", testIdLogPath);
			s_logger.info("Starting logs for this test: {}", sb);
			s_logger.info("Test id: {} ", methodAnnotation.testId());
			s_logger.info("Test area: {} ", methodAnnotation.testArea());
			s_logger.info("Test priority: {} ", methodAnnotation.priority());
			sb.append(" TestInvType").append(methodAnnotation.testcaseInvType()).append(" :: TestLocation:").append(methodAnnotation.testLocation());
		} else {
			s_logger.info("Starting logs for this test: {}", "Unknown");
			s_statusLogger.info("Test Started {}", "Unknown");
			sb.append("Info not available.");
			MDC.put("testcaseDetails", sb.toString());
		}

		String baseDir = MDC.get("testOutputDir");
		String relativePath = MDC.get("testCaseId");
		StringBuilder logPath = new StringBuilder();
		logPath.append(baseDir);
		if(!(baseDir.endsWith("\\") || baseDir.endsWith("/"))) {
			logPath.append("/");
		}
		logPath.append(relativePath).append("/");
		
		// Initializing the context with test specific information
		TestExecutionContext.getInstance().initializeContext(browserType, logPath.toString(), relativePath);
		
		// Log status in status log file.
		logTestStartStatusInfo(testMethod, methodAnnotation, methodParams);
		
		//Adding Test Case Details to Report Bean
		ReportBean rBean = new ReportBean();
		rBean.setBrowser(browserType.getBrowserName());
		rBean.setTestCaseArea(methodAnnotation.testArea());
		String testcaseName = testMethod.getDeclaringClass().getName()+"_"+testMethod.getName();
		if (browserType != BrowserTypeEnum.NONE) {
			testcaseName += "_"+browserType.getBrowserName();
		}
		rBean.setTestCaseName(testcaseName);
		rBean.setTestCaseOwner(methodAnnotation.testOwner());
		rBean.setTestCaseLocation(methodAnnotation.testLocation());
		rBean.setTestStartDate(new Date());
		rBean.setCurrentIndex(ReportListener.getCurrentDataIndex("1", methodParams));
		rBean.setTestCaseId(methodAnnotation.testId());
		rBean.setTestCaseSuiteId(methodAnnotation.testSuiteId());
		ReportThreadLocal.setReportBean(rBean);
		
	}
	
	/**
	 * Log test start information to status log.
	 * 
	 * @param testMethod
	 * @param methodAnnotation
	 * @param methodParams
	 */
	private void logTestStartStatusInfo(Method testMethod,
			TestInfo methodAnnotation, Object[] methodParams) {
		if (methodAnnotation == null) {
			s_statusLogger.info("Starting test class name: {} - method name: {}", testMethod.getDeclaringClass(), testMethod.getName());
		} else if (methodParams.length > 0
				&& methodParams[methodParams.length - 1] instanceof DataProviderIndex) {
			s_statusLogger.info("Starting test class name: {} - method name: {} - testId: {} - area:{} - datasetid:{}",
							testMethod.getDeclaringClass(),
							testMethod.getName(),
							methodAnnotation.testId(),
							methodAnnotation.testArea(),
							((DataProviderIndex) methodParams[methodParams.length - 1]).getIndex());
		} else {
			s_statusLogger.info("Starting test class name: {} - method name: {} - testId: {} - area:{} ",
							testMethod.getDeclaringClass(),
							testMethod.getName(), methodAnnotation.testId(),
							methodAnnotation.testArea());
		}
	}

	/**
	 * Log test end info to logs.
	 * 
	 * @param testMethod
	 * @param result
	 */
	private void logTestEndStatusInfo(Method testMethod, ITestResult result) {
		Object[] methodParams = result.getParameters();
		TestInfo methodAnnotation = testMethod.getAnnotation(TestInfo.class);
		String resultStatus = getResultStatus(result);
		if (methodAnnotation == null) {
			s_statusLogger.info("Ending test class name: {} - method name: {} - result:{}",
					testMethod.getDeclaringClass(), testMethod.getName(), resultStatus);
		} else if (methodParams.length > 0
				&& methodParams[methodParams.length - 1] instanceof DataProviderIndex) {
			s_statusLogger.info("Ending test class name: {} - method name: {} - testId: {} - area:{} - datasetid:{} - result:{}",
							testMethod.getDeclaringClass(),
							testMethod.getName(),
							methodAnnotation.testId(),
							methodAnnotation.testArea(),
							((DataProviderIndex) methodParams[methodParams.length - 1]).getIndex(), 
							resultStatus);
		} else {
			s_statusLogger.info("Ending test class name: {} - method name: {} - testId: {} - area:{} - result:{}",
							testMethod.getDeclaringClass(),
							testMethod.getName(), methodAnnotation.testId(),
							methodAnnotation.testArea(), resultStatus);
		}
	}
	
	/**
	 * Return the string based on the result status. 
	 * 
	 * @param result
	 * @return
	 */
	private String getResultStatus(ITestResult result) {
		if(result.isSuccess()) {
			return "PASS";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			return "FAIL";
		} else {
			return "SKIP";
		}
	}

	protected void tearDown(ITestResult result, Method testMethod) throws Exception {

		logTestEndStatusInfo(testMethod, result);

		logException(result);
		
		s_logger.info("Complete test on this thread.");		
		
		String relativeLogPath =  TestExecutionContext.getInstance().getRelativeLogPathInSuite();
		String logFolderPath = TestExecutionContext.getInstance().getPathToTestLogs(); 
		
        if(relativeLogPath.indexOf("[") != -1){
            String getSuiteFileName = relativeLogPath.substring(relativeLogPath.indexOf("[")+1, relativeLogPath.indexOf("]"));
            String suiteName = relativeLogPath.substring(relativeLogPath.indexOf("/")+1);
            suiteName = getSuiteFileName+"/"+suiteName;
            relativeLogPath = suiteName;
        }
        
		String remoteLogPath = ReportListener.TEST_RUN_ID +"/"+relativeLogPath;
		
		if(ReportListener.isSecondAttempt()){
			remoteLogPath += "/"+"attempt2";
		}
		
		String logFilePath = logFolderPath+ "testSpecific.log";
		File logFile = new File(logFilePath);
	
		
		//Set the Log file details, test is finished or not, execution status, and current index in current report bean
		ReportBean rBean = ReportThreadLocal.getReportBean();
		rBean.setTestFinished(true);
		rBean.setLogFile(logFile);
		rBean.setLogPath(remoteLogPath);
		rBean.setSuccess(result.isSuccess());
		rBean.setCurrentIndex(ReportListener.getCurrentDataIndex(result));			
		ReportThreadLocal.setReportBean(rBean);
	}

	/**
	 * Log Exception for this test.
	 * 
	 * @param result
	 */
	private void logException(ITestResult result) {
		if(!result.isSuccess()) {
			s_logger.error("Exception during test case execution:", getRealCause(result));
		}
	}

	/**
	 * Return the real exception happened in this test.
	 * @param result
	 * @return
	 */
	protected Throwable getRealCause(ITestResult result) {
		return result.getThrowable();
	}

	protected abstract void initEnvironment(String env);

}
