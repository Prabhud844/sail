package com.asda.core.baseexecution;

import com.asda.core.annotations.TestInfo;
import com.asda.core.database.SpringConfiguration;
import com.asda.core.enums.BrowserTypeEnum;
import com.asda.core.enums.SystemVariableEnum;
import com.asda.core.reporters.FailedSuiteGenerator;
import com.asda.core.reporters.ReportListener;
import com.asda.core.reporters.beans.ReportBean;
import com.asda.core.reporters.beans.ReportThreadLocal;
import com.asda.core.reporters.util.DataProviderIndex;
import com.asda.qa.environment.EnvironmentConfig;
import com.asda.qa.utility.HttpClientAPIUtility;
import com.asda.qa.utility.JiraUtils;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;

@Listeners({com.asda.core.listener.ScreenshotHTMLReporter.class, org.uncommons.reportng.JUnitXMLReporter.class, ReportListener.class, FailedSuiteGenerator.class, com.asda.core.listener.CoverageReportListener.class})

public abstract class BaseMobileTest {
    private  final Logger log = LoggerFactory.getLogger(BaseTest.class);
    private  final Logger s_statusLogger = LoggerFactory.getLogger("STATUS_LOGGER");
    public static HashMap<String, Object> runtimeData;
    protected static Config globalData;
    protected static String environment;
    protected HttpClientAPIUtility api;


    @BeforeSuite(alwaysRun = true)
    @Parameters({"test.env"})
    public void initSuite(String env, ITestContext context) throws Exception {
        runtimeData = new HashMap<String, Object>();
        System.setProperty("org.uncommons.reportng.escape-output", "false");
        log.info("Setting Output dir [" + Thread.currentThread().getId() + "] " + context.getOutputDirectory());
        env = new ReportListener().getValueFromSystemProperties(SystemVariableEnum.TEST_ENV.getSysVarName(), env); // test.env is parameter from suite file and can be passed as jvm arg as well.
        log.info("!!!!!!!!!!!Test environment for this run is" + env);
        environment = env;
        initEnvironment(environment);

        globalData = ConfigFactory.parseFile(new File(System.getProperty("user.dir").replace("/target","") + "/src/test/resources/common/testdata/" + env + ".conf"));
    }

    /**
     * Initialize the test setting the path where logs should go and set values to update reports dashboard.
     *
     * @param testMethod
     * @param context
     * @param browserType
     * @param methodParams
     * @throws Exception
     */
    public void beforeTest(Method testMethod, ITestContext context, BrowserTypeEnum browserType, Object[] methodParams) throws Exception {
        TestInfo methodAnnotation = testMethod.getAnnotation(TestInfo.class);
        String ctxName = context.getName().replaceAll("\\(failed\\)", "");
                   /* if (ctxName.contains("iphone")) {String deviceType = "";
        try {
            ;// ((Map<String, String>) context.getAttribute("testparams")).get("deviceName").toLowerCase();


                deviceType = "iPhone";
            } else if (ctxName.contains("ipad")) {
                deviceType = "iPad";
            } else if (ctxName.contains("tab") || ctxName.contains("nexus_10")) {//|| temp.contains("nexus_10")
                deviceType = "Tab";
            } else {
                deviceType = "Phone";
            }
        }
        catch(Exception e){

        }*/
        StringBuilder sb = new StringBuilder();
        sb.append(testMethod.getDeclaringClass() + ":" + testMethod.getName());
        if (methodAnnotation != null) {
            String browserPath = "";
            if (browserType != BrowserTypeEnum.NONE) {
                browserPath = "/" + browserType.getBrowserName();
            }
            String dataSetIndex = new ReportListener().getCurrentDataIndex(null, methodParams);
            String dataSetIndexPath = "";
            if (dataSetIndex != null) {
                dataSetIndexPath = String.format("/dataset%s", dataSetIndex);
            }
            String testIdLogPath = ctxName+"-"+methodAnnotation.testId() + browserPath + dataSetIndexPath;
            MDC.put("testCaseId", testIdLogPath);
            log.info("Starting logs for this test: {}", sb);
            log.info("Test id: {} ", methodAnnotation.testId());
            log.info("Test area: {} ", methodAnnotation.testArea());
            log.info("Test priority: {} ", methodAnnotation.priority());
            sb.append(" TestInvType").append(methodAnnotation.testcaseInvType()).append(" :: TestLocation:").append(methodAnnotation.testLocation());
        } else {
            log.info("Starting logs for this test: {}", "Unknown");
            s_statusLogger.info("Test Started {}", "Unknown");
            sb.append("Info not available.");
            MDC.put("testcaseDetails", sb.toString());
        }

        String baseDir = MDC.get("testOutputDir");
        String relativePath = MDC.get("testCaseId");//ctxName+"-"+
        StringBuilder logPath = new StringBuilder();
        logPath.append(baseDir);
        if (!(baseDir.endsWith("\\") || baseDir.endsWith("/"))) {
            logPath.append("/");
        }
        logPath.append(relativePath).append("/");

        // Initializing the context with test specific information
        TestExecutionContext.getInstance().initializeContext(browserType, logPath.toString(), relativePath);

        // Log status in status log file.
        logTestStartStatusInfo(testMethod, methodAnnotation, methodParams);

        //Adding Test Case Details to Report Bean
        ReportBean rBean = new ReportBean();
        rBean.setBrowser(browserType.getBrowserName());

        //rBean.setTestCaseArea(methodAnnotation.testArea());
        rBean.setTestCaseArea(methodAnnotation.testArea() + "_" +ctxName );
        String testcaseName = context.getName().replaceAll("\\(failed\\)", "")+"_"+testMethod.getDeclaringClass().getName() + "_" + testMethod.getName();
        if (browserType != BrowserTypeEnum.NONE) {
            testcaseName += "_" + browserType.getBrowserName();
        }
        rBean.setTestCaseName(testcaseName);
        rBean.setTestCaseOwner(methodAnnotation.testOwner());
        rBean.setTestCaseLocation(methodAnnotation.testLocation());
        rBean.setTestStartDate(new Date());
        rBean.setCurrentIndex(new ReportListener().getCurrentDataIndex("1", methodParams));
        rBean.setTestCaseId(methodAnnotation.testId());
        rBean.setTestCaseSuiteId(methodAnnotation.testSuiteId());
        ReportThreadLocal.setReportBean(rBean);

    }

    /**
     * Log test start information to status log.
     *
     * @param testMethod
     * @param methodAnnotation
     * @param methodParams
     */
    private void logTestStartStatusInfo(Method testMethod,
                                        TestInfo methodAnnotation, Object[] methodParams) {
        if (methodAnnotation == null) {
            s_statusLogger.info("Starting test class name: {} - method name: {}", testMethod.getDeclaringClass(), testMethod.getName());
        } else if (methodParams.length > 0
                && methodParams[methodParams.length - 1] instanceof DataProviderIndex) {
            s_statusLogger.info("Starting test class name: {} - method name: {} - testId: {} - area:{} - datasetid:{}",
                    testMethod.getDeclaringClass(),
                    testMethod.getName(),
                    methodAnnotation.testId(),
                    methodAnnotation.testArea(),
                    ((DataProviderIndex) methodParams[methodParams.length - 1]).getIndex());
        } else {
            s_statusLogger.info("Starting test class name: {} - method name: {} - testId: {} - area:{} ",
                    testMethod.getDeclaringClass(),
                    testMethod.getName(), methodAnnotation.testId(),
                    methodAnnotation.testArea());
        }
    }

    /**
     * Log test end info to logs.
     *
     * @param testMethod
     * @param result
     */
    private void logTestEndStatusInfo(Method testMethod, ITestResult result) {
        Object[] methodParams = result.getParameters();
        TestInfo methodAnnotation = testMethod.getAnnotation(TestInfo.class);
        String resultStatus = getResultStatus(result);
        if (methodAnnotation == null) {
            s_statusLogger.info("Ending test class name: {} - method name: {} - result:{}",
                    testMethod.getDeclaringClass(), testMethod.getName(), resultStatus);
        } else if (methodParams.length > 0
                && methodParams[methodParams.length - 1] instanceof DataProviderIndex) {
            s_statusLogger.info("Ending test class name: {} - method name: {} - testId: {} - area:{} - datasetid:{} - result:{}",
                    testMethod.getDeclaringClass(),
                    testMethod.getName(),
                    methodAnnotation.testId(),
                    methodAnnotation.testArea(),
                    ((DataProviderIndex) methodParams[methodParams.length - 1]).getIndex(),
                    resultStatus);
        } else {
            s_statusLogger.info("Ending test class name: {} - method name: {} - testId: {} - area:{} - result:{}",
                    testMethod.getDeclaringClass(),
                    testMethod.getName(), methodAnnotation.testId(),
                    methodAnnotation.testArea(), resultStatus);
        }
    }

    /**
     * Return the string based on the result status.
     *
     * @param result
     * @return
     */
    private String getResultStatus(ITestResult result) {
        if (result.isSuccess()) {
            return "PASS";
        } else if (result.getStatus() == ITestResult.FAILURE) {
            return "FAIL";
        } else {
            return "SKIP";
        }
    }

    protected void tearDown(ITestResult result, Method testMethod) throws Exception {

        logTestEndStatusInfo(testMethod,result);

        logException(result);

        log.info("Complete test on this thread.");

        String relativeLogPath = TestExecutionContext.getInstance().getRelativeLogPathInSuite();
        String logFolderPath = TestExecutionContext.getInstance().getPathToTestLogs();

        if (relativeLogPath.indexOf("[") != -1) {
            String getSuiteFileName = relativeLogPath.substring(relativeLogPath.indexOf("[") + 1, relativeLogPath.indexOf("]"));
            String suiteName = relativeLogPath.substring(relativeLogPath.indexOf("/") + 1);
            suiteName = getSuiteFileName + "/" + suiteName;
            relativeLogPath = suiteName;
        }

        String remoteLogPath = ReportListener.TEST_RUN_ID + "/" + relativeLogPath;

        if (ReportListener.isSecondAttempt()) {
            remoteLogPath += "/" + "attempt2";
        }

        String logFilePath = logFolderPath + "testSpecific.log";
        File logFile = new File(logFilePath);
        //Set the Log file details, test is finished or not, execution status, and current index in current report bean
        ReportBean rBean = ReportThreadLocal.getReportBean();
        rBean.setTestFinished(true);
        rBean.setLogFile(logFile);
        rBean.setLogPath(remoteLogPath);
        rBean.setSuccess(result.isSuccess());
        rBean.setCurrentIndex(new ReportListener().getCurrentDataIndex(result));
        String saucePath = "";
        try {
            saucePath = result.getAttribute("sauceURL").toString();
            if (!saucePath.equals("")) {
                String temp = rBean.getExceptionName() + "\n Sauce Video URL-> \n" + saucePath;
                rBean.setExceptionName(temp);
            }
        } catch (Exception e) {

        }
        ReportThreadLocal.setReportBean(rBean);
    }

    /**
     * Log Exception for this test.
     *
     * @param result
     */
    private void logException(ITestResult result) {
        if (!result.isSuccess()) {
            log.error("Exception during test case execution:", getRealCause(result));
        }
    }

    /**
     * Return the real exception happened in this test.
     *
     * @param result
     * @return
     */
    protected Throwable getRealCause(ITestResult result) {
        return result.getThrowable();
    }

    @BeforeTest(alwaysRun = true)
    public void initTestNGTest(ITestContext test) {


        initializeTest(test);


    }

    protected abstract void initializeTest(ITestContext test);


    @AfterTest(alwaysRun = true)
    public abstract void tearDownTest(ITestContext test);



    protected void initEnvironment(String env) {
        log.info("Initilizing environment {} for tests.", env);
        EnvironmentConfig.initEnvironment(env);
        log.info("Initilizing db environment {} for tests.", env);
        SpringConfiguration.init(env);

    }


    public void upsertJira(ITestResult result, String comments, String assignee) {
        try {
            String methodName;
            int itr = result.getMethod().getCurrentInvocationCount();
            if(itr>1) {
                methodName = result.getMethod().getMethodName() + "_" +itr;
            }
            else{
                methodName = result.getMethod().getMethodName();
            }


            String methodInfo = "*MethodName :*\n" + methodName;
            String testDescription = "*Description :*\n" + result.getMethod().getDescription();
            String envInfo = "*EnvInfo :*\n" + result.getTestContext().getAttribute("Env");
            String consolidatedComment = methodInfo + "\n" + testDescription + "\n " + envInfo + "\n " +comments;
            log.info("Test Summary: " + consolidatedComment);
            JiraUtils ju = new JiraUtils();
            String issue = "ASDAA-13082";//result.getTestContext().getAttribute("jiraId").toString();
            if (issue.isEmpty()) {
                String summary = "Result analysis for " + result.getTestContext().getAttribute("summary");
                String description = "Analyze the failures reported in comments and raise bugs if needed. \n Env Info : "
                        + result.getTestContext().getAttribute("envInfo");
                String epic = result.getTestContext().getAttribute("epicId").toString();
                String project = StringUtils.substringBefore(epic,"-");

                issue = ju.createTask(project, epic, summary, description,assignee);
                result.getTestContext().setAttribute("jiraId", issue);
            }
            ju.addComment(issue, consolidatedComment);

        } catch (Exception e) {
            log.info(ExceptionUtils.getStackTrace(e));
        }
    }
}
