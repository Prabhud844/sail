package com.asda.core.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesReader {
    private final Properties properties;

    public PropertiesReader(String propertyFileName) throws IOException {
        InputStream is = getClass().getClassLoader()
                .getResourceAsStream(propertyFileName);
        this.properties = new Properties();
        this.properties.load(is);
    }

    public String getProperty(String propertyName) {
        return this.properties.getProperty(propertyName);
    }

    public static String getGlobalPOMProperties(String propertyName){
        PropertiesReader reader = null;
        try {
            reader = new PropertiesReader("properties-from-pom.properties");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return reader.getProperty(propertyName);
    }
}