package com.asda.qa.utility;

import java.awt.image.BufferedImage;
import java.awt.image.RasterFormatException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

import javax.imageio.ImageIO;

import org.apache.commons.io.IOUtils;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.googlecode.sardine.Sardine;
import com.googlecode.sardine.SardineFactory;
import com.googlecode.sardine.util.SardineException;
import com.asda.core.reporters.beans.ReportThreadLocal;
import com.asda.core.baseexecution.BaseWebPage;
import com.asda.core.utils.MigrationUtil;
import com.asda.core.reporters.ReportListener;

// Move getDriver code from to BasePage

public class ScreenshotUtil
{
	private static final Logger s_logger = LoggerFactory.getLogger(ScreenshotUtil.class);
	static Properties properties = new Properties();
	static String remoteUser = "";
	static String remotePassword = "";
	static String baseUrl = "";
//	static boolean isBaseLineRun=false;

	private ScreenshotUtil() 
	{
        throw new RuntimeException();
    }
	
	private static boolean checkIfBaselineRun()
	{
		Properties propertiesLocal = new Properties();
	
		try 
		{
			
			propertiesLocal.load(ScreenshotUtil.class.getClassLoader().getResourceAsStream("executionlocal.properties"));
			boolean isBaselineRun = Boolean.parseBoolean(propertiesLocal.getProperty("IS_VISUAL_BASELINE_RUN"));
			
			
			
			return isBaselineRun;
		}
		catch (IOException e)
		{
			s_logger.info("ScreenshotUtil: Failed reading property file");
		}
		catch (Exception e)
		{
			s_logger.info("ScreenshotUtil: Exception e");
		}
		
		return false;
	}
	
	private static Sardine getSardine() throws SardineException
	{
		Sardine sardine;
		
		InputStream inStream;
		
		try 
		{
			inStream = ScreenshotUtil.class.getClassLoader().getResourceAsStream("visualtesting.properties");

			properties.load(inStream);
			remoteUser = properties.getProperty("USERNAME");
			remotePassword = properties.getProperty("PASSWORD");
			
			if (checkIfBaselineRun())
			{
				baseUrl = properties.getProperty("BASELINE_DIRECTORY");
			}
			else
			{
				baseUrl = properties.getProperty("IMAGE_TEST_DIRECTORY");
			}
		}
		catch (IOException e)
		{
			s_logger.info("ScreenshotUtil: Failed reading property file");
		}
			
		try 
		{
			sardine = SardineFactory.begin(remoteUser,remotePassword);
		}
		catch (SardineException e)
		{
			throw e;
		}
		
		return sardine;
	}
	
	/**
	 * Takes a screenshot of element and uploads to the server. This method is used to take screenshots of static pages
	 * where changing the Selenium driver is not necessary. For example, on homepage, you can take screenshot of header
	 * and footer using this method, since the header and footer do not require a Mouse/Action event between screenshots. 
	 * Using this method will help increase performance.
	 * 
	 * @param basePage containing element to take screenshot of
	 * @param elements in Map<Webelement element, String name> to take screenshot of
	 */
	public static void takeScreenshot(BaseWebPage basePage, Map<WebElement, String> elements)
	{
		File file = null;
		String browser = ReportThreadLocal.getReportBean().getBrowser();
		String dataIndex = ReportThreadLocal.getReportBean().getCurrentIndex();

		try
		{	
			MigrationUtil.unconditionalWait(1000);
			s_logger.info("Taking full page screenshot for multiple elements");
			
			// take a single full page screenshot and then use this to crop for local elements that we were sent
			file = basePage.captureScreenshotAndGetFile();	
		}
		catch (Exception e)
		{
			// Only time a full page screenshot can fail is if the QA page failed to load
			e.printStackTrace();
			return;
		}
		
		for (Map.Entry<WebElement, String> entry : elements.entrySet()) 
		{
			WebElement element = entry.getKey();
			String fileName = entry.getValue();
			
			if (element == null || fileName.equals("null") || fileName == null)
			{
				continue;
			}
			
			// got the full page image, now try to crop the image and take screenshot of WebElement
			String imageName = fileName.toLowerCase() + "+" + browser.toLowerCase() + "+" + dataIndex.toLowerCase() + ".png";
			File cropped = cropImageForWebElement(file, element, imageName);
			
			// upload to server
			
			try
			{
				FileInputStream stream;
				byte[] array;	
				stream = new FileInputStream(cropped);
				array = IOUtils.toByteArray(stream);

				uploadScreenshotToServer(basePage.getName(), imageName, array);
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			} 
		}
	}
	
	/**
	 * Takes a screenshot of element and uploads to the server
	 * 
	 * @param basePage containing element to take screenshot of
	 * @param element to take screenshot of
	 * @param imageName corresponding to the baseline image
	 */
	public static void takeScreenshot(BaseWebPage basePage, WebElement element, String imageName)
	{
		// wait for 1 seconds for everything to be loaded correctly
		
		File file = null;
		String browser = ReportThreadLocal.getReportBean().getBrowser();
		String dataIndex = ReportThreadLocal.getReportBean().getCurrentIndex();
		imageName = imageName.toLowerCase() + "+" + browser.toLowerCase() + "+" + dataIndex.toLowerCase() + ".png";
		
		s_logger.info("Taking screenshot for: " +imageName);
	
		try
		{	
			MigrationUtil.unconditionalWait(1000);
			s_logger.info("Taking full page screenshot for: " +imageName);
			file = basePage.captureScreenshotAndGetFile();	
		}
		catch (Exception e)
		{
			// Only time a full page screenshot can fail is if the QA page failed to load
			e.printStackTrace();
			return;
		}
		
		// got the full page image, now try to cropvi  the image and take screenshot of WebElement

		File cropped = cropImageForWebElement(file, element, imageName);
		
		// upload to server
		
		try
		{
			FileInputStream stream;
			byte[] array;	
			stream = new FileInputStream(cropped);
			array = IOUtils.toByteArray(stream);

			uploadScreenshotToServer(basePage.getName(), imageName, array);
		}
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	private static File cropImageForWebElement(File fullPageScreenshot, WebElement element, String imageName)
	{	
		s_logger.info("Cropping full page screenshot for: " +imageName);

		Point p = element.getLocation();
		File destFile = new File(imageName + ".png");
		try
		{
			BufferedImage img = ImageIO.read(fullPageScreenshot);
			
			// getSubImage throws RasterFormatException, use it to help QE/QA debug their visual test case
			BufferedImage dest = img.getSubimage(p.getX(), p.getY(), element.getSize().getWidth(), element.getSize().getHeight());
			ImageIO.write(dest, "png", destFile);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		catch (RasterFormatException e)
		{
			// Means full page screenshot does not contain what we are looking for
			// In this case, we have to upload the full page screenshot so that user can see what went wrong
			destFile = fullPageScreenshot;
			e.printStackTrace();
		}
		
		return destFile;
	}
	
	private static void uploadScreenshotToServer(String trackName, String imageName, byte[] fileInBytes)
	{
		Sardine sardine;
		try 
		{
			sardine = getSardine();
			String sitePath="";

			if(!checkIfBaselineRun()){
				sitePath = checkAndCreateDirectory(ReportListener.TEST_RUN_ID, trackName);
			}else{
				sitePath = checkAndCreateDirectory("", trackName);
			}
			
			if (sitePath == null)
			{
				return;
			}
			
			sardine.put(sitePath+"/"+imageName, fileInBytes);
			s_logger.info("Visual Testing Image uploaded to this path :"+ sitePath + "/"+ imageName);
		} 
		catch (SardineException e) 
		{
			e.printStackTrace();
		}
	}
	
	// by Mukund Goel
	private static String checkAndCreateDirectory(String runId, String trackName) throws SardineException
	{
		boolean doesDirectoryExist = false;
		
		try
		{
			Sardine sardine = getSardine();
			String url = baseUrl+runId;
			doesDirectoryExist = sardine.exists(url);
	
			// create directory if it does not exist
			if(!doesDirectoryExist) 
			{
				sardine.createDirectory(url);
			}
			
			doesDirectoryExist = sardine.exists(url+"/"+trackName);
			
			// create directory if it does not exist
			if(!doesDirectoryExist) 
			{
				sardine.createDirectory(url+"/"+trackName);
			}
			
			String sitePath = url+"/"+trackName;
			
			return sitePath;
		}
		catch (SardineException e)
		{
			e.printStackTrace();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return null;
	}
	
}
