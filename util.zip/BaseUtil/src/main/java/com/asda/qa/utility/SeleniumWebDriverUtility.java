package com.asda.qa.utility;

import com.asda.core.baseexecution.BaseWebPage;
import com.asda.core.baseexecution.ExecutionConfig;
import com.asda.core.enums.FindElementByEnum;
import com.asda.core.utils.MigrationUtil;
import com.google.common.base.Function;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * @author dneela
 * 
 */

public class SeleniumWebDriverUtility {

	private static final Logger s_logger = LoggerFactory.getLogger(SeleniumWebDriverUtility.class);

	private final WebDriver driver;
	private static long PAGE_LOAD_TIMEOUT = 60;
	private static long ELEMENT_WAIT_TIMEOUT = 60;
	private static final long PAGE_LOAD_TIMEOUT_IN_MILLI_SECS;
	private static final long ELEMENT_WAIT_TIMEOUT_IN_MILLI_SECS;

	static {
		PAGE_LOAD_TIMEOUT = ExecutionConfig.getInstance().getLongValue("PAGE_LOAD_TIMEOUT", PAGE_LOAD_TIMEOUT);
		ELEMENT_WAIT_TIMEOUT = ExecutionConfig.getInstance().getLongValue("ELEMENT_WAIT_TIMEOUT", ELEMENT_WAIT_TIMEOUT);
		PAGE_LOAD_TIMEOUT_IN_MILLI_SECS = PAGE_LOAD_TIMEOUT * 1000;
		ELEMENT_WAIT_TIMEOUT_IN_MILLI_SECS = ELEMENT_WAIT_TIMEOUT * 1000;
	}

	public SeleniumWebDriverUtility(WebDriver driverIn) {
		if (driverIn == null) {
			throw new RuntimeException("Invalid browser instance");
		}
		driver = driverIn;
	}

	/**
	 * Wait for page to load completely.
	 * 
	 * @throws InterruptedException
	 */
	public void waitForPageLoad() throws InterruptedException {
		waitForPageLoad(driver);
	}

	/**
	 * Wait for page to load completely.
	 * 
	 * @param driver
	 */
	public static void waitForPageLoad(WebDriver driver) {
		try {
			new WebDriverWait(driver, PAGE_LOAD_TIMEOUT).until(new Function<WebDriver, Boolean>() {
				public Boolean apply(WebDriver input) {
					if (input == null) {
						return false;
					}
					Object resp = ((JavascriptExecutor) input).executeScript("return document.readyState=='complete'");
                    return resp instanceof Boolean && ((Boolean) resp);
                }
				// public boolean apply(@Nullable WebDriver input) {
				// if (input == null) {
				// return false;
				// }
				// Object resp = ((JavascriptExecutor) input)
				// .executeScript("return document.readyState=='complete'");
				// if (resp instanceof Boolean && ((Boolean) resp)) {
				// return true;
				// }
				// return false;
				// }
			});
		} catch (Exception e) {
			s_logger.info("Exception waiting for page to load: {}", e);
		}
	}

	public void clearCookies() {
		driver.manage().deleteAllCookies();
	}

	public void clearCookie(String cookieName) {
		driver.manage().deleteCookieNamed(cookieName);
	}

	public void clearCookie(Cookie cookie) {
		driver.manage().deleteCookie(cookie);
	}

	public boolean isCookiePresent(String cookieName) {
		return driver.manage().getCookieNamed(cookieName).getName() != null;

	}

	public String getCookie(String cookieName) {
		return driver.manage().getCookieNamed(cookieName).getName();
	}

	public void open(String url) {
		driver.get(url);
	}

	public String getPageTitle() {
		return driver.getTitle();
	}

	public String getCurrentUrl() {
		return driver.getCurrentUrl();
	}

	public static String getCurrentUrl(WebDriver dri) {
		return dri.getCurrentUrl();
	}

	public String getPageSource() {
		return driver.getPageSource();
	}

	public void click(FindElementByEnum findElementBy, String locator) {
		WebElement element = findelement(findElementBy, locator);
		element.click();
	}

	public void selectRadioOption(FindElementByEnum findElementBy, String locator) {
		WebElement element = findelement(findElementBy, locator);
		element.click();
	}

	public static void selectDropDownValue(WebElement element, String value) {
		Select droplist = new Select(element);
		droplist.selectByValue(value);
	}

	public static String selectDropDownVisibleValue(WebElement element, String value) {
		Select droplist = new Select(element);
		droplist.selectByVisibleText(value);
		MigrationUtil.unconditionalWait(1000);
		return droplist.getFirstSelectedOption().getText();
	}

	public static String getSelectedValue(WebElement element) {
		Select droplist = new Select(element);
		MigrationUtil.unconditionalWait(1000);
		return droplist.getFirstSelectedOption().getText();
	}

	public static void selectDropDownByIndex(WebElement element, int index) {

		MigrationUtil.unconditionalWait(2000);
		// element.click();
		Select droplist = new Select(element);
		droplist.selectByIndex(index);
		MigrationUtil.unconditionalWait(2000);
	}

	public static String selectDropDownByIndexAndReturnText(WebElement element, int index) {
		MigrationUtil.unconditionalWait(4000);
		Select droplist = new Select(element);
		droplist.selectByIndex(index);
		MigrationUtil.unconditionalWait(4000);
		return droplist.getFirstSelectedOption().getText();
	}

	public static String checkOptionsFromDropDownByIndexAndReturnText(WebElement element, String value) {
		Select droplist = new Select(element);
		int noOfOption = droplist.getOptions().size();
		for (int i = 0; i < noOfOption; i++) {
			MigrationUtil.unconditionalWait(2000);
			selectDropDownByIndex(element, i);
			MigrationUtil.unconditionalWait(2000);
			if (droplist.getFirstSelectedOption().getText().equalsIgnoreCase(value))
				return droplist.getFirstSelectedOption().getText();
		}
		MigrationUtil.unconditionalWait(2000);
		return droplist.getFirstSelectedOption().getText();
	}
	
	public static String checkOptionsFromDropDownAndReturnText(WebElement element, String value) {
		Select droplist = new Select(element);
		List<WebElement> optionValues = droplist.getOptions();
		for (int i = 0; i < droplist.getOptions().size(); i++) {
			MigrationUtil.unconditionalWait(2000);
			if(optionValues.get(i).getText().trim().contains(value))
				return	selectDropDownByIndexAndReturnText(element, i);
		}
		MigrationUtil.unconditionalWait(2000);
		return "";
	}

	public static String checkOptionsFromDropDownByDynamicSelectAndReturnText(WebElement element) {
		Select droplist = new Select(element);
		int noOfOption = droplist.getOptions().size();
		for (int i = 1; i < noOfOption; i++) {
			MigrationUtil.unconditionalWait(2000);
			selectDropDownByIndex(element, i);
			MigrationUtil.unconditionalWait(2000);
			return droplist.getFirstSelectedOption().getText();
		}
		MigrationUtil.unconditionalWait(2000);
		return null;
	}

	public static String getSelectedRecentlyAddedPaymentCardName(WebElement element) {
		Select droplist = new Select(element);
		return droplist.getFirstSelectedOption().getText();
	}

	public static String getTextOfSelectedOption(WebElement element) {
		Select droplist = new Select(element);
		return droplist.getFirstSelectedOption().getText();
	}

	public void check(FindElementByEnum findElementBy, String locator) {
		click(findElementBy, locator);
	}

	public void uncheck(FindElementByEnum findElementBy, String locator) {
		click(findElementBy, locator);
	}

	public void type(FindElementByEnum findElementBy, String locator, String text) {
		WebElement element = findelement(findElementBy, locator);
		element.sendKeys(text);
	}

	public String getText(FindElementByEnum findElementBy, String locator) {
		WebElement element = findelement(findElementBy, locator);
		return element.getText();
	}

	public void clickAndWaitForPageToLoad(FindElementByEnum findElementBy, String locator) throws InterruptedException {
		click(findElementBy, locator);
		waitForPageLoad();
	}

	public boolean isTextPresent(String text) {

		try {
			String locator = "//*[contains(.,'" + text + "')]";
			findelement(FindElementByEnum.XPATH, locator);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	public boolean isTextPresent(String text, long timeOutInMilliSec) {
		try{
			WebDriverWait webDriverWait = new WebDriverWait(driver, timeOutInMilliSec);
			return webDriverWait.until(ExpectedConditions.visibilityOf(findelement(FindElementByEnum.XPATH, "//*[contains(.,'" + text + "')]"))).isDisplayed();
		}catch (Exception ex){
			return false;
		}

	}

	public boolean isElementPresent(FindElementByEnum findElementBy, String locator) {
		try {
            return findelement(findElementBy, locator).isDisplayed();
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	public void selectWindow(String nameOrHandle) {
		driver.switchTo().window(nameOrHandle);
	}

	public void selectFrame(String frameNameOrId) {
		String windowHandle = driver.getWindowHandle();
		driver.switchTo().window(windowHandle);
		driver.switchTo().frame(frameNameOrId);
	}

	public static String selectWindowWithTitle(String winTitle, WebDriver driver) {
		String parentWindowHandle = driver.getWindowHandle(); // save the
																// current
																// window
																// handle.
		WebDriver popup = null;
		for (String winHandle : driver.getWindowHandles()) {
			popup = driver.switchTo().window(winHandle);
			String title = popup.getTitle();
			if (popup.getTitle().contains(winTitle)) {
				parentWindowHandle = winHandle;
				break;
			}

		}
		return parentWindowHandle;
	}

	public void selectParentWindow() {
		driver.switchTo().defaultContent();
	}

	public boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException ex) {
			return false;
		}

	}

	public String getAlert() {
		return driver.switchTo().alert().getText();
	}

	public void acceptAlert() {
		driver.switchTo().alert().accept();
	}

	public void closeAlert() {
		driver.switchTo().alert().dismiss();
	}

	public boolean isElementExist(FindElementByEnum findElementBy, String locator, long timeout) {
		try{
			WebDriverWait webDriverWait = new WebDriverWait(driver, timeout);
			return webDriverWait.until(ExpectedConditions.visibilityOf(findelement(findElementBy,locator))).isDisplayed();
		}catch (Exception ex){
			return false;
		}
	}

	public void doubleClick(FindElementByEnum findElementBy, String locator) {
		WebElement element = findelement(findElementBy, locator);
		Actions action = new Actions(driver);
		action.doubleClick(element);
		action.perform();
	}

	public static void click(WebElement elementIn, WebDriver driver) {
		final WebElement element = elementIn;
		new WebDriverWait(driver, SeleniumWebDriverUtility.ELEMENT_WAIT_TIMEOUT).withTimeout(20, TimeUnit.SECONDS)
				.pollingEvery(5, TimeUnit.MILLISECONDS).ignoring(StaleElementReferenceException.class)
				.ignoring(NoSuchElementException.class)
				// .until(new Predicate<WebDriver>() {
				//
				// @Override
				// public boolean apply(WebDriver arg0) {
				// element.click();
				// return true;
				// }
				// });
				.until(new ExpectedCondition<Boolean>() {
					public Boolean apply(WebDriver webDriver) {
						element.isDisplayed();
						return true;
					}
				});

		element.click();
	}

	public void waitForElementDisplay(WebElement elementIn) {
		final WebElement element = elementIn;
		new WebDriverWait(driver, SeleniumWebDriverUtility.ELEMENT_WAIT_TIMEOUT)
				.until(new ExpectedCondition<Boolean>() {
					public Boolean apply(WebDriver webDriver) {
						return element.isDisplayed();
					}
				});
	}

	public void close() {
		driver.close();
	}

	public void mouseOver(WebElement element) {
		Actions builder = new Actions(driver);
		builder.moveToElement(element).perform();
	}

	public boolean isChecked(WebElement element) {
		return element.isSelected();
	}

	public void refreshPage() {
		driver.navigate().refresh();
	}

	public void browserBack() {
		driver.navigate().back();
	}

	public String getSelectedOption(WebElement element) {
		Select select = new Select(element);
		return select.getFirstSelectedOption().getText();
	}

	public int getSelectedIndex(WebElement element) {
		Select select = new Select(element);
		List<WebElement> elements = select.getOptions();
		int index = 0;
		for (int i = 0; i < elements.size(); i++) {
			if (element.isSelected()) {
				index = i + 1;
			}
		}
		return index;
	}

	public boolean isEditable(WebElement element) {
		return element.isEnabled();
	}

	public Object executeJavaScript(String script) {
		JavascriptExecutor js = null;
		if (driver instanceof JavascriptExecutor) {
			js = (JavascriptExecutor) driver;
		}
		return (js).executeScript(script);
	}
	
	/**
	 * Execute java script.
	 *
	 * @param ele the ele
	 * @param driver the driver
	 */
	public static void executeJavaScript(WebElement ele, WebDriver driver) {
		JavascriptExecutor js = null;
		if (driver instanceof JavascriptExecutor) {
			js = (JavascriptExecutor) driver;
		}
		(js).executeScript("arguments[0].click();", ele);
	}

	public static void clickWebElementJavaScript(WebElement ele, WebDriver driver) {
		JavascriptExecutor js = null;
		if (driver instanceof JavascriptExecutor) {
			js = (JavascriptExecutor) driver;
		}
		(js).executeScript("arguments[0].click();", ele);
	}

	public void windowMaximize() {
		driver.manage().window().maximize();
	}

	public WebElement findelement(FindElementByEnum findElementBy, String locator) {
		WebElement element = null;

		if (findElementBy == FindElementByEnum.ID) {
			element = driver.findElement(By.id(locator));
		} else if (findElementBy == FindElementByEnum.LINKTEXT) {
			element = driver.findElement(By.linkText(locator));
		} else if (findElementBy == FindElementByEnum.PARTIALLINKTEXT) {
			element = driver.findElement(By.partialLinkText(locator));
		} else if (findElementBy == FindElementByEnum.NAME) {
			element = driver.findElement(By.name(locator));
		} else if (findElementBy == FindElementByEnum.TAGNAME) {
			element = driver.findElement(By.tagName(locator));
		} else if (findElementBy == FindElementByEnum.XPATH) {
			element = driver.findElement(By.xpath(locator));
		} else if (findElementBy == FindElementByEnum.CLASSNAME) {
			element = driver.findElement(By.className(locator));
		} else if (findElementBy == FindElementByEnum.CSSSELECTOR) {
			element = driver.findElement(By.cssSelector(locator));
		}

		return element;

	}

	/**
	 * Wait for asynchronous calls on page to complete.
	 * 
	 * @param driver
	 */
	public static void waitForAsyncCallToComplete(WebDriver driver) {
		MigrationUtil.unconditionalWait(1000);
		if (!(driver instanceof JavascriptExecutor)) {
			s_logger.error("Not a javascript executor.");
		}
		final JavascriptExecutor scriptExecutor = (JavascriptExecutor) driver;
		try {
			if ((Boolean) scriptExecutor.executeScript("return !(typeof jQuery === 'undefined')")) {
				long activeThreads = (Long) scriptExecutor.executeScript("return jQuery.active");
				s_logger.info("ActiveThreads: {}", activeThreads);
				if (activeThreads > 0) {
					s_logger.info("Waiting for JQ Req to complete");
					WebDriverWait wait = new WebDriverWait(driver, ELEMENT_WAIT_TIMEOUT);
					wait.until(new ExpectedCondition<Boolean>() {
						public Boolean apply(WebDriver webDriver) {
							return (Boolean) scriptExecutor.executeScript("return jQuery.active == 0");
						}
					});
					s_logger.info("Complete JQ req");
				}
			}
		} catch (Throwable t) {
			s_logger.error("Unable to check Async (JQuery) calls status", t);
		}

		try {
			if ((Boolean) scriptExecutor.executeScript("return !(typeof dojo === 'undefined')")) {
				int activeThreads = (Integer) scriptExecutor
						.executeScript("return dojo.io.XMLHTTPTransport.inFlight.length");
				s_logger.info("ActiveThreads: {}", activeThreads);
				if (activeThreads > 0) {
					s_logger.info("Waiting for DOJO Req to complete");
					WebDriverWait wait = new WebDriverWait(driver, ELEMENT_WAIT_TIMEOUT);
					wait.until(new ExpectedCondition<Boolean>() {

						public Boolean apply(WebDriver webDriver) {
							return (Boolean) scriptExecutor
									.executeScript("return dojo.io.XMLHTTPTransport.inFlight.length == 0");
						}
					});
					s_logger.info("Complete DOJO req");
				}
			}
		} catch (

		Throwable t) {
			s_logger.error("Unable to check Async (JQuery) calls status", t);
		}
	}

	/**
	 * Clicks on a specific element. Checks if element is click able before
	 * performing action.
	 * 
	 * @param locator
	 * @param webDriver
	 */
	public static void click(String locator, WebDriver webDriver) {
		By by = convertToBy(locator);
		s_logger.info("Waiting to see if element is clickable: {}", locator);
		new WebDriverWait(webDriver, ELEMENT_WAIT_TIMEOUT).until(ExpectedConditions.elementToBeClickable(by));
		s_logger.info("Waiting complete. Preforming click.");
		webDriver.findElement(by).click();
		waitForAsyncCallToComplete(webDriver);
	}

	/**
	 * Convert legacy locator to By to use with webDriver.
	 * 
	 * @param locator
	 * @return
	 */
	private static By convertToBy(String locator) {
		By by = null;
		if (locator.startsWith("css=")) {
			by = By.cssSelector(locator.replace("css=", ""));
		} else if (locator.startsWith("name=")) {
			by = By.name(locator.substring("name=".length()));
		} else if (locator.startsWith("id=")) {
			by = By.id(locator.substring("id=".length()));
		} else if (locator.startsWith("link=")) {
			by = By.linkText(locator.substring("link=".length()));
		} else if (locator.startsWith("/")) {
			by = By.xpath(locator);
		} else {
			by = By.id(locator);
		}
		return by;
	}

	/**
	 * mouseOver element identified by xpath.
	 * 
	 * @param webDriver
	 * @param xpath
	 */
	public static void mouseOver(WebDriver webDriver, String xpath) {
		Actions builder = new Actions(webDriver);
		builder.moveToElement(webDriver.findElement(By.xpath(xpath))).perform();
	}

	public static void clickButtons(WebDriver webDriver, List<String> locators) {
		for (String locator : locators) {
			click(locator, webDriver);
		}
	}

	/**
	 * Print the current page url on logs.
	 */
	public static void logCurrentPageUrl(WebDriver driver) {
		s_logger.info("In Page: {}", driver.getCurrentUrl());
	}

	/**
	 * set cookie values
	 * 
	 * @param cookie
	 */
	public void setCookie(Cookie cookie) {
		driver.manage().addCookie(cookie);
		s_logger.info(" Cookie Name : {}, Value : {}, Domain : {}, Path : {}", cookie.getName(), cookie.getValue(),
				cookie.getDomain(), cookie.getPath());
	}

	public static String getFutureDate() throws Exception {
		GregorianCalendar calendar = new GregorianCalendar();
		Date tomorrow;
		SimpleDateFormat dateFormatCN = new SimpleDateFormat("MM-dd-yyyy", Locale.UK);
		calendar.add(Calendar.DAY_OF_MONTH, 15);
		Date nextweek = calendar.getTime();
		String nv = dateFormatCN.format(nextweek).replace("-", "/");

		return nv;
	}

	public static int getDateFormattEEE_DD_MMM_YYYY(String date) throws Exception {
		try {
			s_logger.info("getting date difference");
			GregorianCalendar calendar = new GregorianCalendar();
			GregorianCalendar calendar2 = new GregorianCalendar();
			Date tomorrow;
			SimpleDateFormat dateFormatCN = new SimpleDateFormat("EEE, dd MMM yyyy", Locale.UK);
			SimpleDateFormat dateFormatCN2 = new SimpleDateFormat("EEE, dd MMM yyyy", Locale.UK);
			dateFormatCN2.setTimeZone(TimeZone.getTimeZone("GMT"));
//		calendar.add(Calendar.DAY_OF_MONTH, 0);
			Date date1 = dateFormatCN.parse(date);
			Date date2 = dateFormatCN.parse(dateFormatCN2.format(new Date()));

			// String dateToday=new Date().toString();
			// Date date2=dateFormatCN.parse(dateToday);
			return Days.daysBetween(new LocalDate(date2), new LocalDate(date1.getTime())).getDays();

		} catch (Exception ele) {
			return -1;
		}

	}

	public static String getFutureDate(int noOfDays) throws Exception {
		GregorianCalendar calendar = new GregorianCalendar();
		Date tomorrow;
		SimpleDateFormat dateFormatCN = new SimpleDateFormat("MM-dd-yyyy", Locale.UK);
		calendar.add(Calendar.DAY_OF_MONTH, noOfDays);
		Date nextweek = calendar.getTime();
		String nv = dateFormatCN.format(nextweek).replace("-", "/");

		return nv;
	}

	public static String[] getFutureDateValue() {

		String[] Datelist = new String[5];
		GregorianCalendar calendar = new GregorianCalendar();
		Date tomorrow;
		SimpleDateFormat dateFormatCN = new SimpleDateFormat("MM-dd-yyyy", Locale.UK);
		int noOfdays = 0, days = 7;
		try {
			for (int i = 0; i < 5; i++) {
				if (i == 0)
					noOfdays = days + 1;
				else
					noOfdays = 1;

				calendar.add(Calendar.DAY_OF_MONTH, noOfdays);
				tomorrow = calendar.getTime();
				Datelist[i] = dateFormatCN.format(tomorrow).replace("-", "/");
				//
				// break;

			}
		} catch (Exception ele) {
			return Datelist;
		}

		return Datelist;

	}

	public static String[] getFutureDateValueAfterWeek() {

		String[] Datelist = new String[5];
		GregorianCalendar calendar = new GregorianCalendar();
		Date tomorrow;
		SimpleDateFormat dateFormatCN = new SimpleDateFormat("MM-dd-yyyy", Locale.UK);
		int noOfdays = 0, days = 14;
		try {
			for (int i = 0; i < 5; i++) {
				if (i == 0)
					noOfdays = days + 1;
				else
					noOfdays = 1;

				calendar.add(Calendar.DAY_OF_MONTH, noOfdays);
				tomorrow = calendar.getTime();
				Datelist[i] = dateFormatCN.format(tomorrow).replace("-", "/");
				//
				// break;

			}
		} catch (Exception ele) {
			return Datelist;
		}

		return Datelist;
	}

	public static String[] getDateValue() {
		String currentTime = null;
		String[] Datelist = new String[5];
		GregorianCalendar calendar = new GregorianCalendar();
		java.util.Date now = calendar.getTime();
		java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(now.getTime());
		// currentTime=currentTimestamp.toString().replace(":", "").replace(" ",
		// "").replace("-", "").replace(".", "");
		// currentTime=currentTime.substring(0, 11).toString();
		// currentTime=currentTime.substring(0, 13);
		// to find tomor date
		Date tomorrow;
		SimpleDateFormat dateFormatCN = new SimpleDateFormat("MM-dd-yyyy", Locale.UK);

		for (int i = 0; i < 5; i++) {
			if (i == 0) {
				tomorrow = calendar.getTime();
				Datelist[0] = dateFormatCN.format(tomorrow).replace("-", "/");
				System.out.println(Datelist[0]);
			} else {
				calendar.add(Calendar.DAY_OF_MONTH, 1);
				tomorrow = calendar.getTime();
				Datelist[i] = dateFormatCN.format(tomorrow).replace("-", "/");
				// System.out.println(Datelist[i]);
			}

		}

		return Datelist;

	}

	// public static String getcurrentYear() {
	//
	//
	// Date year=new Date();
	// return year.getYear();
	//
	// }

	public static String getMonthAndYear(boolean previousMonth) {

		Calendar c = new GregorianCalendar();
		c.setTime(new Date());
		SimpleDateFormat sdf = new SimpleDateFormat("MM YYYY");
		if (previousMonth == true) {
			c.add(Calendar.MONTH, -1);
			System.out.println(sdf.format(c.getTime()));
			return sdf.format(c.getTime());
		} else {
			System.out.println(sdf.format(c.getTime())); // NOW
			return sdf.format(c.getTime());
		}
	}

	/**
	 * This method returns JsessionID
	 * 
	 * @return returns the string of cookie followed by its value
	 */
	public static void getJSessionValue(WebDriver webdriver) {
		try {
			String cookie = webdriver.manage().getCookies().toString();
			s_logger.info("Cookie value including JSESSIONID: " + cookie);
		} catch (Exception ele) {
			s_logger.info("session is found to be null");
		}
	}

	/**
	 * This method returns all the cookie and its value as string with delimiter
	 * 
	 * @return returns the string of cookie followed by its value
	 */
	public String getAllCookiesAndValue(WebDriver webdriver) {
		return Arrays.toString(webdriver.manage().getCookies().toArray());

	}

	public static void setCookie(WebDriver webdriver) {
		Cookie name = new Cookie("asdaCookie", "https");
		webdriver.manage().addCookie(name);
		for (Cookie c : webdriver.manage().getCookies()) {

			if (c != null) {
				if (c.getName().equals("asdaCookie") && c.getValue().equals("https")) {
					s_logger.info("the cookie values is set to https");
				}

			}
		}

	}

	public static void deleteCookiesAndValue(WebDriver webdriver, String cookieName) {
		{
			webdriver.manage().deleteCookieNamed(cookieName);

		}

	}

	/**
	 * Check if string is empty
	 */

	public static boolean isStringNotEmpty(String inpt) {
		boolean resultFlag = false;
		try {
			if (!inpt.isEmpty()) {
				s_logger.info("String given not empty.");
				resultFlag = true;
				return resultFlag;

			} else {
				resultFlag = false;
				return resultFlag;
			}
		} catch (Exception e) {
			s_logger.info("String given is empty.");
			resultFlag = false;
		}
		return resultFlag;

	}

	/**
	 * executeScript and return value
	 * 
	 */

	public static String getSignalVar(String var, JavascriptExecutor jse) {
		MigrationUtil.unconditionalWait(2000);
		try {
			// JavascriptExecutor jse = (JavascriptExecutor) driver;
			String query = "window.ACCELERATOR.APP.OMI_INT_SIGNAL." + var + ";";
			String value = jse.executeScript("return window.ACCELERATOR.APP.OMI_INT_SIGNAL." + var + ";").toString();
			s_logger.info("executeScript was successful for signal tag - " + query);
			return value;
		} catch (Exception e) {
			s_logger.info("There was an exception while running js script");
			return null;
		}
	}

	/**
	 * Compare 2 maps return true if all k,V of map1 = k,V of map2
	 * 
	 */

	public static boolean compareMap(Map<String, String> appVar, Map<String, String> excel) {
		boolean resultFlag = false;
		outerloop: for (Map.Entry<String, String> appVarEntry : appVar.entrySet()) {
			String appVarKey = appVarEntry.getKey();
			String valueappVarKey = appVarEntry.getValue();
			A: for (Map.Entry<String, String> testMapEntry : excel.entrySet()) {
				String testmapKey = testMapEntry.getKey();
				if (appVarKey.equalsIgnoreCase(testmapKey.trim())) {
					String valuetestMapKey = testMapEntry.getValue();
					if (valueappVarKey.contains(",") && appVarKey.contains("cf")) {
						String[] arr = valueappVarKey.split(",");
						for (int i = 0; i < arr.length; i++) {
							if (arr[i].trim().equalsIgnoreCase(valuetestMapKey.trim())) {
								s_logger.info("From app - Key " + arr[i] + " has value." + valueappVarKey);
								s_logger.info("From Excel - Key " + testmapKey + " has value." + valuetestMapKey);
								resultFlag = true;
								break A;
							}
						}
					}
					if (valueappVarKey.trim().equalsIgnoreCase(valuetestMapKey.trim())) {
						s_logger.info("From app - Key " + appVarKey + " has value." + valueappVarKey);
						s_logger.info("From Excel - Key " + testmapKey + " has value." + valuetestMapKey);
						resultFlag = true;
						break A;
					} else {
						s_logger.info("Key, Values did not match");
						s_logger.info("Application Key " + appVarKey + " has value " + valueappVarKey
								+ " but testdata have " + valuetestMapKey);
						resultFlag = false;
						break outerloop;
					}

				}
			}
		}

		return resultFlag;

	}

	public static boolean compareMap(Map<String, String> appVar, Map<String, String> excel, boolean forHL) {
		boolean resultFlag = false;
		outerloop: for (Map.Entry<String, String> appVarEntry : appVar.entrySet()) {
			String appVarKey = appVarEntry.getKey();
			String valueappVarKey = appVarEntry.getValue();
			A: for (Map.Entry<String, String> testMapEntry : excel.entrySet()) {
				String testmapKey = testMapEntry.getKey();
				if (appVarKey.equalsIgnoreCase(testmapKey.trim())) {
					String valuetestMapKey = testMapEntry.getValue();
					if (valueappVarKey.contains(",")) {
						String[] arr = valueappVarKey.split(",");
						for (int i = 0; i < arr.length; i++) {
							if (arr[i].trim().equalsIgnoreCase(valuetestMapKey.trim())) {
								s_logger.info("From app - Key " + arr[i] + " has value." + valueappVarKey);
								s_logger.info("From Excel - Key " + testmapKey + " has value." + valuetestMapKey);
								resultFlag = true;
								break A;
							}
						}
					}
					if (valueappVarKey.trim().equalsIgnoreCase(valuetestMapKey.trim())) {
						s_logger.info("From app - Key " + appVarKey + " has value." + valueappVarKey);
						s_logger.info("From Excel - Key " + testmapKey + " has value." + valuetestMapKey);
						resultFlag = true;
						break A;
					} else {
						s_logger.info("Key, Values did not match");
						s_logger.info("Application Key " + appVarKey + " has value " + valueappVarKey
								+ " but testdata have " + valuetestMapKey);
						resultFlag = false;
						break outerloop;
					}

				}
			}
		}

		return resultFlag;

	}

	/**
	 * Check WMX banner
	 * 
	 * @return
	 */

	public static boolean isWmxExist(WebDriver driver, String page) {
		boolean resultFlag = false;
		try {
			if (page.equalsIgnoreCase("homepage")) {
				List<WebElement> ele = driver.findElements(By.xpath("//div[@id='div-gpt-ad-home-bottom-1']//iframe"));
                resultFlag = ele.size() > 0;
			}
			if (page.equalsIgnoreCase("cat")) {
				String upperAdPlacement = "//div[@id='div-gpt-ad-taxonomy-0']//iframe | //div[@id='div-gpt-ad-cat-top-1']//iframe";
				String lowerAdPlacement = "//div[@id='div-gpt-ad-taxonomy-1']//iframe | //div[@id='div-gpt-ad-cat-bottom-1']//iframe";

				List<WebElement> upperAdList = driver.findElements(By.xpath(upperAdPlacement));
				List<WebElement> lowerAdList = driver.findElements(By.xpath(lowerAdPlacement));
                resultFlag = upperAdList.size() > 0 && lowerAdList.size() > 0;

			}
			if (page.equalsIgnoreCase("dept")) {
				String upperAdPlacement = "//div[@id='div-gpt-ad-taxonomy-0']//iframe | //div[@id='div-gpt-ad-dept-top-1']//iframe";
				String lowerAdPlacement = "//div[@id='div-gpt-ad-taxonomy-1']//iframe | //div[@id='div-gpt-ad-dept-bottom-1']//iframe";

				List<WebElement> upperAdList = driver.findElements(By.xpath(upperAdPlacement));
				List<WebElement> lowerAdList = driver.findElements(By.xpath(lowerAdPlacement));
                resultFlag = upperAdList.size() > 0 && lowerAdList.size() > 0;

			}
			if (page.equalsIgnoreCase("aisle")) {
				String upperAdPlacement = "//div[@id='div-gpt-ad-taxonomy-0']//iframe | //div[@id='div-gpt-ad-aisle-top-1']//iframe";
				String lowerAdPlacement = "//div[@id='div-gpt-ad-taxonomy-1']//iframe | //div[@id='div-gpt-ad-aisle-bottom-1']//iframe";

				List<WebElement> upperAdList = driver.findElements(By.xpath(upperAdPlacement));
				List<WebElement> lowerAdList = driver.findElements(By.xpath(lowerAdPlacement));
                resultFlag = upperAdList.size() > 0 && lowerAdList.size() > 0;

			}

			if (page.equalsIgnoreCase("Shelf")) {
				String upperAdPlacement = "//div[@id='div-gpt-ad-shelf-middle']//iframe | //div[@id='div-gpt-ad-shelf-top-1']//iframe";
				String lowerAdPlacement = "//div[@id='div-gpt-ad-shelf-bottom']//iframe | //div[@id='div-gpt-ad-shelf-bottom-1']//iframe";

				List<WebElement> upperAdList = driver.findElements(By.xpath(upperAdPlacement));
				List<WebElement> lowerAdList = driver.findElements(By.xpath(lowerAdPlacement));
                resultFlag = upperAdList.size() > 0 && lowerAdList.size() > 0;

			}

			if (page.equalsIgnoreCase("Search")) {
				String searchMiddleAd = "//div[@id='div-gpt-ad-search-top-0']//iframe";
				String searchBottomAd = "//div[@id='div-gpt-ad-search-bottom-1']//iframe";

				List<WebElement> middleAd = driver.findElements(By.xpath(searchMiddleAd));
				List<WebElement> bottomAd = driver.findElements(By.xpath(searchBottomAd));

                resultFlag = middleAd.size() > 0 && bottomAd.size() > 0;

			}

			if (page.equalsIgnoreCase("Favorites")) {
				String favAd = "//div[@id='div-gpt-ad-Favourites-bottom-0']//iframe | //div[@id='div-gpt-ad-favourites-bottom-1']//iframe";
				MigrationUtil.unconditionalWait(3000);
				List<WebElement> favoritesPageAd = driver.findElements(By.xpath(favAd));

                resultFlag = favoritesPageAd.size() > 0;

			}

		} catch (NoSuchElementException ignored) {
			resultFlag = false;

		}
		return resultFlag;
	}

	// Add the cookie
	public static void addCookieValue(WebDriver webdriver) {
		Cookie atgcookie = new Cookie("comm_version", "11");
		webdriver.manage().addCookie(atgcookie);
		MigrationUtil.unconditionalWait(2000);
		s_logger.info("Cookie atg 11 cookie value is added" + webdriver.manage().getCookieNamed("comm_version"));
	}

	/**
	 * validate if the theme cookie value has code change
	 * 
	 */
	public static boolean validateCmsCode(String themeValue, WebDriver driver) {
		MigrationUtil.unconditionalWait(2000);
		try {

			JavascriptExecutor jse = (JavascriptExecutor) driver;
			String query = "window.ACCELERATOR.APP.cssPath";
			String query2 = "window.ACCELERATOR.APP.jsBaseScriptPath";
			String ccsPath = jse.executeScript("return " + query + ";").toString();
			String jsBasePath = jse.executeScript("return " + query2 + ";").toString();
			s_logger.info("validating the code changes");
            return ccsPath.contains(themeValue) && jsBasePath.contains(themeValue);

		} catch (Exception e) {
			s_logger.info("There was an exception while running js script");
			return false;
		}
	}

	/*
	 * Closes PopUp opened in New Window. It shifts focus from Parent Window to
	 * Child Window, closes the Child Window and returns the focus to the Parent
	 * Window.
	 * 
	 * @author rkanni.
	 * 
	 * @param driver. WebDriver Instance.
	 * 
	 * @return boolean. Indicates if closing PopUp action was successful.
	 * 
	 * @throws Exception.
	 */
	public static boolean closePopUpInNewWindow(WebDriver driver) {
		driver.switchTo().defaultContent();

		Set<String> allWindowHandles = null;
		String parentWindow = "";
		String childWindow = "";
		boolean isPopUpClosed = false;
		Iterator<String> iterator = null;
		try {
			if (driver != null) {
				allWindowHandles = driver.getWindowHandles();

				if (allWindowHandles != null && allWindowHandles.size() > 1) {
					iterator = allWindowHandles.iterator();
					while (iterator.hasNext()) {
						parentWindow = iterator.next();
						s_logger.info("ParentWindow: " + parentWindow);
						childWindow = iterator.next();
						s_logger.info("ChildWindow: " + childWindow + " Title: " + driver.getTitle());
						driver.switchTo().window(childWindow);

						// The following close() closes only the window where
						// the focus is at. It doesn't close the main WebDriver
						// instance.
						driver.close();
						isPopUpClosed = true;
						s_logger.info("isPopUpClosed: " + isPopUpClosed);

						// Currently iterating through only one Child Window,
						// hence
						// breaking the loop.
						break;
					}
				} else {
					s_logger.debug("Looks like there is no PopUp to operate on...");
				}
				driver.switchTo().window(parentWindow);
			}
		} catch (NoSuchWindowException nsw) {
			s_logger.error("There is no such window! Please check if the intended window is displayed");
		} catch (Exception ex) {
			s_logger.debug("Exception while trying to operate on PopUp in New Window");
		}

		return isPopUpClosed;

	}

	/*
	 * Clicks at the specified index.
	 * 
	 * @author rkanni
	 * 
	 * @param List<WebEelement>
	 * 
	 * @param Index
	 * 
	 * @param WebDriver Instance
	 * 
	 * @return boolean. Indicates if the click action with the button at given index
	 * is successful.
	 * 
	 * @throws Exception.
	 */
	public static boolean clickAtIndex(List<WebElement> inputList, int index, WebDriver driver) {
		try {
s_logger.info("clicking add to basket banner ");
			if (inputList != null && index >= inputList.size()) {
				s_logger.warn("There is no element to click at position: " + index);
			} else {
				JavascriptExecutor jse = (JavascriptExecutor) driver;
				if (inputList.get(index).isDisplayed()) {
					jse.executeScript("arguments[0].click();", inputList.get(index));

					s_logger.info("Click action at position: " + index + " successful.");
					MigrationUtil.unconditionalWait(4000);
					return true;
				}
			}
		} catch (WebDriverException wde) {
			s_logger.info("Unable to click at position: " + index + ". Trying again...");

			try {

				if (inputList.get(index).isDisplayed()) {
					inputList.get(index).click();
					s_logger.info("Click action at position: " + index + "successful.");
					MigrationUtil.unconditionalWait(4000);
					return true;
				}
			} catch (Exception ex) {
				s_logger.error("Unable to click the given element");
				s_logger.info("Throwing exception...");
				throw ex;
			}
		} catch (Exception ex) {
			com.asda.qa.utility.FluentWaitImplicit.waitForElemenAndClick(inputList.get(index), driver, 30);
			return true;
		}
		return false;
	}

	public static String extractAndReturnHashMapValues(HashMap<String, String> assertFalures) {
		String errorMessages = "";
		for (String msg : assertFalures.values())
			errorMessages = errorMessages + " **** " + msg;

		return errorMessages;

	}

	public static String returnTextFromWebElement(WebElement ele, WebDriver driver) {
		try {
			if (ele.isDisplayed())
				return ele.getText();
		} catch (Exception e) {
			return "";
		}
		return "";

	}

	public static String returntextFromAttributeValue(WebElement ele, WebDriver driver) {
		try {
			if (ele.isDisplayed())
				return ele.getAttribute("value").trim();
		} catch (Exception e) {
			return "";
		}
		return "";

	}

	public static boolean isRadioBtnSelected(WebElement ele, WebDriver driver) {
		try {
			if (ele.isDisplayed())
				return ele.isSelected();
		} catch (Exception e) {
			return false;
		}
		return false;

	}

	public static boolean isWebElementSelected(WebElement ele, WebDriver driver) {
		try {
			if (ele.isDisplayed())
				return ele.isSelected();
		} catch (Exception e) {
			return false;
		}
		return false;

	}

	public static String VisaRandName() {
		Calendar currentDate = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("MMddyyhhmmss");
		String randNickName = formatter.format(currentDate.getTime());
		return "name" + " " + randNickName;
	}

	public static void closeSiteSpecBar(WebDriver driver) {

//		try {
//			driver.findElement(By.xpath("//div[@class='dx-pane--header-menu']")).click();
//			driver.findElement(By.xpath("//div[@title='Close Preview Panel']")).click();
//
//		} catch (Exception e) {
//			s_logger.info("Error while clearing sitespec panel");
//		}

	}
	
	public static void clickAndcloseSiteSpecBar(WebDriver driver) {

		try {
			driver.findElement(By.xpath("//div[@class='dx-pane--header-menu']"))
					.click();
			driver.findElement(By.xpath("//div[@title='Close Preview Panel']"))
					.click();

		} catch (Exception e) {
			s_logger.info("Error while clearing sitespec panel");
		}

	}

	public static String randNameGeneratorOnlyChar(int stringLenght) {
		String ALPHA_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		StringBuilder builder = new StringBuilder();
		while (stringLenght-- != 0) {
			int character = (int) (Math.random() * ALPHA_STRING.length());
			builder.append(ALPHA_STRING.charAt(character));
		}
		return builder.toString();
	}

	public static void clearInputBoxValues(WebElement element, WebDriver driver) {
		try {
			Actions navigator = new Actions(driver);
			navigator.click(element).sendKeys(Keys.END).keyDown(Keys.SHIFT).sendKeys(Keys.HOME).keyUp(Keys.SHIFT)
					.sendKeys(Keys.BACK_SPACE).perform();
		} catch (Exception ele) {

		}
	}

	public static void setCookie(WebDriver webdriver, String cookieName, String value) {
		JavascriptExecutor jse = (JavascriptExecutor) webdriver;
		jse.executeScript("document.cookie ='" + cookieName + "=" + value + "'");

	}

	public static void hoverAction(WebElement ele, WebDriver driver) {
		s_logger.info("Performing hover action");
		Actions action = new Actions(driver);
		action.moveToElement(ele);
		action.build().perform();

	}

	/*
	 * Return WebElement from Xpath
	 * 
	 * @author sgowda
	 * 
	 * @param none
	 * 
	 * @return WebElement
	 * 
	 * @throws Exception.
	 */
	public static WebElement returnWebElement(String xpath, WebDriver driver) {
		s_logger.info("Returning web element for xpath" + xpath);
		return driver.findElement(By.xpath(xpath));

	}

	/*
	 * Replace string and return WebElement from Xpath Optimization flow
	 * 
	 * @author sgowda
	 * 
	 * @param none
	 * 
	 * @return WebElement
	 * 
	 * @throws Exception.
	 */

	public static WebElement returnWebElement(String xpath, String orginalStr, String replaceStr, WebDriver driver) {
		xpath = xpath.replace(orginalStr, replaceStr);
		s_logger.info("Returning web element for xpath" + xpath);
		return driver.findElement(By.xpath(xpath));

	}
	
	/*
	 * Replace string and return WebElement from Xpath Optimization flow
	 * 
	 * @author sgowda
	 * 
	 * @param none
	 * 
	 * @return WebElement
	 * 
	 * @throws Exception.
	 */

	public static WebElement returnWebElement(String xpath, String[] orginalStr, String[] replaceStr, WebDriver driver) {
		String updatedXpath=xpath;
		for(int i=0; i< orginalStr.length; i++ )
		{
			updatedXpath=updatedXpath.replace(orginalStr[i], replaceStr[i]);
		}
		s_logger.info("Returning web element for xpath: " + updatedXpath);
		
		return returnWebElement(updatedXpath, driver);
	}
	
	public static List<WebElement> returnWebElements(String xpath, String[] orginalStr, String[] replaceStr, WebDriver driver) {
		s_logger.info("Returning web element for xpath " + xpath);
		String updatedXpath=xpath;
		for(int i=0; i<  orginalStr.length; i++ )
		{
			updatedXpath=updatedXpath.replace(orginalStr[i], replaceStr[i]);
		}
		
		return returnWebElements(updatedXpath, driver);
	}

	/*
	 * Return list of WebElements from Xpath
	 * 
	 * @author sgowda
	 * 
	 * @param none
	 * 
	 * @return List<WebElement>
	 * 
	 * @throws Exception.
	 */

	public static List<WebElement> returnWebElements(String xpath, WebDriver driver) {

		s_logger.info("Returning web element for xpath" + xpath);
			String[] xpaths=xpath.split("#");
		for(String objectXpath: xpaths)
		{
			try {
		if(!(driver.findElements(By.xpath(objectXpath)).size()==0))
			return driver.findElements(By.xpath(objectXpath));
		}
		
		catch(NoSuchElementException ele)
		{
			s_logger.debug("moving to next xpath");
		}
		catch(ArrayIndexOutOfBoundsException ele)
		{
			s_logger.debug("moving to next xpath");
		}
		}
		
		return new ArrayList<WebElement>();

	}
	
	public static void clickWebElement(String xpath, WebDriver driver, int waitTime) {
		s_logger.info("Clicking web element for xpath" + xpath);
		com.asda.qa.utility.FluentWaitImplicit.waitForElemenAndClick(returnWebElement(xpath, driver), driver, waitTime);
	}

	public static void clickWebElement(WebElement element, WebDriver driver, int waitTime) {
		com.asda.qa.utility.FluentWaitImplicit.waitForElemenAndClick(element, driver, waitTime);
	}

	/***
	 * The below method is used to do browser back
	 */
	public static void browserBackButtonClick(WebDriver driver) {
		s_logger.info("Clicking browser back button");
		String beforeBack = driver.getCurrentUrl();
		BaseWebPage base = new BaseWebPage(driver);
		if (base.getBrowserType().toString().equalsIgnoreCase("SAFARI")
				|| base.getBrowserType().toString().equalsIgnoreCase("SAFARIIPAD")
				|| base.getBrowserType().toString().equalsIgnoreCase("INTERNET_EXPLORER_11")) {
			((JavascriptExecutor) driver).executeScript("javascript: setTimeout(\"history.go(-1)\", 2000)");
		} else
			driver.navigate().back();
		// sometimes browser back doesnt happen. So adding step to click browser
		// back again
		if (beforeBack == driver.getCurrentUrl())
			((JavascriptExecutor) driver).executeScript("javascript: setTimeout(\"history.go(-1)\", 2000)");
		MigrationUtil.unconditionalWait(5000);
		s_logger.info("Clicked browser back button");

	}

	public static void scrollToBottom(WebDriver driver) {
		JavascriptExecutor jse = null;
		try {
			jse = (JavascriptExecutor) driver;
			jse.executeScript("scroll(0,2500)");
		} catch (Exception ex) {
			s_logger.error("Exception occured while trying to scroll to Bottom of the Page");
		} finally {
			if (jse != null)
				jse = null;
		}
		MigrationUtil.unconditionalWait(4000);
	}

	
}
