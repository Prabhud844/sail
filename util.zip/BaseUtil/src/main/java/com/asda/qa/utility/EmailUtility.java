package com.asda.qa.utility;

import java.io.IOException;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class EmailUtility {
	private static final Logger s_logger = LoggerFactory.getLogger(EmailUtility.class);
	static String host = null;

	/** The text is html. */
	static boolean textIsHtml = false;

	/**
	 * Gets the host name.
	 *
	 * @param domain the domain
	 * @return the host name
	 */
	public static String getHostName(String domain) {
		if(domain.equalsIgnoreCase("GMAIL"))
			host = "imap.gmail.com";
		else
			host = "imap-mail.outlook.com";
		return host;
	}

	private static Properties setEmailProperties(String email, String password, String domain) {
		Properties props = new Properties();
		props.setProperty("mail.store.protocol", "imaps");
		props.setProperty("mail.imaps.host", getHostName(domain));
		props.setProperty("mail.imaps.user", email);
		props.setProperty("mail.imaps.password", password);
		props.setProperty("mail.imaps.port", "993");
		props.setProperty("mail.imaps.auth", "true");
		props.setProperty("mail.debug", "false");
		props.setProperty("mail.imaps.starttls.enable","true");
		return props;
	}

	/**
	 * Check email.
	 *
	 * @param email the email
	 * @param password the password
	 * @param domain the domain
	 * @return the string
	 */
	public static String checkEmail(String email, String password, String domain) {
		String data = null;

		Properties props =  setEmailProperties(email, password, domain);
		try {
			Session session = Session.getInstance(props, null);
			Store store = session.getStore("imaps");
			store.connect(host, email , password);
			try {
				data = getMailFromInbox(session, store);
			} catch (Exception e) {
				data = getMailFromSpam(session, store);
			}
			data = data.replaceAll("\\<.*?\\>", "");
		}catch(Exception e) {
			e.printStackTrace();
		}
		return data;
	}

	/**
	 * Gets the mail from inbox.
	 *
	 * @param session the session
	 * @param store the store
	 * @return the mail from inbox
	 * @throws MessagingException the messaging exception
	 */
	public static String getMailFromInbox(Session session, Store store) throws MessagingException{
		String message = null;
		Folder folder = null;
		try {
			folder = store.getFolder("INBOX");
			message = readMails(folder);
		}catch(Exception e) {
			folder.close(true);
			store.close();
			return message;
		}
		return message;
	}

	/**
	 * Gets the mail from spam.
	 *
	 * @param session the session
	 * @param store the store
	 * @return the mail from spam
	 * @throws MessagingException the messaging exception
	 */
	public static String getMailFromSpam(Session session, Store store) throws MessagingException{
		String message = null;
		Folder folder = null;
		try {
			folder = store.getFolder("SPAM");
			message = readMails(folder);
		}catch(Exception e) {
			folder.close(true);
			store.close();
			return message;
		}
		return message;
	}

	/**
	 * Read mails.
	 *
	 * @param folder the folder
	 * @return the string
	 */
	public static String readMails(Folder folder) {
		String message = null;
		try {
			folder.open(Folder.READ_WRITE);
			Message[] messages = folder.getMessages();
			int messageCount = folder.getMessageCount();
			s_logger.info("There are : {} messages.", messageCount);
			Message currMessage;
			String from, subject;
			for(int i=messageCount - 1; i>=0; i--) {
				currMessage = messages[i];
				s_logger.info("Email Number " + i);
				s_logger.info("From : " + currMessage.getFrom()[0]);
				s_logger.info("Subject : " + currMessage.getSubject());

				from = currMessage.getFrom()[0].toString();
				subject = currMessage.getSubject();
				if(from.equalsIgnoreCase("ASDA Customer Services <home.shopping@asda.co.uk>")) {
					if(1==1 || subject.equalsIgnoreCase("Your personal details have been changed") || subject.equalsIgnoreCase("Your ASDA email address has been changed") || 1==1 ) {
						Multipart mp = (Multipart) currMessage.getContent();
						BodyPart bp = mp.getBodyPart(0);
						message = bp.getContent().toString();
						currMessage.setFlag(Flags.Flag.DELETED, true);
						break;
					}
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
			return message;
		}
		return message;
	}

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		String message = EmailUtility.checkEmail("testuser_sp_asda@outlook.com", "testuser1234", "outlook");
		s_logger.info("message is : {}", message);
	}

	/**
	 * Gets the text.
	 *
	 * @param p the p
	 * @return the text
	 * @throws MessagingException the messaging exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static String getText(Part p) throws MessagingException, IOException {
		if (p.isMimeType("text/*")) {
			String s = (String)p.getContent();
			textIsHtml = p.isMimeType("text/html");
			return s;
		}

		if (p.isMimeType("multipart/alternative")) {
			// prefer html text over plain text
			Multipart mp = (Multipart)p.getContent();
			String text = null;
			for (int i = 0; i < mp.getCount(); i++) {
				Part bp = mp.getBodyPart(i);
				if (bp.isMimeType("text/plain")) {
					if (text == null)
						text = getText(bp);
					continue;
				} else if (bp.isMimeType("text/html")) {
					String s = getText(bp);
					if (s != null)
						return s;
				} else {
					return getText(bp);
				}
			}
			return text;
		} else if (p.isMimeType("multipart/*")) {
			Multipart mp = (Multipart)p.getContent();
			for (int i = 0; i < mp.getCount(); i++) {
				String s = getText(mp.getBodyPart(i));
				if (s != null)
					return s;
			}
		}

		return null;
	}

	public static Message readMail(Folder folder) {
		Message currMessage = null;
		try {
			folder.open(Folder.READ_WRITE);
			Message[] messages = folder.getMessages();
			int messageCount = folder.getMessageCount();
			s_logger.info("There are : {} messages.", messageCount);
			String from, subject;
			for(int i=messageCount - 1; i>=0; i--) {
				currMessage = messages[i];
				s_logger.info("Email Number " + i);
				s_logger.info("From : " + currMessage.getFrom()[0]);
				s_logger.info("Subject : " + currMessage.getSubject());

				from = currMessage.getFrom()[0].toString();
				subject = currMessage.getSubject();
				if(from.equalsIgnoreCase("ASDA Customer Services <home.shopping@asda.co.uk>")) {
//					currMessage.setFlag(Flags.Flag.DELETED, true);
					break;
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
			return currMessage;
		}
		return currMessage;
	}

	public static Message getEmailsFromMailBox(String email, String password, String domain) {
		Message data = null;

		Properties props =  setEmailProperties(email, password, domain);
		try {
			Session session = Session.getInstance(props, null);
			Store store = session.getStore("imaps");
			store.connect(host, email , password);
			try {
				data = getEmailFromInbox(session, store);
			} catch (Exception e) {
				data = getEmailFromSpam(session, store);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return data;
	}

	/**
	 * Gets the mail from inbox.
	 *
	 * @param session the session
	 * @param store the store
	 * @return the mail from inbox
	 * @throws MessagingException the messaging exception
	 */
	public static Message getEmailFromInbox(Session session, Store store) throws MessagingException{
		Message message = null;
		Folder folder = null;
		try {
			folder = store.getFolder("INBOX");
			message = readMail(folder);
		}catch(Exception e) {
			folder.close(true);
			store.close();
			return message;
		}
		return message;
	}

	/**
	 * Gets the mail from spam.
	 *
	 * @param session the session
	 * @param store the store
	 * @return the mail from spam
	 * @throws MessagingException the messaging exception
	 */
	public static Message getEmailFromSpam(Session session, Store store) throws MessagingException{
		Message message = null;
		Folder folder = null;
		try {
			folder = store.getFolder("SPAM");
			message = readMail(folder);
		}catch(Exception e) {
			folder.close(true);
			store.close();
			return message;
		}
		return message;
	}

	public static String getMessageBody(Message message) {
		String body = null;
		Multipart mp;
		try {
			mp = (Multipart) message.getContent();
			BodyPart bp = mp.getBodyPart(0);
			body = bp.getContent().toString();
			body = body.replaceAll("\\<.*?\\>", "");
		} catch (IOException | MessagingException e) {
			return message.toString();
			//e.printStackTrace();
		}
		return body;
	}

	public static String getMessageBody(Message message, boolean removeHtmlTags) {
		if(removeHtmlTags) return getMessageBody(message);
		String body = null;
		Multipart mp;
		try {
			mp = (Multipart) message.getContent();
			BodyPart bp = mp.getBodyPart(0);
			body = bp.getContent().toString();
		} catch (IOException | MessagingException e) {
			e.printStackTrace();
		}
		return body;
	}

	public static void deleteMessage(Message message) {
		try {
			message.setFlag(Flags.Flag.DELETED, true);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}
	
	
	/**** to send an email - adeed by Soumya(s0s02hx) *****/
	public boolean sendemail(String from,String m_subject, String[] recipient_list,String text,String[] attachment)
			throws IOException {
		
		boolean sendmsgflag = false;

		

		if(from==null)return false;
		if(recipient_list==null)return false;
		
		if(m_subject==null)m_subject="No data";
		if(text==null)text="no data";
		
		
		String host = "172.26.45.89";// or IP address

		// Get the session object
		Properties properties = System.getProperties();
		properties.setProperty("mail.smtp.host", host);
		Session session = Session.getDefaultInstance(properties);

		

		// compose the message
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));

			
		   message.setSubject(m_subject);
	


			/// Create the message part
			BodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setText(text);

			Multipart multipart = new MimeMultipart();

			// Set text message part
			multipart.addBodyPart(messageBodyPart);
			
			messageBodyPart = new MimeBodyPart();
			
			if(attachment!=null) {
				
				for(int i=0;i<attachment.length;i++)
				{
					DataSource source = new FileDataSource(attachment[i]);
					messageBodyPart.setDataHandler(new DataHandler(source));
					messageBodyPart.setFileName(attachment[i]);
					multipart.addBodyPart(messageBodyPart);
					message.setContent(multipart);
					messageBodyPart = new MimeBodyPart();
				}
				
			}
		
			
			

			// Send messages

			for (int i = 0; i < recipient_list.length; i++) {

				String str = recipient_list[i];
				message.addRecipient(Message.RecipientType.TO, new InternetAddress(str));
				if (i == recipient_list.length - 1)
					Transport.send(message);
				System.out.println("message sent successfully to " + recipient_list[i]);
			}

			System.out.println("message sent successfully to all ");

			return sendmsgflag = true;
		} catch (MessagingException mex) {
			mex.printStackTrace();
			return sendmsgflag;
		}

	}

}
