package com.asda.qa.utility;

public class APIResponse {

private int StatusCode;

public int getStatusCode() {
return StatusCode;
}

public void setStatusCode(int statusCode) {
StatusCode = statusCode;
}
}
