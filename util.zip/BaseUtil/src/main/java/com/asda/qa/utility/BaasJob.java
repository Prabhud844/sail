package com.asda.qa.utility;

import com.asda.core.utils.MigrationUtil;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BaasJob {
	private static final Logger s_logger = LoggerFactory.getLogger(BaasJob.class);
	private static final String baasUrl = "https://baas.stg.walmart.com/baas/api/jobs";
	public static Map<String, String> headers;
	
	public static void setBaasHeaders(){
		headers = new HashMap<String,String>();
		headers.put("WM_CONSUMER.ID", "1");
		headers.put("WM_QOS.CORRELATION_ID", "1");
		headers.put("WM_SVC.ENV", "baasEnv");
		headers.put("WM_SVC.NAME", "baas");
		headers.put("WM_SVC.VERSION", "1.2.3");
	}
	
	public static Map<String, String> getBaasHeaders(){
		setBaasHeaders();
		return headers;
	}
	
	public static String getBaasRunnableName(String jobName, String env) {
		s_logger.info("Getting the runnable name for Job {} and env {}");
		env = env.toLowerCase();
		String url = baasUrl + "/"+ jobName + "/runnables?pageIndex=1&pageSize=100";
		RestAssured.baseURI = url;
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.defaultParser = Parser.JSON;
		String runnableName = null;
		
		RequestSpecification request = RestAssured.given();
		request.headers(getBaasHeaders());
		s_logger.info("Get Runnable Name Request Url : " + url + " headers : " + headers);
		Response response = request.request(Method.GET);
		s_logger.info("Get Runnable Name Response is : " + response.asString());
		List<String> jobNames = response.jsonPath().get("payload.content.name");
		s_logger.info("Runnable list: {}",jobNames);
		for(String job : jobNames) {
			String temp = job.toLowerCase();
			if(temp.contains(env)){
				runnableName = job;
				break;
			}
		}
		s_logger.info("Runnable Name : {}",runnableName);
		return runnableName;
	}
	
	public boolean isJobCompleted(String url) {
		s_logger.info("Checking if the Job is completed...");
		boolean isCompleted = false;
		url = url + "/iterations?pageIndex=1&pageSize=100";
		RestAssured.baseURI = url;
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.defaultParser = Parser.JSON;
		
		s_logger.info("Is Job Completed URL : {}",url);
		RequestSpecification request = RestAssured.given();
		request.headers(getBaasHeaders());
		
		Response response;
		List<String> completeList;
		long waitingTime = 0;
		while(!isCompleted && waitingTime < 300000) {
			waitingTime += 10000;
			response = request.request(Method.GET);
			s_logger.info("Response : {}",response.asString());
			completeList = response.jsonPath().get("payload.content.status");
			s_logger.info("List : {} ",completeList);
			int count = 0;
			/*completeList.remove("NOT_AVAILABLE");
			completeList.remove("SKIPPED");
			for(String data : completeList) {
				if(data.equalsIgnoreCase("COMPLETED"))
					count ++;
			}
			if(count == completeList.size()) {
				isCompleted = true;
				continue;
			}*/
			if(completeList.get(0).equalsIgnoreCase("COMPLETED")) {
				isCompleted = true;
				continue;
			}
			MigrationUtil.unconditionalWait(10000);
		}
		
		s_logger.info("Is Job Completed : {}", isCompleted);
		return isCompleted;
	}
	
	@SuppressWarnings("unchecked")
	public boolean triggerJob(String jobName, String env) {
		s_logger.info("Triggering a {} job in {} env", jobName, env);
		boolean flag = false;
		String runnableName = getBaasRunnableName(jobName, env);
		if(runnableName != null) {
			String url = baasUrl + "/"+ jobName + "/runnables/" + runnableName;
			RestAssured.baseURI = url;
			RestAssured.useRelaxedHTTPSValidation();
			RestAssured.defaultParser = Parser.JSON;
			
			RequestSpecification request = RestAssured.given();
			JSONObject obj = new JSONObject();
			obj.put("description", "Launching ["+runnableName+"] runnable");
			obj.put("model", "LAUNCH");
			obj.put("name", runnableName);
			s_logger.info("Request Url : " + url + "\n headers : " + headers + "\n Body : " + obj);
			
			headers.put("Content-Type", "application/json");
			request.headers(headers);
			request.body(obj);
			Response response = request.request(Method.POST);
			s_logger.info("Response is : {}",response.asString());
			
			String status = response.jsonPath().get("status");
			s_logger.info("Status : " + status);
			if(status.equalsIgnoreCase("OK")) {
				s_logger.info("JOB is triggered successfully");
				if(isJobCompleted(url)) {
					s_logger.info("Job is completed");
					flag = true;
				}
			}else {
				s_logger.info("Job failed to trigger");
			}
		}
		return flag;
	}
	
	public static void main(String[] args) {
		BaasJob b = new BaasJob();
		b.triggerJob("CommonPriceCacheScheduler", "QA5");
	}
}