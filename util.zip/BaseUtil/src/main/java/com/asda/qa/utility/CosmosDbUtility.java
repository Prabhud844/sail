package com.asda.qa.utility;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.microsoft.azure.documentdb.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class CosmosDbUtility {
	private static final Logger s_logger = LoggerFactory.getLogger(CosmosDbUtility.class);
	
	public static DocumentClient connect(String cosmosCon, String cosmosKey) {
		return new DocumentClient(cosmosCon, cosmosKey, new ConnectionPolicy(), ConsistencyLevel.Session);
	}
	
	public static void disconnect(DocumentClient client) {
		client.close();
	}
	
	/**
	 * be sure to close the @client at your end
	 * @param client
	 * @param cosmosDb
	 * @param cosmosTable
	 * @param query
	 * @return
	 */
	public static JSONArray executeQuery(DocumentClient client, String cosmosDb, String cosmosTable, String query) {
		JSONArray arr = new JSONArray();
		String collectionlink = String.format("/dbs/%s/colls/%s", cosmosDb, cosmosTable);
		try {
			s_logger.info("Executing the query: `{}` on tableName : `{}`", query, cosmosTable);
			List<Document> results = client.queryDocuments(collectionlink, query, getFeedOptions()).getQueryIterable()
					.toList();
			arr = convertDocumentsToJSONArray(results);
			s_logger.info("TOTAL RESULTS FROM COSMOS : {}", arr.size());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return arr;
	}
	
	public static JSONArray executeQuery(String cosmosCon, String cosmosKey, String cosmosDb, String cosmosTable, String query) {
		JSONArray arr = new JSONArray();
		DocumentClient client = null;
		String collectionlink = String.format("/dbs/%s/colls/%s", cosmosDb, cosmosTable);
		try {
			client = connect(cosmosCon, cosmosKey);
			
			s_logger.info("Executing the query: {} on tableName : {}", query, cosmosTable);
			List<Document> results = client.queryDocuments(collectionlink, query, getFeedOptions()).getQueryIterable().toList();
			
			arr = convertDocumentsToJSONArray(results);
			
			s_logger.info("TOTAL RESULTS FROM COSMOS : {}", arr.size());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(client != null) disconnect(client);
		}
		
		return arr;
	}
	
	@SuppressWarnings("unchecked")
	private static JSONArray convertDocumentsToJSONArray(List<Document> docs) {
		ObjectMapper mapper = new ObjectMapper();
		mapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
		JSONArray arr = new JSONArray();
		for(Document doc : docs) {
			try {
				JSONObject obj = JsonUtil.convertStringToJsonObject(mapper.writeValueAsString(doc));
				obj = (JSONObject) obj.get("hashMap");
				arr.add(obj);
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
		}
		return arr;
	}
	
	public static FeedOptions getFeedOptions() {
		FeedOptions queryOptions = new FeedOptions();
		queryOptions.setEnableCrossPartitionQuery(true);
		queryOptions.setMaxBufferedItemCount(1200);
		return queryOptions;
	}

	public static RequestOptions getRequestOptions(String id) {
		PartitionKey key = new PartitionKey(id);
		RequestOptions reqOptions = new RequestOptions();
		reqOptions.setPartitionKey(key);
		return reqOptions;
	}

	public static List<Document> _executeQuery(DocumentClient client, String cosmosDb, String cosmosTable, String query) {
		String collectionlink = String.format("/dbs/%s/colls/%s", cosmosDb, cosmosTable);
		List<Document> results = null;
		try {
			s_logger.info("Executing the query: `{}` on tableName : `{}`", query, cosmosTable);
			results = client.queryDocuments(collectionlink, query, getFeedOptions()).getQueryIterable().toList();
		} catch (Exception e) {
			s_logger.info("Exception Occured in Fetching Data from {} table.", cosmosTable + "Getting Exception :: " + e.getStackTrace());
		}
		return results;
	}

	public static boolean updateDocument(DocumentClient client, Document documentToUpdate) {
		boolean isDocumentUpdated = false;
		Document documentObj = null;
		try {
			documentObj = client.replaceDocument(documentToUpdate.getSelfLink(), documentToUpdate, null).getResource();
			if (documentObj != null) {
				isDocumentUpdated = true;
				s_logger.info("Cosmos Table Updated Successfully.");
			}
		} catch (DocumentClientException dcex) {
			s_logger.info("Getting Exception :: " + dcex.getMessage());
		} finally {
			if (client != null)
				client.close();
		}
		return isDocumentUpdated;
	}

}
