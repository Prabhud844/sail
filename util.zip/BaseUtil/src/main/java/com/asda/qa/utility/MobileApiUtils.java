package com.asda.qa.utility;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.with;

public class MobileApiUtils {
    /**
     * process.
     *
     * @param builder RequestSpecBuilder
     */
    public RequestSpecification process(RequestSpecBuilder builder) {
        return with().given().spec(builder.build()).relaxedHTTPSValidation().when();
    }

    public RequestSpecBuilder initRequest(String s) {
        RestAssured.proxy("sysproxy.wal-mart.com",8080);
        return new RequestSpecBuilder().setBaseUri(s);
    }
}
