package com.asda.qa.utility;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchSessionException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.asda.core.database.ASDADataBaseTypes;
import com.asda.qa.webservice.WS_IAM_User;
import com.google.common.base.Function;
import com.asda.core.baseexecution.ExecutionConfig;
import com.asda.core.baseexecution.BaseWebPage;
import com.asda.core.utils.MigrationUtil;

public class FluentWaitImplicit extends BaseWebPage {

	public FluentWaitImplicit(BaseWebPage page) {
		super(page);
		PageFactory.initElements(driver, this);
	}

	private static final Logger s_logger = LoggerFactory.getLogger(FluentWaitImplicit.class);

	/***
	 * Fluent wait for page load
	 */

	public static boolean waitForElementToLoad(WebElement element,WebDriver driver)
	{
		try {
			@SuppressWarnings("deprecation")
			FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
					.withTimeout(Duration.ofSeconds(20))
					.pollingEvery(Duration.ofMillis(1000))
					.ignoring(NoSuchElementException.class)
					.ignoring(StaleElementReferenceException.class);
			return wait.until(ExpectedConditions.visibilityOf(element)) != null;
		}catch(TimeoutException e) {
			e.printStackTrace();
			s_logger.info("Web Element is not found after time out exception {} ",element);
			return false;
		}

	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Object waitForeithierOfTwoEleIsVisible(final WebElement element,final WebElement element2,WebDriver driver){
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(50))
				.pollingEvery(Duration.ofMillis(500))
				.ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);
		return	wait.until(new Function()
		{
			public Object apply(Object arg0) {

				return element.isDisplayed() ||	element2.isDisplayed();
			}
		});

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Object waitForeithierOfTwoEleIsVisibleCustom(final WebElement element,final WebElement element2,WebDriver driver,int timeInterval){
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(timeInterval))
				.pollingEvery(Duration.ofSeconds(2000))
				.ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);
		return	wait.until(new Function()
		{
			public Object apply(Object arg0) {

				return element.isDisplayed() ||	element2.isDisplayed();
			}
		});

	}

	/***
	 * Fluent wait for page load
	 */

	public static boolean waitForElementToBeClikable(WebElement element,WebDriver driver)
	{

		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(50))
				.pollingEvery(Duration.ofMillis(500))
				.ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);
		return wait.until(ExpectedConditions.elementToBeClickable(element)) != null;

	}
	/***
	 * Fluent wait for page load 
	 */

	public static boolean waitForElementNotDisplayed(String element,WebDriver driver,String by)
	{
		if(by=="xpath")
		{
			FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
					.withTimeout(Duration.ofSeconds(90))
					.pollingEvery(Duration.ofSeconds(2))
					.ignoring(NoSuchElementException.class)
					.ignoring(StaleElementReferenceException.class);
			return wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(element)));
		}
		if(by=="css")
		{
			FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
					.withTimeout(Duration.ofSeconds(70))
					.pollingEvery(Duration.ofSeconds(2))
					.ignoring(NoSuchElementException.class)
					.ignoring(StaleElementReferenceException.class);
			return wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(element)));
		}
		else
		{
			FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
					.withTimeout(Duration.ofSeconds(50))
					.pollingEvery(Duration.ofMillis(500))
					.ignoring(NoSuchElementException.class)
					.ignoring(StaleElementReferenceException.class);
			return wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id(element)));

		}

	}

	/***
	 * Fluent wait for page load
	 */

	public static boolean waitForElementNotDisplayedCustom(String element,WebDriver driver,String by, int timeInterval)
	{
		if(by=="xpath")
		{
			FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
					.withTimeout(Duration.ofSeconds(timeInterval))
					.pollingEvery(Duration.ofSeconds(1))
					.ignoring(NoSuchElementException.class)
					.ignoring(StaleElementReferenceException.class);
			return wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(element)));
		}
		if(by=="css")
		{
			FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
					.withTimeout(Duration.ofSeconds(timeInterval))
					.pollingEvery(Duration.ofSeconds(2))
					.ignoring(NoSuchElementException.class)
					.ignoring(StaleElementReferenceException.class);
			return wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(element)));
		}
		else
		{
			FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
					.withTimeout(Duration.ofSeconds(50))
					.pollingEvery(Duration.ofMillis(500))
					.ignoring(NoSuchElementException.class)
					.ignoring(StaleElementReferenceException.class);
			return wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id(element)));

		}

	}
	/***
	 * Fluent wait for page load
	 */

	public static boolean waitForElementNotDisplayed(WebElement element,WebDriver driver,int timeInterval)
	{

		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(timeInterval))
				.pollingEvery(Duration.ofSeconds(2))
				.ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);
		return wait.until(ExpectedConditions.stalenessOf(element));


	}
	/***
	 * Fluent wait for page load 
	 */

	public static boolean waitForElementToLoadWithCustomWait(WebElement element,WebDriver driver,int timeInterval)
	{
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(timeInterval))
				.pollingEvery(Duration.ofSeconds(5))
				.ignoring(NoSuchSessionException.class)
				.ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);
		return wait.until(ExpectedConditions.visibilityOf(element)) != null;


	}

	/***
	 * Fluent wait for page load
	 */

	public static boolean waitForElementNotToBeVisible(WebElement element,WebDriver driver)
	{

		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(20))
				.pollingEvery(Duration.ofSeconds(2))
				.ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);
		return wait.until(ExpectedConditions.not(ExpectedConditions.visibilityOf(element))) != null;

	}

	/***
	 * Fluent wait for page load 
	 */

//	public static boolean waitForElementToLoadnew(WebElement element,WebDriver driver,int timeOutInSec)
//	{
//	
//	     FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
//	     			.withTimeout(30, TimeUnit.SECONDS)
//	     			.pollingEvery(500, TimeUnit.MILLISECONDS)
//	     			.ignoring(NoSuchElementException.class);
//	     	@SuppressWarnings("unchecked")
//			WebElement foo = wait.until(new Function() {
// 
//	     				public WebElement apply(WebDriver driver) {
// 
//	     						return driver.findElement(By.id("foo"));
// 
//	     						}
// 
//	     				});
//	}
	/**
	 * Frequency with which FluentWait has to check the conditions defined.
	 * Ignore specific types of exception waiting such as NoSuchElementExceptions while searching for an element on the page
	 * Maximum amount of time to wait for a condition
	 * @param welement
	 */
	public static void waitForWebElementFluently25(WebDriver driver,WebElement welement){
		long ELEMENT_WAIT_TIMEOUT = 30;
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		try {

			new FluentWait<WebElement>(welement).
					withTimeout(Duration.ofSeconds(25)).
					pollingEvery(Duration.ofSeconds(2)).
					until(new Function<WebElement, Boolean>() {
							  @Override
							  public Boolean apply(WebElement element) {
								  return element.isDisplayed();
							  }
						  }
					);
		} catch (NoSuchElementException e) {
			s_logger.info("WebElement Not Found / Doesn't Exist");
		}
		driver.manage().timeouts().implicitlyWait(ExecutionConfig.getInstance().getLongValue("ELEMENT_WAIT_TIMEOUT",  ELEMENT_WAIT_TIMEOUT), TimeUnit.SECONDS);
	}

	/**
	 * Frequency with which FluentWait has to check the conditions defined.
	 * Ignore specific types of exception waiting such as NoSuchElementExceptions while searching for an element on the page
	 * Maximum amount of time to wait for a condition
	 * @param welement
	 */
	public static void waitForWebElementFluently30(WebDriver driver,WebElement welement){
		long ELEMENT_WAIT_TIMEOUT = 30;
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		try {

			new FluentWait<WebElement>(welement).
					withTimeout(Duration.ofSeconds(30)).
					pollingEvery(Duration.ofSeconds(3)).
					until(new Function<WebElement, Boolean>() {
							  @Override
							  public Boolean apply(WebElement element) {
								  return element.isDisplayed();
							  }
						  }
					);
		} catch (NoSuchElementException e) {
			s_logger.info("WebElement Not Found / Doesn't Exist");
		}
		driver.manage().timeouts().implicitlyWait(ExecutionConfig.getInstance().getLongValue("ELEMENT_WAIT_TIMEOUT",  ELEMENT_WAIT_TIMEOUT), TimeUnit.SECONDS);
	}

	/**
	 * Frequency with which FluentWait has to check the conditions defined.
	 * Ignore specific types of exception waiting such as NoSuchElementExceptions while searching for an element on the page
	 * Maximum amount of time to wait for a condition
	 * @param welement
	 */
	public static void waitForWebElementFluently60(WebDriver driver,WebElement welement){
		long ELEMENT_WAIT_TIMEOUT = 60;
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		try {

			new FluentWait<WebElement>(welement).
					withTimeout(Duration.ofSeconds(60)).
					pollingEvery(Duration.ofSeconds(3)).
					until(new Function<WebElement, Boolean>() {
							  @Override
							  public Boolean apply(WebElement element) {
								  return element.isDisplayed();
							  }
						  }
					);
		} catch (NoSuchElementException e) {
			s_logger.info("WebElement Not Found / Doesn't Exist");
		}
		driver.manage().timeouts().implicitlyWait(ExecutionConfig.getInstance().getLongValue("ELEMENT_WAIT_TIMEOUT",  ELEMENT_WAIT_TIMEOUT), TimeUnit.SECONDS);

	}

	/**
	 * Frequency with which FluentWait has to check the conditions defined.
	 * Ignore specific types of exception waiting such as NoSuchElementExceptions while searching for an element on the page
	 * Maximum amount of time to wait for a condition
	 * @param welement
	 */
	public static void waitForWebElementFluently120(WebDriver driver,WebElement welement){
		long ELEMENT_WAIT_TIMEOUT = 120;
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		try {

			new FluentWait<WebElement>(welement).
					withTimeout(Duration.ofSeconds(120)).
					pollingEvery(Duration.ofSeconds(3)).
					until(new Function<WebElement, Boolean>() {
							  @Override
							  public Boolean apply(WebElement element) {
								  return element.isDisplayed();
							  }
						  }
					);
		} catch (NoSuchElementException e) {
			s_logger.info("WebElement Not Found / Doesn't Exist");
		}
		driver.manage().timeouts().implicitlyWait(ExecutionConfig.getInstance().getLongValue("ELEMENT_WAIT_TIMEOUT",  ELEMENT_WAIT_TIMEOUT), TimeUnit.SECONDS);

	}

	/**
	 * Frequency with which FluentWait has to check the conditions defined.
	 * Ignore specific types of exception waiting such as NoSuchElementExceptions while searching for an element on the page
	 * Maximum amount of time to wait for a condition
	 * @param welement
	 */
	public  static boolean isElementDisplayed5(WebDriver driver,WebElement welement){
		boolean blnFound =  true;
//		long ELEMENT_WAIT_TIMEOUT = 30;
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		try {

			new FluentWait<WebElement>(welement).
					withTimeout(Duration.ofSeconds(5)).
					pollingEvery(Duration.ofSeconds(1)).
					until(new Function<WebElement, Boolean>() {
							  @Override
							  public Boolean apply(WebElement element) {
								  return element.isDisplayed();
							  }
						  }
					);
		} catch (Exception e) {
			s_logger.info("WebElement Not Found / Doesn't Exist");
			blnFound = false;
		}
		// driver.manage().timeouts().implicitlyWait(ExecutionConfig.getInstance().getLongValue("ELEMENT_WAIT_TIMEOUT",  ELEMENT_WAIT_TIMEOUT), TimeUnit.SECONDS);
		return blnFound;
	}

	/**
	 * Frequency with which FluentWait has to check the conditions defined.
	 * Ignore specific types of exception waiting such as NoSuchElementExceptions while searching for an element on the page
	 * Maximum amount of time to wait for a condition
	 * @param welement
	 */
	public  static void waitForWebElementToHide(WebDriver driver,WebElement welement){
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		long ELEMENT_WAIT_TIMEOUT = 30;
		boolean found = true;
		int i=5;
		do{
			MigrationUtil.unconditionalWait(500);
			i--;
			found =  true;
			try {

				new FluentWait<WebElement>(welement).
						withTimeout(Duration.ofSeconds(3)).
						pollingEvery(Duration.ofSeconds(1)).
						until(new Function<WebElement, Boolean>() {
								  @Override
								  public Boolean apply(WebElement element) {
									  return element.isDisplayed();
								  }
							  }
						);
			} catch (Exception e) {
				s_logger.info("WebElement Not Found / Doesn't Exist");
				found = false;
			}
		}  while(found && i>0);
		driver.manage().timeouts().implicitlyWait(ExecutionConfig.getInstance().getLongValue("ELEMENT_WAIT_TIMEOUT",  ELEMENT_WAIT_TIMEOUT), TimeUnit.SECONDS);
	}

	/**
	 * Frequency with which FluentWait has to check the conditions defined.
	 * Ignore specific types of exception waiting such as NoSuchElementExceptions while searching for an element on the page
	 * Maximum amount of time to wait for a condition
	 * @param welement
	 */
	public  static boolean isElementDisplayedImplicit20(WebDriver driver,WebElement welement){
		boolean blnFound =  true;
//		long ELEMENT_WAIT_TIMEOUT = 30;
		//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		try {
			new FluentWait<WebElement>(welement).
					withTimeout(Duration.ofSeconds(20)).
					pollingEvery(Duration.ofSeconds(1)).
					until(new Function<WebElement, Boolean>() {
							  @Override
							  public Boolean apply(WebElement element) {
								  return element.isDisplayed();
							  }
						  }
					);
		} catch (NoSuchElementException e) {
			s_logger.info("WebElement Not Found / Doesn't Exist");
			blnFound = false;
		}
		// driver.manage().timeouts().implicitlyWait(ExecutionConfig.getInstance().getLongValue("ELEMENT_WAIT_TIMEOUT",  ELEMENT_WAIT_TIMEOUT), TimeUnit.SECONDS);
		return blnFound;
	}

	/***
	 * Fluent wait for page load 
	 */
	public static boolean waitForElementToLoadWithWait(WebElement element,WebDriver driver,int timeInterval)
	{
		try {
			FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
					.withTimeout(Duration.ofSeconds(timeInterval))
					.pollingEvery(Duration.ofSeconds(2))
					.ignoring(NoSuchSessionException.class)
					.ignoring(NoSuchElementException.class)
					.ignoring(StaleElementReferenceException.class);

			return wait.until(ExpectedConditions.visibilityOf(element)) != null;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			return false;
		}


	}

	/***
	 * Fluent wait for page load
	 */

	public static boolean waitForElementToLoadWithCustomWaitAndPolling(WebElement element,WebDriver driver,int timeInterval,int pooling)
	{
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(timeInterval))
				.pollingEvery(Duration.ofMillis(pooling))
				.ignoring(NoSuchSessionException.class)
				.ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);
		return wait.until(ExpectedConditions.visibilityOf(element)) != null;


	}

	/**
	 * Wait for element to be visible and click using javascript
	 * TimeOut exception is not handel as we need the test case to fail at the poit of failure and not to continue furter
	 */

	public static void waitForElemenAndClick(WebElement elementIn, WebDriver driver,int timeInterval ) {
		try {

			waitForElementToLoadWithCustomWait(elementIn, driver, timeInterval);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", elementIn);
		}catch(JavascriptException ele)
		{
			elementIn.click();
		}


	}

	public  static void updateIAMPwdSingleUser(String userName) throws Exception {

		ASDADataBaseTypes dbutil = new ASDADataBaseTypes();

		s_logger.info("Connecting ASDA DB");
		dbutil.openDBConnect();

		s_logger.info("Get IAM User Details From ASDA DB");
		List<String> getoutput = dbutil.fetchCustomerInfo(userName);

		if(getoutput!=null && getoutput.size()>0){

			s_logger.info("Customer ID is :" + getoutput.get(0));
			String custID = getoutput.get(0);

			s_logger.info("Email ID is :" + getoutput.get(1));
			String email = getoutput.get(1);

			s_logger.info("Concat Password is :" + getoutput.get(2));
			String cPwd = getoutput.get(2);

			s_logger.info("Executing step:IAM Update user Password");
			WS_IAM_User.getInstance().IAMUpdatePwd(custID, email, cPwd);
		}

		s_logger.info("Closing DB Connection");
		dbutil.closeDBconnet();
	}

	public static boolean waitForElementToLoad(HashMap<WebElement, Integer> ele, WebDriver driver) {
		try {
			@SuppressWarnings("deprecation")
			FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
					.withTimeout(20, TimeUnit.SECONDS)
					.pollingEvery(1, TimeUnit.SECONDS)
					.ignoring(NoSuchElementException.class)
					.ignoring(StaleElementReferenceException.class);
			return wait.until(ExpectedConditions.visibilityOf((WebElement) ele)) != null;
		}catch(TimeoutException e) {
			e.printStackTrace();
			s_logger.info("Web Element is not found after time out exception {} ",ele);
			return false;
		}
	}

	public static boolean waitForTillTextValueChanges(WebDriver newDriver, String textTochange, String xapth, int timeInterval) {

		try {
			//	FluentWait<WebDriver> wait = new FluentWait<WebDriver>(newDriver);
//		        .withTimeout(Duration.ofSeconds(timeInterval))
//		        .pollingEvery(Duration.ofSeconds(2))
//		        .ignoring(NoSuchSessionException.class)
//		        .ignoring(NoSuchElementException.class)
//		        .ignoring(StaleElementReferenceException.class);
//		
//		if( wait.until(ExpectedConditions.textToBePresentInElementValue(By.xpath(textTochange), textTochange)))
//				return false;
			s_logger.info("");
			WebDriverWait wait = new WebDriverWait(newDriver, timeInterval);
			wait.until(new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver driver) {
					if (driver.findElement(By.id(xapth)).getText().trim().isEmpty()){
						return Boolean.TRUE;
					}
					return false;
				}

			});

		} catch (TimeoutException e) {
			// TODO Auto-generated catch block
			return false;
		}
		return false;

	}

	public static boolean waitForElementToBeVisible(WebElement element,WebDriver driver) {

		FluentWait<WebDriver> wait = new FluentWait<>(driver)
				.withTimeout(Duration.ofSeconds(20))
				.pollingEvery(Duration.ofSeconds(2))
				.ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);
		return wait.until(ExpectedConditions.visibilityOf(element)) != null;

	}
	/*
	fluent wait untill element invisble
	 */
	public static boolean waitForElementToBeInvisible(WebElement element,WebDriver driver) {

		FluentWait<WebDriver> wait = new FluentWait<>(driver)
				.withTimeout(Duration.ofSeconds(20))
				.pollingEvery(Duration.ofSeconds(2))
				.ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);
		return wait.until(ExpectedConditions.invisibilityOf(element)) != null;

	}
}