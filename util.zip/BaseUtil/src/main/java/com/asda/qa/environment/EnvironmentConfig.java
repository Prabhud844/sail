package com.asda.qa.environment;

import java.io.IOException;
import java.util.Properties;

import static com.asda.core.baseexecution.BaseASDAFrontEndTest.APP_NAME;

/**
 * @author jkandul
 * 
 */
public class EnvironmentConfig {

	private static EnvironmentConfig s_instance;
	// Test
	private final Properties envProps;
	private String currentEnv;
	private static String subenv = "";

	private EnvironmentConfig(Properties props) {
		envProps = props;
	}

	private EnvironmentConfig(Properties props, String env) {
		envProps = props;
		currentEnv = env;
	}

	public synchronized static void initEnvironment(String env) {
		String[] arr = env.split("-");
		if(arr.length > 1) subenv = arr[1];
		else subenv = "";
		env = arr[0];

		if (s_instance != null) {
			System.out.println("Trying to reinitilize env with:" + env);
		}
		else {
			Properties props = new Properties();
			try {
				props.load(EnvironmentConfig.class.getClassLoader()
						.getResourceAsStream("com/asda/qa/environment/" + env + "config.properties"));
			} catch (IOException e) {
				throw new RuntimeException("Unable intialize environment.", e);
			}
			s_instance = new EnvironmentConfig(props, env);
		}
	}
	
	public String getSubenv() {
		if(subenv == null || subenv.isEmpty())
			subenv = "";
		return subenv;
	}
	
	public String getCurrentEnvironment() {
		return currentEnv;
	}

	public boolean isPRODEnv() {
		return getCurrentEnvironment().equalsIgnoreCase("PROD");
	}

	public static EnvironmentConfig getInstance() {
		if (s_instance == null) {
			throw new RuntimeException("Environment not initialized.");
		}
		return s_instance;
	}

	public String getHomePageUrl() {
		switch (APP_NAME) {
			case "FLAMINGO_GL_HOME":
				return envProps.getProperty("FLAMINGO_GOOD_LIVING_HOME_URL");
			case "GIFT_CARD":
				return envProps.getProperty("GIFT_CARD_HOME_URL");
			case "GL_HOME":
				return envProps.getProperty("FLAMINGO_GOOD_LIVING_HOME_URL");
			default:
				return envProps.getProperty("homepageUrl");
		}
	}

	public String getSeasonalityActiveStatus() {
		return envProps.getProperty("SeasonalityActiveStatus");
	}

	/**
	 * Return the value for this key from environment specific properties.
	 * 
	 * @param key
	 * @return
	 */
	public String getValueForKey(String key) {
		return envProps.getProperty(key);
	}

	/**
	 * Get Postcodes
	 * 
	 */

	public String getHomeDevliveryPostCode() {
		return envProps.getProperty("HDPostCode");
	}

	public String getEACViewPortForSmall() {
		return envProps.getProperty("EACConfSmall");
	}

	public String getEACViewPortForXXLarge() {
		return envProps.getProperty("EACConfXXLarge");
	}

	public String getEACViewPortForLarge() {
		return envProps.getProperty("EACConfLarge");
	}

	public String getEACViewPortForDefault() {
		return envProps.getProperty("EACConfLarge");
	}

	public String getEACViewPortForMed() {
		return envProps.getProperty("EACConfMed");
	}

	public String getEACViewPortForMedium() {
		return envProps.getProperty("EACConfMedium");
	}

	public String getHomeDeliveryPostCodeTwo() {
		return envProps.getProperty("hdPostCode.two");
	}

	public String getHomeDeliveryPostCodeThree() {
		return envProps.getProperty("hdPostCode.three");
	}

	public String getHomeDeliveryPostCodeFour() {
		return envProps.getProperty("hdPostCode.four");
	}

	public String getHomeDeliveryPostCodePangaeaTwo() {
		return envProps.getProperty("hdPostCode.Pangaea.two");
	}

	public String getCNCPostCode() {
		return envProps.getProperty("CNCPostCode");
	}

	public String getAmendOrderPostCode() {
		return envProps.getProperty("AmendOrders");
	}

	public String getAnotherCNCPostcode() {
		return envProps.getProperty("CNCAnotherPostCode");
	}

	public String getQuickregHomeDeliveryPostCode() {

		return envProps.getProperty("QuickRegHDPostCode");
	}

	public String getHDAnotherPostcode() {

		return envProps.getProperty("HDAnotherPostcode");
	}

	public String getCASPERCNCPostCode() {
		return envProps.getProperty("CNCCasperPostCode");
	}

	/**
	 * Get Search Keyword
	 */
	public String getSearchKeyword() {
		return envProps.getProperty("SearchKeyword");
	}

	/***
	 * returns second search keyword
	 * 
	 * @return
	 */
	public String getsearchkeyword2() {
		return envProps.getProperty("searchkeyword2");
	}

	public String getDYMSuggestedTerm() {
		return envProps.getProperty("DYMSuggestedTerm");
	}

	public String getQuickregHomeDeliveryPostCodeMessage() {
		return envProps.getProperty("QuickRegHDMessage");
	}

	public String getCasperCNCPostCodeOne() {

		return envProps.getProperty("cncCasperPostCode.one").trim();
	}

	public String getCasperRCNCPostCodeOne() {

		return envProps.getProperty("rcncCasperPostCode.one").trim();
	}

	// ORS

	/**
	 * get cins for linksave validation
	 */
	public String getoffer15cin() {
		return envProps.getProperty("Offer15CIN");
	}

	/**
	 * Get common search terms in Production
	 */
	public String getcommonsearchterm() {
		return envProps.getProperty("getcommonsearchterm");
	}

	public String getprductReview50Plus() {
		return envProps.getProperty("prductReview50Plus");
	}

	public String getRollBackProduct() {
		return envProps.getProperty("RollBackProduct");
	}

	public String getnewProduct() {
		return envProps.getProperty("newProduct");
	}

	public String getasdaPriceProductName() {
		return envProps.getProperty("asdaPriceProductName");
	}

	public String getSignOutPopText() {

		return envProps.getProperty("SignOutPopText").trim();
	}

	public String getSignoutPopupHeader() {

		return envProps.getProperty("SignoutPopupHeader").trim();
	}

	public String getSignOutbuttonTxt() {
		return envProps.getProperty("SignOutbuttonTxt").trim();
	}

	public String geteVoucherTitle() {
		return envProps.getProperty("eVoucherTitle").trim();
	}

	public String getAccountMessage1() {
		return envProps.getProperty("accountMessage1").trim();
	}

	public String getAccountMessage2() {
		return envProps.getProperty("accountMessage2").trim();
	}

	public String getSiginInPopUpTiltle() {
		return envProps.getProperty("siginInPopUpTiltle").trim();
	}

	public String getDBUrl() {

		return envProps.getProperty("DBurl");
	}

	public String getDBUserid() {

		return envProps.getProperty("DBUser");
	}

	public String getDBPwd() {

		return envProps.getProperty("DBpwd");
	}

	public String getIAMHead() {

		return envProps.getProperty("WMENV_REALMID").toUpperCase();
	}

	public String getExployerURL() {
		return envProps.getProperty("ExployerURL");
	}

	public String getExployeruserName() {
		return envProps.getProperty("Exployer_userName");
	}

	public String getExployerPass() {
		return envProps.getProperty("Exployer_pass");
	}

	public String getCatalogMaintainanceURL() {
		return envProps.getProperty("catalogMaintenance");
	}

	public String getRundeckURL() {
		return envProps.getProperty("rundeckURL");
	}

	public String getRundeckuserName() {
		return envProps.getProperty("rundeckuserName");
	}

	public String getRundeckPass() {
		return envProps.getProperty("rundeckpass");
	}

	public String getRundeckEmail() {
		return envProps.getProperty("rundeckEmail");
	}

	/**
	 * Get the Search Indexing URL
	 */
	public String getSearchIndexURL() {
		return envProps.getProperty("searchIndexURL");
	}

	public String getSearchIndexingURL() {
		return envProps.getProperty("searchIndexingURL");
	}

	public String getweightedProduct() {
		return envProps.getProperty("weightedProduct");

	}

	public String getjdbcDriver() {

		return envProps.getProperty("jdbcDriver").trim();
	}

	public String getSearchTuningBoostedRerankingStatus() {

		return envProps.getProperty("searchTuningBoostedRerankingStatus").trim();
	}

	public String getdbUrl() {

		return envProps.getProperty("dbUrl").trim();
	}

	public String getdbUserName() {

		return envProps.getProperty("dbUserName").trim();
	}

	public String getdbPassword() {

		return envProps.getProperty("dbPassword").trim();
	}

	/**
	 * Select OOOITEM_UNAVAILABLE_POSTCODE location
	 */
	public String getOOStockItem_Unavailable_Postcode() {
		return envProps.getProperty("OOSTOCK_ITEM_UNAVAILABLE_POSTCODE").trim();
	}

	public String getCategory1() {

		return envProps.getProperty("Category1").trim();
	}

	public String getDepartment2() {

		return envProps.getProperty("Department2").trim();
	}

	public String getGLOBALNAVIGATION_prd7() {

		return envProps.getProperty("GLOBALNAVIGATION_prd7").trim();
	}

	public String getGLOBALNAVIGATION_prd7_catid() {

		return envProps.getProperty("GLOBALNAVIGATION_prd7_catid").trim();
	}

	public String getjquerycdnurl() {
		return envProps.getProperty("jquerycdnurl").trim();
	}

	public String getapplicationcdnurl() {
		return envProps.getProperty("applicationcdnurl").trim();
	}

	public String getExployerApp1() {
		return envProps.getProperty("Exployer_Application1");
	}

	public String getExployerApp2() {
		return envProps.getProperty("Exployer_Application2");
	}

	public String getSearchdynadmincompURL() {
		return envProps.getProperty("searchcomponent");
	}

	public String getCocuhBaseURL() {
		return envProps.getProperty("couchbaseURL");
	}

	public String getRecurSlotInfoHeader() {
		return envProps.getProperty("recurSlotInfoHeader").trim();
	}

	public String getRecurSlotInfoTxt() {
		return envProps.getProperty("recurSlotInfoTxt").trim();
	}

	public String getRecurFindOutMoreLink() {
		return envProps.getProperty("recurFindOutMoreLink").trim();
	}

	public String getRecurSlotNote() {
		return envProps.getProperty("recurSlotNote").trim();
	}

	public String getRecurSlotTitle() {
		return envProps.getProperty("RecurSlotTitle").trim();
	}

	public String getRecurSlotFrequencyNote() {
		return envProps.getProperty("RecurSlotFrequencyNote").trim();
	}

	public String getRecurSlotHolidayNote() {
		return envProps.getProperty("RecurSlotHolidayNote").trim();
	}

	public String getRecurringSlotSuccesMsg() {
		return envProps.getProperty("RecurringSlotSuccesMsg").trim();
	}

	public String getDpInfoUserOne() {
		return envProps.getProperty("DpInfoUserOne").trim();
	}

	public String getRecurSlotManageInfo() {
		return envProps.getProperty("RecurSlotManageInfo").trim();
	}

	public String getrecurNotBookedMessageTitle() {
		return envProps.getProperty("recurNotBookedMessageTitle").trim();
	}

	public String getrecurNotbookedinfo1() {
		return envProps.getProperty("recurNotbookedinfo1").trim();
	}

	public String getrecurNotbookedinfo2() {
		return envProps.getProperty("recurNotbookedinfo2").trim();
	}

	public String getrecurNotbookedinfo3() {
		return envProps.getProperty("recurNotbookedinfo3").trim();
	}

	public String getDpErrorMessage() {
		return envProps.getProperty("dpErrorMessage").trim();
	}

	public String getFreqBoughtMessage1() {
		return envProps.getProperty("FreqBoughtMessage1").trim();
	}

	public String getFreqBoughtMessage2() {
		return envProps.getProperty("FreqBoughtMessage2").trim();
	}

	public CharSequence getFreqBoughtMessage3() {
		return envProps.getProperty("FreqBoughtMessage3").trim();
	}

	public String getestoreUrlThirdParty() {
		return envProps.getProperty("estoreUrlThirdParty").trim();
	}

	public String getOBIEEPRODurl() {
		return envProps.getProperty("OBIEEPRODurl");
	}

	public String getcolleagueRegistrationTitle() {
		return envProps.getProperty("colleagueRegistrationTitle");
	}

	public String getcolleagueRegistrationInfo() {
		return envProps.getProperty("colleagueRegistrationInfo");
	}

	public String getWalmartNumber() {
		return envProps.getProperty("WalmartNumber");
	}

	public String getDiscountRegistrationNumber() {
		return envProps.getProperty("DiscountRegistrationNumber");
	}

	public String getcolleagueRegistrationNote() {
		return envProps.getProperty("colleagueRegistrationNote");
	}

	public String getcolleagueRegistrationURL() {
		return envProps.getProperty("colleagueRegistrationURL");
	}

	public String getcolleagueRegistrationSuccessMsg() {
		return envProps.getProperty("colleagueRegistrationSuccessMsg");
	}

	public String getOOSProductWithoutAlternativesProduct() {
		return envProps.getProperty("OOSProductWithoutAlternativesProduct");
	}

	public String getOffer15CINProductName() {
		return envProps.getProperty("Offer15CINProductName");
	}

	public String getOffer8CINProductName() {
		return envProps.getProperty("Offer8CINProductName");
	}

	public String getOffer6CINProductName() {
		return envProps.getProperty("Offer6CINProductName");
	}

	public String getOffer12CINProductName() {
		return envProps.getProperty("Offer12CINProductName");
	}

	public String getBYGHookLogicContainerPosition() {
		return envProps.getProperty("bygHookLogicContainer.position").trim();
	}

	public String getBYGRichRelevanceContainerPosition() {
		return envProps.getProperty("bygRichRelevanceContainer.position").trim();
	}

	public String getOffer11CINProductName() {
		return envProps.getProperty("Offer11CINProductName");
	}

	public String getAsdaDotComUrl() {
		return envProps.getProperty("asdadotcomurl");
	}

	public String getLinkSaveOverlayTitle() {
		return envProps.getProperty("linkSaveOverlayTitle").trim();
	}

	public String getLinkSaveOverlayBannerText() {
		return envProps.getProperty("linkSaveOverlayBannerText").trim();
	}

	public String getNutritionalDimesionMapping() {
		return envProps.getProperty("NutritionalDimesionMapping");
	}

	public String getbothTypeProduct() {
		return envProps.getProperty("bothTypeProduct");
	}

	public String getSearchTuningJsonFile() {
		return envProps.getProperty("searchTuningJsonFile");
	}

	public String getSlotExpiryErrorMessage() {
		return envProps.getProperty("SlotExpiryErrorMessage");
	}

	public String getPaymentExpiryErrorMessage() {
		return envProps.getProperty("PaymentExpiryErrorMessage");
	}

	public String getLettingYouKnowOverlayTitle() {
		return envProps.getProperty("LettingYouKnowOverlayTitle");
	}

	public String getLettingYouKnowOverlayMessage() {
		return envProps.getProperty("LettingYouKnowOverlayMessage");
	}

	public String getLettingYouKnowOverlayDontShowLabel() {
		return envProps.getProperty("LettingYouKnowOverlayDontShowLabel");
	}

	public String getOmnitureFTPServer() {
		return envProps.getProperty("omnitureFTPServer");
	}

	public String getOmnitureFTPUsername() {
		return envProps.getProperty("omnitureFTPUsername");
	}

	public String getOmnitureFTPpassword() {
		return envProps.getProperty("omnitureFTPPassword");
	}

	public String getOmnitureFTPfileLocation() {
		return envProps.getProperty("omnitureFTPLocation");
	}

	public String getITLFTPServer() {
		return envProps.getProperty("ITLFTPServer");
	}

	public String getITLFTPUsername() {
		return envProps.getProperty("ITLFTPUsername");
	}

	public String getITLOmnitureFTPDirectory() {
		return envProps.getProperty("ITLOmnitureFTPDirectory");
	}

	public String getITLOmnitureFTPFile() {
		return envProps.getProperty("ITLOmnitureFTPFile");
	}

	public String getTibcoEmsUrl() {
		return envProps.getProperty("tibcoEmsUrl");
	}

	public String getTibcoEmsUser() {
		return envProps.getProperty("tibcoEmsUser");
	}

	public String getTibcoEmsPassword() {
		return envProps.getProperty("tibcoEmsPassword");
	}

	public String getOSDOBoverlayInfo1() {
		return envProps.getProperty("DOBoverlayInfo1");
	}

	public String getOSDOBoverlayInfo2() {
		return envProps.getProperty("DOBoverlayInfo2");
	}

	public String getOSDOBoverlayInfo3() {
		return envProps.getProperty("DOBoverlayInfo3");
	}

	public String getOSDOBTitle() {
		return envProps.getProperty("DOBTitle");
	}

	public String getOSDOBErrorMessage() {
		return envProps.getProperty("DOBErrorMessage");
	}

	public String getOutOfStockItemTwoCIN() {
		return envProps.getProperty("outOfStock.item.two.CIN").trim();
	}

	public String getOutOfStockItemTwoName() {
		return envProps.getProperty("outOfStock.item.two.Name").trim();
	}

	public String getOutOfStockItemTwoOOSPostCode() {
		return envProps.getProperty("outOfStock.item.two.OOSPostCode").trim();
	}

	public String getOutOfStockItemTwoAvailablePostCode() {
		return envProps.getProperty("outOfStock.item.two.AvailablePostCode").trim();

	}

	public String getauthCheckoutTomorrow() {
		return envProps.getProperty("authCheckoutTomorrow").trim();
	}

	public String getauthCheckoutTomorrowCollection() {
		return envProps.getProperty("authCheckoutTomorrowCollection").trim();
	}

	public String getauthCheckoutTodayDelivery() {
		return envProps.getProperty("authCheckoutTodayDelivery").trim();
	}

	public String getauthCheckoutTodayColletion() {
		return envProps.getProperty("authCheckoutTodayColletion").trim();
	}

	public String getauthCheckoutFutureDelivery() {
		return envProps.getProperty("authCheckoutFutureDelivery").trim();
	}

	public String getauthCheckoutFutureDeliveryOverlay() {
		return envProps.getProperty("authCheckoutFutureDeliveryOverlay").trim();
	}

	public String getauthCheckoutFutureDateCollection() {
		return envProps.getProperty("authCheckoutFutureDateCollection").trim();
	}

	public String getauthCheckoutFutureDateCollectionOverlay() {
		return envProps.getProperty("authCheckoutFutureDateCollectionOverlay").trim();
	}

	public String getPriceInfoOrderConfirmationPage() {
		return envProps.getProperty("PriceInfoOrderConfirmationPage").trim();
	}

	public CharSequence getForgottenSomething() {
		return envProps.getProperty("ForgottenSomething").trim();
	}

	public String getauthCheckoutOldTomorrowOverlay() {
		return envProps.getProperty("authCheckoutOldTomorrowOverlay").trim();
	}

	public String getauthCheckoutOldTomorrowNoteSection() {
		return envProps.getProperty("authCheckoutOldTomorrowNoteSection").trim();
	}

	public String getauthCheckoutOldBatchOverlay() {
		return envProps.getProperty("authCheckoutOldBatchOverlay").trim();
	}

	public String getauthCheckoutOldBatchNoteSectiong() {
		return envProps.getProperty("authCheckoutOldBatchNoteSection").trim();
	}

	public String getOffer2ProductName() {
		return envProps.getProperty("Offer2ProductName");
	}

	public String getCancelAmendOrderOverlayMessage() {
		return envProps.getProperty("CancelAmendOrderOverlayMessage").trim();
	}

	// Recipes

	public String getBrowseApp_RecipeSiteSpecUrl() {
		return envProps.getProperty("RecipesSitespecURL").trim();
	}

	public String getNewProductBrowse() {
		return envProps.getProperty("NewProductBrowse").trim();
	}

	public String getRollbackProductBrowse() {
		return envProps.getProperty("RollbackProductBrowse").trim();
	}

	public String getAsdaPriceProductBrowse() {
		return envProps.getProperty("AsdaPriceProductBrowse").trim();
	}

	public String getOutOfStockProductBrowseWithoutAlternaties() {
		return envProps.getProperty("OutOfStockProductBrowseWithoutAlternaties").trim();
	}

	public String getOutOfStockProductBrowse() {
		return envProps.getProperty("OutOfStockProductBrowse").trim();
	}

	public String getOutOfStockProductBrowseAlt() {
		return envProps.getProperty("OutOfStockProductBrowse").trim();
	}

	public String getUnavaliableProductBrowse() {
		return envProps.getProperty("UnavaliableProductBrowse").trim();
	}

	public String getBothTypProductBrowse() {
		return envProps.getProperty("BothTypProductBrowse").trim();
	}

	public String getWeightedTypeProductBrowse() {
		return envProps.getProperty("WeightedTypeProductBrowse").trim();
	}

	public String getGeorgeHomePageUrl() {
		return envProps.getProperty("georgeHomePageUrl").trim();
	}
	
	public String getEACSearchTerm() {
		return envProps.getProperty("eacSearchTerm").trim();
	}
	public String getEACSearchText() {
		return envProps.getProperty("eacSearchText").trim();
	}
	public String getEACMultiSearchTerm() {
		return envProps.getProperty("eacMultiSearchTerm").trim();
	}
	public String getEACSingleChar() {
		return envProps.getProperty("eacSingleChar").trim();
	}

	public String getEACLinkSaveSearchTerm() {
		return envProps.getProperty("eacLinkSaveSearchTerm").trim();
	}
	public String getDBUserid_RMS() { return envProps.getProperty("RMS_Username"); }
	public String getCinWithSpecialIcons() {
		return envProps.getProperty("cinWithSpecialIcons").trim(); }

	public String getAlertUserName(){
		return envProps.getProperty("pfedCertAlertLoginUserName").trim(); }

	public String getAlert(){
		return envProps.getProperty("pfedCertAlertLogin").trim();
	}

	public void setApplicationBaseUrl(String appName, String property) {
	}
}
