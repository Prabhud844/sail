package com.asda.qa.utility;

import javax.json.Json;
import javax.json.JsonObject;

import com.google.common.base.CharMatcher;
import com.asda.core.reporters.ReportListener;

import io.restassured.authentication.PreemptiveBasicAuthScheme;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class JiraUtils {
    private final MobileApiUtils api = new MobileApiUtils();




    public String createTask(String projectKey, String epic, String summary, String description, String assignee) {
        try {
            String encodedData = getJsonToCreateTask(projectKey, epic, summary, description, assignee);
            RequestSpecBuilder request = getBasicRequest("rest/api/2/issue/");
            request.setBody(encodedData);
            Response response = api.process(request).post();
            return response.jsonPath().getString("key");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void addComment(String jiraKey, String comments) {
        try {
            String encodedData = getJsonToAddComment(comments);
            RequestSpecBuilder request = getBasicRequest("rest/api/2/issue/" + jiraKey);
            request.setBody(encodedData);
            api.process(request).put();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getJsonToAddComment(String comment) {
        String cleanComment = CharMatcher.ascii().retainFrom(comment);
        JsonObject updateIssue = Json.createObjectBuilder()
                .add("update",
                        Json.createObjectBuilder().add("comment", Json.createArrayBuilder().add(
                                Json.createObjectBuilder().add("add",
                                        Json.createObjectBuilder().add("body", cleanComment))))
                ).build();
        return updateIssue.toString();
    }

    private String getJsonToCreateTask(String projectKey, String epic, String summary, String description, String assignee) {
        JsonObject createTask = Json.createObjectBuilder()
                .add("fields", Json.createObjectBuilder()
                        .add("project", Json.createObjectBuilder().add("key", projectKey))
                        .add("summary", summary)
                        .add("description", description)
                        .add("assignee", Json.createObjectBuilder().add("name", assignee))
                        .add("customfield_10007", epic)
                        .add("labels", Json.createArrayBuilder().add("AutomatedTestExecutions")
                                .add(ReportListener.TEST_RUN_ID))
                        .add("issuetype", Json.createObjectBuilder().add("name", "Task"))
                ).build();
        return createTask.toString();
    }

    private RequestSpecBuilder getBasicRequest(String path) {
        RequestSpecBuilder request = new RequestSpecBuilder();
        request.setBaseUri("https://jira.walmart.com/" + path);
        PreemptiveBasicAuthScheme auth = new PreemptiveBasicAuthScheme();
        auth.setUserName("Jbertus");
        auth.setPassword("Jb12345");
        request.setAuth(auth);
        request.setContentType(ContentType.JSON);
        return request;
    }
}
