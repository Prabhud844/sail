package com.asda.qa.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
public class DBlayer extends oracle.jdbc.driver.OracleDriver{
	
//	static final String JDBC_DRIVER = "oracle.jdbc.OracleDriver";  
//	   static final String DB_URL = "jdbc:oracle:thin:@dal-uk-scan-sr1.staging.walmart.com:51290/srv_asda_qa3_admin.gecwalmart.com";
//	   												 //  asdagrqa5.gecwalmart.com:1521/srv_asda_qa5_admin
//
//	   //  Database credentials
//	   static final String USER = "WRITEUKGUSER";
//	   static final String PASS = "UPdelwr2015";

	public static ArrayList<String> exectueQuery(String query,String JDBC_DRIVER, String DB_URL, String User, String Password) {
		// JDBC driver name and database URL		   
		
		//String query1 ="select max(order_id) from ATGORDER.dcspp_order where profile_id='1109550344' and state NOT IN ('INCOMPLETE') ";
		
		return  returnQueryResult(query,JDBC_DRIVER,DB_URL,User,Password);
		
	}


	
	public static ArrayList<String> returnQueryResult(String query,String JDBC_DRIVER,String DB_URL,String USER,String PASS)
	{
		 ArrayList<String> columns = new ArrayList<String>();
		 ArrayList<String> orderDetails = new ArrayList<String>();
		 int count =1;
		 
		int rows = 0;
		   Connection conn = null;
		   Statement stmt = null;
		   try{
		      
		      Class.forName("com.mysql.jdbc.Driver");

		      
		      System.out.println("Connecting to database...");
		      conn = DriverManager.getConnection(DB_URL,USER,PASS);

		  
		      System.out.println("Creating statement...");
		      stmt = conn.createStatement();
		      ResultSet resultSet = stmt.executeQuery(query);
		      ResultSetMetaData metadata = resultSet.getMetaData();
		      // commenting for current modification
		      int columnCount = metadata.getColumnCount();
		     
			    for (int i = 1; i <= columnCount; i++) {
				String columnName = metadata.getColumnName(i);
				columns.add(columnName);
			    }
		      
		      while (resultSet.next() ) {
//		    	  orderDetails.add("order" +count+ " details currently in the user profile");
		  		for (String columnName : columns) {		  			
		  		    String value = resultSet.getString(columnName);
		  		    orderDetails.add(columnName + " = " + value);
		  		  //  System.out.println(columnName + " = " + value);
		  		      }
		  	      count++;
		  		}
		  	    	
//		      while (resultSet.next() )
//		      {
//		      if(!resultSet.getString(1).isEmpty())
//		    	  return resultSet.getString(1).trim();
//		      }
		      resultSet.close();
		      stmt.close();
		      conn.close();
		      return orderDetails;
		   }catch(SQLException se){
		  	      se.printStackTrace();
		   }catch(Exception e){
		     
		      e.printStackTrace();
		   }finally{
		   
		      try{
		         if(stmt!=null)
		            stmt.close();
		      }catch(SQLException se2){
		      }
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }
		   }
		  return null;
	
		}
	}

