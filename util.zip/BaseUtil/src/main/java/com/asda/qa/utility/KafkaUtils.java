package com.asda.qa.utility;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.Future;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.poi.ss.formula.functions.T;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class KafkaUtils {

    private static final Logger s_logger = LoggerFactory.getLogger(KafkaUtils.class);

    //private Logger logger = LogManager.getLogger(this.getClass());

    private final Class <T> type;

    public KafkaUtils(Class type) {
        this.type = type;
    }

    private static KafkaConsumer<Long, String> createConsumer(String kafkaUri){
        final Properties props = new Properties();

        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaUri);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "CatalogKafkaConsumer_test");
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("enable.auto.commit","false");
        props.put("auto.offset.reset", "earliest");
        props.put("auto.commit.interval.ms", "1000");
        props.put("session.timeout.ms", "10000");
        KafkaConsumer<Long, String> consumer = new KafkaConsumer<>(props);
        return consumer;
    }

    public static List<String> readMessageFromKafka(String uri, String topicName) {

        final Consumer<Long, String> consumer = createConsumer(uri);
        consumer.subscribe(Collections.singletonList(topicName));
        List<String> kafkaMsgList = new ArrayList<>();
        final int giveUp = 100;
        int noRecordsCount = 0;

        while (true) {
            final ConsumerRecords<Long, String> consumerRecords =
                    consumer.poll(1000);

            if (consumerRecords.count() == 0) {
                noRecordsCount++;
                if (noRecordsCount > giveUp) break;
                else continue;
            }

            consumerRecords.forEach(record -> {
                kafkaMsgList.add(record.value());
            });

            consumer.commitAsync();
        }
        consumer.close();
        s_logger.info("Kafka message reading from Topic is completed!!");
        return kafkaMsgList;
    }

    public  void postMessageToKafka(String uri, String topicName, String msg){

        System.out.println("Kafka URI: "+ uri);
        System.out.println("Topic Name: "+ topicName);
        System.out.println("Message Content: "+ msg);

        Producer<String, String> producer = null;

        Properties props = new Properties();
        props.put("bootstrap.servers", uri);
        props.put("acks", "all");
        props.put("retries", 0);
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        //props.put("auto.create.topics.enable", false);

        producer = new KafkaProducer<>(props);

        try {
            producer = new KafkaProducer<String, String>(props);
        } catch (Exception e) {
            e.printStackTrace();
        }

        ProducerRecord<String, String> record = new ProducerRecord<String, String>(topicName, null, msg);
        if (producer != null) {
            try {
                Future<RecordMetadata> future = producer.send(record);
                RecordMetadata metadata = future.get();
                System.out.println("***************** Message Posted Successfully!! ********************");
            } catch (Exception e) {
                System.err.println(e.getMessage());
                e.printStackTrace();
            }
        }
        producer.close();
    }
}
