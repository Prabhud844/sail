package com.asda.qa.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Vector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

/**
 * @author Brameshwar Gupta(Brameshwar.gupta@walmartlabs.com)
 * 
 *         FTP utility to perform the action on SFTP/BFD/VM location
 */
public class FTPUtility {

	private static final Logger s_logger = LoggerFactory.getLogger(FTPUtility.class);

	private JSch ssh = null;
	private String server = null;
	private String username = null;
	private final int port;
	private Session session;
	private Channel channel;
	private ChannelSftp channelSftp;

	/**
	 * Constructor when username and port location is needed to connect the server
	 * 
	 * @param servername
	 * @param username
	 * @param port
	 */
	public FTPUtility(String servername, String username, int port) {
		this.server = servername;
		this.username = username;
		this.port = port;
	}

	/**
	 * Connects to the FTP server using password authentication
	 * 
	 * @param password
	 */
	public void ftpconnectWithPassword(String password) {
		try {
			ssh = new JSch();
			session = null;
			channel = null;
			channelSftp = null;
			session = ssh.getSession(username, server, port);
			s_logger.info("session created.");
			Properties config = new Properties();
			config.put("StrictHostKeyChecking", "no");
			config.put("PreferredAuthentications", "password");
			session.setConfig(config);
			session.setTimeout(15000);
			session.setPassword(password);
			s_logger.info("Password set...");
			session.connect();
			s_logger.info("Connecting to host {}", server);
			channel = session.openChannel("sftp");
			channel.connect();
			s_logger.info("shell channel connected....");
			channelSftp = (ChannelSftp) channel;
			s_logger.info("SFTP server Connected Successfully");
		} catch (JSchException e) {
			s_logger.info(e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Connects to the FTP server using SSH authentication with passphrase
	 * 
	 * @param privatekey
	 * @param passphrase
	 */
	public void ftpconnectWithSshKeyWithPassphrase(String privateKey, String passphrase) {
		try {

			ssh = new JSch();
			session = null;
			channel = null;
			channelSftp = null;
			ssh.addIdentity(FTPUtility.class.getClassLoader().getResource(privateKey).getPath(), passphrase);

			session = ssh.getSession(username, server, port);
			s_logger.info("session created.");
			session.setConfig("StrictHostKeyChecking", "no");
			session.setTimeout(15000);
			session.connect();

			channel = session.openChannel("sftp");
			channel.setInputStream(System.in);
			channel.setOutputStream(System.out);
			channel.connect();
			s_logger.info("shell channel connected....");
			channelSftp = (ChannelSftp) channel;
			s_logger.info("SFTP server Connected Successfully");

		} catch (JSchException e) {
			s_logger.info(e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Connects to the FTP server using SSH authentication without passphrase
	 * 
	 * @param privatekey
	 */
	public void ftpconnectWithSshKeyWithoutPassphrase(String privateKey) {
		try {

			ssh = new JSch();
			session = null;
			channel = null;
			channelSftp = null;
			ssh.addIdentity(FTPUtility.class.getClassLoader().getResource(privateKey).getPath());

			session = ssh.getSession(username, server, port);
			s_logger.info("session created.");
			session.setConfig("StrictHostKeyChecking", "no");
			session.setTimeout(15000);
			session.connect();

			channel = session.openChannel("sftp");
			channel.setInputStream(System.in);
			channel.setOutputStream(System.out);
			channel.connect();
			s_logger.info("shell channel connected....");
			channelSftp = (ChannelSftp) channel;
			s_logger.info("SFTP server Connected Successfully");

		} catch (JSchException e) {
			s_logger.info(e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * This method is to get the session object.
	 * 
	 * @return session
	 */
	public Session getSession() {
		return session;
	}

	/**
	 * Disconnect from the FTP server
	 */
	public void ftpDisconnect() {
		try {
			if (channelSftp != null)
				channelSftp.exit();
			if (channel != null)
				channel.disconnect();
			if (session != null)
				session.disconnect();
			channel = null;
			session = null;
			channelSftp = null;
			s_logger.info("FTP server Disconnected successfully");
		} catch (Exception e) {
			s_logger.info("Unable to Disconnect from FTP server");
			e.printStackTrace();
		}
	}

	/**
	 * connect with password, upload and disconnect from the SFTP server
	 * 
	 * @param password
	 * @param sftpDirectory
	 * @param fileToTransfer
	 * @return file size of the uploaded file
	 */
	public long connectWithPasswordAndUpload(String password, String sftpDirectory, String fileToTransfer) {
		ftpconnectWithPassword(password);
		long filesize = uploadFile(sftpDirectory, fileToTransfer);
		ftpDisconnect();
		return filesize;
	}

	/**
	 * connect with ssh with Passphrase, upload and disconnect from the SFTP server
	 * 
	 * @param privateKey
	 * @param sftpDirectoryPath
	 * @param fileToTransfer
	 * @return file size of the uploaded file
	 */
	public long connectWithSshWithoutPassphraseAndUpload(String privateKey, String sftpDirectory,
			String fileToTransfer) {
		ftpconnectWithSshKeyWithoutPassphrase(privateKey);
		long filesize = uploadFile(sftpDirectory, fileToTransfer);
		ftpDisconnect();
		return filesize;
	}

	/**
	 * connect with ssh using Passphrase, upload and disconnect from the SFTP server
	 * 
	 * @param privateKey
	 * @param sftpDirectoryPath
	 * @param fileToTransfer
	 * @return file size of the uploaded file
	 */
	public long connectWithSshWithPassphraseAndUpload(String privateKey, String sftpDirectory, String fileToTransfer,
			String passphrase) {
		ftpconnectWithSshKeyWithPassphrase(privateKey, passphrase);
		long filesize = uploadFile(sftpDirectory, fileToTransfer);
		ftpDisconnect();
		return filesize;
	}

	/**
	 * connect with password, download and disconnect from the SFTP server
	 *
	 * @param password
	 * @param sftpDirectory
	 * @param fileToTransfer
	 * @return file size of the uploaded file
	 */
	public boolean connectWithPasswordAndDownload(String password, String sftpDirectory, String fileToDownload,
			String destinationPath) {

		boolean status = false;
		ftpconnectWithPassword(password);
		status = downloadFile(sftpDirectory, fileToDownload, destinationPath);
		ftpDisconnect();
		return status;
	}

	/**
	 * Connect SFTP with SSH without Passphrase, download and disconnect from the
	 * SFTP server
	 *
	 * @param privateKey
	 * @param sftpDirectory
	 * @param fileToTransfer
	 * @return status
	 */
	public boolean connectWithSshWithoutPassphraseAndDownload(String privateKey, String sftpDirectory,
			String fileToDownload, String destinationPath) {
		boolean status = false;
		ftpconnectWithSshKeyWithoutPassphrase(privateKey);
		status = downloadFile(sftpDirectory, fileToDownload, destinationPath);
		ftpDisconnect();
		return status;
	}

	/**
	 * Connect SFTP with SSH using Passphrase, download and disconnect from the SFTP
	 * server
	 *
	 * @param privateKey
	 * @param sftpDirectory
	 * @param fileToTransfer
	 * @return status
	 */
	public boolean connectWithSshWithPassphraseAndDownload(String privateKey, String sftpDirectory,
			String fileToDownload, String destinationPath, String passphrase) {
		boolean status = false;
		ftpconnectWithSshKeyWithPassphrase(privateKey, passphrase);
		status = downloadFile(sftpDirectory, fileToDownload, destinationPath);
		ftpDisconnect();
		return status;
	}

	/**
	 * Connect SFTP with password, execute command and disconnects from SFTP server
	 * 
	 * @param command
	 *            multiple lines of the commands should be separated with ;
	 * @param password
	 * @return output of the executed command
	 */
	public String connectWithPasswordAndRunCommand(String command, String password) {
		ftpconnectWithPassword(password);
		String output = runCommandOnVM(command);
		ftpDisconnect();
		return output;
	}

	/**
	 * Connect SFTP with SSH without Passphrase, execute command and disconnects
	 * from SFTP server
	 * 
	 * @param command
	 *            multiple lines of the commands should be separated with ;
	 * @param password
	 * @return output of the executed command
	 */
	public String connectWithSshWithoutPassphraseAndRunCommand(String command, String privateKey) {
		ftpconnectWithSshKeyWithoutPassphrase(privateKey);
		String output = runCommandOnVM(command);
		ftpDisconnect();
		return output;
	}

	/**
	 * Connect SFTP with SSH using Passphrase, execute command and disconnects from
	 * SFTP server
	 * 
	 * @param command
	 *            multiple lines of the commands should be separated with ;
	 * @param password
	 * @return output of the executed command
	 */
	public String connectWithSshWithPassphraseAndRunCommand(String command, String privateKey, String passphrase) {
		ftpconnectWithSshKeyWithPassphrase(privateKey, passphrase);
		String output = runCommandOnVM(command);
		ftpDisconnect();
		return output;
	}

	/**
	 * Connect SFTP with password, fetch the list of file on the server for the
	 * given folder location and disconnects from SFTP server
	 * 
	 * @param folderLocation
	 * @param password
	 * @return list of files
	 */
	public ArrayList<String> connectWithPasswordAndreadFileListForFolder(String folderLocation, String password) {
		ArrayList<String> contents = new ArrayList<String>();
		ftpconnectWithPassword(password);
		contents = readFileListForFolder(folderLocation);
		ftpDisconnect();
		return contents;
	}

	/**
	 * Connect SFTP with SSH Without Passphrase, fetch the list of file on the
	 * server for the given folder location and disconnects from SFTP server
	 * 
	 * @param folderLocation
	 * @param password
	 * @return list of files
	 */
	public ArrayList<String> connectWithSshWithoutPassphraseAndreadFileListForFolder(String folderLocation,
			String privateKey) {
		ArrayList<String> contents = new ArrayList<String>();
		ftpconnectWithSshKeyWithoutPassphrase(privateKey);
		contents = readFileListForFolder(folderLocation);
		ftpDisconnect();
		return contents;
	}

	/**
	 * Connect SFTP with SSH using Passphrase, fetch the list of file on the server
	 * for the given folder location and disconnects from SFTP server
	 * 
	 * @param folderLocation
	 * @param password
	 * @return list of files
	 */
	public ArrayList<String> connectWithSshWithPassphraseAndreadFileListForFolder(String folderLocation,
			String privateKey, String passphrase) {
		ArrayList<String> contents = new ArrayList<String>();
		ftpconnectWithSshKeyWithPassphrase(privateKey, passphrase);
		contents = readFileListForFolder(folderLocation);
		ftpDisconnect();
		return contents;
	}

	/**********************************
	 * Private methods needed to drive the operation for this class
	 *****************************/

	/**
	 * Upload the file to the connected SFTP location at the SFTP server
	 *
	 * @param sftpDirectoryPath
	 * @param fileToTransfer
	 * @return file size of the uploaded file
	 */
	private long uploadFile(String sftpDirectory, String fileToTransfer) {
		long filesize = 0L;
		try {
			channelSftp.cd(sftpDirectory);
			s_logger.info("Changed the directory to..." + sftpDirectory);
			s_logger.info("In directory {}", channelSftp.pwd());
			s_logger.info("Before Placing file ... ");
			Vector filelist = channelSftp.ls(sftpDirectory);
			for (int i = 0; i < filelist.size(); i++) {
				LsEntry entry = (LsEntry) filelist.get(i);
				s_logger.info("{}", entry.getFilename());
			}

			File f = new File(FTPUtility.class.getClassLoader().getResource(fileToTransfer).getPath());
			s_logger.info("Uploading file started..." + f.getCanonicalPath());
			channelSftp.put(new FileInputStream(f), f.getName());
			s_logger.info("File uploaded to SFTP Directory: " + sftpDirectory);

			s_logger.info("In directory {}", channelSftp.pwd());
			s_logger.info("After Placing file ... ");

			boolean uplaodstatus = false;

			filelist = channelSftp.ls(sftpDirectory);
			for (int i = 0; i < filelist.size(); i++) {
				LsEntry entry = (LsEntry) filelist.get(i);
				s_logger.info("{}", entry.getFilename());
				if (entry.getFilename().equalsIgnoreCase(f.getName())) {
					filesize = entry.getAttrs().getSize();
					uplaodstatus = true;
					s_logger.info("File placed successfully with file size as {}", filesize);
				}
			}
			if (!uplaodstatus) {
				s_logger.info("Uploaded file do not exist in the server directory {}", channelSftp.pwd());
				throw new Exception("Uploaded file do not exist in the server directory");
			}

		} catch (Exception ex) {
			s_logger.info("Failed to upload file {}", ex.getMessage());
		}

		return filesize;
	}

	/**
	 * Download the file to the connected sftp location at the SFTP server
	 *
	 * @param privateKey
	 * @param sftpDirectory
	 * @param fileToDownload
	 * @param destinationPath
	 * @return status
	 */
	private boolean downloadFile(String sftpDirectory, String fileToDownload, String destinationPath) {
		boolean status = false;
		try {
			channelSftp.cd(sftpDirectory);
			s_logger.info("Changed the directory to..." + sftpDirectory);
			s_logger.info("In directory {}", channelSftp.pwd());
			destinationPath = FTPUtility.class.getClassLoader().getResource(destinationPath).getPath();
			channelSftp.get(fileToDownload, destinationPath);
			s_logger.info("File has been downloaded... {} ", fileToDownload);
			status = true;
		} catch (Exception ex) {
			status = false;
			s_logger.info("Failed to download file {}", ex.getMessage());
		}
		return status;
	}

	/**
	 * Executed command on the connected SFTP server
	 * 
	 * @param command
	 *            multiple lines of the commands should be separated with ;
	 * @return execution output
	 */
	private String runCommandOnVM(String command) {
		String output = "";
		int i = 0;
		try {
			channel = session.openChannel("exec");
			((ChannelExec) channel).setCommand(command);
			channel.setInputStream(null);
			((ChannelExec) channel).setErrStream(System.err);
			InputStream in = channel.getInputStream();
			channel.connect();

			byte[] tmp = new byte[1024];

			while (true) {
				while (in.available() > 0) {
					i = in.read(tmp, 0, 1024);
					if (i < 0)
						break;
				}
				if (channel.isClosed()) {
					s_logger.info("exit-status: " + channel.getExitStatus());
					break;
				}
				try {
					Thread.sleep(1000);
				} catch (Exception ee) {

				}
			}
			output = new String(tmp, 0, i);

		} catch (Exception ex) {
			s_logger.info("Failed to execute the commandas {}", ex.getMessage());
			ex.printStackTrace();
		}
		return output;
	}

	/**
	 * Provides the list of file on the server for the given folder location
	 * 
	 * @param folderLocation
	 * @return list of files
	 */
	private ArrayList<String> readFileListForFolder(String folderLocation) {
		ArrayList<String> contents = new ArrayList<String>();
		try {
			channelSftp.cd(folderLocation);
			@SuppressWarnings("unchecked")
			Vector<ChannelSftp.LsEntry> list = ((ChannelSftp) channel).ls("*.*");
			for (ChannelSftp.LsEntry entry : list) {
				contents.add(entry.getFilename());
			}
		} catch (SftpException e) {
			s_logger.info(e.getMessage());
		}
		return contents;
	}
}