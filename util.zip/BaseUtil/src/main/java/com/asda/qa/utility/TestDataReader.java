package com.asda.qa.utility;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import com.asda.core.utils.FileReader;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.util.LinkedHashMap;
import java.util.LinkedList;


public class TestDataReader {
	
	private static final Logger s_logger = LoggerFactory.getLogger(TestDataReader.class);

	// To retrieve all records having one column
	public List<String> getTestDataValues(String excelFilePath)  {
		
	      InputStream io = null;
	      if (excelFilePath.toLowerCase().startsWith("c:\\")
					|| excelFilePath.toLowerCase().startsWith("c:/")) {
				io = FileReader.getInstance().readInputStreamFromDisk(excelFilePath);
			} else {
				io = FileReader.getInstance().readInputStreamFromClassPath(
						excelFilePath);
			}
	      List<String> rec = new ArrayList<String>();
	        try{ 
	        Workbook workbook;
			workbook = new XSSFWorkbook(io);
	        Sheet firstSheet = workbook.getSheetAt(0);
	        Iterator<Row> iterator = firstSheet.iterator();
	        
	        
	        while (iterator.hasNext()) {
	            Row nextRow = iterator.next();
	            Iterator<Cell> cellIterator = nextRow.cellIterator();
	             
	            while (cellIterator.hasNext()) {
	                Cell cell = cellIterator.next();
	                 
	                switch (cell.getCellType()) {
	                    case Cell.CELL_TYPE_STRING:
	                        System.out.println(cell.getStringCellValue());
	                        rec.add(cell.getStringCellValue());
	                        break;
/*	                    case Cell.CELL_TYPE_BOOLEAN:
	                        System.out.print(cell.getBooleanCellValue());
	                        break;
	                    case Cell.CELL_TYPE_NUMERIC:
	                        System.out.print(cell.getNumericCellValue());
	                        break;*/
	                }
	            }
	        }
	       } catch (FileNotFoundException  e) {
				e.printStackTrace();
			}
			 catch (IOException e) {
				e.printStackTrace();
			}
	      finally{
	        try {
				io.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
	      }
			return rec;

	}
	
	// To retrieve all column values for a particular row using key Name for a row
	public static Map<String, String> getTestDataValues(String keyName,	String fileLocation) {

		// Read input stream
		InputStream io = null;
		if (fileLocation.toLowerCase().startsWith("c:\\")
				|| fileLocation.toLowerCase().startsWith("c:/")) {
			io = FileReader.getInstance().readInputStreamFromDisk(fileLocation);
		} else {
			io = FileReader.getInstance().readInputStreamFromClassPath(
					fileLocation);
		}
		Assert.assertNotNull(io, "unable to read file");

		XSSFWorkbook wb = null;
		try {
			wb = new XSSFWorkbook(io);
		} catch (IOException e) {
			s_logger.error("unable to read data file", e);
			Assert.fail("unable to read data file", e);
		}
		XSSFSheet sheet = wb.getSheetAt(0);
		LinkedList<String> columnNames = getColumnNames(sheet, keyName);
		LinkedHashMap<String, String> testDataMap = findTestDataRows(sheet,
				keyName, columnNames);
		return testDataMap;
	}

	// To retrieve column names for first sheet
	private static LinkedList<String> getColumnNames(XSSFSheet sheet,
			String dataKey) {
		LinkedList<String> columnList = new LinkedList<String>();
		Row row = sheet.getRow(0);
		int firstColNum = row.getFirstCellNum();
		int lastColNum = row.getLastCellNum();
		for (int i = firstColNum; i < lastColNum; i++) {
			if (row.getCell(i) == null || row.getCell(i).toString().isEmpty()) {
				columnList.add("BlankColumn");
				continue;
			}
			String cell = row.getCell(i).toString();
			columnList.add(cell);
		}
		return columnList;
	}

	// To set all column values for a particular row in a LinkedHashMap
	private static LinkedHashMap<String, String> findTestDataRows(
			XSSFSheet sheet, String dataKey, LinkedList<String> columnNames) {
		LinkedHashMap<String, String> sheetData = new LinkedHashMap<String, String>();
		try {
			int firstColNum = 0;
			int firstrowNum = sheet.getFirstRowNum();
			int lastrownum = sheet.getLastRowNum();
			System.out.println(firstrowNum + " " + lastrownum);
			outerloop: for (int i = firstrowNum; i <= lastrownum; i++) {
				Row row = sheet.getRow(i);
				if (i == 0) {
					firstColNum = row.getFirstCellNum();
				}
				XSSFCell cell = (XSSFCell) row.getCell(0);
				if (cell == null) {
					continue;
				}
				Cell testIdSheet = row.getCell(0);
				testIdSheet.setCellType(Cell.CELL_TYPE_STRING);
				if (testIdSheet.getStringCellValue().trim().equals(dataKey)) {
					for (int j = firstColNum; j < columnNames.size(); j++) {
						String value = "";
						String columnName = "";
						columnName = columnNames.get(j);
						cell = (XSSFCell) row.getCell(j);
						if (columnName.equalsIgnoreCase("BlankColumn")) {
							continue;
						} else if (cell == null
								|| row.getCell(j).toString().isEmpty()) {
							cell = (XSSFCell) row.createCell(j);
							value = String.valueOf(cell);
							sheetData.put(columnName, value);
						} else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
							cell.setCellType(Cell.CELL_TYPE_STRING);
							value = String.valueOf(cell);
							sheetData.put(columnName, value);
						} else {
							cell = (XSSFCell) row.getCell(j);
							value = String.valueOf(cell);
							sheetData.put(columnName, value);
						}
					}
					break outerloop;
				}
			}
		}

		catch (Exception e) {
			s_logger.error("Unable to fetch the row", e);
			Assert.fail("Unable to fetch the row", e);
		}
		return sheetData;
	}	
	
	// To set Two column values for all rows in a LinkedHashMap - Ex: Search / Shelf rules
	// column 1: as key , column 2: as value
	public LinkedHashMap<String, String> getTwoColumnTestDataRows(String fileLocation) {
		// Read input stream
		InputStream io = null;
		if (fileLocation.toLowerCase().startsWith("c:\\")
				|| fileLocation.toLowerCase().startsWith("c:/")) {
			io = FileReader.getInstance().readInputStreamFromDisk(fileLocation);
		} else {
			io = FileReader.getInstance().readInputStreamFromClassPath(
					fileLocation);
		}
		Assert.assertNotNull(io, "unable to read file");

		XSSFWorkbook wb = null;
		try {
			wb = new XSSFWorkbook(io);
		} catch (IOException e) {
			s_logger.error("unable to read data file", e);
			Assert.fail("unable to read data file", e);
		}
		XSSFSheet sheet = wb.getSheetAt(0);
		
		LinkedHashMap<String, String> sheetData = new LinkedHashMap<String, String>();
		try {
			int firstrowNum = sheet.getFirstRowNum();
			int lastrownum = sheet.getLastRowNum();
			System.out.println(firstrowNum + " " + lastrownum);
			String key = ""; // Column 1 name
			String value = ""; // Column 2 name
			for (int i = firstrowNum+1; i <= lastrownum; i++) {
				Row row = sheet.getRow(i);
				XSSFCell keyCell = (XSSFCell) row.getCell(0);
				XSSFCell valueCell = (XSSFCell) row.getCell(1);
				if (keyCell == null) {
					continue;
				}else{
					key = String.valueOf(keyCell);
					valueCell= (XSSFCell) row.getCell(1);
					value = String.valueOf(valueCell);
					sheetData.put(key, value);
				}
			}
			//s_logger.info("Sheet Data size : "+sheetData.size());			
		}

		catch (Exception e) {
			s_logger.error("Unable to fetch the row", e);
			Assert.fail("Unable to fetch the row", e);
		}
		return sheetData;
	}	
}