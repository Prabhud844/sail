package com.asda.qa.utility;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;
import javax.sql.DataSource;
import com.asda.core.utils.MigrationUtil;
import com.asda.qa.environment.EnvironmentConfig;
import org.apache.commons.dbcp.ConnectionFactory;
import org.apache.commons.dbcp.DriverManagerConnectionFactory;
import org.apache.commons.dbcp.PoolableConnectionFactory;
import org.apache.commons.dbcp.PoolingDataSource;
import org.apache.commons.pool.impl.GenericObjectPool;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.asda.qa.data.SQLQueries;
import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ColumnDefinitions;
import com.datastax.driver.core.Host;
import com.datastax.driver.core.Metadata;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import org.testng.Assert;

/**
 * The Class SQLUtils.
 *
 * @author b0g00cf
 */

public class SQLUtils {

    /** The conn. */

    public static Connection conn = null;

    /** The stmt. */
    PreparedStatement stmt = null;

    /** The rs. */
    ResultSet rs = null;

    /** The maria db details. */
    HashMap<String, String> mariaDbDetails;
    HashMap<String, String> cassandraDbDetails;

    /** The oracle db details. */
    HashMap<String, String> oracleDbDetails;
    HashMap<String, String> azureDbDetails;
    HashMap<String, String> db2DbDetails;

    /** The db details map. */
    HashMap<String, String> dbDetailsMap;

    /** The cluster. */
    private Cluster cluster;

    /** The session. */
    private Session session;

    /** The data source. */
    DataSource dataSource;
    private static GenericObjectPool connection_pool = null;
    /** The Constant s_logger. */
    private static final Logger s_logger = LoggerFactory.getLogger(SQLUtils.class);

    /**
     * Instantiates a new SQL utils.
     *
     * @param env
     *            the env
     */
    public SQLUtils(String env) {
        this.mariaDbDetails = GeneralUtility.getMariaDBDetails(env, "");
        this.oracleDbDetails = GeneralUtility.getOracleDBDetails(env, "");
        this.cassandraDbDetails = GeneralUtility.getCassandraDBDetails(env, "");
        this.azureDbDetails = GeneralUtility.getAzureDBDetails(env, "");
        this.db2DbDetails = GeneralUtility.getDB2Details(env, "");
        dbDetailsMap = oracleDbDetails;
    }

    /**
     * Instantiates a new SQL utils.
     *
     * @param env
     *            the env
     * @param userType
     *            the user type
     */
    public SQLUtils(String env, String userType) {
        this.mariaDbDetails = GeneralUtility.getMariaDBDetails(env, userType);
        this.oracleDbDetails = GeneralUtility.getOracleDBDetails(env, userType);
        this.cassandraDbDetails = GeneralUtility.getCassandraDBDetails(env, userType);
        this.azureDbDetails = GeneralUtility.getAzureDBDetails(env, userType);
        this.db2DbDetails = GeneralUtility.getDB2Details(env, userType);

        if(userType.equals("CATALOG")) this.azureDbDetails = GeneralUtility.getCatalogAzureDBDetails(env, userType);

        dbDetailsMap = oracleDbDetails;
    }

    /**
     * Creates the connection.
     *
     * @throws SQLException
     *             the SQL exception
     */
    private void createConnection() throws SQLException, ClassNotFoundException {
        if (conn == null) {
            // Register JDBC driver

            if(dbDetailsMap.get("DB_DRIVER").contains("DB2Driver")){
                Class.forName(dbDetailsMap.get("DB_DRIVER"));
            }else {
                Driver myDriver = new oracle.jdbc.driver.OracleDriver();
                DriverManager.registerDriver(myDriver);
            }
            // Open a connection
            s_logger.info("Connecting to a selected database...");
            conn = DriverManager.getConnection(dbDetailsMap.get("DB_CONNECTION_URL"), dbDetailsMap.get("DB_USERNAME"),
                    dbDetailsMap.get("DB_PASSWORD"));
            s_logger.info("Connected database successfully...");

        } else {
            //conn = dataSource.getConnection();
            s_logger.info("Connected database successfully using Pool...");
        }
    }

    public DataSource setUpPool(String JDBC_DRIVER,String JDBC_DB_URL,String JDBC_USER,String JDBC_PASS) throws Exception {
        Class.forName(JDBC_DRIVER);

        // Creates an Instance of GenericObjectPool That Holds Our Pool of Connections Object!
        connection_pool = new GenericObjectPool();
        connection_pool.setMaxActive(5);

        // Creates a ConnectionFactory Object Which Will Be Use by the Pool to Create the Connection Object!
        ConnectionFactory cf = new DriverManagerConnectionFactory(JDBC_DB_URL, JDBC_USER, JDBC_PASS);

        // Creates a PoolableConnectionFactory That Will Wraps the Connection Object Created by the ConnectionFactory to Add Object Pooling Functionality!
        PoolableConnectionFactory pcf = new PoolableConnectionFactory(cf, connection_pool, null, null, false, true);
        return new PoolingDataSource(connection_pool);
    }

    /**
     * Gets the data from maria DB.
     *
     * @param sqlName
     *            the sql name
     * @param sqlParams
     *            the sql params
     * @return the data from maria DB
     */
    public String[][] getDataFromMariaDB(String sqlName, String[] sqlParams) {
        dbDetailsMap = mariaDbDetails;
        return readTableFromDB(sqlName, sqlParams);
    }

    /**
     * Gets the data from maria DB.
     *
     * @param sqlName
     *            the sql name
     * @return the data from maria DB
     */
    public String[][] getDataFromMariaDB(String sqlName) {
        dbDetailsMap = mariaDbDetails;
        return readTableFromDB(sqlName, null);
    }

    /**
     * Gets the data from Cassandra DB.
     *
     * @param sqlName
     *            the sql name
     * @param sqlParams
     *            the sql params
     * @return the data from maria DB
     */
    public String[][] getDataFromCassandraDB(String sqlName, String[] sqlParams) {
        dbDetailsMap = cassandraDbDetails;
        return getCassandraData(sqlName, sqlParams);
    }

    public String[][] getDataFromAzureDB(String sqlName) {
        dbDetailsMap = azureDbDetails;
        return getAzureData(sqlName, null);
    }

    public String[][] getDataFromAzureDB(String sqlName, String[] sqlParams) {
        if(EnvironmentConfig.getInstance().getCurrentEnvironment().equalsIgnoreCase("qa2")){
            dbDetailsMap = oracleDbDetails;
            return getDataFromDB(sqlName, sqlParams);
        }
        dbDetailsMap = azureDbDetails;
        return getAzureData(sqlName, sqlParams);
    }
    //Test
    public String[][] getDataFromAzureDB(String sqlName, String[] sqlParams,int lsize) {
        dbDetailsMap = azureDbDetails;
        return getAzureData(sqlName, sqlParams,lsize);
    }

    public boolean runUpdateQueryOnAzure(String sqlName, String[] sqlParams) {
        dbDetailsMap = azureDbDetails;
        return updateAzureTable(sqlName, sqlParams);
    }

    /**
     * Gets the data from Cassandra DB.
     *
     * @param sqlName
     *            the sql name
     * @param sqlParams
     *            the sql params
     * @return the data from maria DB
     */
    public String[][] getDataFromCassandraDBWithConnectionAlive(String sqlName, String[] sqlParams) {

        try {
            String query = (SQLQueries.valueOf(sqlName)).getSQL();

            if ( null != sqlParams )
                query = buildQuery(query, sqlParams);
            s_logger.info("Executing Query :: "+query);
            com.datastax.driver.core.ResultSet rs = session.execute(query);
            ColumnDefinitions cd = rs.getColumnDefinitions();

            int colCount = cd.size();

            List<Row> rowList = rs.all();
            String[][] data = new String[rowList.size()][colCount];
            rs.one();
            String value = "";
            int x = 0, y = 0;
            for (Row row : rowList) {
                for (int i = 0; i < colCount; i++) {
                    switch (cd.getType(i).getName().name().toUpperCase()) {
                        case "VARCHAR":
                            value = row.getString(i);
                            break;
                        case "BIGINT":
                            value = String.valueOf(row.getLong(i));
                            break;
                        case "BOOLEAN":
                            value = String.valueOf(row.getBool(i));
                            break;
                        case "BLOB":
                            value = String.valueOf(row.getBytes(i));
                            break;
                        case "DOUBLE":
                            value = String.valueOf(row.getDouble(i));
                            break;
                        case "INT":
                            value = String.valueOf(row.getInt(i));
                            break;
                        case "TIMESTAMP":
                            value = String.valueOf(row.getTimestamp(i));
                            break;
                        case "TIMEUUID":
                            value = String.valueOf(row.getUUID(i));
                            break;
                        default:
                            s_logger.error("UNEXPECTED COLUMN TYPE: columname=" + cd.getName(i) + ", columntype="
                                    + cd.getType(i).getName().name().toUpperCase());
                    }
                    data[x][y++] = value;
                }
                y = 0;
                x++;
            }
            return data;
        } catch (Exception e) {
            s_logger.info("ERROR: Fetching data from Cassandra Database!!");
            e.printStackTrace();
            closeCassandraConnection();
            return null;
        }
    }

    /**
     * Gets the data from Cassandra DB.
     *
     * @param sqlName
     *            the sql name
     * @return the data from maria DB
     */
    public String[][] getDataFromCassandraDB(String sqlName) {
        dbDetailsMap = cassandraDbDetails;
        return getCassandraData(sqlName, null);
    }

    /**
     * Gets the data from DB.
     *
     * @param sqlName
     *            the sql name
     * @param sqlParams
     *            the sql params
     * @return the data from DB
     */
    public String[][] getDataFromDB(String sqlName, String[] sqlParams) {
        if(EnvironmentConfig.getInstance().getCurrentEnvironment().equalsIgnoreCase("pqa")
        || EnvironmentConfig.getInstance().getCurrentEnvironment().equalsIgnoreCase("stage")
        || EnvironmentConfig.getInstance().getCurrentEnvironment().equalsIgnoreCase("prod")){
            dbDetailsMap = azureDbDetails;
            return getDataFromAzureDB(sqlName, sqlParams);
        }
        dbDetailsMap = oracleDbDetails;
        return  readTableFromDB(sqlName, sqlParams);
    }

    /**
     * Gets the data from DB.
     *
     * @param sqlName
     *            the sql name
     * @return the data from DB
     */
    public String[][] getDataFromDB(String sqlName) {
        dbDetailsMap = oracleDbDetails;
        s_logger.info("*********** Database Details *************");
        s_logger.info(dbDetailsMap.get("DB_CONNECTION_URL"));
        return readTableFromDB(sqlName, null);
    }

    public String[][] getDataFromDB2(String sqlName) {
        dbDetailsMap = db2DbDetails;
        s_logger.info("*********** Database Details *************");
        s_logger.info(dbDetailsMap.get("DB_CONNECTION_URL"));
        return readTableFromDB(sqlName, null);
    }

    public String[][] getDataFromDB2(String sqlName, String[] sqlParams) {
        dbDetailsMap = db2DbDetails;
        s_logger.info("*********** Database Details *************");
        s_logger.info(dbDetailsMap.get("DB_CONNECTION_URL"));
        return readTableFromDB(sqlName, sqlParams);
    }

    /**
     * Gets the data from maria DB.
     *
     * @param sqlName
     *            the sql name
     * @param colName
     *            the col name
     * @return the data from maria DB
     */
    public String[] getDataFromMariaDB(String sqlName, String colName) {
        dbDetailsMap = mariaDbDetails;
        String[][] tableData = readTableFromDB(sqlName, null);
        return getColumnValuesFromTable(tableData, colName);
    }

    /**
     * Gets the data from maria DB.
     *
     * @param sqlName
     *            the sql name
     * @param params
     *            the params
     * @param colName
     *            the col name
     * @return the data from maria DB
     */
    public String[] getDataFromMariaDB(String sqlName, String[] params, String colName) {
        dbDetailsMap = mariaDbDetails;
        String[][] tableData = readTableFromDB(sqlName, params);
        return getColumnValuesFromTable(tableData, colName);
    }

    /**
     * Gets the data from DB.
     *
     * @param sqlName
     *            the sql name
     * @param colName
     *            the col name
     * @return the data from DB
     */
    public String[] getDataFromDB(String sqlName, String colName) {
        dbDetailsMap = oracleDbDetails;
        String[][] tableData = readTableFromDB(sqlName, null);
        return getColumnValuesFromTable(tableData, colName);
    }

    /**
     * Gets the data from DB.
     *
     * @param sqlName
     *            the sql name
     * @param params
     *            the params
     * @param colName
     *            the col name
     * @return the data from DB
     */
    public String[] getDataFromDB(String sqlName, String[] params, String colName) {
        dbDetailsMap = oracleDbDetails;
        String[][] tableData = readTableFromDB(sqlName, params);
        return getColumnValuesFromTable(tableData, colName);
    }

    /**
     * Gets the data from maria DB.
     *
     * @param sqlName
     *            the sql name
     * @param colIndex
     *            the col index
     * @return the data from maria DB
     */
    public String[] getDataFromMariaDB(String sqlName, int colIndex) {
        dbDetailsMap = mariaDbDetails;
        String[][] tableData = readTableFromDB(sqlName, null);
        return getColData(tableData, colIndex);
    }

    /**
     * Gets the data from maria DB.
     *
     * @param sqlName
     *            the sql name
     * @param params
     *            the params
     * @param colIndex
     *            the col index
     * @return the data from maria DB
     */
    public String[] getDataFromMariaDB(String sqlName, String[] params, int colIndex) {
        dbDetailsMap = mariaDbDetails;
        String[][] tableData = readTableFromDB(sqlName, params);
        return getColData(tableData, colIndex);
    }

    /**
     * Gets the data from DB.
     *
     * @param sqlName
     *            the sql name
     * @param colIndex
     *            the col index
     * @return the data from DB
     */
    public String[] getDataFromDB(String sqlName, int colIndex) {
        dbDetailsMap = oracleDbDetails;
        String[][] tableData = readTableFromDB(sqlName, null);
        return getColData(tableData, colIndex);
    }

    /**
     * Gets the data from DB.
     *
     * @param sqlName
     *            the sql name
     * @param params
     *            the params
     * @param colIndex
     *            the col index
     * @return the data from DB
     */
    public String[] getDataFromDB(String sqlName, String[] params, int colIndex) {
        dbDetailsMap = oracleDbDetails;
        String[][] tableData = readTableFromDB(sqlName, params);
        return getColData(tableData, colIndex);
    }

    /**
     * Update data to maria DB.
     *
     * @param sqlName
     *            the sql name
     * @param sqlParams
     *            the sql params
     * @return true, if successful
     */
    public boolean updateDataToMariaDB(String sqlName, String[] sqlParams) {
        dbDetailsMap = mariaDbDetails;
        return updateDBTable(sqlName, sqlParams);
    }

    /**
     * Update data to DB.
     *
     * @param sqlName
     *            the sql name
     * @param sqlParams
     *            the sql params
     * @return true, if successful
     */
    public boolean updateDataToDB(String sqlName, String[] sqlParams) {
        dbDetailsMap = oracleDbDetails;
        return updateDBTable(sqlName, sqlParams);
    }

    /**
     * Delete data from maria DB.
     *
     * @param sqlName
     *            the sql name
     * @param sqlParams
     *            the sql params
     * @return true, if successful
     */
    public boolean deleteDataFromMariaDB(String sqlName, String[] sqlParams) {
        dbDetailsMap = mariaDbDetails;
        return updateDBTable(sqlName, sqlParams);
    }

    /**
     * Delete data from DB.
     *
     * @param sqlName
     *            the sql name
     * @param sqlParams
     *            the sql params
     * @return true, if successful
     */
    public boolean deleteDataFromDB(String sqlName, String[] sqlParams) {
        dbDetailsMap = oracleDbDetails;
        return updateDBTable(sqlName, sqlParams);
    }

    /**
     * Gets the column values from table.
     *
     * @param tableData
     *            the table data
     * @param colName
     *            the col name
     * @return the column values from table
     */
    private String[] getColumnValuesFromTable(String[][] tableData, String colName) {
        int colIndex = -1;
        for (int i = 0; i < tableData[0].length; i++) {
            if (colName.equalsIgnoreCase(tableData[0][i])) {
                colIndex = i;
                break;
            }
        }

        return getColData(tableData, colIndex);
    }

    /**
     * Gets the col data.
     *
     * @param tableData
     *            the table data
     * @param colIndex
     *            the col index
     * @return the col data
     */
    private String[] getColData(String[][] tableData, int colIndex) {
        String[] colData = new String[tableData.length];

        for (int i = 0; i < colData.length; i++) {
            colData[i] = tableData[i][colIndex];
        }
        return colData;
    }

    /**
     * Read table from DB.
     *
     * @param sqlName
     *            the sql name
     * @param sqlParams
     *            the sql params
     * @return the string[][]
     */
    public String[][] readTableFromDB(String sqlName, String[] sqlParams) {

        String query = (SQLQueries.valueOf(sqlName)).getSQL();

        try {
            // Creating Connection
            createConnection();

            // Building SQL Query
            s_logger.info("Building SQL Query...");
            if (sqlParams != null)
                query = buildQuery(query, sqlParams);

            // Execute a query
            s_logger.info("Creating statement in given database...");

            // Query to be executed
            s_logger.info("Query: " + query);


            if(dbDetailsMap.get("DB_DRIVER").contains("DB2Driver")){
                Class.forName(dbDetailsMap.get("DB_DRIVER"));
            }else {
                Driver myDriver = new oracle.jdbc.driver.OracleDriver();
                DriverManager.registerDriver(myDriver);
            }
            // Open a connection
            s_logger.info("Connecting to a selected database...");
            conn = DriverManager.getConnection(dbDetailsMap.get("DB_CONNECTION_URL"), dbDetailsMap.get("DB_USERNAME"),
                    dbDetailsMap.get("DB_PASSWORD"));
            s_logger.info("Connected database successfully...");


            stmt = conn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

            rs = stmt.executeQuery();
            String[][] data = create2DArrayFromResultSet(rs);
            return data;
        } catch (Exception e) {
            // Handle errors for Class.forName
            e.printStackTrace();
            return null;
        } finally {
            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
            }
            try {
                if (stmt != null)
                    stmt.close();
            } catch (Exception e) {
            }
            try {
                if (conn != null)
                    conn.close();
                    conn=null;
            } catch (Exception e) {
            }
        }
    }

    /**
     * Builds the query.
     *
     * @param query
     *            the query
     * @param params
     *            the params
     * @return the string
     */
    private String buildQuery(String query, String[] params) {
        for (String eachParameter : params) {
            query = query.replaceFirst("\\?", eachParameter);
        }
        return query;
    }

    /**
     * Creates the 2 D array from result set.
     *
     * @param rs
     *            the rs
     * @return the string[][]
     */
    private String[][] create2DArrayFromResultSet(ResultSet rs) {
        List<String> list = new ArrayList<>();
        try {
            int columnCount = rs.getMetaData().getColumnCount();
//			rs.last();
//			int rowCount = rs.getRow();
//			rs.beforeFirst();
            while (rs.next()) {
                String temp = "";
                for (int i = 0; i < columnCount; i++) {
//					db_Data[rs.getRow() - 1][i] = rs.getString(i + 1);
                    temp =  temp + "~" + rs.getString(i + 1);
                }
                list.add(temp.substring(1));
            }
            System.out.println(list.size());
            String[][] db_Data = new String[list.size()][columnCount];
            int i = -1, j = 0;
            for(String each: list){
                i++;
                String[] coldata = each.split("~",columnCount);
                for(String col: coldata){
                    db_Data[i][j++] = col;
                }
                j=0;
            }

            return db_Data;
        } catch (Exception e) {

            e.printStackTrace();
            return null;
        }

    }

    private String[][] create2DArrayFromResultSet(ResultSet rs,int lsize,String param) {
        List<String> list = new ArrayList<>();
        try {
            int columnCount = rs.getMetaData().getColumnCount();
            while (rs.next()) {
                String temp = "";
                for (int i = 0; i < columnCount; i++) {
                    temp =  temp + "~" + rs.getString(i + 1);
                }
                list.add(temp.substring(1));
            }

            String[][] db_Data = new String[list.size()/lsize][columnCount-1];
            String val="Prod_SKUs";
            String[][] value=get2DSArray(list.toArray(),list.size(),lsize);
            int i,j;
            for( i=0;i< list.size()/lsize;i++) {
                for(j=0;j<columnCount;j++)
                    db_Data[i][j] = val+","+Arrays.toString(value[i]).trim()+","+param;

            }


            return db_Data;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }
    /***
     *
     *************/
    public static String[][] get2DSArray(Object[] d,int length2D,int division) {
        String[][] a = new String[length2D/division][division];

        int count = 0;
        for (int i = 0; i < length2D/division; i++)
        {
            for (int j = 0; j < division; j++)
            {
                if (count == d.length)
                    break;

                a[i][j] = (String) d[count];
                count++;
            }


        }

        return a;
    }

    /**
     * Update DB table.
     *
     * @param sqlName
     *            the sql name
     * @param sqlParams
     *            the sql params
     * @return true, if successful
     */
    public boolean updateDBTable(String sqlName, String[] sqlParams) {
        String query = (SQLQueries.valueOf(sqlName)).getSQL();
        boolean flag = false;
        try {
            // Creating Connection
            createConnection();
            // conn.setAutoCommit(true);
            // Building SQL Query
            s_logger.info("Building SQL Query...");
            if (sqlParams != null)
                query = buildQuery(query, sqlParams);
            // Query to be executed
            s_logger.info("Query: " + query);
            // Execute a query
            s_logger.info("Creating table in given database...");
            stmt = conn.prepareStatement(query);

            int count = stmt.executeUpdate();// .next();
            flag = count > 0;
            // conn.commit();
            s_logger.info("Created table in given database...");
            MigrationUtil.unconditionalWait(5000);
        } catch (Exception e) {
            // Handle errors for Class.forName
            e.printStackTrace();

        } finally {
            // conn.setAutoCommit(false);
            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
            }
            try {
                if (stmt != null)
                    stmt.close();
            } catch (Exception e) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (Exception e) {
            }
        }
        return flag;
    }

    /**
     * Update DB table.
     *
     * @param sqlName
     *            the sql name
     * @param sqlParams
     *            the sql params
     * @param longStringPos
     *            the long string pos
     * @return true, if successful
     */
    public boolean updateDBTable(String sqlName, String[] sqlParams, int longStringPos) {
        String query = (SQLQueries.valueOf(sqlName)).getSQL();
        boolean flag = false;
        try {
            s_logger.info("Long String at Position: " + longStringPos);
            // Creating Connection
            createConnection();
            // conn.setAutoCommit(true);
            // Building SQL Query
            s_logger.info("Building SQL Query...");
            // Query to be executed
            s_logger.info("Query: " + query);
            s_logger.info("Parameters: " + sqlParams);
            // Execute a query
            s_logger.info("Creating table in given database...");
            stmt = conn.prepareStatement(query);
            int i = 0;
            for (String each : sqlParams) {
                stmt.setString(++i, each);
            }

            int count = stmt.executeUpdate();// .next();
            flag = count > 0;
            // conn.commit();
            s_logger.info("Created table in given database...");
            // if(count>0) flag = true;
            // else flag = false;

        } catch (Exception e) {
            // Handle errors for Class.forName
            e.printStackTrace();

        } finally {
            // conn.setAutoCommit(false);
            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
            }
            try {
                if (stmt != null)
                    stmt.close();
            } catch (Exception e) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (Exception e) {
            }
        }
        return flag;
    }

    /**
     * Connect to cassandra.
     *
     * @param node
     *            the node
     * @param port
     *            the port
     */
    public void connectToCassandra(final String node, final int port) {
        this.cluster = Cluster.builder().addContactPoint(node).withPort(port)
                .withCredentials(cassandraDbDetails.get("DB_USERNAME"), cassandraDbDetails.get("DB_PASSWORD")).build();
        final Metadata metadata = cluster.getMetadata();
        s_logger.info("Connected to cluster: " + metadata.getClusterName());
        for (final Host host : metadata.getAllHosts()) {
            s_logger.info("Datacenter: " + host.getDatacenter() + "; Host: " + host.getAddress() + "; Rack: "
                    + host.getRack());
        }
        session = cluster.connect(oracleDbDetails.get("DB_KEYSPACE"));
    }

    /**
     * Gets the cassandra session.
     *
     * @return the cassandra session
     */
    private Session getCassandraSession() {
        return this.session;
    }

    /** Close cluster. */
    public void closeCassandraConnection() {
        s_logger.info("Closing Cassandra Connection");
        cluster.close();
        session.close();
    }
    /**
     * Gets the data from cassandra DB.
     *
     * @param sqlName
     *            the sql name
     * @return the data from cassandra DB
     */
    private String[][] getCassandraData(String sqlName, String[] sqlParams) {
        try {
            String query = (SQLQueries.valueOf(sqlName)).getSQL();

            s_logger.info("Building SQL Query...");
            if (sqlParams != null)
                query = buildQuery(query, sqlParams);
            s_logger.info("Query: "+ query);
            String node_url = cassandraDbDetails.get("DB_CONNECTION_URL");
            connectToCassandra(node_url, 9042);
            com.datastax.driver.core.ResultSet rs = session.execute(query);
            ColumnDefinitions cd = rs.getColumnDefinitions();

            int colCount = cd.size();

            List<Row> rowList = rs.all();
            String[][] data = new String[rowList.size()][colCount];
            rs.one();
            String value = "";
            int x = 0, y = 0;
            for (Row row : rowList) {
                for (int i = 0; i < colCount; i++) {
                    switch (cd.getType(i).getName().name().toUpperCase()) {
                        case "VARCHAR":
                            value = row.getString(i);
                            break;
                        case "BIGINT":
                            value = String.valueOf(row.getLong(i));
                            break;
                        case "BOOLEAN":
                            value = String.valueOf(row.getBool(i));
                            break;
                        case "BLOB":
                            value = String.valueOf(row.getBytes(i));
                            break;
                        case "DOUBLE":
                            value = String.valueOf(row.getDouble(i));
                            break;
                        case "FLOAT":
                            value = String.valueOf(row.getFloat(i));
                            break;
                        case "INT":
                            value = String.valueOf(row.getInt(i));
                            break;
                        case "UDT":
                            value = String.valueOf(row.getUDTValue(i));
                            break;
                        case "TIMESTAMP":
                            value = String.valueOf(row.getTimestamp(i));
                            break;
                        case "TIMEUUID":
                            value = String.valueOf(row.getUUID(i));
                            break;
                        default:
                            s_logger.error("UNEXPECTED COLUMN TYPE: columname=" + cd.getName(i) + ", columntype="
                                    + cd.getType(i).getName().name().toUpperCase());
                    }
                    data[x][y++] = value;
                }
                y = 0;
                x++;
            }
            return data;
        } catch (Exception e) {
            s_logger.info("ERROR: Fetching data from Cassandra Database!!");
            e.printStackTrace();
            return null;
        } finally {
            closeCassandraConnection();
        }
    }

    public boolean updateCassandraDBTable(String sqlName, String[] sqlParams) {
        boolean flag = false;
        try {
            String query = (SQLQueries.valueOf(sqlName)).getSQL();

            s_logger.info("Building SQL Query...");
            if (sqlParams != null)
                query = buildQuery(query, sqlParams);

            String node_url = cassandraDbDetails.get("DB_CONNECTION_URL");
            connectToCassandra(node_url, 9042);

            s_logger.info("Query to be executed: \n" + query);

            com.datastax.driver.core.ResultSet rs = session.execute(query);

            flag = rs.wasApplied();

            return flag;
        } catch (Exception e) {
            s_logger.info("ERROR: Fetching data from Cassandra Database!!");
            e.printStackTrace();
            return false;
        } finally {
            closeCassandraConnection();
        }
    }

    public void runStoredProcedures(String sqlName) {
        boolean procMessage;
        String procQuery = (SQLQueries.valueOf(sqlName)).getSQL();
        System.out.println("------------------|| Running Stored Procedure: "+ procQuery);
        try {
            //Connection con = this.createConnection();
            createConnection();
            PreparedStatement pstmt = conn.prepareStatement(procQuery);
            pstmt.execute(procQuery);
            procMessage = true;
        }catch(Exception e) {
            e.printStackTrace();
            procMessage = false;
        }
        if(procMessage) {
            System.out.println("------------------------------------ "+procQuery+" Completed Successfully !! ------------------------------------ ");
        }else {
            System.out.println("------------------------------------ "+procQuery+" Failed !! ------------------------------------ ");
        }

    }

    public boolean insertIntoTable(String sqlName, String[] sqlParams) {
        String query = (SQLQueries.valueOf(sqlName)).getSQL();
        boolean flag = false;
        try {
            // Creating Connection
            createConnection();
            // conn.setAutoCommit(true);
            // Building SQL Query
            s_logger.info("Building SQL Query...");
            // Query to be executed
            s_logger.info("Query: " + query);
            s_logger.info("Parameters: " + sqlParams);
            // Execute a query
            stmt = conn.prepareStatement(query);
            int i = 0;
            for (String each : sqlParams) {
                stmt.setString(++i, each);
            }

            int count = stmt.executeUpdate();// .next();
            flag = count > 0;
            // conn.commit();
            s_logger.info("Inserted row in given table...");
            // if(count>0) flag = true;
            // else flag = false;

        } catch (Exception e) {
            // Handle errors for Class.forName
            e.printStackTrace();

        } finally {
            // conn.setAutoCommit(false);
            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
            }
            try {
                if (stmt != null)
                    stmt.close();
            } catch (Exception e) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (Exception e) {
            }
        }
        return flag;
    }

    public  boolean validateKafkaPriceDataWithPiStoreData(List<String> msgList, String sqlName){
        boolean flag = true;
        String query_template = (SQLQueries.valueOf(sqlName)).getSQL();
        String query = "";
        JSONParser parser = new JSONParser();
        int no_of_records_to_be_checked = 50;
        try {
            // Creating Connection
            createConnection();
            int kafkaCount = msgList.size();
            // Execute a query
            s_logger.info("Creating statement in given database...");
            stmt = conn.prepareStatement("SELECT COUNT(*) FROM CSDBUSER.PI_FEED_UPDATES", ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = stmt.executeQuery();
            rs.next();
            int dbCount = rs.getInt(1);
            System.out.println("Kafka Count: "+ kafkaCount);
            System.out.println("DB Count: "+ dbCount);
            if(kafkaCount!=dbCount) flag=false;
            int i = 0;
            for(String each: msgList){
                if(i>no_of_records_to_be_checked) break;
                else i++;
                JSONObject eachObj = (JSONObject) parser.parse(each.trim());
                String jsonUPC = (String) eachObj.get("upc");
                String jsonStore = (String) eachObj.get("store_number");
                String jsonListPrice = (String) eachObj.get("retail_price");
                String jsonMUP = (String) eachObj.get("minimum_unit_price");

                query = query_template.replaceFirst("\\?", jsonUPC).replaceFirst("\\?", jsonStore);
                // Query to be executed
                stmt = conn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                rs = stmt.executeQuery();
                rs.next();
                String actual_list_price = String.valueOf(rs.getString(3));
                String actual_mup = String.valueOf(rs.getString(4));
                String expected_list_price = jsonListPrice;
                String expected_mup = jsonMUP;
                try {
                    if (Double.parseDouble(actual_list_price) == Double.parseDouble(expected_list_price)
                            && Double.parseDouble(actual_mup) == Double.parseDouble(expected_mup)) {
                        System.out.println(". ");
                    } else {
                        s_logger.info("Query: " + query);
                        s_logger.info("Kafka Data Mismatch: UPC - Store Id - List Price - MUP : " + jsonUPC + "-" + jsonStore + "-" + expected_list_price + "-" + expected_mup);
                        s_logger.info("   DB Data Mismatch: UPC - Store Id - List Price - MUP : " + jsonUPC + "-" + jsonStore + "-" + actual_list_price + "-" + actual_mup);
                        flag = false;
                    }
                }catch (NumberFormatException npe){

                    if(actual_list_price.charAt(actual_list_price.length()-1)=='0')
                        actual_list_price = actual_list_price.replace(".0","");
                    if(actual_mup.charAt(actual_mup.length()-1)=='0')
                        actual_mup = actual_mup.replace(".0","");

                    if(expected_list_price.charAt(expected_list_price.length()-1)=='0')
                        expected_list_price = expected_list_price.replace(".0","");
                    if(expected_mup.charAt(expected_mup.length()-1)=='0')
                        expected_mup = expected_mup.replace(".0","");


                    if (actual_list_price.equalsIgnoreCase(expected_list_price)
                            && actual_mup.equalsIgnoreCase(expected_mup)) {
                        System.out.println(". ");
                    } else {
                        s_logger.info("Query: " + query);
                        s_logger.info("Kafka Data Mismatch: UPC - Store Id - List Price - MUP : " + jsonUPC + "-" + jsonStore + "-" + expected_list_price + "-" + expected_mup);
                        s_logger.info("   DB Data Mismatch: UPC - Store Id - List Price - MUP : " + jsonUPC + "-" + jsonStore + "-" + actual_list_price + "-" + actual_mup);
                        flag = false;
                    }
                }
            }
        } catch (Exception e) {
            // Handle errors for Class.forName
            e.printStackTrace();
            Assert.assertTrue(false);
            return false;
        } finally {
            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
            }
            try {
                if (stmt != null)
                    stmt.close();
            } catch (Exception e) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (Exception e) {
            }
        }
        if(flag) s_logger.info("PASSED: All data matched!!");
        Assert.assertTrue(flag);
        return flag;
    }

    public boolean validatePAOCMSSTAGEAgainstFeedFile(String sqlName, String[] sqlParams, String feed_file) {
        String query = (SQLQueries.valueOf(sqlName)).getSQL();
        boolean flag = true;
        try {
            HashMap<String, Date> file_list = new HashMap<String, Date> ();
            HashMap<String, Date> db_list = new HashMap<String, Date>();

            String[][] file_data = GeneralUtility.readCsvFileIntoArray(feed_file);

            // Creating Connection
            createConnection();

            // Building SQL Query
            s_logger.info("Building SQL Query...");
            if (sqlParams != null)
                query = buildQuery(query, sqlParams);

            // Query to be executed
            s_logger.info("Query: " + query);

            stmt = conn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

            rs = stmt.executeQuery();

            String[][] db_data = create2DArrayFromResultSet(rs);

            int x = 0;
            for(String[] row : file_data){
                if(x==0){
                    x++;
                    continue;
                }
                Date date=null;
                if(row[2].length()!=0) date=new SimpleDateFormat("yyyy-MM-dd").parse(row[2].trim());
                file_list.put(row[0].trim()+"-"+row[1].trim()+"-"+row[3].trim(), date);

                //file_list.add(GeneralUtility.getArrayAsCommaSeparatedString(row));
            }

            for(String[] row : db_data){
                //if(row[2]==null) r	ow[2] = "";
                if(row[3]==null) row[3] = "";
                Date date = null;
                if(row[2]!=null) date =new SimpleDateFormat("MM/yy/dd").parse(row[2].trim());
                db_list.put(row[0].trim()+"-"+row[1].trim()+"-"+row[3].trim(), date);
                //db_list.add(GeneralUtility.getArrayAsCommaSeparatedString(row));
            }

            //flag = GeneralUtility.TwoDArrayComparator(file_data, db_data);

            Iterator hmIterator = file_list.entrySet().iterator();

            while (hmIterator.hasNext()) {
                Map.Entry mapElement = (Map.Entry)hmIterator.next();
                String key = (String) mapElement.getKey();

                if(db_list.containsKey(key)){
                    Date fileDate = file_list.get(key);
                    Date dbDate = db_list.get(key);
                    if(!dbDate.equals(fileDate)){
                        s_logger.info("--------  Data Mismatch !! ---------");
                        s_logger.info("--------    Actual Data: " +key+ " - "+ fileDate+ " ---------");
                        s_logger.info("--------  Expected Data: " +key+ " - "+ dbDate+ " ---------");
                        flag = false;
                    }
                }else{
                    s_logger.info("--------  Data not found !! ---------");
                    s_logger.info("--------    Data not found in DB: " +key+ " ---------");
                    flag = false;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            flag = false;
        } finally {
            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
            }
            try {
                if (stmt != null)
                    stmt.close();
            } catch (Exception e) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (Exception e) {
            }
        }
        if(flag) s_logger.info("PASSED: All data matched!!");
        else s_logger.info("FAILED: Data didn't match!!");
        Assert.assertTrue(flag);
        return flag;
    }

    public boolean validateAPACMSSTAGEAgainstFeedFile(String sqlName, String[] sqlParams, String feed_file) {
        String query = (SQLQueries.valueOf(sqlName)).getSQL();
        boolean flag = true;
        try {
            List<String> file_list = new ArrayList<String>();
            List<String> db_list = new ArrayList<String>();

            String[][] file_data = GeneralUtility.readCsvFileIntoArray(feed_file);

            // Creating Connection
            createConnection();

            // Building SQL Query
            s_logger.info("Building SQL Query...");
            if (sqlParams != null)
                query = buildQuery(query, sqlParams);

            // Query to be executed
            s_logger.info("Query: " + query);

            stmt = conn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

            rs = stmt.executeQuery();

            String[][] db_data = create2DArrayFromResultSet(rs);

            for(String[] row : file_data){
                file_list.add(GeneralUtility.getArrayAsCommaSeparatedString(row));
            }

            for(String[] row : db_data){
                db_list.add(GeneralUtility.getArrayAsCommaSeparatedString(row));
            }

            //flag = GeneralUtility.TwoDArrayComparator(file_data, db_data);

            Collections.sort(file_list);
            Collections.sort(db_list);

            for(int i = 0; i < file_list.size()-1; i++) {
                if(!file_list.get(i).equals(db_list.get(i))) {
                    s_logger.info("--------  Data Mismatch !! ---------");
                    s_logger.info("--------    Actual Data: " +file_list.get(i)+ " ---------");
                    s_logger.info("--------  Expected Data: " +db_list.get(i)+ " ---------");
                    flag = false;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            flag = false;
        } finally {
            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
            }
            try {
                if (stmt != null)
                    stmt.close();
            } catch (Exception e) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (Exception e) {
            }
        }
        return flag;
    }

    public boolean validateKafkaInventoryDataWithPiStoreData(List<String> msgList, String sqlName) {
        boolean flag = true;
        String query_tamplate = (SQLQueries.valueOf(sqlName)).getSQL();
        String query = "";
        int no_of_records_to_be_checked = 50;
        try {
            // Creating Connection
            createConnection();

            int kafkaCount = msgList.size();

            // Execute a query
            s_logger.info("Creating statement in given database...");
            stmt = conn.prepareStatement("SELECT COUNT(*) FROM CSDBUSER.INV_FEED_UPDATES", ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = stmt.executeQuery();
            rs.next();
            int dbCount = rs.getInt(1);
            System.out.println("Kafka Count: "+ kafkaCount);
            System.out.println("DB Count: "+ dbCount);
            if(kafkaCount!=dbCount) flag=false;
            int i = 0;
            JSONParser parser = new JSONParser();
            for(String each: msgList){
                if(i>no_of_records_to_be_checked) break;
                else i++;

                JSONObject eachObj = (JSONObject) parser.parse(each.trim());
                String jsonUPC = (String) eachObj.get("upc");
                String jsonStore = (String) eachObj.get("store_number");
                String jsonStatus = (String) eachObj.get("status");
                String jsonStoreStatus = (String) eachObj.get("store_level_status");
                String jsonIOS = (String) eachObj.get("ios");
                String jsonOOS = (String) eachObj.get("oos");

                query = query_tamplate.replaceFirst("\\?", jsonUPC).replaceFirst("\\?", jsonStore);
                // Query to be executed
                stmt = conn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                rs = stmt.executeQuery();
                rs.next();
                String status = String.valueOf(rs.getString(3));
                String store_level_status = String.valueOf(rs.getString(4));
                String ios = rs.getString(5);
                String oos = rs.getString(6);

                if(ios == null) ios = "null";
                if(oos == null) oos = "null";
                if(jsonIOS ==  null) jsonIOS = "null";
                if(jsonOOS == null) jsonOOS = "null";

                if(jsonStatus.equals(status) && jsonStoreStatus.equals(store_level_status)
                        && jsonIOS.equals(ios) && jsonOOS.equals(oos)){
                    System.out.println(". ");
                } else {
                    s_logger.info("Query: " + query);
                    s_logger.info("Kafka Data Mismatch: UPC - Store Id - Status - Store Level Status - IOS - OOS : " + jsonUPC + "-" + jsonStore + "-" + jsonStatus + "-" + jsonStoreStatus + "-" + jsonIOS + "-" + jsonOOS);
                    s_logger.info("   DB Data Mismatch: UPC - Store Id - Status - Store Level Status - IOS - OOS : " + jsonUPC + "-" + jsonStore + "-" + status + "-" + store_level_status + "-" + ios + "-" + ios);
                    flag = false;
                }
            }
        } catch (Exception e) {
            // Handle errors for Class.forName
            e.printStackTrace();
            Assert.assertTrue(false);
            return false;
        } finally {
            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
            }
            try {
                if (stmt != null)
                    stmt.close();
            } catch (Exception e) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (Exception e) {
            }
        }
        if(flag) s_logger.info("PASSED: All data matched!!");
        Assert.assertTrue(flag);
        return flag;
    }

    public boolean compareOracleWithAzureTable(String sqlName, String azureSqlName, String testEnv) {
        boolean flag = false;

        SQLUtils sqlUtils = new SQLUtils(testEnv);
        String[][] oracleDB_data = sqlUtils.getDataFromDB(sqlName);

        String[][] azureDB_data = sqlUtils.getDataFromAzureDB(azureSqlName, null);

        flag = GeneralUtility.TwoDArrayComparator(oracleDB_data, azureDB_data);

        return flag;
    }

    private String[][] getAzureData(String sqlName, String[] sqlParams) {
        Statement stat = null;
        String query = (SQLQueries.valueOf(sqlName)).getSQL();

        // Building SQL Query
        s_logger.info("Building SQL Query...");
        if (sqlParams != null)
            query = buildQuery(query, sqlParams);


        // Execute a query
        s_logger.info("Creating statement in given database...");

        // Query to be executed
        query = query.replace("single_profile.", "");
        s_logger.info("Query: " + query);

        String user = dbDetailsMap.get("DB_USERNAME");
        String password = dbDetailsMap.get("DB_PASSWORD");
        String url = dbDetailsMap.get("DB_CONNECTION_URL");
        try {
            Class.forName(dbDetailsMap.get("DB_DRIVER"));
            Thread.sleep(1000);
            conn = DriverManager.getConnection(url, user, password);
            stat = conn.createStatement();
            rs = stat.executeQuery(query);
            String[][] data = create2DArrayFromResultSet(rs);
            return data;
        } catch (Exception cnfe) {
            cnfe.printStackTrace();
            System.out.println("ERROR: While reading Azure Database!!");
        } finally {
            if(rs!=null) try{rs.close();}catch(Exception e){ e.printStackTrace();}
            if(stat!=null) try{stat.close();}catch(Exception e){ e.printStackTrace();}
            if(conn!=null) try{conn.close();}catch(Exception e){ e.printStackTrace();}
        }
        return null;
    }

    private String[][] getAzureData(String sqlName, String[] sqlParams,int lsize) {
        Statement stat = null;
        String query = (SQLQueries.valueOf(sqlName)).getSQL();

        // Building SQL Query
        s_logger.info("Building SQL Query...");
        if (sqlParams != null)
            query = buildQuery(query, sqlParams);

        // Execute a query
        s_logger.info("Creating statement in given database...");

        // Query to be executed
        s_logger.info("Query: " + query);

        String user = dbDetailsMap.get("DB_USERNAME");
        String password = dbDetailsMap.get("DB_PASSWORD");
        String url = dbDetailsMap.get("DB_CONNECTION_URL");
        try {
            Class.forName(dbDetailsMap.get("DB_DRIVER"));
            conn = DriverManager.getConnection(url, user, password);
            stat = conn.createStatement();
            rs = stat.executeQuery(query);
            String[][] data = create2DArrayFromResultSet(rs,lsize,sqlParams[2]);
            return data;
        } catch (Exception cnfe) {
            cnfe.printStackTrace();
            System.out.println("ERROR: While reading Azure Database!!");
        } finally {
            if(rs!=null) try{rs.close();}catch(Exception e){ e.printStackTrace();}
            if(stat!=null) try{stat.close();}catch(Exception e){ e.printStackTrace();}
            if(conn!=null) try{conn.close();}catch(Exception e){ e.printStackTrace();}
        }
        return null;
    }

    private boolean updateAzureTable(String sqlName, String[] sqlParams) {
        Statement stat = null;
        String query = (SQLQueries.valueOf(sqlName)).getSQL().toLowerCase().replaceFirst("single_profile.","");
        s_logger.info("**************######## Running Query on AZURE  ########*****************");
        // Building SQL Query
        s_logger.info("Building SQL Query...");
        if (sqlParams != null)
            query = buildQuery(query, sqlParams);

        // Execute a query
        s_logger.info("Creating statement in given database...");

        // Query to be executed
        s_logger.info("Query: " + query);

        String user = dbDetailsMap.get("DB_USERNAME");
        String password = dbDetailsMap.get("DB_PASSWORD");
        String url = dbDetailsMap.get("DB_CONNECTION_URL");
        try {
            Class.forName(dbDetailsMap.get("DB_DRIVER"));
            conn = DriverManager.getConnection(url, user, password);
            stat = conn.createStatement();
            stat.executeUpdate(query);
            //String[][] data = create2DArrayFromResultSet(rs);
            return true;
        } catch (Exception cnfe) {
            System.out.println("ERROR: While updating Azure Database!!");
            System.out.println("Exception: "+ cnfe);
        } finally {
            try{stat.close();}catch(Exception e){ e.printStackTrace();}
            try{conn.close();}catch(Exception e){ e.printStackTrace();}
        }
        return false;
    }

    public boolean validateKafkaPromotionDataWithPromotionUpdateTable(List<String> msgList, String sqlName) {
        boolean flag = true;

        String query_template = (SQLQueries.valueOf(sqlName)).getSQL();
        String query = "";
        JSONParser parser = new JSONParser();
        int no_of_records_to_be_checked = 50;
        try {
            // Creating Connection
            createConnection();
            int kafkaCount = msgList.size();
            // Execute a query
            s_logger.info("Creating statement in given database...");
            stmt = conn.prepareStatement("SELECT COUNT(*) FROM csdbuser.promotion_feed_updates", ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = stmt.executeQuery();
            rs.next();
            int dbCount = rs.getInt(1);
            System.out.println("Kafka Count: "+ kafkaCount);
            System.out.println("DB Count: "+ dbCount);
            if(kafkaCount!=dbCount) flag=false;
            int i = 0;
            for(String each: msgList){
                if(i>no_of_records_to_be_checked) break;
                else i++;
                JSONObject eachObj = (JSONObject) parser.parse(each.trim());
                String jsonAction = (String) eachObj.get("action");
                String jsonUPC = (String) eachObj.get("upc");
                String jsonStore = (String) eachObj.get("storeNumber");
                String jsonOfferId = (String) eachObj.get("offerId");
                String jsonOfferType = (String) eachObj.get("offerTypeCode");
                String jsonOfferName = (String) eachObj.get("offerNameText");
                String jsonBeginDate = (String) eachObj.get("beginDate");
                String jsonEndDate = (String) eachObj.get("endDate");
                String jsonPurchaseQty =  eachObj.get("purchaseQuantity").toString();
                String jsonOfferQty = eachObj.get("offerQuantity").toString();
                String jsonOfferDiscPct = (String) eachObj.get("offerDiscPct");
                String jsonOfferPrice = (String) eachObj.get("offerPriceAmt");
                String jsonAdjuster = (String) eachObj.get("adjuster");
                String jsonAdjType = (String) eachObj.get("adjusterType");


                query = query_template.replaceFirst("\\?", jsonUPC).replaceFirst("\\?", jsonStore).replaceFirst("\\?", jsonOfferId);
                // Query to be executed
                stmt = conn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                rs = stmt.executeQuery();
                rs.next();


                String dbAction = rs.getString(15);
                String dbOfferType = rs.getString(4);
                String dbOfferName = rs.getString(5);
                String dbBeginDate = rs.getString(6);
                String dbEndDate = rs.getString(7);
                String dbPurchaseQty = rs.getString(11);
                String dbOfferQty = rs.getString(12);
                String dbOfferDiscPct = rs.getString(14);
                String dbOfferPrice = rs.getString(13);
                String dbAdjuster = rs.getString(8);
                String dbAdjType = rs.getString(9);


                if (dbAction.equals(jsonAction) && dbOfferName.equals(jsonOfferName) && dbOfferName.equals(jsonOfferName)
                        && dbAdjType.equals(dbAdjType)) {
                    System.out.println(". ");
                } else {
//					s_logger.info("Query: " + query);
                    s_logger.info("Kafka Data Mismatch: "+  eachObj.toJSONString());
                    flag = false;
                }

                if (Double.parseDouble(dbOfferType) == Double.parseDouble(jsonOfferType)
                        && Double.parseDouble(dbOfferDiscPct) == Double.parseDouble(jsonOfferDiscPct)
                        && Double.parseDouble(dbOfferPrice) == Double.parseDouble(jsonOfferPrice)
                        && Double.parseDouble(dbAdjuster) == Double.parseDouble(jsonAdjuster)
                        && Double.parseDouble(dbOfferQty) == Double.parseDouble(jsonOfferQty)
                        && Double.parseDouble(dbPurchaseQty) == Double.parseDouble(jsonPurchaseQty)) {
                    System.out.println(". ");
                } else {
//					s_logger.info("Query: " + query);
                    s_logger.info("Kafka Data Mismatch: "+  eachObj.toJSONString());
                    flag = false;
                }

                SimpleDateFormat sdf1 = new SimpleDateFormat("YYYY-MM-DD");
                //SimpleDateFormat sdf2 = new SimpleDateFormat("DD-MM-yy hh:mm:ss.SSS");
                Date jStartDate, jEndDate, dStartDate, dEndDate;
                jStartDate = sdf1.parse(jsonBeginDate);
                jEndDate = sdf1.parse(jsonEndDate);
                dStartDate = sdf1.parse(dbBeginDate.split(" ")[0]);
                dEndDate = sdf1.parse(dbEndDate.split(" ")[0]);

                if (jStartDate.compareTo(dStartDate)==0
                        && jEndDate.compareTo(dEndDate)==0) {
                    System.out.println(". ");
                } else {
                    //s_logger.info("Query: " + query);
                    s_logger.info("Kafka Data Mismatch: "+  eachObj.toJSONString());
                    flag = false;
                }

            }
        } catch (Exception e) {
            // Handle errors for Class.forName
            e.printStackTrace();
            Assert.assertTrue(false);
            return false;
        } finally {
            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
            }
            try {
                if (stmt != null)
                    stmt.close();
            } catch (Exception e) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (Exception e) {
            }
        }
        if(flag) s_logger.info("PASSED: All data matched!!");
        Assert.assertTrue(flag);

        return flag;
    }
}
