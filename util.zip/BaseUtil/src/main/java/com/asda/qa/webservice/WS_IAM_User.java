package com.asda.qa.webservice;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import com.asda.qa.environment.EnvironmentConfig;
import com.asda.core.webservice.BaseWebService;
import com.asda.core.webservice.ParamTokenDelimiter;
import com.asda.core.webservice.WebServiceResponse;

public class WS_IAM_User extends BaseWebService {

	private static final WS_IAM_User s_instance = new WS_IAM_User();

	private static final Logger s_logger = LoggerFactory.getLogger(WS_IAM_User.class);

	ParamTokenDelimiter atDel = new ParamTokenDelimiter("< >");
	private final Map<String, String> headersMap = new HashMap<String, String>();
	
	public static final WS_IAM_User getInstance() {
		return s_instance ;
	}

	private String getIamUpdatePWD() {
		return getRequestFromFile("com/asda/qa/webservice/IAM/IamChangePwd.xml");
	}

	/**
	 * Initialize IAM header parameters
	 * 
	 * @return
	 */
	private void addIAMHeaderParameters() {
		
		String envRealMid = EnvironmentConfig.getInstance().getIAMHead();
		headersMap.put("Accept", "application/json");
		headersMap.put("WM_CONSUMER.ID", "ab2c8dd3-0037-4283-af76-518701d31a48");
		headersMap.put("WM_CONSUMER.INTIMESTAMP", "1468917255608");
		headersMap.put("WM_CONSUMER.IP", "172.28.143.118");
		headersMap.put("WM_SVC.NAME", "platform-iam-server");
		headersMap.put("WM_SEC.KEY_VERSION", "1");
		headersMap.put("WM_CONSUMER.NAME", "L-IDC10FDKQ2-M");
		headersMap.put("WM_IFX.CLIENT_TYPE", "INTERNAL");
		headersMap.put("WM_IFX.TRANSACTION_PROTOCOL", "https");
		headersMap.put("WM_QOS.CORRELATION_ID", "-_ser_L-IDC10FDKQ2-M");
		headersMap.put("WM_SEC.AUTH_TOKEN", "NA");
		headersMap.put("WM_SVC.ENV", "qa");
		headersMap.put("WM_SVC.VERSION", "1.0.0");
		headersMap.put("User-Agent", "Apache CXF 2.7.2");
		headersMap.put("Cache-Control", "no-cache");
		headersMap.put("Host", "estoreapp-58323053-1-85851574.qa5.ukgrsps.dfwqa2.qa.walmart.com");
		headersMap.put("Connection", "eep-alive");
		headersMap.put("Content-Type", "application/json");
		headersMap.put("WMENV_REALMID", envRealMid);
		headersMap.put("HASH_ALGO", "SHA-256SLT18");
	}

	/**
	 * Update IAM customer identified by userName and password.
	 * 
	 * @param userName
	 * @param password
	 * @return
	 */
	public String IAMUpdatePwd(String custID, String userName, String concatPWD) {
		Map<String, String> postParams = new HashMap<String, String>();
		postParams.put("custID", custID);
		postParams.put("userName", userName);
		postParams.put("concatPWD", concatPWD);
		addIAMHeaderParameters();
		String request = getIamUpdatePWD();
		String destUrl = "http://qa.iam.platform.prod.walmart.com/platform-iam-server/iam/wm/mgrtn";
		WebServiceResponse result = invokeRESTPostRequest(destUrl, headersMap, request, atDel, postParams, true);
		s_logger.info("Response is : " + result.getResponseXml());
		// WebServiceResponse result =invokeRESTPostRequest(EnvironmentConfig.getInstance().getServiceEndPointUrl()+"/persons/signup",headerParams,request,atDel,postParams,false);
		Assert.assertNotNull(result);
		Assert.assertEquals(result.getResponseCode(), 200);
		return result.getResponseXml();
	}
	
	
	/**
	 * Update IAM user and return email id Updated.
	 * 
	 * @return
	 */

	public String IAMUpdatePwd(String email) {
		IAMUpdatePwd(email);
		return email;
	}


}
