package com.asda.qa.utility;

import com.asda.core.utils.FileReader;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;

/**
 * author:Yashaswini
 * The class contains methods required for reading test data from excel sheet. 
 *
 */
public class DataReader {

	private static final Logger s_logger = LoggerFactory
			.getLogger(DataReader.class);

	/**
	 * Get a Map with all column names mapped to their respective column values for the row corresponding to dataKey.
	 * @param keyName
	 * @param fileLocation
	 * @return
	 */
	public static Map<String, String> getDataValues(String keyName,
			String fileLocation) {
		XSSFWorkbook wb = null;
		try {
			InputStream io = FileReader.getInstance().readInputStreamFromClassPath(fileLocation);
			wb = new XSSFWorkbook(io);
		} catch (IOException e) {
			s_logger.error("Unable to read data file", e);
			Assert.fail("Unable to read data file", e);
		}
		XSSFSheet sheet = wb.getSheetAt(0);
		LinkedList<String> columnNames = getColumnNames(sheet);
		LinkedHashMap<String, String> testDataMap = getRowData(sheet,
				keyName, columnNames);
		return testDataMap;
	}
	
	
	public static Map<String, String> getDataValues(String keyName, String sheetName,
			String fileLocation) {
		XSSFWorkbook wb = null;
		try {
			InputStream io = DataReader.class.getClassLoader()
					.getResourceAsStream(fileLocation);
			wb = new XSSFWorkbook(io);
		} catch (IOException e) {
			s_logger.error("Unable to read data file", e);
			Assert.fail("Unable to read data file", e);
		}
//		XSSFSheet sheet = wb.getSheetAt(0);
		XSSFSheet sheet = wb.getSheet(sheetName);
		LinkedList<String> columnNames = getColumnNames(sheet);
		LinkedHashMap<String, String> testDataMap = getRowData(sheet,
				keyName, columnNames);
		return testDataMap;
	}
	
	public static Map<String, String> getDataValues(String keyName, String pageVarExcelName, boolean anothersheet, 
			String fileLocation) {
		XSSFWorkbook wb = null;
		try {
			InputStream io = DataReader.class.getClassLoader()
					.getResourceAsStream(fileLocation);
			wb = new XSSFWorkbook(io);
		} catch (IOException e) {
			s_logger.error("Unable to read data file", e);
			Assert.fail("Unable to read data file", e);
		}
		XSSFSheet sheet = wb.getSheetAt(0);
		LinkedList<String> columnNames = getColumnNames(sheet);
		LinkedHashMap<String, String> testDataMap = getRowData(sheet,
				keyName, columnNames);
		
		if(anothersheet){
			XSSFSheet sheet2 = wb.getSheet(pageVarExcelName);
			LinkedList<String> columnNameforPageVar = getColumnNames(sheet2);
			LinkedHashMap<String, String> testDataMapforPageVar = getRowData(sheet2,
					keyName, columnNameforPageVar);
			testDataMap.putAll(testDataMapforPageVar);
		}
		
		return testDataMap;
	}
	

	/**
	 * Get the column names from the sheet.
	 * @param sheet
	 * @return
	 */
	private static LinkedList<String> getColumnNames(XSSFSheet sheet) {
		LinkedList<String> columnList = new LinkedList<String>();
		Row row = sheet.getRow(0);
		int firstColNum = row.getFirstCellNum();
		int lastColNum = row.getLastCellNum();
		for (int i = firstColNum; i < lastColNum; i++) {
			String cell = row.getCell(i).toString();
			columnList.add(cell);
		}
		return columnList;
	}
	
	
	/**
	 * Get a Map with all column names mapped to their respective column values for the row corresponding to dataKey. 
	 * @param sheet
	 * @param dataKey
	 * @param columnNames
	 * @return
	 */
	private static LinkedHashMap<String, String> getRowData(
			XSSFSheet sheet, String dataKey, LinkedList<String> columnNames) {
		LinkedHashMap<String, String> sheetData = new LinkedHashMap<String, String>();
		try {
			int firstColNum = 0;
			int lastColNum = 0;
			int firstrowNum = sheet.getFirstRowNum();
			int lastrownum = sheet.getLastRowNum();
			outerloop: for (int i = firstrowNum; i <= lastrownum; i++) {
				Row row = sheet.getRow(i);
				if (i == 0) {
					firstColNum = row.getFirstCellNum();
					lastColNum = row.getLastCellNum();
				}
				Cell testIdSheet = row.getCell(0);
				testIdSheet.setCellType(Cell.CELL_TYPE_STRING);
				if (testIdSheet.getStringCellValue().trim().equals(dataKey)) {
					for (int j = firstColNum; j < lastColNum; j++) {
						XSSFCell cell;
						String value = "";
						String columnName = "";
						columnName = columnNames.get(j);
						cell = (XSSFCell) row.getCell(j);
						if (cell == null) {
							cell = (XSSFCell) row.createCell(j);
							value = String.valueOf(cell);
							sheetData.put(columnName, value);
						} else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
							cell.setCellType(Cell.CELL_TYPE_STRING);
							value = String.valueOf(cell);
							sheetData.put(columnName, value);
						} else {
							cell = (XSSFCell) row.getCell(j);
							value = String.valueOf(cell);
							sheetData.put(columnName, value);
						}
					}
					break outerloop;
				}
			}
		}

		catch (Exception e) {
			s_logger.error("Unable to fetch the row", e);
			Assert.fail("Unable to fetch the row", e);
		}
		return sheetData;
	}
	

	
	public static LinkedHashMap<String, String> writeRowData(
			XSSFSheet sheet, String dataKey, File file, XSSFWorkbook wb) {
		LinkedHashMap<String, String> sheetData = new LinkedHashMap<String, String>();
		try {
			int lastColNum = 0;
			int firstrowNum = sheet.getFirstRowNum();
			int lastrownum = sheet.getLastRowNum();
			outerloop: for (int i = firstrowNum; i <= lastrownum; i++) {
				Row row = sheet.getRow(i);
				if (i == 0) {
					lastColNum = row.getLastCellNum();
				}
				Cell testIdSheet = row.getCell(0);
				testIdSheet.setCellType(Cell.CELL_TYPE_STRING);
				if (testIdSheet.getStringCellValue().trim().equals(dataKey)) {
					XSSFCell cell = (XSSFCell) row.createCell(lastColNum);
					cell.setCellValue("str");
					System.out.println("Writing to "+lastColNum);
					break outerloop;
				}
			}
			FileOutputStream outs = new FileOutputStream(file);
			wb.write(outs);
            outs.close();
		}

		catch (Exception e) {
			s_logger.error("Unable to fetch the row", e);
			Assert.fail("Unable to fetch the row", e);
		}
		return sheetData;
	}
	
	public static Map<String, String> setDataValues(String keyName, int data,
			String fileLocation) {
		XSSFWorkbook wb = null;
		File file = null;
		try {
			InputStream io = DataReader.class.getClassLoader()
					.getResourceAsStream(fileLocation);
			file = new File(System.getProperty("user.dir") + "\\src\\main\\resources\\com\\asda\\qa\\data\\Accessibility.xlsx");
			wb = new XSSFWorkbook(io);
		} catch (IOException e) {
			s_logger.error("Unable to read data file", e);
			Assert.fail("Unable to read data file", e);
		}
		XSSFSheet sheet = wb.getSheetAt(0);
//		LinkedHashMap<String, String> testDataMap = writeRowData(sheet,
//				keyName,file,wb);
		LinkedHashMap<String, String> testDataMap = writeRowData(sheet,
				keyName,data,file,wb);
		return testDataMap;
	}
	
	public static LinkedHashMap<String, String> writeRowData(
			XSSFSheet sheet, String dataKey, int data, File file, XSSFWorkbook wb) {
		LinkedHashMap<String, String> sheetData = new LinkedHashMap<String, String>();
		try {
			int lastColNum = 0;
			int firstrowNum = sheet.getFirstRowNum();
			int lastrownum = sheet.getLastRowNum();
			int firstCell;
			int lastCell;
			outerloop: for (int i = firstrowNum; i <= lastrownum; i++) {
				Row row = sheet.getRow(i);
				if (i == 0) {
					lastColNum = row.getLastCellNum();
				}
				firstCell = row.getFirstCellNum();
				lastCell = row.getLastCellNum();
				for (int k = firstCell; k < lastCell; k++) {
					Cell testIdSheet = row.getCell(k);
					testIdSheet.setCellType(Cell.CELL_TYPE_STRING);
					if (testIdSheet.getStringCellValue().trim().equals(dataKey)) {
						XSSFCell cell = (XSSFCell) row
								.createCell(lastColNum - 1);
						cell.setCellValue(data);
						System.out.println("Writing to " + lastColNum);
						break outerloop;
					}
				}
			}
			FileOutputStream outs = new FileOutputStream(file);
			wb.write(outs);
            outs.close();
		}

		catch (Exception e) {
			s_logger.error("Unable to fetch the row", e);
			Assert.fail("Unable to fetch the row", e);
		}
		return sheetData;
	}
}
