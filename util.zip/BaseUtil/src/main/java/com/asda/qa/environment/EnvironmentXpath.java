package com.asda.qa.environment;

import java.io.IOException;
import java.util.Properties;

public class EnvironmentXpath {
	private static EnvironmentXpath xpathInstance;
	// Test
	private static Properties xpath;

	private EnvironmentXpath(Properties props) {
		xpath = props;
	}

	public synchronized static void xpathInitialization() {
		if (xpathInstance != null) {
			throw new RuntimeException("Trying to load xpath properties file");
		}
		Properties props = new Properties();
		try {
			props.load(EnvironmentXpath.class.getClassLoader()
					.getResourceAsStream("com/asda/qa/environment/xpathInitialize.properties"));
		} catch (IOException e) {
			throw new RuntimeException("Unable intialize environment.", e);
		}

		xpathInstance = new EnvironmentXpath(props);
	}

	public static EnvironmentXpath getInstance() {
		if (xpathInstance == null) {
			throw new RuntimeException("xpath not initialized.");
		}
		return xpathInstance;
	}

	public static String getOSEvoucherNamesList() {

		return xpath.getProperty("evoucherNamesList");
	}

	public static String getOSEvoucherName() {

		return xpath.getProperty("EvoucherName");
	}

	public static String getOSEvoucherCheckBoxXpath() {

		return xpath.getProperty("evoucherCheckBoxXpath");
	}

	public static String getOSEvoucherTitle() {

		return xpath.getProperty("evoucherTitle");
	}

	public static String getOSEvoucherTitleNew() {

		return xpath.getProperty("eVoucherTitleNew");
	}

	public static String getOSEvoucherCloseLink() {

		return xpath.getProperty("evoucherCloseLink");
	}

	public static String getOSAddAnEvoucherLink() {

		return xpath.getProperty("addAnEvoucherLink");
	}

	public static String getOSYourTotalMiniTrolley() {

		return xpath.getProperty("yourTotalMiniTrolley");
	}

	public static String getOSPaymentCardTitle() {

		return xpath.getProperty("paymentCardTitle");
	}

	public static String getOSPaymentChangeLink() {

		return xpath.getProperty("paymentChangeLink");
	}

	public static String getOSSelectCardDropDown() {

		return xpath.getProperty("selectCardDropDown");
	}

	public static String getOSCardNumberLabel() {

		return xpath.getProperty("CardNumberLabel");
	}

	public static String getOSCardNumberInputBox() {

		return xpath.getProperty("cardNumberInputBox");
	}

	public static String getOSNameOnCardLabel() {

		return xpath.getProperty("nameOnCardLabel");
	}

	public static String getOSNameCardLabelInputBox() {

		return xpath.getProperty("nameCardLabelInputBox");
	}

	public static String getOSExpiryDateLabel() {

		return xpath.getProperty("expiryDateLabel");
	}

	public static String getOSExpiryDateInputBox() {

		return xpath.getProperty("expiryDateInputBox");
	}

	public static String getOSBillingAddress() {

		return xpath.getProperty("BillingAddress");
	}

	public static String getOSSaveText() {

		return xpath.getProperty("SaveText");
	}

	public static String getOSUseCardButton() {

		return xpath.getProperty("useCardButton");
	}

	public static String getOSSaveThisCardButton() {

		return xpath.getProperty("saveThisCardButton");
	}

	public static String getOSYourPostcodeLabel() {

		return xpath.getProperty("youPostcodeLabel");
	}

	public static String getOSAddAddressTitle() {

		return xpath.getProperty("addAddressTitle");
	}

	public static String getOSPostCodeInputBox() {

		return xpath.getProperty("postCodeInputBox");
	}

	public static String getOSFindButton() {

		return xpath.getProperty("findButton");
	}

	public static String getOSCancelButton() {

		return xpath.getProperty("cancelButton");
	}

	public static String getOSAddressDropdown() {

		return xpath.getProperty("addressDropdown");
	}

	public static String getOSAddress1label() {

		return xpath.getProperty("address1label");
	}

	public static String getOSAddress1value() {

		return xpath.getProperty("address1value");
	}

	public static String getOSAddress2Label() {

		return xpath.getProperty("address2Label");
	}

	public static String getOSAddress2Value() {

		return xpath.getProperty("address2Value");
	}

	public static String getOSCityLabel() {

		return xpath.getProperty("cityLabel");
	}

	public static String getOSCityValue() {

		return xpath.getProperty("cityValue");
	}

	public static String getOSPostCodeLabel() {

		return xpath.getProperty("postCodeLabel");
	}

	public static String getOSPostCodeValue() {

		return xpath.getProperty("postCodeValue");
	}

	public static String getOSPropertyType() {

		return xpath.getProperty("propertyType");
	}

	public static String getOSHouseRadioBtn() {

		return xpath.getProperty("houseRadioBtn");
	}

	public static String getOSFlatRadioBtn() {

		return xpath.getProperty("flatRadioBtn");
	}

	public static String getOSEvoucherInputBox() {

		return xpath.getProperty("evoucherInputBox");
	}

	public static String getOSEvoucherAddButton() {

		return xpath.getProperty("evoucherAddButton");
	}

	public static String getOSEvoucherTypeDetails() {

		return xpath.getProperty("EvoucherTypeDetails");
	}

	public static String getOSEVoucherType() {

		return xpath.getProperty("EVoucherType");
	}

	public static String getOSEVoucherPrice() {

		return xpath.getProperty("EVoucherPrice");
	}

	public static String getOSEvoucherTNC() {

		return xpath.getProperty("EvoucherTNC");
	}

	public static String getOSEvoucherExpiresLabel() {

		return xpath.getProperty("EvoucherExpiresLabel");
	}

	public static String getOSEvoucherExpiryValue() {

		return xpath.getProperty("EvoucherExpiryValue");
	}

	public static String getOSrestrictedInfoError() {

		return xpath.getProperty("restrictedInfoError");
	}

	public static String getOSTrolleyHeader() {

		return xpath.getProperty("TrolleyHeader");
	}

	public static String getOSTrolleyViewLink() {

		return xpath.getProperty("TrolleyViewLink");
	}

	public static String getOSTrolleyInfoText() {

		return xpath.getProperty("TrolleyInfoText");
	}

	public static String getOSTrolleyChangeOptionLink() {

		return xpath.getProperty("TrolleyChangeOptionLink");
	}

	public static String getOSAllowSubsText() {

		return xpath.getProperty("AllowSubsText");
	}

	public static String getOSAllowSubsCheckbox() {

		return xpath.getProperty("AllowSubsCheckbox");
	}

	public static String getOSDepartmenNameList() {

		return xpath.getProperty("DepartmenNameList");
	}

	public static String getOSProductCheckBoxList() {

		return xpath.getProperty("ProductCheckBoxList");
	}

	public static String getOSDepartmentName() {

		return xpath.getProperty("DepartmentName");
	}

	public static String getOSProductTitleList() {

		return xpath.getProperty("ProductTitleList");
	}

	public static String getOSProductName() {

		return xpath.getProperty("ProductName");
	}

	public static String getOSProductSkuSize() {

		return xpath.getProperty("ProductSkuSize");
	}

	public static String getOSProductPrice() {

		return xpath.getProperty("ProductPrice");
	}

	public static String getOSProductOUM() {

		return xpath.getProperty("ProductOUM");
	}

	public static String getOSProductImage() {

		return xpath.getProperty("ProductImage");
	}

	public static String getOSProductWasprice() {

		return xpath.getProperty("ProductWasprice");
	}

	public static String getOSProductQty() {

		return xpath.getProperty("ProductQty");
	}

	public static String getOSProductSubsLabel() {

		return xpath.getProperty("ProductSubsLabel");
	}

	public static String getOSProductSubsCheckBox() {

		return xpath.getProperty("ProductSubsCheckBox");
	}

	public static String getOSTrolleyCloseLinkList() {

		return xpath.getProperty("TrolleyCloseLinkList");
	}

	public static String getOSProductPlusBtn() {

		return xpath.getProperty("ProductPlusBtn");
	}

	public static String getOSProductMinusBtn() {

		return xpath.getProperty("ProductMinusBtn");
	}

	public static String getOSProductqtyAddBtn() {

		return xpath.getProperty("ProductqtyAddBtn");
	}

	public static String getOSProductPromo() {

		return xpath.getProperty("ProductPromo");
	}

	public static String getOSProductLinkSaveTitle() {

		return xpath.getProperty("ProductLinkSaveTitle");
	}

	public static String getOSYourTotalTextMiniTrolley() {

		return xpath.getProperty("YourTotalTextMiniTrolley");
	}

	public static String getOSYourOrderSummaryTextMiniTrolley() {

		return xpath.getProperty("YourOrderSummaryTextMiniTrolley");
	}

	public static String getOSShoppingTotalTextMiniTrolley() {

		return xpath.getProperty("ShoppingTotalTextMiniTrolley");
	}

	public static String getOSShoppingTotalValueMiniTrolley() {

		return xpath.getProperty("ShoppingTotalValueMiniTrolley");
	}

	public static String getOSPickPackTexMiniTrolley() {

		return xpath.getProperty("PickPackTexMiniTrolley");
	}

	public static String getOSPickPackValueMiniTrolley() {

		return xpath.getProperty("PickPackValueMiniTrolley");
	}

	public static String getOSCarrierBagsTotalLabelMiniTrolley() {

		return xpath.getProperty("CarrierBagsTotalLabelMiniTrolley");
	}

	public static String getOSCarrierBagsTotalvalueMiniTrolley() {

		return xpath.getProperty("CarrierBagsTotalvalueMiniTrolley");
	}

	public static String getOSeVoucherLabelMiniTrolley() {

		return xpath.getProperty("eVoucherLabelMiniTrolley");
	}

	public static String getOSeVoucherValueMiniTrolley() {

		return xpath.getProperty("eVoucherValueMiniTrolley");
	}

	public static String getOSMulitiSavingsLabelMiniTrolley() {

		return xpath.getProperty("MulitiSavingsLabelMiniTrolley");
	}

	public static String getOSMultiSavingsValueMiniTrolley() {

		return xpath.getProperty("MultiSavingsValueMiniTrolley");
	}

	public static String getOSOtherInfoTitle() {

		return xpath.getProperty("OtherInfoTitle");
	}

	public static String getOSFirstNameLabel() {

		return xpath.getProperty("FirstNameLabel");
	}

	public static String getOSFirstNameValue() {

		return xpath.getProperty("FirstNameValue");
	}

	public static String getOSLastNameLabel() {

		return xpath.getProperty("LastNameLabel");
	}

	public static String getOSLastNameValue() {

		return xpath.getProperty("LastNameValue");
	}

	public static String getOSContactNumberLabel() {

		return xpath.getProperty("ContactNumberLabel");
	}

	public static String getOSContactInfoText() {

		return xpath.getProperty("ContactInfoText");
	}

//	public static String getOSMobileText() {
//
//		return xpath.getProperty("MobileText");
//	}

	public static String getOSMobileValue() {

		return xpath.getProperty("MobileValue");
	}

	public static String getOSMobileDropdown() {

		return xpath.getProperty("MobileDropdown");
	}

	public static String getOSDayTimeValue() {

		return xpath.getProperty("DayTimeValue");
	}

//	public static String getOSDayTimeDeleteBtn() {
//
//		return xpath.getProperty("DayTimeDeleteBtn");
//	}

//	public static String getOSEveningText() {
//
//		return xpath.getProperty("EveningText");
//	}

//	public static String getOSEveningDeleteBtn() {
//
//		return xpath.getProperty("EveningDeleteBtn");
//	}

	public static String getOSCarrierBagText() {

		return xpath.getProperty("CarrierBagText");
	}

	public static String getOSWhatIsThisLink() {

		return xpath.getProperty("WhatIsThisLink");
	}
	public static String getOSFindOutWhyLink() {

		return xpath.getProperty("FindOutWhy");
	}

	public static String getOSUseCarrierBagRadioBtn() {

		return xpath.getProperty("UseCarrierBagRadioBtn");
	}

	public static String getOSUseCarrierBagTxt() {

		return xpath.getProperty("UseCarrierBagTxt");
	}

	public static String getOSNoCarrierBagRadioBtn() {

		return xpath.getProperty("NoCarrierBagRadioBtn");
	}

	public static String getOSNoCarrierBagTxt() {

		return xpath.getProperty("NoCarrierBagTxt");
	}

	public static String getOSDeliveryInstructionTxt() {

		return xpath.getProperty("DeliveryInstructionTxt");
	}

	public static String getOSDeliveryInstructionValue() {

		return xpath.getProperty("DeliveryInstructionValue");
	}

	public static String getOSSaveAndContBtn() {

		return xpath.getProperty("SaveAndContBtn");
	}

	public static String getOSOtherInfoCloseLink() {

		return xpath.getProperty("OtherInfoCloseLink");
	}

	public static String getOSTrolleyCloseLink() {
		return xpath.getProperty("TrolleyCloseLink");

	}

	public static String getOSQtyKgSelect() {
		return xpath.getProperty("QtyKgSelect");

	}

	public static String getOSOtherInfoChangeLink() {
		return xpath.getProperty("OtherInfoChangeLink");
	}

	public static String getOSContactNoText() {
		return xpath.getProperty("ContactNoText");
	}

	public static String getOSPrimaryNumberValue() {
		return xpath.getProperty("PrimaryNumberValue");
	}

	public static String getOSCarrierBags() {
		return xpath.getProperty("CarrierBags");
	}

	public static String getOSCarrierBagSelected() {
		return xpath.getProperty("CarrierBagSelected");
	}

	public static String getOSOnLoadDelivaryInstruction() {
		return xpath.getProperty("OnLoadDelivaryInstruction");
	}

	public static String getOSOnLoadDelivaryEntered() {
		return xpath.getProperty("OnLoadDelivaryEntered");
	}

//	public static String getOSAddAnotherPhoneNumberBtn() {
//		return xpath.getProperty("AddAnotherPhoneNumberBtn");
//	}

	public static String getOSAddPhoneNumberSelectBox() {
		return xpath.getProperty("PhoneNumberSeletBox");
	}

	public static String getOSEveningValue() {
		return xpath.getProperty("EveningValue");
	}

	public static String getOSSaveThisAddress() {
		return xpath.getProperty("SaveThisAddress");
	}

	public static String getOSTitleText() {
		return xpath.getProperty("TitleText");
	}

	public static String getOSTitleValue() {
		return xpath.getProperty("TitleValue");
	}

	public static String getOSWhyThisOvrelayCloseBtn() {
		return xpath.getProperty("WhyThisOvrelayCloseBtn");
	}

	public static String getOSWhyThisHeader() {
		return xpath.getProperty("WhyThisHeader");
	}
	
	public static String getOSFindOutWhyHeader() {
		return xpath.getProperty("FindOutWhyHeader");
	}

	public static String getOSWhyThisOverlayContinueBtn() {
		return xpath.getProperty("WhyThisOverlayContinueBtn");
	}

	public static String getOSVanIcon() {
		return xpath.getProperty("VanIcon");
	}

	public static String getOSDelivarySlotHeader() {
		return xpath.getProperty("DelivarySlotHeader");
	}

	public static String getOSDelivaryAddress() {
		return xpath.getProperty("DelivaryAddress");
	}

	public static String getOSDelivaryTimeIcon() {
		return xpath.getProperty("DelivaryTimeIcon");
	}

	public static String getOSDelivaryTime() {
		return xpath.getProperty("DelivaryTime");
	}

	public static String getOSChangeSlotLink() {
		return xpath.getProperty("ChangeSlotLink");
	}

	public static String getOSTrolleyDescription() {
		return xpath.getProperty("TrolleyDescription");
	}

	public static String getOSOrderSummaryHeader() {
		return xpath.getProperty("OrderSummaryHeader");
	}

	public static String getOSLockIcon() {
		return xpath.getProperty("LockIcon");
	}

	public static String getCollectionInstructionTxt() {
		return xpath.getProperty("CollectionInstructionTxt");
	}

	public static String getOSCollectionInstructionValue() {
		return xpath.getProperty("CollectionInstructionValue");
	}

	public static String getOSCollectionDeatilsHeader() {
		return xpath.getProperty("CollectionDeatilsHeader");
	}

	public static String getOSShoppingBagIcon() {
		return xpath.getProperty("ShoppingBagIcon");
	}

	public static String getOSMobileMandateErrorMessage() {
		return xpath.getProperty("MobileMandateErrorMessage");
	}

	public static String getOSMobileNumErrorMessage() {
		return xpath.getProperty("MobileNumErrorMessage");
	}

	public static String getOSFirstNameErrorMessage() {
		return xpath.getProperty("FirstNameErrorMessage");
	}

	public static String getOSLastNameErrorMessage() {
		return xpath.getProperty("LastNameErrorMessage");
	}

	// Before You Go Page - Mini Trolley
	public static String getMiniTrolleyProductListDefaultSection() {
		return xpath.getProperty("miniTrolleyProductListDefaultSection").trim();
	}

	public static String getMiniTrolleyProductListExpandedSection() {
		return xpath.getProperty("miniTrolleyProductListExpandedSection").trim();
	}

	public static String getMiniTrolleyProductTitleDefaultList() {
		return xpath.getProperty("miniTrolleyProductTitleDefaultList").trim();
	}

	public static String getMiniTrolleyProductTitleExpandedList() {
		return xpath.getProperty("miniTrolleyProductTitleExpandedList").trim();
	}

	public static String getMiniTrolleyProductName() {
		return xpath.getProperty("miniTrolleyProductName").trim();
	}

	public static String getMiniTrolleyProductNameFirstProd() {
		return xpath.getProperty("miniTrolleyProductNameFirstProd").trim();
	}

	public static String getMiniTrolleyProductPrice() {
		return xpath.getProperty("miniTrolleyProductPrice").trim();
	}

	public static String getMiniTrolleyProductUOM() {
		return xpath.getProperty("miniTrolleyProductUOM").trim();
	}

	public static String getMiniTrolleyProductQty() {
		return xpath.getProperty("miniTrolleyProductQty").trim();
	}

	public static String getMiniTrolleyProductMinusBtn() {
		return xpath.getProperty("miniTrolleyProductMinusBtn").trim();
	}

	public static String getMiniTrolleyProductPlusBtn() {
		return xpath.getProperty("miniTrolleyProductPlusBtn").trim();
	}

	// Book Slot - CNC - Map View
	public static String getCNCMapViewAsListLink() {
		return xpath.getProperty("cncMapViewAsListLink").trim();
	}

	// Book Slot - CNC - List View

	public static String getCNCListViewForm() {
		return xpath.getProperty("cncListViewForm").trim();
	}

	public static String getCNCListViewFindBtn() {
		return xpath.getProperty("cncListViewFindBtn").trim();
	}

	public static String getCNCListViewPostCodeTextBox() {
		return xpath.getProperty("cncListViewPostCodeTextBox").trim();
	}

	public static String getCNCListViewLocationTableHeader() {
		return xpath.getProperty("cncListViewLocationTableHeader").trim();
	}

	public static String getCNCListViewLocationSelectText() {
		return xpath.getProperty("cncListViewLocationSelectText").trim();
	}

	public static String getCNCListViewAsMapLink() {
		return xpath.getProperty("cncListViewAsMapLink").trim();
	}

	public static String getCNCListViewLocationDropdown() {
		return xpath.getProperty("cncListViewLocationDropdown").trim();
	}

	public static String getCNCListViewLocationTable() {
		return xpath.getProperty("cncListViewLocationTable").trim();
	}

	public static String getCNCListViewStoreNames() {
		return xpath.getProperty("cncListViewStoreNames").trim();
	}

	public static String getCNCListViewStoreLocationSection() {
		return xpath.getProperty("cncListViewStoreLocationSection").trim();
	}

	public static String getCNCListViewIcon() {
		return xpath.getProperty("cncListViewIcon").trim();
	}

	public static String getCNCListViewAddressSection() {
		return xpath.getProperty("cncListViewStoreAddressSection").trim();
	}

	public static String getCNCListViewAddressLine1() {
		return xpath.getProperty("cncListViewStoreAddressLine1").trim();
	}

	public static String getCNCListViewAddressLine2() {
		return xpath.getProperty("cncListViewStoreAddressLine2").trim();
	}

	public static String getCNCListViewStoreAddressCity() {
		return xpath.getProperty("cncListViewStoreAddressCity").trim();
	}

	public static String getCNCListViewStorePostalCode() {
		return xpath.getProperty("cncListViewStorePostalCode").trim();
	}

	public static String getCNCListViewPhoneNumber() {
		return xpath.getProperty("cncListViewStorePhoneNumber").trim();
	}

	public static String getCNCListViewCollectionInstruction() {
		return xpath.getProperty("cncListViewCollectionInstruction").trim();
	}

	public static String getCNCListViewMiles() {
		return xpath.getProperty("cncListViewMiles").trim();
	}

	public static String getCNCListViewDirectionsLink() {
		return xpath.getProperty("cncListViewDirectionsLink").trim();
	}

	public static String getCNCListViewSelectThisLocationLink() {
		return xpath.getProperty("cncListViewSelectThisLocationLink").trim();
	}

	public static String getOSPaymentCloseLink() {
		return xpath.getProperty("paymentCloseLink").trim();
	}

	public static String getOSStartDateInputBox() {
		return xpath.getProperty("StartDateInputBox").trim();
	}

	public static String getOSBillingAddressList() {
		return xpath.getProperty("BillingAddressList").trim();
	}

	public static String getOSMobileValueBillingAddress() {

		return xpath.getProperty("MobileValueBillingAddress");
	}

	public static String getOSAppliedEvoucherName() {

		return xpath.getProperty("AppliedEvoucherName");
	}

	public static String getOSAppliedEVoucherType() {

		return xpath.getProperty("AppliedEVoucherType");
	}

	public static String getOSAppliedEVoucherPrice() {

		return xpath.getProperty("AppliedEVoucherPrice");
	}

	public static String getOSAppliedEvoucherTNC() {

		return xpath.getProperty("AppliedEvoucherTNC");
	}

	public static String getOSoverlayTitle() {
		return xpath.getProperty("overlayTitle");
	}

	public static String getOSOverlayErrorMessage() {
		return xpath.getProperty("OverlayErrorMessage");
	}

	public static String getOSOverlayContinueBtn() {
		return xpath.getProperty("OverlayContinueBtn");
	}

	public static String getOSOverlayCloseBtn() {
		return xpath.getProperty("OverlayCloseBtn");
	}

	public static String getOSEvoucherErrorMessage() {
		return xpath.getProperty("EvoucherErrorMessage");
	}

	public static String getOSCvvNumberLabel() {
		return xpath.getProperty("CvvNumberLabel");
	}

	public static String getOSCvvWhatIsThisLink() {
		return xpath.getProperty("CvvWhatIsThisLink");
	}

	public static String getOSCvvInputBox() {
		return xpath.getProperty("CvvInputBox");
	}

	public static String getOSCvvImage() {
		return xpath.getProperty("CvvImage");
	}

	public static String getOSCvvOverlayContent() {
		return xpath.getProperty("CvvOverlayContent");
	}

	public static String getOSCvvOvealayImg1() {
		return xpath.getProperty("CvvOvealayImg1");
	}

	public static String getOSCvvOvealayImg2() {
		return xpath.getProperty("CvvOvealayImg2");
	}

	public static String getOSOverlayMessage() {
		return xpath.getProperty("overlayMessage");
	}

	public static String getOSauthMessage() {
		return xpath.getProperty("authMessage");
	}

	public static String getOSDontshowMeLabel() {
		return xpath.getProperty("DontshowMeLabel");
	}

	public static String getOSDontshowMeCheckBox() {
		return xpath.getProperty("DontshowMeCheckBox");
	}

	public static String getOSProceedToCheckoutBtn() {
		return xpath.getProperty("proceedToCheckout");
	}

	public static String getOSBackToShopBtn() {
		return xpath.getProperty("BackToShop");
	}

	public static String getOSDOBoverlayInfo1() {
		return xpath.getProperty("DOBoverlayInfo1");
	}

	public static String getDOBoverlayInfo2() {
		return xpath.getProperty("DOBoverlayInfo2");
	}

	public static String getOSDOBoverlayInfo3() {
		return xpath.getProperty("DOBoverlayInfo3");
	}

	public static String getOSDOBdateDropdown() {
		return xpath.getProperty("DOBdateDropdown");
	}

	public static String getOSDOBmonthDropdown() {
		return xpath.getProperty("DOBmonthDropdown");
	}

	public static String getOSDOBYear() {
		return xpath.getProperty("DOBYear");
	}

	public static String getOSDOBErrorMessage() {
		return xpath.getProperty("DOBErrorMessage");
	}

	// Book Slot - Changes To Your Trolley Overlay
	public static String getChangesToTrolleyOverlay() {
		return xpath.getProperty("changesToTrolleyOverlay").trim();
	}

	public static String getChangesToTrolleyOverlayModalHeader() {
		return xpath.getProperty("changesToTrolleyOverlayModalHeader").trim();
	}

	public static String getChangesToTrolleyOverlayModalHeaderText() {
		return xpath.getProperty("changesToTrolleyOverlayModalHeaderText").trim();
	}

	public static String getChangesToTrolleyOverlayTextArea() {
		return xpath.getProperty("changesToTrolleyTextArea").trim();
	}

	public static String getChangesToTrolleyOverlaySorryText() {
		return xpath.getProperty("changesToTrolleySorryText").trim();
	}

	public static String getChangesToTrolleyOverlayListTitle() {
		return xpath.getProperty("changesToTrolleyListTitle").trim();
	}

	public static String getChangesToTrolleyOverlayListTitleNew() {
		return xpath.getProperty("changesToTrolleyListTitleNew").trim();
	}

	public static String getChangesToTrolleyOverlayListTitleText() {
		return xpath.getProperty("changesToTrolleyListTitleText").trim();
	}

	public static String getChangesToTrolleyOverlayProductImage() {
		return xpath.getProperty("changesToTrolleyProductImage").trim();
	}

	public static String getChangesToTrolleyOverlayProductName() {
		return xpath.getProperty("changesToTrolleyProductName").trim();
	}

	public static String getChangesToTrolleyOverlayProductWeight() {
		return xpath.getProperty("changesToTrolleyProductWeight").trim();
	}

	public static String getChangesToTrolleyOverlayProductPrice() {
		return xpath.getProperty("changesToTrolleyProductPrice").trim();
	}

	public static String getChangesToTrolleyOverlayProductPricePerUOM() {
		return xpath.getProperty("changesToTrolleyProductPricePerUOM").trim();
	}

	public static String getChangesToTrolleyOverlayProductChangeBanner() {
		return xpath.getProperty("changesToTrolleyProductChangeBanner").trim();
	}

	public static String getChangesToTrolleyOverlayItemUnavailableBannerText() {
		return xpath.getProperty("changesToTrolleyItemUnavailableBannerText").trim();
	}

	public static String getChangesToTrolleyOverlayCancelBtn() {
		return xpath.getProperty("changesToTrolleyCancelBtn").trim();
	}

	public static String getChangesToTrolleyOverlayContinueBtn() {
		return xpath.getProperty("changesToTrolleyContinueBtn").trim();
	}

	public static String getChangesToTrolleyOverlayCloseBtn() {
		return xpath.getProperty("changesToTrolleyCloseBtn").trim();
	}

	public static String getBookSlotOverlayCloseBtn() {
		return xpath.getProperty("bookSlotOverlayCloseBtn").trim();
	}

	public static String getChangesToTrolleyOverlayPriceChangeText() {
		return xpath.getProperty("changesToTrolleyPriceChangeListTitleText").trim();
	}

	public static String getChangesToTrolleyProductQty() {
		return xpath.getProperty("changesToTrolleyProductQty").trim();
	}

	public static String getChangesToTrolleyProductIncrementBtn() {
		return xpath.getProperty("changesToTrolleyProductIncrementBtn").trim();
	}

	public static String getChangesToTrolleyProductDecrementBtn() {
		return xpath.getProperty("changesToTrolleyProductDecrementBtn").trim();
	}

	public static String getChangesToTrolleyProductQtyDescription() {
		return xpath.getProperty("changesToTrolleyProductQtyDescription").trim();
	}

	public static String getChangesToTrolleyProductQtyDescriptionText() {
		return xpath.getProperty("changesToTrolleyProductQtyDescriptionText").trim();
	}

	public static String getChangesToTrolleyOverlayOutOfStockBannerText() {
		return xpath.getProperty("changesToTrolleyOutOfStockBannerText").trim();
	}

	public static String getSlotReservedOverlay() {
		return xpath.getProperty("slotReservedOverlay").trim();
	}

	public static String getRecurringSlotSuccessMessage() {
		return xpath.getProperty("recurringSlotSuccessMsg").trim();
	}

	public static String getRecurringSlotActiveForInfo() {
		return xpath.getProperty("recurringSlotActiveForInfo").trim();
	}

	public static String getRecurringSlotYourOrdersLink() {
		return xpath.getProperty("recurringSlotYourOrdersLink").trim();
	}

	public static String getRecurringSlotTermsAndConditionsLink() {
		return xpath.getProperty("recurringSlotTermsNConditionsLink").trim();
	}

	public static String getRecurringSlotLeftLabels() {
		return xpath.getProperty("recurringSlotLeftLables").trim();
	}

	public static String getRecurringSlotRightDetails() {
		return xpath.getProperty("recurringSlotRightDetails").trim();
	}

	public static String getOSIUnderStandLabel() {
		return xpath.getProperty("IUnderStandLabel").trim();
	}

	public static String getOSTrolleyProductAddButton() {
		return xpath.getProperty("TrolleyProductAddButton").trim();
	}

	public static String getOSProceedButton() {
		return xpath.getProperty("ProceedButton").trim();
	}

	public static String getOSMaxQtyText() {
		return xpath.getProperty("MaxQtyText").trim();
	}

	public static String getOSMaxQtyHeader() {
		return xpath.getProperty("MaxQtyHeader").trim();
	}

	public static String getOSMaxQtyCloseButton() {
		return xpath.getProperty("MaxQtyCloseButton").trim();
	}

	public static String getOSGoToShopBtn() {
		return xpath.getProperty("GoToShopBtn").trim();
	}

	// Print Preview Page Attributes
	public static String getPrintPreviewProductAttributes() {
		return xpath.getProperty("printPreviewProductAttributes").trim();
	}

	public static String getChangeSlotLinkOnSlotReservedOverlay() {
		return xpath.getProperty("changeSlotLinkOnSlotReservedOverlay").trim();
	}

	public static String getAuthMessagefooter() {
		return xpath.getProperty("AuthMessagefooter").trim();
	}

	public static String getAuthMessageOverlay() {
		return xpath.getProperty("AuthMessageOverlay").trim();
	}

	// Order Confirmation Page Attributes
	public static String getOrderConfirmationAsdaLogo() {
		return xpath.getProperty("orderConfirmationAsdaLogo").trim();
	}

	public static String getOrderConfirmationMainContentSection() {
		return xpath.getProperty("orderConfirmationMainContentSection").trim();
	}

	public static String getOrderConfirmationPageTitle() {
		return xpath.getProperty("orderConfirmationPageTitle").trim();
	}

	public static String getOrderConfirmationSecureIcon() {
		return xpath.getProperty("orderConfirmationSecureIcon").trim();
	}

	public static String getOrderConfirmationTopMessage() {
		return xpath.getProperty("orderConfirmationTopMessage").trim();
	}

	public static String getOrderConfirmationTnCLink() {
		return xpath.getProperty("orderConfirmationTnCLink").trim();
	}

	public static String getOrderConfirmationRightContentSection() {
		return xpath.getProperty("orderConfirmationRightContentSection").trim();
	}

	public static String getOrderConfirmationRichText1() {
		return xpath.getProperty("orderConfirmationRichText1").trim();
	}

	public static String getOrderConfirmationRichText2() {
		return xpath.getProperty("orderConfirmationRichText2").trim();
	}

	public static String getOCYourOrderConfiramtionHeader() {
		return xpath.getProperty("YourOrderConfiramtionHeader").trim();
	}

	public static String getOCOrderNumberLabel() {
		return xpath.getProperty("OrderNumberLabel").trim();
	}

	public static String getOCOrderNumber() {
		return xpath.getProperty("OrderNumber").trim();
	}

	public static String getOCItemsOrderedLabel() {
		return xpath.getProperty("ItemsOrderedLabel").trim();
	}

	public static String getOCItemsOrdered() {
		return xpath.getProperty("ItemsOrdered").trim();
	}

	public static String getOCTimeLabel() {
		return xpath.getProperty("TimeLabel").trim();
	}

	public static String getOCTime() {
		return xpath.getProperty("Time").trim();
	}

	public static String getOCYourTotalLabel() {
		return xpath.getProperty("YourTotalLabel").trim();
	}

	public static String getOCYourTotal() {
		return xpath.getProperty("YourTotal").trim();
	}

	public static String getOCDeliveryText() {
		return xpath.getProperty("DeliveryText").trim();
	}

	public static String getOCDeliveryAddress() {
		return xpath.getProperty("DeliveryAddress").trim();
	}

	public static String getOCNoteInfo() {
		return xpath.getProperty("NoteInfo").trim();
	}

	public static String getOCForgottenSomethingLabel() {
		return xpath.getProperty("ForgottenSomethingLabel").trim();
	}

	public static String getOCForgottenSomethingInfo() {
		return xpath.getProperty("ForgottenSomethingInfo").trim();
	}

	public static String getOCInformedLabel() {
		return xpath.getProperty("orderConfirmationInformedLabel").trim();
	}

	public static String getOCInformedInfo1() {
		return xpath.getProperty("orderConfirmationInformedInfo1").trim();
	}

	public static String getOCInformedInfo2() {
		return xpath.getProperty("orderConfirmationInformedInfo2").trim();
	}

	public static String getOCInformedOrderDetailsLink() {
		return xpath.getProperty("orderConfirmationInformedOrderDetailsLink").trim();
	}

	public static String getOCInformedFaqsLink() {
		return xpath.getProperty("orderConfirmationInformedVisitFaqsLink").trim();
	}

	public static String getContactDetailsDropdown() {
		return xpath.getProperty("ContactDetailsDropdown");
	}

	public static String getoutOfStockBanner() {
		return xpath.getProperty("outOfStockBanner");
	}

	public static String getseeAlternativeLink() {
		return xpath.getProperty("seeAlternativeLink");
	}

	public static String getpaymentCardErrorMessage() {
		return xpath.getProperty("paymentCardErrorMessage");
	}

	public static String getOSReviewPaymentBtn() {
		return xpath.getProperty("getOSReviewPaymentBtn");
	}

	public static String getOver18TickBox() {
		return xpath.getProperty("Over18tickBox");
	}

	public static String getminiTrolleyShoppingTotal() {
		return xpath.getProperty("miniTrolleyShoppingTotal");
	}

	public static String getminiTrolleyYourTotal() {
		return xpath.getProperty("miniTrolleyYourTotal");
	}

	public static String getminiTrolleyMultibugSavingsTotal() {
		return xpath.getProperty("miniTrolleyMultibugSavingsTotal");
	}

	public static String getminiTrolleyOfferStatus() {
		return xpath.getProperty("miniTrolleyOfferStatus");
	}

	public static String getCancelAmendOrderLink() {
		return xpath.getProperty("CancelAmendOrderLink");
	}

	public static String getCancelAmendOrderInfo() {
		return xpath.getProperty("CancelAmendOrderInfo");
	}

	public static String getCancleAmendOrderButton() {
		return xpath.getProperty("CancleAmendOrderButton");
	}

	public static String getproductCountAddedInAmendFlow() {
		return xpath.getProperty("productCountAddedInAmendFlow");
	}

	public static String getproductLabelHeaderAmendFlow() {
		return xpath.getProperty("productLabelHeaderAmendFlow");
	}

	public static String getOrderedLabelHeaderAmendFlow() {
		return xpath.getProperty("OrderedLabelHeaderAmendFlow");
	}

	public static String getUnitPriceLabelHeaderAmendFlow() {
		return xpath.getProperty("UnitPriceLabelHeaderAmendFlow");
	}

	public static String getTotalLabelHeaderAmendFlow() {
		return xpath.getProperty("TotalLabelHeaderAmendFlow");
	}

	public static String getProductNameAmendFlow() {
		return xpath.getProperty("ProductNameAmendFlow");
	}

	public static String getProductQtyAmendFlow() {
		return xpath.getProperty("ProductQtyAmendFlow");
	}

	public static String getProductUnitPriceAmendFlow() {
		return xpath.getProperty("ProductUnitPriceAmendFlow");
	}

	public static String getProductTotalAmendFlow() {
		return xpath.getProperty("ProductTotalAmendFlow");
	}

	public static String getCardNumberErrorMessage() {
		return xpath.getProperty("CardNumberErrorMessage");
	}

	public static String getCardNameErrorMessage() {
		return xpath.getProperty("CardNameErrorMessage");
	}

	public static String getExpiryDateErrorMessage() {
		return xpath.getProperty("ExpiryDateErrorMessage");
	}

	public static String getPostCodeErrorMessage() {
		return xpath.getProperty("PostCodeErrorMessage");
	}

	public static String getAddressLine1ErrorMessage() {
		return xpath.getProperty("AddressLine1ErrorMessage");
	}

	public static String getCityOrTownErrorMessage() {
		return xpath.getProperty("CityOrTownErrorMessage");
	}

	public static String getMobileNumberErrorMessage() {
		return xpath.getProperty("MobileNumberErrorMessage");
	}

	public static String getNonUKBillingAddressLink() {
		return xpath.getProperty("NonUKBillingkAddressLink");
	}

	public static String getOSMobileText() {

		return xpath.getProperty("MobileText");
	}

	public static String getOSDayTimeText() {

		return xpath.getProperty("DayTimeText");
	}

	public static String getOSDayTimeDeleteBtn() {

		return xpath.getProperty("DayTimeDeleteBtn");
	}

	public static String getOSEveningText() {

		return xpath.getProperty("EveningText");
	}

	public static String getOSEveningDeleteBtn() {

		return xpath.getProperty("EveningDeleteBtn");
	}

	public static String getOSAddAnotherPhoneNumberBtn() {
		return xpath.getProperty("AddAnotherPhoneNumberBtn");
	}


}