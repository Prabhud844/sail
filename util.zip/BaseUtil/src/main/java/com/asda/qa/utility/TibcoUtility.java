package com.asda.qa.utility;

import java.util.Hashtable;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.asda.qa.environment.EnvironmentConfig;

public class TibcoUtility {
	private static final Logger s_logger = LoggerFactory.getLogger(TibcoUtility.class);
	public final static String JNDI_FACTORY="com.tibco.tibjms.naming.TibjmsInitialContextFactory";
    public final static String JMS_FACTORY="QCF";
    public static final String SECURITY_PROTOCOL = "com.tibco.tibjms.naming.security_protocol";

    private static QueueConnectionFactory qconFactory;
    private static QueueConnection qcon;
    private static QueueSession qsession;
    private static QueueSender qsender;
    private static Queue queue;
    private static TextMessage msg;

    private static final String env = EnvironmentConfig.getInstance().getCurrentEnvironment();
    private static final String tibcoUrl = EnvironmentConfig.getInstance().getTibcoEmsUrl();
    private static final String tibcoUser = EnvironmentConfig.getInstance().getTibcoEmsUser();
    private static final String tibcoPassword = EnvironmentConfig.getInstance().getTibcoEmsPassword();

    /*
     * Invoke a tibco queue
     * @param - queueName
     * */
	public static void invoke(String queueName) throws JMSException {
		String QUEUE = null;
		s_logger.info("Invoking {} queue", queueName);

		QUEUE = queueName;

    		try {
    				s_logger.info("Invoking in {} environment :{}",env,tibcoUrl);
				InitialContext ic = getInitialContext(tibcoUrl);
				init(ic,QUEUE);
				send("start");
				close();
			} catch (NamingException e) {
				e.printStackTrace();
			} catch (JMSException e) {
				e.printStackTrace();
			}finally {
				if(qcon != null) {
					qsender.close();
					qsession.close();
					qcon.close();
				}
			}
    		s_logger.info("{} has been invoked.", QUEUE);

	}

	/*
	 * Initializing the tibco by connecting to particular tibco message sender
	 * @param context
	 * @param queueName
	 * */
    private static void init(Context ctx, String queueName) throws NamingException, JMSException {
        qconFactory = (QueueConnectionFactory) ctx.lookup(JMS_FACTORY);
        qcon = qconFactory.createQueueConnection(tibcoUser, tibcoPassword);
        qsession = qcon.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
        s_logger.info("connected");
        queue = (Queue) ctx.lookup(queueName);
        qsender = qsession.createSender(queue);
        msg = qsession.createTextMessage();
        qcon.start();
     }

    /*
     * Send a message via tibco
     * @param message
     * */
    private static void send(String message) throws JMSException{
        msg.setText(message);
        if(message !=null && !message.isEmpty() && message.trim().length()!=0) {
        		qsender.send(msg);
        		s_logger.info("JMS Message sent :{}",message);
        	}
     }

    /*
     * Initialize the Tibco Context
     * @param url for tibco server
     * */
     private static InitialContext getInitialContext(String url) throws NamingException {
        Hashtable<String, String> env = new Hashtable<String, String>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, JNDI_FACTORY);
        env.put(Context.PROVIDER_URL, url);
        env.put(Context.SECURITY_PRINCIPAL, tibcoUser );
        env.put(Context.SECURITY_CREDENTIALS, tibcoPassword);
        env.put(SECURITY_PROTOCOL, "tcp");
        return new InitialContext(env);
     }

     /*
      * closing a tibco connection
      * */
	 public static void close() throws JMSException {
	       qsender.close();
	       qsession.close();
	       qcon.close();
	       s_logger.info("Tibco Closed");
	 }

	 /*private static void readAndSend(TibcoMessageSender qs) throws IOException, JMSException {
	        String line=null;
	         s_logger.info("Entering message: ");
	         line = "start";
	         if (line != null && line.trim().length() != 0) {
	           qs.send(line);
	           s_logger.info("JMS Message Sent: "+line);
	         }
	 }*/
}
