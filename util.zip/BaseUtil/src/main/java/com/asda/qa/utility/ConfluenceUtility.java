package com.asda.qa.utility;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;



public class ConfluenceUtility {

//private static final String BASE_URL = "http://localhost:1990/confluence";
    private static final String BASE_URL = "https://confluence.walmart.com";
    private static  String USERNAME = "no data";
    private static  String PASSWORD = "no data";
    private static final String ENCODING = "utf-8";
    
    public String newpageurl="no data";
    
    
    public ConfluenceUtility(String uname,String pwd)
    {
    	USERNAME=uname;
    	PASSWORD=pwd;
    }

    public  String createContentRestUrl()throws UnsupportedEncodingException
    {
        return String.format("%s/rest/api/content/?&os_authType=basic&os_username=%s&os_password=%s", BASE_URL, URLEncoder.encode(USERNAME, ENCODING), URLEncoder.encode(PASSWORD, ENCODING));

    }

    


   

    public  void createConfluencePageViaPost(JSONObject newPage) throws Exception
    {
        HttpClient client = new DefaultHttpClient();

        // Send update request
        HttpEntity pageEntity = null;

        try
        {
            //2016-12-18 - StirlingCrow: Left off here.  Was finally able to get the post command to work
            //I can begin testing adding more data to the value stuff (see above)
            HttpPost postPageRequest = new HttpPost(createContentRestUrl());

            StringEntity entity = new StringEntity(newPage.toString(), ContentType.APPLICATION_JSON);
            postPageRequest.setEntity(entity);

            HttpResponse postPageResponse = client.execute(postPageRequest);
            pageEntity = postPageResponse.getEntity();
    
            

            System.out.println("Push Page Request returned " + postPageResponse.getStatusLine().toString());
            System.out.println(IOUtils.toString(pageEntity.getContent()));
            String strResponse=IOUtils.toString(pageEntity.getContent()).split(",")[0].split(":")[1];
         System.out.println("Id for new page:"+strResponse);
          String const_str="/pages/viewpage.action?pageId=";
          String newpageurl=BASE_URL+const_str+strResponse.replace("\"", "");
          
          setNewpageurl(newpageurl);
            
           System.out.println(newpageurl);
            
            
          
        }
        finally
        {
            EntityUtils.consume(pageEntity);
            
        }
    }

    public  JSONObject defineConfluencePage(String pageTitle,
                                                  String wikiEntryText,
                                                  String pageSpace,
                                                  String label,
                                                  int parentPageId) throws JSONException
    {
        //This would be the command in Python (similar to the example
        //in the Confluence example:
        //
        //curl -u <username>:<password> -X POST -H 'Content-Type: application/json' -d'{
        // "type":"page",
        // "title":"My Awesome Page",
        // "ancestors":[{"id":9994246}],
        // "space":{"key":"JOUR"},
        // "body":
        //        {"storage":
        //                   {"value":"<h1>Things That Are Awesome</h1><ul><li>Birds</li><li>Mammals</li><li>Decapods</li></ul>",
        //                    "representation":"storage"}
        //        },
        // "metadata":
        //             {"labels":[
        //                        {"prefix":"global",
        //                        "name":"journal"},
        //                        {"prefix":"global",
        //                        "name":"awesome_stuff"}
        //                       ]
        //             }
        // }'
        // http://localhost:8080/confluence/rest/api/content/ | python -mjson.tool

        JSONObject newPage = new JSONObject();

        // "type":"page",
        // "title":"My Awesome Page"
        newPage.put("type","page");
        newPage.put("title", pageTitle);

        // "ancestors":[{"id":9994246}],
        JSONObject parentPage = new JSONObject();
        parentPage.put("id",parentPageId);

        JSONArray parentPageArray = new JSONArray();
        parentPageArray.put(parentPage);

        newPage.put("ancestors", parentPageArray);

        // "space":{"key":"JOUR"},
        JSONObject spaceOb = new JSONObject();
        spaceOb.put("key",pageSpace);
        newPage.put("space", spaceOb);

        // "body":
        //        {"storage":
        //                   {"value":"<p><h1>Things That Are Awesome</h1><ul><li>Birds</li><li>Mammals</li><li>Decapods</li></ul></p>",
        //                    "representation":"storage"}
        //        },
        JSONObject jsonObjects = new JSONObject();

        jsonObjects.put("value", wikiEntryText);
        jsonObjects.put("representation","storage");

        JSONObject storageObject = new JSONObject();
        storageObject.put("storage", jsonObjects);

        newPage.put("body", storageObject);


        //LABELS
        // "metadata":
        //             {"labels":[
        //                        {"prefix":"global",
        //                        "name":"journal"},
        //                        {"prefix":"global",
        //                        "name":"awesome_stuff"}
        //                       ]
        //             }
        JSONObject prefixJsonObject1 = new JSONObject();
        prefixJsonObject1.put("prefix","global");
        prefixJsonObject1.put("name","journal");
        JSONObject prefixJsonObject2 = new JSONObject();
        prefixJsonObject2.put("prefix","global");
        prefixJsonObject2.put("name",label);

        JSONArray prefixArray = new JSONArray();
        prefixArray.put(prefixJsonObject1);
        prefixArray.put(prefixJsonObject2);

        JSONObject labelsObject = new JSONObject();
        labelsObject.put("labels", prefixArray);

        newPage.put("metadata",labelsObject);

        return newPage;
    }






	public String getNewpageurl() {
		return newpageurl;
	}






	public  void setNewpageurl(String newpageurl) {
		newpageurl = newpageurl;
	}
	
	
	public String writeintoConfluence(String text, int parentPageId,String title) {

		String newpage = "no data";

		

		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();

		String str = formatter.format(date);

		//String wikiPageTitle = str;
		
		String wikiPageTitle =title+"_"+str;

		
		String wikiSpace = "ASDA";
		String labelToAdd = "ganesh";

		JSONObject JnewPage = defineConfluencePage(wikiPageTitle, text, wikiSpace,
				labelToAdd, parentPageId);

		try {
			createConfluencePageViaPost(JnewPage);
			newpage = getNewpageurl();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return newpage;
	}

}
