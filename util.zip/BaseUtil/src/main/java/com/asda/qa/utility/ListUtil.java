package com.asda.qa.utility;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * List Utility Functions
 * @author m0a00pf
 */
public class ListUtil {

	/**
	 * compares actualList to expectedList exactly, in terms of size & indexes.
	 * @param actual
	 * @param expected
	 * @return
	 */
	public static boolean compareListsExact(List<String> actual, List<String> expected) {
		if(actual.size() != expected.size()) return false;
		for(int i=0; i<actual.size(); i++) 
			if(!actual.get(i).equalsIgnoreCase(expected.get(i))) return false;
		return true;
	}
	
	/**
	 * validates if actualList is a sublist of expectedList. expectedList_size >= actualList_size
	 * @param actual
	 * @param expected
	 * @return
	 */
	public static <T> boolean compareListsContains(List<T> actual, List<T> expected) {
		for(T data : actual) 
			if(!expected.contains(data)) return false;
		return true;
	}
	
	/**
	 * subtracts actualList from expectedList
	 * @param actual
	 * @param expected
	 * @return
	 */
	public static <T> List<T> difference(List<T> actual, List<T> expected) {
		List<T> temp = new ArrayList<T>(expected);
		temp.removeAll(actual);
		return temp;
	}

	public static <T> List<T> removeDuplicates(List<T> list){
		return list.stream()
				.distinct()
				.collect(Collectors.toList());
	}
}
