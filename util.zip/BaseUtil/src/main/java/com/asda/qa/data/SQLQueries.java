package com.asda.qa.data;

public enum SQLQueries {

    CancelledTicketsMonthly("Select dc_nbr, count(problem_id) from problem where  problem_status_code=10 and create_ts BETWEEN ? AND ? group by dc_nbr order by dc_nbr "),
    OracleSampleQuery("Select is_daily_preview,is_preview from caversion.imp_import"),
    MariaSampleQuery("Select RECIPE_TITLE, SOURCE, COOK_TIME, COURSE from recipeservice.recipe_info_master"),
    RecipeQuery("Select RECIPE_TITLE, SOURCE, COOK_TIME, COURSE from recipeservice.recipe_info_master where cook_time = ?"),
    ParameterizedSQL("Select MTEP_MDS_FAM_ID from CSDBUSER.MTEP_OLIF where MTEP_CONSUMER_ITEM_NBR = ?");

    private final String SQL;

    SQLQueries(String SQL) {
            this.SQL=SQL;
        }

    public String getSQL() {
        return SQL;
    }

}
