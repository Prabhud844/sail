package com.asda.qa.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class FileZipUtility {
	
public void zipfiles(String filepath, String zipfilename) {
		
		ArrayList<String> srcFiles=new ArrayList<String>();
		  FileOutputStream fos;
	
		File filepath1=new File(filepath);
		
		if(filepath1.isDirectory())
		{
			 File[] filesList = filepath1.listFiles();
		  
		      for(File file : filesList) {
		    	  srcFiles.add(filepath+"/"+file.getName());
		      }
		}
		
		
		
      
		try {
			fos = new FileOutputStream(zipfilename+".zip");
			ZipOutputStream zipOut = new ZipOutputStream(fos);
			
	        for (String srcFile : srcFiles) {
	            File fileToZip = new File(srcFile);
	            FileInputStream fis = new FileInputStream(fileToZip);
	            ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
	            try {
					zipOut.putNextEntry(zipEntry);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

	            byte[] bytes = new byte[1024];
	            int length;
	            try {
					while((length = fis.read(bytes)) >= 0) {
					    zipOut.write(bytes, 0, length);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	            try {
					fis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        try {
				zipOut.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        try {
				fos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
	}


}
