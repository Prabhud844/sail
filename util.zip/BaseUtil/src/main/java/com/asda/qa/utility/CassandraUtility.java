package com.asda.qa.utility;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Cluster.Builder;
import com.datastax.driver.core.Session;

/**
 * The Class CassandraUtility.
 */
public class CassandraUtility {
	
	/** The Constant s_logger. */
	private static final Logger s_logger = LoggerFactory.getLogger(CassandraUtility.class);
	
	/** The cluster. */
	private Cluster cluster;
	 
    /** The session. */
    private Session session;
    
    private static Session instance = null;
    
    /**
     * Connect.
     *
     * @param node the node
     * @param username the username
     * @param password the password
     * @param port the port
     * @return the session
     */
    public Session connect(final String node, final String username, final String password, final Integer port) {
        Builder b = getBuilder(node);
        if (port != null) {
               b.withPort(port);
        }
        if (username != null)
               b.withCredentials(username, password);
        cluster = b.build();
        s_logger.info("Cluster is : {} ",cluster.toString());

        session = cluster.connect();
        s_logger.info("Connected to Cassandra");
        return session;
    }
    
    /**
     * Gets the session.
     *
     * @return the session
     */
    public Session getSession() {
    		return session;
    }
    
    /**
     * Disconnect.
     */
    public void disconnect() {
    		if(session != null) {
    			session.close();
    		}
    		s_logger.info("Connection Closed");
    }
    
    public void disconnect(Session session) {
    		if(session != null) session.close();
    		s_logger.info("Connection Closed");
    }

    public static Session getInstance(String node, String username, String password, Integer port) {
    		if(instance == null) {
    			CassandraUtility cu = new CassandraUtility();
    			instance = cu.connect(node, username, password, port);
    		}
    		return instance;
    }

    /**
     * Returns a new session.
     * Once the operation is done, close the session with session.close()
     * @param node
     * @param username
     * @param password
     * @param port
     * @return
     */
    public static Session getNewSession(String node, String username, String password, Integer port){
        Builder b = getBuilder(node);
        if (port != null) {
            b.withPort(port);
        }
        if (username != null)
            b.withCredentials(username, password);
        Cluster newCluster = b.build();
        s_logger.info("Cluster is : {} ",newCluster.toString());

        Session newSession = newCluster.connect();
        s_logger.info("Connected to Cassandra");
        return newSession;
    }

    public static Builder getBuilder(String node){
        Builder builder = null;

        if(node.contains(","))
            builder = Cluster.builder().withoutJMXReporting().addContactPoints(node.split(","));
        else
            builder = Cluster.builder().withoutJMXReporting().addContactPoint(node);

        return builder;
    }
}
