package com.asda.qa.utility;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

public class DateUtility  {
	private static final Logger s_logger  = LoggerFactory.getLogger(DateUtility.class);
	
	/**
	 * Converts the date from input date format to output date format.
	 * 
	 * @param inputData
	 * @param inputDateFormat
	 * @param outputDateFormat
	 * @return
	 */
	public static String defineDate(String inputDate, String inputDateFormat, String outputDateFormat){
		s_logger.info("Input date: {} inputFormat: {} outputFormat: {}", inputDate, inputDateFormat, outputDateFormat);
		if(inputDate == null ||inputDateFormat == null || outputDateFormat == null ) {
			s_logger.info("Insufficient data to change date format.");
			Assert.fail("Insufficient data to change date format.");
		}
		// Convert date
		SimpleDateFormat inputFormatter = new SimpleDateFormat(inputDateFormat);
		Date date = null;
		try {
			date = inputFormatter.parse(inputDate);
		} catch (ParseException e) {
			s_logger.error("Invalid input date", e);
			Assert.fail("Invalid data/input format.");
		}
		
		SimpleDateFormat outputFormatter = new SimpleDateFormat(outputDateFormat);
		String outputDate = outputFormatter.format(date);
		s_logger.info("Converted date: {}", outputDate);
		return outputDate;
	}

	/**
	 * Return current date in the required format.
	 * 
	 * @param dateFormat
	 * @return
	 */
	public static String getDate(String dateFormat){
		s_logger.info("Date Format: {}", dateFormat);
		SimpleDateFormat inputFormatter = new SimpleDateFormat(dateFormat);
		Date date = new Date();
		String outputDate = inputFormatter.format(date);
		s_logger.info("OutputDate: {}", outputDate);
		return outputDate;
	}
	
	/**
	 * Return milli seconds as string.
	 * 
	 * @return
	 */
	public static String getGregorianCalendarMilliSecond(){
		Long timeInMillisecond = GregorianCalendar.getInstance().getTimeInMillis();
		s_logger.info("Output timeInMillisecond: " + timeInMillisecond);
		return Long.toString(timeInMillisecond);
	}

	
	/**
	 * Return a date based on diff.
	 * 
	 * @param dateFormat
	 * @param delta
	 * @return
	 */
	public static String getDeltaDate(String dateFormat, String delta){
		int daysdiff = getDatesDiff(delta);
		s_logger.info("InputFormat: {}", dateFormat);
		s_logger.info("Delta: {}", delta);
		SimpleDateFormat inputFormatter = new SimpleDateFormat(dateFormat);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, daysdiff);
		Date date = cal.getTime();
		String outputDate = inputFormatter.format(date);
		s_logger.info("OutputDate: {}", outputDate);
		return outputDate;
	}
	
	private static int getDatesDiff(String delta){
			
		try{
			return Integer.parseInt(delta);
		} catch (NumberFormatException e) {
			s_logger.info("DataError: Invalid delta for data" + delta);
			throw new NumberFormatException();
		}
	}
	
	
}
