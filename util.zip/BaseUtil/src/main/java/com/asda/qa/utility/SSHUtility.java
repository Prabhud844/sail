package com.asda.qa.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.asda.core.utils.MigrationUtil;

/**
 * The Class SSHUtility.
 */
public class SSHUtility {

	/**
	 * Connect SSH with password.
	 *
	 * @param host the host
	 * @param username the username
	 * @param password the password
	 * @return the session
	 */
	public Session connectSSHWithPassword(String host, String username, String password) {
		Session session = null;
		JSch jsch = new JSch();
		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		try {
			session=jsch.getSession(username, host, 22);
			session.setPassword(password);
			System.out.println("Password set");
			session.setConfig(config);
			session.connect();
			System.out.println("Connected");
		} catch (JSchException e) {
			e.printStackTrace();
		}

		return session;
	}

	/**
	 * Connect SSH with private key.
	 *
	 * @param host the host
	 * @param username the username
	 * @param privateKey the private key
	 * @return the session
	 */
	public Session connectSSHWithPrivateKey(String host, String username, String privateKey) {
		Session session = null;
		JSch jsch = new JSch();
		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		try {
//			jsch.addIdentity(SSHUtility.class.getClassLoader().getResource(privateKey).getPath());
			jsch.addIdentity(privateKey);
			System.out.println("Private Key added");
			session=jsch.getSession(username, host, 22);
			session.setConfig(config);
			session.connect();
			System.out.println("Connected");
		} catch (JSchException e) {
			e.printStackTrace();
		}

		return session;
	}

	public Session connectSSHWithPrivateKeyFromResources(String host, String username, String privateKey) {
		Session session = null;
		JSch jsch = new JSch();
		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		try {
			jsch.addIdentity(SSHUtility.class.getClassLoader().getResource(privateKey).getPath());
//			jsch.addIdentity(privateKey);
			System.out.println("Private Key added");
			session=jsch.getSession(username, host, 22);
			session.setConfig(config);
			session.connect();
			System.out.println("Connected");
		} catch (JSchException e) {
			e.printStackTrace();
		}

		return session;
	}

	/**
	 * Gets the couchbase logs.
	 *
	 * @param host the host
	 * @param username the username
	 * @param privatekey the privatekey
	 * @param patternToCapture the pattern to capture
	 * @param command the command
	 * @return the couchbase logs
	 */
	/*
	 * @params - host - ssh host to be connected.
	 * @params - username
	 * @params - privatekey to connect
	 * @params - patternToCapture - pattern to get from the result
	 * @params - command - unix command to be executed.
	 * @return - list of strings containing the data that matches the pattern
	 * */
	public List<String> getCouchbaseLogs(String host, String username, String privatekey, String patternToCapture, String command) {
		List<String> prices = new ArrayList<String>();
		Session session = null;

		try {
			session = connectSSHWithPrivateKey(host, username, privatekey);
			String data = executeShellCommand(command, session);

			Pattern pattern = Pattern.compile(patternToCapture);
			Matcher matcher = pattern.matcher(data);

			while(matcher.find()) {
				prices.add(matcher.group());
			}

		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(session != null)
				session.disconnect();
		}
		return prices;
	}

	/**
	 * Execute shell command.
	 *
	 * @param command the command
	 * @param session the session
	 * @return the string
	 */
	/*
	 * @params - command - command to be executed
	 * @params - session - ssh session
	 * */
	public String executeShellCommand(String command, Session session) {
		StringBuilder sb = new StringBuilder();
		ChannelExec channel = null;
		try {
			channel = (ChannelExec) session.openChannel("exec");
			BufferedReader in=new BufferedReader(new InputStreamReader(channel.getInputStream()));
			channel.setCommand(command);
			channel.connect();
			System.out.println("Channel Connected");

			String line, line2 = "";
			List<String> lines = new ArrayList<String>();
			System.out.println("Reading Started");
			while((line = in.readLine()) != null) {
				sb.append(line);
				line = line.substring((line.length()/2));
				if(line2.contains(line)) {
					lines.add(line);
				}else {
					lines = new ArrayList<String>();
				}
				if(lines.size() >= 7)
					break;
				line2 = line;
			}
			System.out.println("Reading finished");

		} catch (JSchException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			channel.disconnect();
		}
		return sb.toString();
	}

	/**
	 * Gets the multiple patterns.
	 *
	 * @param host the host
	 * @param username the username
	 * @param privatekey the privatekey
	 * @param patterns the patterns
	 * @param command the command
	 * @return the multiple patterns
	 */
	public Map<String, String> getMultiplePatterns(String host, String username, String privatekey, List<String> patterns, String command) {
		Map<String, String> matches = new HashMap<String, String>();
		Session session = null;

		try {
			session = connectSSHWithPrivateKey(host, username, SSHUtility.class.getClassLoader().getResource(privatekey).getPath());
			String data = executeShellCommand(command, session);

			for(String patternToCapture : patterns) {
				Pattern pattern = Pattern.compile(patternToCapture);
				Matcher matcher = pattern.matcher(data);

				StringBuilder sb = new StringBuilder();
				while(matcher.find()) {
					sb.append(matcher.group());
				}
				matches.put(patternToCapture, sb.toString());
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(session != null)
				session.disconnect();
		}
		return matches;
	}

	/**
	 * Disconnect.
	 *
	 * @param session the session
	 */
	public void disconnect(Session session) {
		if(session != null) {
			session.disconnect();
			System.out.println("Session disconnected");
		}else {
			System.out.println("No session to disconnect");
		}
	}

	/**
	 * Switch off server.
	 *
	 * @param serverIp the server ip
	 * @param username the username
	 * @param privateKey the private key
	 * @return true, if successful
	 */
	public boolean switchOffServer(String serverIp, String username, String privateKey) {
		boolean isSwitchedOff = true;
		SSHUtility ssh = new SSHUtility();
		Session session = null;
		try {
			session = ssh.connectSSHWithPrivateKey(serverIp, username, SSHUtility.class.getClassLoader().getResource(privateKey).getPath());
			String processOutput = ssh.executeStaticShellCommand("ps -ef | grep java", session);
			System.out.println("Process Output " + processOutput);
			String[] processesList = processOutput.split("app");
			int index = -1;
			for(int i=0; i<processesList.length; i++) {
				if(processesList[i].contains("-Djava.util.logging.config")) {
					index = i;
					break;
				}
			}
			if(index != -1) {
				String process = processesList[index].trim();
				System.out.println("Process : " + process);
				String processId = process.split(" ")[0];
				System.out.println("Process Id is : " + processId);
				System.out.println("Switching off the server");
				processOutput = ssh.executeStaticShellCommand("kill -9 "+processId, session);
				System.out.println(processOutput);
				System.out.println("Server is switched off");
				MigrationUtil.unconditionalWait(10000);
			}else {
				System.out.println("Server already switched off");
			}
		}catch(Exception e) {
			System.out.println("Server is not switched off");
			isSwitchedOff = false;
			e.printStackTrace();
		}finally {
			if(ssh != null)
				ssh.disconnect(session);
		}
		return isSwitchedOff;
	}

	/**
	 * Switch on server.
	 *
	 * @param serverIp the server ip
	 * @param username the username
	 * @param privateKey the private key
	 * @return true, if successful
	 */
	public boolean switchOnServer(String serverIp, String username, String privateKey) {
		boolean isSwitchedOff = true;
		Session session = null;
		try {
			session = connectSSHWithPrivateKey(serverIp, username, SSHUtility.class.getClassLoader().getResource(privateKey).getPath());
			String processOutput = executeStaticShellCommand("ps -ef | grep java", session);
			System.out.println("Process Output " + processOutput);
			String[] processesList = processOutput.split("javaapp");
			int index = processesList.length - 1;
			if(index > 0) {
				processOutput = executeStaticShellCommand("/etc/init.d/tomcat7 restart", session);
				System.out.println(processOutput);
			}else {
				System.out.println("Server already running");
			}
		}catch(Exception e) {
			System.out.println("Server is not switched off");
			isSwitchedOff = false;
			e.printStackTrace();
		}
		return isSwitchedOff;
	}

	/**
	 * Execute static shell command.
	 *
	 * @param command the command
	 * @param session the session
	 * @return the string
	 */
	public String executeStaticShellCommand(String command, Session session) {
		StringBuilder sb = new StringBuilder();
		ChannelExec channel = null;
		try {
			channel = (ChannelExec) session.openChannel("exec");
			BufferedReader in=new BufferedReader(new InputStreamReader(channel.getInputStream()));
			channel.setCommand(command);
			channel.connect();
			System.out.println("Channel Connected");

			String line;
			System.out.println("Reading Started");
			while((line = in.readLine()) != null) {
				sb.append(line);
			}
			System.out.println("Reading finished");

		} catch (JSchException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			channel.disconnect();
		}
		return sb.toString();
	}

	public void copyRemoteToLocal(Session session, String directory, String remoteFile, String localDestination) throws JSchException, SftpException, FileNotFoundException {
		ChannelSftp channel = null;
		channel = (ChannelSftp)session.openChannel("sftp");
		channel.connect();

		File localFile = new File(SSHUtility.class.getClassLoader().getResource(localDestination).getPath());
		channel.cd(directory);
		channel.get(remoteFile, new FileOutputStream(localFile));
		channel.disconnect();
	}
}
