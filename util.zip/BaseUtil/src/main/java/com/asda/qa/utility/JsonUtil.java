package com.asda.qa.utility;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchema;
import com.github.fge.jsonschema.main.JsonSchemaFactory;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import net.sf.json.JSON;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.*;

public class JsonUtil {
    private static final Logger s_logger = LoggerFactory.getLogger(JsonUtil.class);

    /**
     * @param inputJson       -- jsonObject which has array
     * @param arryKey         --- from which key we are extracting array.
     * @param whichArrayIndex -- index starts with 0 & which index we are extracting
     * @return
     */
    public static JSONArray getSingleArrayFromJsonObject(JSONObject inputJson, String arryKey, int whichArrayIndex) {
        JSONArray localArrayObject = (JSONArray) inputJson.get(arryKey);
        JSONArray expectedArrayObjects = new JSONArray();
        expectedArrayObjects.add(localArrayObject.get(whichArrayIndex));
        return expectedArrayObjects;
    }

    /**
     * @param inputJson          -- jsonObject which has array
     * @param arrayKey           -- from which key we are extracting array
     * @param commaSuperateIndex -- indexes with comma superate EG:- 2,3,4
     * @return only expected array
     */
    public static JSONArray getMultipleArrayFromJsonObject(JSONObject inputJson, String arrayKey, String commaSuperateIndex) {
        JSONArray localArrayObject = (JSONArray) inputJson.get(arrayKey);
        JSONArray expectedArrayObjects = new JSONArray();
        String[] index = commaSuperateIndex.split(",");
        for (int i = 0; i < index.length; i++) {
            expectedArrayObjects.add(localArrayObject.get(Integer.parseInt(index[i])));
        }
        return expectedArrayObjects;
    }

    /**
     * @param inputJson -- jsonObject which has array
     * @param arrayKey  -- from which key we are extracting array
     * @return total arrays will be return
     */
    public static JSONArray getArrayFromJsonObject(JSONObject inputJson, String arrayKey) {
        JSONArray localArrayObject = (JSONArray) inputJson.get(arrayKey);
        return localArrayObject;
    }

    /**
     * This method is used to update the value for the particular  josn key value
     *
     * @param inputJson :- for which JSON objet we are updateing value
     * @param key       :- for which param like : profileId
     * @param value     :- what value you want to update for key.
     * @return :- always will be the josnOject with the updated values if valid
     */
    public static JSONObject updateJsonValue(JSONObject inputJson, String key, String value) {
        inputJson.put(key, value);
        return inputJson;
    }

    /**
     * adds/update a JSONObject for a particular key
     *
     * @param inputJson
     * @param key
     * @param value
     * @return
     */
    public static JSONObject addJsonObject(JSONObject inputJson, String key, JSONObject value) {
        inputJson.put(key, value);
        return inputJson;
    }

    /**
     * adds a JSONArray for a particular key
     *
     * @param inputJson
     * @param key
     * @param value
     * @return
     */
    public static JSONObject addJsonArray(JSONObject inputJson, String key, JSONArray value) {
        inputJson.put(key, value);
        return inputJson;
    }

    /**
     * This method is used to update the jsonValues which are in a format of array like "contacts":[{"key","value"},{"key1","value1"}],
     *
     * @param inputJson        -- jsonObject which contains array
     * @param arrayNameKey     -- key to identify the Array content
     * @param updateArrayIndex -- to which array index we want to update the key & value index
     * @param childKey
     * @param childValue
     * @return
     */
    public static JSONObject updateJsonArrayObject(JSONObject inputJson, String arrayNameKey, int updateArrayIndex, String childKey, String childValue) {
        ((JSONObject) ((JSONArray) inputJson.get(arrayNameKey)).get(updateArrayIndex)).put(childKey, childValue);
        return inputJson;
    }

    /**
     * This method will conver the string into JSONObject
     * generally we use this method to convert the response string to object
     *
     * @param str --
     *            eg:- JsonUtil.convertStringToJsonObject(response.asString());
     * @return if given string is not in a json format then will return null
     */
    public static JSONObject convertStringToJsonObject(String str) {
        JSONParser parser = new JSONParser();
        try {
            JSONObject jsonObject = (JSONObject) parser.parse(str);
            return jsonObject;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    /**
     * @param inputObject
     * @param keyNameToRemove pass attribute value to which you wish to remove
     * @return
     */
    public static JSONObject removeAttributFromJsonObject(JSONObject inputObject, String keyNameToRemove) {

        try {
            inputObject.remove(keyNameToRemove);
            return inputObject;
        } catch (Exception e) {
            System.out.println(e.getMessage());

        }
        return inputObject;
    }

    /**
     * Gets the json object.
     *
     * @param inputObject the input object
     * @param xpath       the xpath
     * @return the json object
     */
    public static JSONObject getJsonObject(JSONObject inputObject, String xpath) {
        try {

            String[] splitXpath = xpath.split("\\.");
            JSONObject expectedJSONObj = null;
            for (int i = 0; i < splitXpath.length; i++) {
                if (splitXpath[i].contains("[")) {
                    expectedJSONObj = getObjectFromIndex(inputObject, splitXpath[i]);
                } else {
                    expectedJSONObj = (JSONObject) inputObject.get(splitXpath[i]);
                }
                inputObject = expectedJSONObj;
            }
            return expectedJSONObj;
        } catch (Exception e) {
            System.out.println(e.getMessage());

        }
        return null;
    }

    /**
     * @param inputJson       -- jsonObject which has array
     * @param arryKey         --- from which key we are extracting array.
     * @param whichArrayIndex -- index starts with 0 & which index we are extracting
     * @return
     */
    public static JSONObject getJsonObjectFromArrayAttribute(JSONObject inputJson, String arryKey, int whichArrayIndex) {
        JSONArray localArrayObject = (JSONArray) inputJson.get(arryKey);
//		localArrayObject.get(whichArrayIndex);
        return (JSONObject) localArrayObject.get(whichArrayIndex);
    }

    /**
     * @param xpath like contacts.contactType or 	profile.basic.email or cards.address.addressType
     * @return will be string
     */
    public static String getValueFromJsonObject(JSONObject obj, String xpath) {
        JSONObject expectedJSONObj = null;
        JSONObject inputObject = new JSONObject(obj);
        String[] splitXpath = xpath.split("\\.");
        for (int i = 0; i < splitXpath.length; i++) {

            try {

                if (i != splitXpath.length - 1) {
                    if (splitXpath[i].contains("[")) {
                        expectedJSONObj = getObjectFromIndex(inputObject, splitXpath[i]);
                        inputObject = expectedJSONObj;
                    } else {
                        expectedJSONObj = (JSONObject) inputObject.get(splitXpath[i]);
                        inputObject = expectedJSONObj;
                    }
                } else if (i == splitXpath.length - 1)
                    return (String) inputObject.get(splitXpath[splitXpath.length - 1]);
            } catch (Exception e) {
                try {
                    if (i != splitXpath.length - 1) {
                        if (splitXpath[i].contains("[")) {
                            expectedJSONObj = getObjectFromIndex(inputObject, splitXpath[i]);
                            inputObject = expectedJSONObj;
                        } else {
                            expectedJSONObj = (JSONObject) ((JSONArray) inputObject.get(splitXpath[i])).get(0);
                            inputObject = expectedJSONObj;
                        }
                    } else if (i == splitXpath.length - 1)
                        if (i == splitXpath.length - 1)
                            return String.valueOf(inputObject.get(splitXpath[splitXpath.length - 1]));
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }
        return null;
    }

    private static JSONObject getObjectFromIndex(JSONObject obj, String xpath) {
        String[] arr = xpath.split("\\[");
        int index = Integer.parseInt(arr[1].replace("]", ""));
        JSONObject output = getJsonObjectFromArrayAttribute(obj, arr[0], index);
        return output;
    }

    /**
     * @param inputObject
     * @param xpath       like contacts.contactType or 	profile.basic.email or cards.address.addressType
     * @return will be list of string
     */
    public static List<String> getValuesFromJsonObject(JSONObject inputObject, String xpath) {
        String[] splitXpath = xpath.split("\\.");
        JSONObject expectedJSONObj = null;
        JSONArray expectedJsonArray = null;
        List<String> expectedValues = new ArrayList<String>();

        for (int i = 0; i < splitXpath.length; i++) {

            try {
                expectedJSONObj = (JSONObject) inputObject.get(splitXpath[i]);
                inputObject = expectedJSONObj;
            } catch (Exception e) {

                expectedJsonArray = (JSONArray) inputObject.get(splitXpath[i]);
                for (int ai = 0; ai < expectedJsonArray.size(); ai++) {
                    String value = getValueFromJsonObject(((JSONObject) expectedJsonArray.get(ai)), xpath.replace(splitXpath[i] + ".", ""));
                    if (value != null)
                        expectedValues.add(value);
                }
                i++;
            }

        }


        return expectedValues;
    }

    /**
     * this method will give the required payLoad from the apiInputs.json file
     *
     * @param payloadName -- pass the required payloadName which is avaliable in the apiInputs.json file
     *                    eg:- profilePost or contactPut....
     * @return if payloadName is valid then return the object or else null
     */
    public static JSONObject getInputJSONObject(String payloadName) {
        JSONParser parser = new JSONParser();
        try {
            //Object obj = parser.parse(new FileReader(System.getProperty("user.dir").replace("/target","") + "/src/main/resources/com/asda/qa/data/apiInputs.json"));
            Object obj = parser.parse(readFile(JsonUtil.class.getClassLoader().getResourceAsStream("com/asda/qa/data/apiInputs.json")));
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject expectedJSONObj = (JSONObject) jsonObject.get(payloadName);
            return expectedJSONObj;

        } catch (Exception e) {
            s_logger.info("Exception Message : {}", e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    public static JSONArray getInputJSONArray(String payloadName) {
        JSONParser parser = new JSONParser();
        try {

            Object obj = parser.parse(readFile(JsonUtil.class.getClassLoader().getResourceAsStream("com/asda/qa/data/apiInputs.json")));
            JSONObject jsonObject = (JSONObject) obj;
            JSONArray expectedJSONObj = (JSONArray) jsonObject.get(payloadName);
            return expectedJSONObj;

        } catch (Exception e) {
            s_logger.info("Exception Message : {}", e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    /**
     * this method will give the required payLoad from the custom folder & Input json file
     *
     * @param jsonPath    -- pass the required jsonPath which is available in the project folder.
     *                    eg:- "com/asda/qa/data/subscription_Inputs/apiRequestsBody.json"
     * @param payloadName -- pass the required payloadName which is available in the apiRequestsBody.json file
     *                    eg:- profilePost or contactPut....
     * @return if payloadName is valid then return the object or else null
     */
    public static JSONObject getInputJSONObject(String jsonPath, String payloadName) {
        JSONParser parser = new JSONParser();
        try {
            s_logger.info("Json Path : " + jsonPath);
            s_logger.info("Payload Name : " + payloadName);
            //Object obj = parser.parse(new FileReader(System.getProperty("user.dir").replace("/target","") + "/src/main/resources/com/asda/qa/data/apiInputs.json"));
            Object obj = parser.parse(readFile(JsonUtil.class.getClassLoader().getResourceAsStream(jsonPath)));
            JSONObject jsonObject = (JSONObject) obj;
            JSONObject expectedJSONObj = (JSONObject) jsonObject.get(payloadName);
            return expectedJSONObj;
        } catch (Exception e) {
            s_logger.info("Exception Message : {}", e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Read file.
     *
     * @param inputStream
     * @return the json content as string
     * @throws IOException
     * @author a0s07pd(Abhishek Singh)
     */
    public static String readFile(InputStream inputStream) throws IOException {
        String content = null;
        Reader reader = new InputStreamReader(inputStream);
        try (BufferedReader br = new BufferedReader(reader)) {

            StringBuilder sb = new StringBuilder();
            String line = br.readLine();

            while (line != null) {
                sb.append(line);
                sb.append(System.lineSeparator());
                line = br.readLine();
            }
            content = sb.toString();
            br.close();
        } catch (IOException e) {

            throw new IOException("Unable to read/load json file requested " + e);
        } catch (NullPointerException e) {

            throw new NullPointerException("Unable to find json file requested(NULLPointerException) " + e);
        }
        return content;
    }

    /**
     * Gets the all array from JSON object.
     *
     * @param inputJson the input json
     * @param arrayKey  the array key
     * @return the all array from JSON object
     */
    public static JSONArray getAllArrayFromJSONObject(JSONObject inputJson, String arrayKey) {
        JSONArray localArrayObject = (JSONArray) inputJson.get(arrayKey);

        return localArrayObject;
    }

    /**
     * Gets the value from response.
     *
     * @param response the response
     * @param jsonPath the json path
     * @return the value from response
     */
    public static String getValueFromResponse(Response response, String jsonPath) {
        JsonPath jsonPathEvaluator = response.jsonPath();
        return jsonPathEvaluator.getString(jsonPath);

    }

    /**
     * Gets the obj from response.
     *
     * @param response the response
     * @param jsonPath the json path
     * @return the obj from response
     */
    public static JSONObject getObjFromResponse(Response response, String jsonPath) {
        JsonPath jsonPathEvaluator = response.jsonPath();
        JSONObject obj = jsonPathEvaluator.getJsonObject(jsonPath);
        return obj;
    }

    /**
     * Gets the list from response.
     *
     * @param response the response
     * @param jsonPath the json path
     * @return the list from response
     */
    public static List<String> getListFromResponse(Response response, String jsonPath) {
        JsonPath jsonPathEvaluator = response.jsonPath();
        List<String> list = jsonPathEvaluator.getList(jsonPath);
        return list;
    }

    /**
     * Gets the objects from response.
     *
     * @param response the response
     * @param jsonPath the json path
     * @return the objects from response
     */
    public static List<JSONObject> getObjectsFromResponse(Response response, String jsonPath) {
        JsonPath jsonPathEvaluator = response.jsonPath();
        List<JSONObject> objs = jsonPathEvaluator.getJsonObject(jsonPath);
        return objs;
    }

    public static JSONObject getObjFromJsonObject(JSONObject obj, String xpath) {
        JSONObject expectedJSONObj = null;
        JSONObject inputObject = new JSONObject(obj);
        String[] splitXpath = xpath.split("\\.");
        for (int i = 0; i < splitXpath.length; i++) {

            try {

                if (i != splitXpath.length - 1) {
                    if (splitXpath[i].contains("[")) {
                        expectedJSONObj = getObjectFromIndex(inputObject, splitXpath[i]);
                        inputObject = expectedJSONObj;
                    } else {
                        expectedJSONObj = (JSONObject) inputObject.get(splitXpath[i]);
                        inputObject = expectedJSONObj;
                    }
                } else if (i == splitXpath.length - 1)
                    return (JSONObject) inputObject.get(splitXpath[splitXpath.length - 1]);
            } catch (Exception e) {
                if (i != splitXpath.length - 1) {
                    if (splitXpath[i].contains("[")) {
                        expectedJSONObj = getObjectFromIndex(inputObject, splitXpath[i]);
                        inputObject = expectedJSONObj;
                    } else {
                        expectedJSONObj = (JSONObject) ((JSONArray) inputObject.get(splitXpath[i])).get(0);
                        inputObject = expectedJSONObj;
                    }
                } else if (i == splitXpath.length - 1)
                    if (i == splitXpath.length - 1)
                        return (JSONObject) inputObject.get(splitXpath[splitXpath.length - 1]);
            }
        }
        return null;
    }

    public static String emailGenerator() {
        long time = System.currentTimeMillis();
        String email = "qa_spguestuser" + time + "@sp.com";
        return email;
    }

    public static void main(String[] args) {
        JSONObject json = getInputJSONObject("test");
        Set<String> keys = json.keySet();

        StringBuilder sb = new StringBuilder();
        for (String key : keys) {
            JSONObject element = (JSONObject) json.get(key);
            String variable = "public MobileElement " + key + ";";

            JSONObject android = (JSONObject) element.get("android");
            if (null != android && android.containsKey("strategy")) {
                sb.append("@AndroidFindBy(")
                        .append(android.get("strategy"))
                        .append(" = ")
                        .append("\"")
                        .append(android.get("locator"))
                        .append("\")")
                        .append("\n");
            } else {
                sb.append("@AndroidFindBy(")
                        .append("xpath")
                        .append(" = ")
                        .append("\"")
                        .append("Not added at the time of migration .Add when failed")
                        .append("\")")
                        .append("\n");
            }

            JSONObject ios = (JSONObject) element.get("ios");
            if (null != ios && ios.containsKey("strategy")) {
                sb.append("@iOSXCUITFindBy(")
                        .append(ios.get("strategy"))
                        .append(" = ")
                        .append("\"")
                        .append(ios.get("locator"))
                        .append("\")")
                        .append("\n");
            } else {
                sb.append("@iOSXCUITFindBy(")
                        .append("xpath")
                        .append(" = ")
                        .append("\"")
                        .append("Not added at the time of migration .Add when failed")
                        .append("\")")
                        .append("\n");
            }

            sb.append(variable)
                    .append("\n\n");
        }

        System.out.println(sb);
    }

    public static boolean validateJsonSchema(String schemaName, JSONObject inpJson) {

        try {
            JSONObject schemaJson = (JSONObject) new JSONParser()
                    .parse(new FileReader(JsonUtil.class.getClassLoader()
                            .getResource("com/asda/qa/data/JsonSchemas/" + schemaName + ".json").getPath()));

            JsonNode schemaJsonNode = (new ObjectMapper()).readTree(schemaJson.toJSONString());
            JsonNode inputJsonNode = (new ObjectMapper()).readTree(inpJson.toJSONString());
            final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
            final JsonSchema schema = factory.getJsonSchema(schemaJsonNode);
            ProcessingReport report;
            report = schema.validate(inputJsonNode);

            if (report.isSuccess()) {
                System.out.println(report);
            } else {
                System.out.println(ConsoleColors.RED + report + ConsoleColors.RESET);
                s_logger.info("------Actual Schema-----");
                s_logger.info(String.valueOf(factory.getJsonSchema(inputJsonNode)));
            }


            return report.isSuccess();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void addExtraObjectToJsonArray(JSONArray arr, JSONObject obj) {
        arr.add(obj);
    }

    public static boolean compareJsonObjects(JSONObject obj1, JSONObject obj2) {
        boolean flag = true;
        if(obj1.size()==obj2.size()){
            for(Object each: obj1.keySet().toArray()){
                Object jObj1 = obj1.get(String.valueOf(each));
                Object jObj2 = obj2.get(String.valueOf(each));

                if((jObj1 instanceof Long && jObj2 instanceof Long) || (jObj1 instanceof Integer && jObj2 instanceof Integer)
                        || (jObj1 instanceof Double && jObj2 instanceof Double) || (jObj1 instanceof Float && jObj2 instanceof Float))
                    flag = jObj1 == jObj2;

                if(jObj1 instanceof String && jObj2 instanceof String){
                    flag = jObj1.toString().equals(jObj2.toString());
                }else if(jObj1 instanceof JSONArray && jObj2 instanceof JSONArray){
                    if(((JSONArray) jObj1).size()==((JSONArray) jObj2).size()) {
                        flag = compareJSONArrays(((JSONArray) jObj1), ((JSONArray) jObj2));
                    }else flag = false;
                }else if(jObj1 instanceof JSONObject && jObj2 instanceof JSONObject)
                    flag = compareJsonObjects((JSONObject) jObj1, (JSONObject) jObj2);
                else {
                    s_logger.info("ERROR: Attribute type is mismatching.!!");
                    flag = false;
                }
            }
        }else{
            s_logger.info("ERROR: Size of both the JsonObject is not same!!");
            flag = false;
        }

        return flag;
    }

    public static boolean compareJSONArrays(JSONArray actualJSONArray, JSONArray expectedJSONArray) {
        boolean flag = true;

        if (null == expectedJSONArray) {
            if (null == actualJSONArray)
                return true;
            if (actualJSONArray.size() == 0)
                return true;
        }

        if (null == actualJSONArray) {
            if (null == expectedJSONArray)
                return true;
            if (expectedJSONArray.size() == 0)
                return true;
        }

        try {
            int size = actualJSONArray.size();
            if (size != expectedJSONArray.size()) {
                s_logger.error("JSONArray Size mismatch!!");
                return false;
            }

            for (int i = 0; i < size; i++) {
                Object jobj1, jobj2;
                try {
                    jobj1 = actualJSONArray.get(i);
                } catch (ClassCastException e) {
                    jobj1 = null;
                }

                try {
                    jobj2 = expectedJSONArray.get(i);
                } catch (ClassCastException e) {
                    jobj2 = null;
                }

                if((jobj1 instanceof Long && jobj2 instanceof Long) || (jobj1 instanceof Integer && jobj2 instanceof Integer)
                        || (jobj1 instanceof Double && jobj2 instanceof Double) || (jobj1 instanceof Float && jobj2 instanceof Float))
                    flag = jobj1 == jobj2;
                else if(jobj1 instanceof String && jobj2 instanceof String)
                    flag = jobj1.toString().equals(jobj2);
                else if(jobj1 instanceof JSONObject && jobj2 instanceof JSONObject)
                    flag = compareJsonObjects((JSONObject) jobj1, (JSONObject) jobj2);
                else if(jobj1 instanceof JSONArray && jobj2 instanceof JSONArray)
                    flag = compareJSONArrays((JSONArray) jobj1, (JSONArray) jobj2);
                else {
                    s_logger.info("ERROR: Attribute type is mismatching.!!");
                    flag = false;
                }

                if (flag == false)
                    break;
            }

        } catch (NullPointerException e) {
            flag = false;
        }
        return flag;
    }

    public static JSONArray convertStringToJsonArray(String data) {
        JSONArray arrayObj;
        JSONParser jsonParser = new JSONParser();
        Object object = null;
        try {
            object = jsonParser.parse(data);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        arrayObj = (JSONArray) object;
        return arrayObj;
    }

    /**
     * Method to fetch value from a map with an optional
     * return if the value is not present in Map
     *
     * @param maps   Map from which the value has to be extracted
     * @param mapKey The Key for which value has to be extracted
     * @return value from the map
     */
    public static String getValueFromMap(Map<String, String> maps, String mapKey) {
        return maps.getOrDefault(mapKey, String.format("The [ %1$s ] is not present in map", mapKey));
    }

    /**
     * Method to Flatten the nested Json Structure into Map
     *
     * @param json JSONObject
     * @return map
     */
    public static Map<String, String> jsonToMap(JSONObject json) {
        LinkedHashMap<String, String> map = new LinkedHashMap<>();

        if (json != org.json.JSONObject.NULL) {
            map = toMap(json, map, "");
        }
        return map;
    }

    public static LinkedHashMap<String, String> toMap(JSONObject object, LinkedHashMap<String, String> map, String key) {
        String oldKey = key;
        Iterator<String> keysItr = object.keySet().iterator();
        while (keysItr.hasNext()) {
            key = keysItr.next();
            Object value = object.get(key);
            if (value instanceof JSONArray) {
                String nestedKey = key;
                if (!oldKey.equals(""))
                    nestedKey = oldKey + "." + key;
                value = toList((JSONArray) value, map, nestedKey);
            } else if (value instanceof JSONObject) {
                String nestedKey = key;
                if (!oldKey.equals(""))
                    nestedKey = oldKey + "." + key;
                value = toMap((JSONObject) value, map, nestedKey);
            }
            if (!oldKey.equals(""))
                key = oldKey + "." + key;

            if (!(value instanceof ArrayList)) {
                if (!(value instanceof HashMap)) {
                    if (value == null) {
                        map.put(key, "");
                    } else {
                        map.put(key, value.toString());
                    }

                }
            }
        }
        return map;
    }

    /**
     * Method to parse the Json Array
     *
     * @param array JSONArray
     * @param map   hashmap which has the flatten json structure
     * @param key   key of the hasmap to be inserted
     * @return Object
     */
    public static Object toList(JSONArray array, LinkedHashMap<String, String> map, String key) {
        Object value = new Object();
        for (int i = 0; i < array.size(); i++) {
            value = array.get(i);
            if (value instanceof JSONArray) {
                value = toList((JSONArray) value, map, key);
            } else if (value instanceof JSONObject) {
                key = key + "." + i;
                value = toMap((JSONObject) value, map, key);
            }
            key = key.substring(0, key.length() - 2);
        }
        if (array.size() == 0) {
            value = "";
        }
        return value;
    }

}
