package com.asda.qa.utility;

import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.GeneralSecurityException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.CookieStore;
import org.apache.http.client.HttpClient;
import org.apache.http.client.HttpResponseException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.cookie.BasicClientCookie;
import org.apache.http.message.BasicHttpResponse;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.asda.qa.environment.EnvironmentConfig;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.http.Headers;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


//import java.util.Base64;

/**
 * The Class HttpClientAPIUtility.
 */
public class HttpClientAPIUtility {


    /** The http context. */
    HttpContext httpContext = null;

    /** The threadcookies. */
    public static Map<Integer,Map<String,String>> threadcookies=new ConcurrentHashMap<Integer, Map<String,String>>();

    /** The threadreq headers. */
    public static Map<Integer,Map<String,String>> threadreqHeaders=new ConcurrentHashMap<Integer, Map<String,String>>();
    //public static Map<String,String> cookies=new HashMap<String, String>();

    //public static Map<String,String> reqHeaders=new HashMap<String, String>();

    /** The thread res headers. */
    public static Map<Integer,Headers> threadResHeaders=new ConcurrentHashMap<Integer,Headers>();


    /** The Constant s_logger. */
    private static final Logger s_logger = LoggerFactory
            .getLogger(HttpClientAPIUtility.class);

    

    /**
     * The Enum ProxyUsage.
     */
    public enum ProxyUsage{

        /** The enable. */
        enable,
        /** The disable. */
        disable,
        enable_local_only,
        enable_looper_only
    }


   
    /** The httpclient. */
    protected DefaultHttpClient httpclient = null;

    /**
     * Instantiates a new API utility.
     */
    public HttpClientAPIUtility() {

        httpclient = new DefaultHttpClient();
        httpContext = new BasicHttpContext();
    }

    /**
     * The Enum PostBodyType.
     */
    public enum PostBodyType {

        /** The xml. */
        xml,
        /** The json. */
        json
    }

    /** The last error. */
    private String lastError = null;

    /**
     * Gets the last error.
     *
     * @return the last error
     */
    public String getLastError() {
        return lastError;
    }

    /**
     * Sets the last error.
     *
     * @param lastError the new last error
     */
    public void setLastError(String lastError) {
        this.lastError = lastError;
    }

    /**
     * Gets the.
     *
     * @param uri the uri
     * @return the string
     */
    public String get(String uri) {
        return null;
    }

    /**
     * Put.
     *
     * @param uri the uri
     * @return the string
     */
    public String put(String uri) {
        return null;
    }

    /**
     * Post.
     *
     * @param uri the uri
     * @param requestBody the request body
     * @param bodyType the body type
     * @param proxyUsage the proxy usage
     * @return the string
     */
    public String post(String uri, String requestBody, PostBodyType bodyType,ProxyUsage proxyUsage) {

        APIResponse apiResponse = new APIResponse();
        String responseMessage = null;

        setUseInsecureSSL(httpclient, false);

        HttpPost httpPost = new HttpPost(uri);

        if(proxyUsage == ProxyUsage.enable){
            HttpHost proxy = new HttpHost("http://sysproxy.wal-mart.com:8080");
            RequestConfig config = RequestConfig.custom().setProxy(proxy).build();
            httpPost.setConfig(config);
            s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled in both local and looper");
        }

        else if (proxyUsage == ProxyUsage.disable){
            s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is disabled in both local and looper");
        }

        else if (proxyUsage == ProxyUsage.enable_local_only){
            if (System.getenv("HUDSON_URL") == null) {
                HttpHost proxy = new HttpHost("http://sysproxy.wal-mart.com:8080");
                RequestConfig config = RequestConfig.custom().setProxy(proxy).build();
                httpPost.setConfig(config);
                s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in local");
            }
            else{
                s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for local but not enabled");
            }
        }

        else if (proxyUsage == ProxyUsage.enable_looper_only){
            if (System.getenv("HUDSON_URL") != null && System.getenv("HUDSON_URL").contains("walmart.com")) {
                HttpHost proxy = new HttpHost("http://sysproxy.wal-mart.com:8080");
                RequestConfig config = RequestConfig.custom().setProxy(proxy).build();
                httpPost.setConfig(config);
                s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in looper");
            }
            else{
                s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for looper but not enabled");
            }
        }

        StringEntity se = null;

        se = new StringEntity(requestBody, "UTF-8");

        // se.setContentEncoding("UTF-8");

        if (bodyType == PostBodyType.xml) {
            httpPost.addHeader("Content-type", "application/xml");
            httpPost.addHeader("Accept", "application/xml");
            se.setContentType("application/xml");
        } else if (bodyType == PostBodyType.json) {
            httpPost.addHeader("Content-type", "application/json");
            httpPost.addHeader("charset", "UTF-8");
            // se.
            // httpPost.addHeader("Accept", "application/json");
            // se.setContentType("application/json");
        }

        httpPost.setEntity(se);

        try {
            HttpContext httpContext = new BasicHttpContext();
            ResponseHandler<String> response = new BasicResponseHandler() {
                @Override
                public String handleResponse(HttpResponse response)
                        throws IOException {
                    StatusLine statusLine = response.getStatusLine();
                    if (statusLine.getStatusCode() < 400) {
                        return super.handleResponse(response);
                    }
                    HttpEntity entity = response.getEntity();
                    return entity == null ? null : EntityUtils.toString(entity);
                }
            };

            HttpResponse httpResponse = httpclient.execute(httpPost,
                    httpContext);
            // HttpResponse response = httpclient.execute(httpPost);
            BasicHttpResponse baseResponse = (BasicHttpResponse) httpContext
                    .getAttribute("http.response");
            apiResponse.setStatusCode(baseResponse.getStatusLine()
                    .getStatusCode());

            Assert.assertNotNull(apiResponse.getStatusCode());
            Assert.assertEquals(apiResponse.getStatusCode(), 200);

            responseMessage = EntityUtils.toString(httpResponse.getEntity());
            System.out.println(responseMessage);

        } catch (Exception e) {
            lastError = "Exception when executing th POST message. Exception is as follows:-"
                    + e.getMessage();
            return null;
        }

        return responseMessage;
    }


    public Boolean put(String uri,String msg)
    {

        CloseableHttpResponse execute = null;
        boolean putsuccess=true;



        try {
            @SuppressWarnings("resource")
            HttpClient httpClient = new DefaultHttpClient();

            s_logger.info("Send PUT request:" + msg + " to url-" + uri);
            HttpPut httpPut = new HttpPut(uri);
            StringEntity entity = new StringEntity(msg, "UTF-8");
            entity.setContentType("application/json");
            httpPut.setEntity(entity);


            httpClient.execute(httpPut);

            httpClient.getConnectionManager().shutdown();



        } catch (Exception e) {
            putsuccess=false;
            s_logger.info( "Was unable to send PUT request:" +msg
                    + " (displaying first 1000 chars) from url-" + uri, e);
        }


        return putsuccess;
    }
    /**
     * Gets the.
     *
     * @param uri the uri
     * @param requestBody the request body
     * @param bodyType the body type
     * @param proxyUsage the proxy usage
     * @return the string
     */
    public String get(String uri, String requestBody, PostBodyType bodyType,ProxyUsage proxyUsage) {
        APIResponse apiResponse = new APIResponse();
        String responseMessage = null;

        setUseInsecureSSL(httpclient, false);

        HttpGet httpPost = new HttpGet(uri);

        if(proxyUsage == ProxyUsage.enable){
            HttpHost proxy = new HttpHost("http://sysproxy.wal-mart.com:8080");
            RequestConfig config = RequestConfig.custom().setProxy(proxy).build();
            httpPost.setConfig(config);
            s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled in both local and looper");
        }

        else if (proxyUsage == ProxyUsage.disable){
            s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is disabled in both local and looper");
        }

        else if (proxyUsage == ProxyUsage.enable_local_only){
            if (System.getenv("HUDSON_URL") == null) {
                HttpHost proxy = new HttpHost("http://sysproxy.wal-mart.com:8080");
                RequestConfig config = RequestConfig.custom().setProxy(proxy).build();
                httpPost.setConfig(config);
                s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in local");
            }
            else{
                s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for local but not enabled");
            }
        }

        else if (proxyUsage == ProxyUsage.enable_looper_only){
            if (System.getenv("HUDSON_URL") != null && System.getenv("HUDSON_URL").contains("walmart.com")) {
                HttpHost proxy = new HttpHost("http://sysproxy.wal-mart.com:8080");
                RequestConfig config = RequestConfig.custom().setProxy(proxy).build();
                httpPost.setConfig(config);
                s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in looper");
            }
            else{
                s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for looper but not enabled");
            }
        }

        if (bodyType == PostBodyType.xml) {
            httpPost.addHeader("Content-type", "application/xml");
            httpPost.addHeader("Accept", "application/xml");
        } else if (bodyType == PostBodyType.json) {
            httpPost.addHeader("Content-type", "application/json");
            httpPost.addHeader("charset", "UTF-8");
            // httpPost.addHeader("Accept", "application/json");
            // se.setContentType("application/json");
        }

        try {
            HttpContext httpContext = new BasicHttpContext();
            ResponseHandler<String> response = new BasicResponseHandler() {
                @Override
                public String handleResponse(HttpResponse response)
                        throws IOException {
                    StatusLine statusLine = response.getStatusLine();
                    if (statusLine.getStatusCode() < 400) {
                        return super.handleResponse(response);
                    }
                    HttpEntity entity = response.getEntity();
                    return entity == null ? null : EntityUtils.toString(entity);
                }
            };
            HttpResponse httpResponse = httpclient.execute(httpPost,
                    httpContext);
            // HttpResponse response = httpclient.execute(httpPost);
            BasicHttpResponse baseResponse = (BasicHttpResponse) httpContext
                    .getAttribute("http.response");
            apiResponse.setStatusCode(baseResponse.getStatusLine()
                    .getStatusCode());

            Assert.assertNotNull(apiResponse.getStatusCode());
            //Assert.assertEquals(apiResponse.getStatusCode(), 200);

            // HttpResponse response = httpclient.execute(httpPost);

            responseMessage = EntityUtils.toString(httpResponse.getEntity());
            // System.out.println(responseMessage);
        } catch (Exception e) {
            lastError = "Exception when executing th POST message. Exception is as follows:-"
                    + e.getMessage();
            return null;
        }
        return responseMessage;

    }

    /**
     * Sets the use insecure SSL.
     *
     * @param httpclient the httpclient
     * @param useCertificate the use certificate
     */
    protected void setUseInsecureSSL(HttpClient httpclient,
                                     boolean useCertificate) {
        try {
            // this.logger.entering(new Object[] { httpclient,
            // Boolean.valueOf(useCertificate) });

            SSLContext sslContext = SSLContext.getInstance("SSL");
            KeyManager[] keyManager = null;
            if (useCertificate) {

                KeyManagerFactory kmf = KeyManagerFactory
                        .getInstance(KeyManagerFactory.getDefaultAlgorithm());
                kmf.init(null, "".toCharArray());
                keyManager = kmf.getKeyManagers();
            }
            sslContext
                    .init(keyManager,
                            new TrustManager[] { new InsecureX509TrustManager() },
                            null);

            SSLSocketFactory socketFactory = new SSLSocketFactory(sslContext,
                    SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);

            Scheme https = new Scheme("https", 443, socketFactory);
            SchemeRegistry schemeRegistry = httpclient.getConnectionManager()
                    .getSchemeRegistry();
            schemeRegistry.register(https);
        } catch (GeneralSecurityException e) {
            String msg = "Unable to establish insecure SSL trust";
            // this.logger.log(Level.WARNING,
            // "GeneralSecurityException thrown. " + msg + ".", e);

            throw new RuntimeException(msg + " in "
                    + getClass().getEnclosingMethod().getName() + " due to"
                    + e.getMessage());
        }

        // this.logger.exiting();
    }

    /**
     * Verify localize.
     *
     * @param response the response
     * @param jObj the j obj
     */
    private void verifyLocalize(String response, Object jObj) {
        if (response.contains("checkPostcodeValidation"))
            try {
                response = ((JSONObject) jObj)
                        .getString("checkPostcodeValidation");
            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        Assert.assertEquals(response, "true");

    }

    /**
     * Parses the response.
     *
     * @param responseMessage the response message
     * @return the object
     */
    private Object parseResponse(String responseMessage) {
        Object jObj = null;
        if (responseMessage.startsWith("[")) {

            try {
                jObj = new org.json.JSONArray(responseMessage);
            } catch (JSONException e) {
                System.out.println("Error parsing data " + e);
            }
        } else {
            try {
                jObj = new JSONObject(responseMessage);
                System.out.println(responseMessage);

            } catch (JSONException e) {
                System.out.println("Error parsing data " + e);
            }
        }
        return jObj;

    }

    /** The config data. */
    private final JSONObject configData = null;

    /**
     * Gets the data.
     *
     * @param key the key
     * @return the data
     */
    public Object getData(String key) {

        if (configData == null)
            return null;

        try {
            if (configData.getJSONObject(key) != null) {
                return configData.getJSONObject(key);
            }
        } catch (Exception e) {

        }

        try {
            if (configData.getJSONArray(key) != null) {
                return configData.getJSONArray(key);
            }
        } catch (Exception e) {

        }

        try {
            if ((configData.getString(key) != null)
                    && (!configData.getString(key).isEmpty())) {
                return configData.getString(key);
            }
        } catch (Exception e) {

        }

        return null;
    }

    /**
     * Response success.
     *
     * @param jb the jb
     * @return true, if successful
     */
    private boolean responseSuccess(JSONObject jb) {
        boolean isSuccess = false;
        try {
            isSuccess = jb.get("statusCode").equals("0");
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return isSuccess;
    }

    /**
     * Creates the http context.
     *
     * @param dcenvReq the dcenv req
     */
    public void createHttpContext(boolean dcenvReq) {

        if (httpContext == null) {
            httpContext = new BasicHttpContext();
        }

        if (dcenvReq) {
            /************************************ New code *******************************/
            CookieStore cookieStore = new BasicCookieStore();
            BasicClientCookie cookie = new BasicClientCookie("DCENV", "ASDA");
            cookie.setPath("/");
            cookie.setDomain("groceries-qa.asda.com");
            cookieStore.addCookie(cookie);

            httpContext.setAttribute(ClientContext.COOKIE_STORE, cookieStore);

            /*******************************************************************************/
        }

    }

   
    /**
     * Gets the dimension param for assembler.
     *
     * @param dimensionIdList the dimension id list
     * @return the dimension param for assembler
     */
    public String getDimensionParamForAssembler(String dimensionIdList){
        String dimensionValue = "";
        String[] dimensions = dimensionIdList.split(",");
        for(int i=0;i<dimensions.length;i++){
            if(i>0 && i<dimensions.length)
                dimensionValue =dimensionValue+"+";

            dimensionValue =  dimensionValue+dimensions[i].trim();
        }
        return dimensionValue;
    }

  
    /**
     * Gets the date parameter.
     *
     * @param shipOnDate the ship on date
     * @return the date parameter
     * @throws UnsupportedEncodingException the unsupported encoding exception
     * @throws ParseException the parse exception
     */
    public String getDateParameter(String shipOnDate) throws UnsupportedEncodingException, ParseException {
        StringBuilder eqlFilterStr = new StringBuilder();
        StringBuilder dateFilterStr = new StringBuilder();
        Long time = getTimeByShipDate(shipOnDate);
        String timeStr = String.valueOf(time);
        eqlFilterStr.append("((");
        eqlFilterStr.append("product.startDate<=").append(timeStr).append(" and product.endDate>=").append(timeStr);
        String currentTimeStr = String.valueOf(new Date().getTime());
        // Adding the OR condition to fetch the coming soon products
        eqlFilterStr.append(") or (product.comingSoonStartDate<=").append(currentTimeStr)
                .append(" and product.comingSoonEndDate>").append(currentTimeStr).append("))");
        if (eqlFilterStr.length() > 0) {
            eqlFilterStr.insert(0, "collection()/record[").append("]");
        }
        String test = URLEncoder.encode(eqlFilterStr.toString(), "UTF-8");
        dateFilterStr.append("&Nrs=");
        dateFilterStr.append(test);
        return dateFilterStr.toString();
    }


    /**
     * Gets the ship on date.
     *
     * @return the ship on date
     */

    public String getShipOnDate() {

        long unixDate = System.currentTimeMillis() / 1000L;
        String shipDate = unixDate + "0000000000000".substring(Long.toString(unixDate).length()) ;
        s_logger.info("Unix Ship on date : " + shipDate);
        return shipDate;

    }

    /**
     * Gets the time by ship date.
     *
     * @param shipOnDate the ship on date
     * @return the time by ship date
     * @throws ParseException the parse exception
     */
    public Long getTimeByShipDate(String shipOnDate) throws ParseException {
        Calendar cal = Calendar.getInstance();
        Date today = new Date();
        cal.setTime(today);
        if (null != shipOnDate) {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            Date shipDate = formatter.parse(shipOnDate);
            if (!shipDate.before(today)) {
                cal.setTime(shipDate);
            }
        }
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        Long time = cal.getTimeInMillis();
        s_logger.info("In ASDAAutoSuggestProcessor--> getTimeByShipDate() --> Date from request :: " + shipOnDate
                + "::Date passed :: " + cal.getTime());
        return time;
    }




    /**
     * Utility to return CMS NavMenu API response by taking different filters as input
     *
     * @param endecaUserSegments the endeca user segments
     * @param StoreID the store ID
     * @param additonalUserSegments the other details
     * @param shipDate the ship date
     * @param No the no
     * @param Nrpp the nrpp
     * @param requestorigin the requestorigin
     * @return the JSON object
     * @throws JSONException the JSON exception
     * @author a0d01cj
     */



    public JSONObject CMS_API(String endecaUserSegments, String StoreID, String additonalUserSegments, String shipDate, String No, String Nrpp, String requestorigin, String API_url) throws JSONException {


        s_logger.info("apiName: NavMenu , endecaUserSegments: " + endecaUserSegments + " StoreID:" + StoreID + " OtherDetails:" + additonalUserSegments + " No:" + No + " Nrpp:" + Nrpp + " requestorigin:" + requestorigin);


        StringBuffer completeUrl = new StringBuffer(API_url);
        String responseMessage = "";

        completeUrl = completeUrl.append("?Endeca_user_segments=" + endecaUserSegments + additonalUserSegments + "&storeId=" + StoreID + "&shipDate=" + shipDate + "&No=" + No + "&Nrpp=" + Nrpp + "&requestorigin=" + requestorigin);

        s_logger.info("CMS API : " + completeUrl);
        responseMessage = get(completeUrl.toString(), "", PostBodyType.json,ProxyUsage.enable);


        s_logger.info("API RESPONSE of CMS API : " + responseMessage);

        if (responseMessage != null) {

            JSONObject responseMessageJSON;
            try {
                responseMessageJSON = new JSONObject(responseMessage);
            } catch (JSONException e) {
                s_logger.info("JSON Exception observed ");
                responseMessageJSON = null;
            }

            return responseMessageJSON;
        } else {
            s_logger.info("Response is null");
            return null;
        }
    }

    /**
     * Utility to return CMS NavMenu API response by taking different filters as input
     *This method takes additional N value as filter
     * @param endecaUserSegments the endeca user segments
     * @param StoreID the store ID
     * @param additonalUserSegments the other details
     * @param shipDate the ship date
     *  @param N the dimValId
     * @param No the no
     * @param Nrpp the nrpp
     * @param requestorigin the requestorigin
     * @return the JSON object
     * @throws JSONException the JSON exception
     * @author a0d01cj
     */
    public JSONObject CMS_API(String endecaUserSegments, String StoreID, String additonalUserSegments, String shipDate,String N, String No, String Nrpp, String requestorigin, String API_url) throws JSONException {


        s_logger.info("apiName: NavMenu , endecaUserSegments: " + endecaUserSegments + " StoreID:" + StoreID + " additonalUserSegments:" + additonalUserSegments + "ShipDate: " + shipDate + "N: " + N + "No:" + No + " Nrpp:" + Nrpp + " requestorigin:" + requestorigin);


        StringBuffer completeUrl = new StringBuffer(API_url);
        String responseMessage = "";

        completeUrl = completeUrl.append("?Endeca_user_segments=" + endecaUserSegments + additonalUserSegments + "&storeId=" + StoreID + "&shipDate=" + shipDate + "&N=" + N + "&No=" + No + "&Nrpp=" + Nrpp + "&requestorigin=" + requestorigin);

        s_logger.info("CMS API : " + completeUrl);
        responseMessage = get(completeUrl.toString(), "", PostBodyType.json,ProxyUsage.enable);


        s_logger.info("API RESPONSE of CMS API : " + responseMessage);

        if (responseMessage != null) {

            JSONObject responseMessageJSON;
            try {
                responseMessageJSON = new JSONObject(responseMessage);
            } catch (JSONException e) {
                s_logger.info("JSON Exception observed ");
                responseMessageJSON = null;
            }

            return responseMessageJSON;
        } else {
            s_logger.info("Response is null");
            return null;
        }
    }
    /**
     * Returns XM information based on the path and the response type(JSON/XML)
     * even if the response is XML, this method converts the same into JSON object
     * @param linkresourcePath the linkresource path
     * @param responseType the response type
     * @return the JSON object
     * @throws JSONException the JSON exception
     * @author a0d01cj
     */

    public JSONObject CMS_XM(String linkresourcePath, String responseType) throws JSONException {


        s_logger.info("apiName: CMS_XMRule , linkresourcePath: " + linkresourcePath);
        s_logger.info("Environment : " + EnvironmentConfig.getInstance());

        String url = EnvironmentConfig.getInstance().getValueForKey("CMS_XMAPI_URL");
        String userName = EnvironmentConfig.getInstance().getValueForKey("CM_XM_UserName");
        String password = EnvironmentConfig.getInstance().getValueForKey("CM_XM_Password");


        StringBuffer completeUrl = new StringBuffer(url);
        String responseMessage = "";

        linkresourcePath = linkresourcePath.replaceAll("\\s", "%20");
        completeUrl.insert(7, userName + ":" + password + "@");


        if(responseType.equals("XML")) {
            completeUrl = completeUrl.append(linkresourcePath + "/content.xml");
        }else {

            completeUrl = completeUrl.append(linkresourcePath + ".json");
        }

        s_logger.info("CMS XM API : " + completeUrl);
        responseMessage = get(completeUrl.toString(), "", PostBodyType.json,ProxyUsage.enable);


        s_logger.info("API RESPONSE  for CMS XM API : " + responseMessage);

        JSONObject responseMessageJSON;
        XMLJSONConvertors xmlToJson=new XMLJSONConvertors();

        if (responseMessage != null && responseType.equals("JSON")) {
            try {
                responseMessageJSON = new JSONObject(responseMessage);
            } catch (JSONException e) {
                s_logger.info("JSON Exception observed ");
                responseMessageJSON = null;
            }

            return responseMessageJSON;

        } else if(responseMessage != null && responseType.equals("XML")) {

            try {
                responseMessageJSON=xmlToJson.XMLJsonConverterReturnsJSONObject(responseMessage);
            }catch (Exception e1) {
                s_logger.info("Exception occured while coverting XML response to JSON : "+e1);
                responseMessageJSON = null;
            }
            return responseMessageJSON;

        }else {
            s_logger.info("Response is null");
            return null;
        }
    }

    /**
     * Return all the rules at a XM path as a Map.
     *
     * @return the JSON object
     * @throws JSONException the JSON exception
     * @author a0d01cj
     */

    public Map<String,ArrayList<String>> getXMRuleList(String xmRuleListAPIUrl) {

        JSONObject XM_RuleList_APIResponse = new JSONObject();
        HttpClientAPIUtility apiUtility = new HttpClientAPIUtility();
        Map<String,ArrayList<String>> ruleMap = new HashMap<String, ArrayList<String>>();

        XM_RuleList_APIResponse = CMS_XM(xmRuleListAPIUrl, "JSON");

        s_logger.info("XM_RuleList_APIResponse: " + XM_RuleList_APIResponse);
        List<String> ruleList = new ArrayList<String>();

        for (Object key : XM_RuleList_APIResponse.keySet()) {
            String keyStr = (String) key;
            Object keyvalue = XM_RuleList_APIResponse.get(keyStr);
            if (keyvalue instanceof JSONObject) {
                ruleList.add(keyStr);
            }
        }
        System.out.println(ruleList);

        for(int i = 0; i<ruleList.size(); i++) {
            ArrayList<String> ruleValueList = new ArrayList<String>();

            JSONObject rule = XM_RuleList_APIResponse.getJSONObject(ruleList.get(i));
            ruleValueList.add(rule.getInt("priority")+"");

            ruleValueList.add(rule.getString("workflowState"));

            ruleValueList.add(rule.getString("templateId"));

            if(rule.getString("startTime").length()==0) {
                ruleValueList.add("0000-00-00T00:00");
            }else {
                ruleValueList.add(rule.getString("startTime"));
            }

            if(rule.getString("endTime").length()==0) {
                ruleValueList.add("9999-12-31T23:59");
            }else {
                ruleValueList.add(rule.getString("endTime"));
            }

            String userSegmentsList = " ";

            if(rule.has("userSegments")) {

                for(int j=0; j< rule.getJSONArray("userSegments").length(); j++) {
                    if(!rule.getJSONArray("userSegments").get(j).toString().equals(" ")){
                        userSegmentsList = userSegmentsList + rule.getJSONArray("userSegments").get(j).toString() ;
                    }
                }
                ruleValueList.add(userSegmentsList);

            }

            ruleMap.put(ruleList.get(i), ruleValueList);
            System.out.println( ruleList.get(i) + " : " + ruleValueList);
        }
        return ruleMap;

    }

    /**
     * To get CMS Full Taxonomy API response based on different filters .
     *
     * @param shipDate the ship date
     * @param requestorigin the requestorigin
     * @return the JSON object
     * @throws JSONException the JSON exception
     * @author a0d01cj
     */



    public JSONObject CMS_FullTaxonomy(String storeID, String shipDate, String requestorigin) {

        s_logger.info("apiName: FullTaxonomy , storeID: " + storeID + " shipDate:" + shipDate + " requestorigin:" + requestorigin );

        s_logger.info("Environment : " + EnvironmentConfig.getInstance());

        String url = EnvironmentConfig.getInstance().getValueForKey("CMS_FullTaxonomy_API_URL");

        StringBuffer completeUrl = new StringBuffer(url);
        String responseMessage = "";

        completeUrl = completeUrl.append("requestorigin=" + requestorigin + "&storeId" + storeID + "&shipDate=" + shipDate);

        s_logger.info("CMS Full Taxonomy API : " + completeUrl);
        responseMessage = get(completeUrl.toString(), "", PostBodyType.json,ProxyUsage.enable);


        s_logger.info("API RESPONSE  for CMS Full Taxonomy : " + responseMessage);

        if (responseMessage != null) {

            JSONObject responseMessageJSON;
            try {
                responseMessageJSON = new JSONObject(responseMessage);
            } catch (JSONException e) {
                s_logger.info("JSON Exception observed ");
                responseMessageJSON = null;
            }

            return responseMessageJSON;
        } else {
            s_logger.info("Response is null");
            return null;
        }
    }



    /**
     * To get getDimensionMap API response .
     *
     * @return the JSON object
     * @throws JSONException the JSON exception
     * @author a0d01cj
     */



    public JSONObject CMS_getDimensionMap_API_Response() {

        s_logger.info("apiName: getDimensionMap "  );

        s_logger.info("Environment : " + EnvironmentConfig.getInstance());

        String url = EnvironmentConfig.getInstance().getValueForKey("CMS_getDimensionMap_API_URL");

        StringBuffer completeUrl = new StringBuffer(url);
        String responseMessage = "";

        s_logger.info("CMS Get Dimension Map API : " + completeUrl);
        responseMessage = get(completeUrl.toString(), "", PostBodyType.json,ProxyUsage.enable);


        s_logger.info("API RESPONSE  for CMS Get Dimension Map: " + responseMessage);

        if (responseMessage != null) {

            JSONObject responseMessageJSON;
            try {
                responseMessageJSON = new JSONObject(responseMessage);
            } catch (JSONException e) {
                s_logger.info("JSON Exception observed ");
                responseMessageJSON = null;
            }

            return responseMessageJSON;
        } else {
            s_logger.info("Response is null");
            return null;
        }
    }
    /**
 
    /**
     * Gets the facet list.
     *
     * @param facetString the facet string
     * @return the facet list
     */
    public String getFacetList(String facetString){
        StringBuffer facet=new StringBuffer();
        if (!facetString.equals("")) {
            String facetName="";
            String facetValue="";
            String[] facets = facetString.split(",");
            String facetTerm="";
            for(int i=0;i<facets.length;i++){
                facetTerm = facets[i];
                facetName = facetTerm.split(":")[0];
                facetValue=	facetTerm.split(":")[1];
                if (i>0 && i<facets.length)
                    facet = facet.append(",");

                if(facetName.equals("Nutrition"))
                    facet = facet.append(facetValue);
            }
        }
        return facet.toString();
    }

    /**
     * Format special characters in url.
     *
     * @param name the name
     * @return the string
     */
   

    /**
     * Checks if is mobile API.
     *
     * @param requestorigin the requestorigin
     * @return true, if is mobile API
     */
    public boolean isMobileAPI(String requestorigin){
        boolean isMobileAPI=false;
        if("ios".equals(requestorigin)){
            isMobileAPI=true;
        }else isMobileAPI= "android".equals(requestorigin);
        s_logger.info("isMobileAPI : "+isMobileAPI);
        return isMobileAPI;
    }


   
   
    /**
     * Check post code.
     *
     * @param postcode the postcode
     */
    public void checkPostCode(String postcode) {

        String url = EnvironmentConfig.getInstance().getValueForKey("SEARCH_API_CHECKPOST_URL");
        String completeUrl = url.concat("postcode=" + postcode);

        s_logger.info("Complete Url for checkPostCode : " + completeUrl);
        String response = get(completeUrl, "", PostBodyType.json,ProxyUsage.enable);
        s_logger.info("CheckPostCode response : " + response);
    }

    
    /**
     * Gets the autosuggest CMS content response.
     *
     * @param searchTerm the search term
     * @param storeId the store id
     * @return the autosuggest CMS content response
     */
    public JSONObject getAutosuggestCMSContentResponse(String searchTerm,String storeId) {
        s_logger.info("apiName: AutosuggestCMSContent , searchTerm: " + searchTerm +" ,storeId : "+storeId);
        String url = EnvironmentConfig.getInstance().getValueForKey("Autosuggest_CMSContent_URL");
        StringBuffer completeUrl= new StringBuffer(url);
        String responseMessage ="";

        searchTerm=searchTerm.replaceAll(" ", "%20");
        searchTerm=searchTerm.replaceAll("#", "%23");
        completeUrl =completeUrl.append("searchTerm="+searchTerm+"&cacheable=true&storeId="+storeId+"&viewPort=XXlarge&requestorigin=gi");

        s_logger.info("completeUrl : "+completeUrl);

        responseMessage = get(completeUrl.toString(), "", PostBodyType.json,ProxyUsage.enable);

        s_logger.info("API RESPONSE : "+responseMessage);
        if (responseMessage != null) {
            JSONObject jb;
            try {
                jb = new JSONObject(responseMessage);
                s_logger.info("==========JSONObject============");
                s_logger.info(jb+"");
            } catch (JSONException e) {
                s_logger.info("JSON Exception observed ");
                jb= null;
            }
            return jb;
        } else {
            s_logger.info("Response is null");
            return null;
        }
    }

    

    /**
     * Json writer.
     *
     * @param nutritionalInfoList the nutritional info list
     * @param skuListForNutrition the sku list for nutrition
     */
    public void jsonWriter(ArrayList<String> nutritionalInfoList,ArrayList<String> skuListForNutrition){

        JSONObject obj = new JSONObject();
        String fileName = "./src/main/resources/com/asda/qa/data/AutoGeneratedFile/NutritionalInfo.json";

        try{

            for(int i =0;i<skuListForNutrition.size();i++){
                String sku = skuListForNutrition.get(i);
                String nutrition = nutritionalInfoList.get(i);
                obj.put(sku, nutrition);
            }

            FileWriter file = new FileWriter(fileName) ;
            file.write(obj.toString());
            file.flush();

        }catch(Exception e){
            e.printStackTrace();
        }


    }

    /**
     * Gets the JSON string from simple string.
     *
     * @param simpleString the simple string
     * @return the JSON string from simple string
     */
    public String getJSONStringFromSimpleString(String simpleString){

        String result = "";
        try{
            simpleString = simpleString.replace("{", "");
            simpleString = simpleString.replace("}", "");

            String[] value = simpleString.split(",");

            for(int i=0;i<value.length;i++){
                String[] val = value[i].split(":");
                if(i==0){
                    result = "{ " + "\""+val[0]+ "\""+" : "+ "\""+val[1]+ "\""+",";
                }else if((i>0) && (i<value.length-1)){
                    result = result + "\""+val[0]+ "\""+" : "+ "\""+val[1]+ "\""+",";
                }else{
                    result = result + "\""+val[0]+ "\""+" : "+ "\""+val[1]+ "\""+" }";
                }


            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return result;

    }

    /**
     * Gets the JSON object from simple string.
     *
     * @param simpleString the simple string
     * @param skuName the sku name
     * @return the JSON object from simple string
     */
    public JSONObject getJSONObjectFromSimpleString(String simpleString,String skuName){

        JSONParser parser = new JSONParser();
        ObjectMapper mapper = new ObjectMapper();
        JSONObject jsonObj = null;
        String result = "";
        try{
            simpleString = simpleString.replace("{", "");
            simpleString = simpleString.replace("}", "");

            String[] value = simpleString.split(",");

            for(int i=0;i<value.length;i++){
                String[] val = value[i].split(":");
                if(i==0){
                    result = "{ " + "\""+val[0]+ "\""+" : "+ "\""+val[1]+ "\""+",";
                }else if((i>0) && (i<value.length-1)){
                    result = result + "\""+val[0]+ "\""+" : "+ "\""+val[1]+ "\""+",";
                }else{
                    result = result + "\""+val[0]+ "\""+" : "+ "\""+val[1]+ "\""+" }";
                }


            }
            //s_logger.info("result = "+result);
            Object obj = parser.parse(result);
            String val = mapper.writeValueAsString(obj);
            jsonObj = new JSONObject(val);
            s_logger.info("For SKU: "+skuName+" - jsonObj = "+jsonObj);
            //s_logger.info("For SKU: "+skuName+" - jsonObj = "+jsonObj.toString());

        }catch(Exception e){
            e.printStackTrace();
        }

        return jsonObj;

    }


    /**
  
    /**
     * Gets the nutritional dimesion mapping.
     *
     * @param term the term
     * @return the nutritional dimesion mapping
     */
    // Get Mapping Nutrional DimensionName from Search term
    public String getNutritionalDimesionMapping(String term) {

        s_logger.info("searchTerm => "+term);
        String searchTerm = term.trim().replaceAll(" +", " ");
        String termLowerCase = searchTerm.toLowerCase().trim();
        String nutrionalDimesion = EnvironmentConfig.getInstance().getNutritionalDimesionMapping();
        String nutritionalDimesionName = "";

        String[] dimArr = nutrionalDimesion.split(",");

        int count = 0;
        for(int i=0;i<dimArr.length;i++){
            if(termLowerCase.contains(dimArr[i].trim())){
                String dimName = getNutritionalDimesionName(dimArr[i].trim());
                if(count>0){
                    nutritionalDimesionName = nutritionalDimesionName.trim() +","+ dimName.trim();
                }else{
                    nutritionalDimesionName = nutritionalDimesionName.trim() + dimName.trim();
                }
                termLowerCase = termLowerCase.replaceAll(dimArr[i].trim(), "").trim();
                count++;
            }
        }

        return nutritionalDimesionName;
    }


    /**
     * Gets the nutritional filter with NTT mapping.
     *
     * @param term the term
     * @return the nutritional filter with NTT mapping
     */
    // Get Mapping Nutrional DimensionName from Search term
    public ArrayList<ArrayList<String>> getNutritionalFilterWithNTTMapping(String term) {

        ArrayList<ArrayList<String>> nutritionalFilterListWithNtt = new ArrayList<ArrayList<String>>();
        try{
            s_logger.info("searchTerm => "+term);
            String searchTerm = term.trim().replaceAll(" +", " ");
            String termLowerCase = searchTerm.toLowerCase().trim();
            String nutrionalDimesion = EnvironmentConfig.getInstance().getNutritionalDimesionMapping();
            ArrayList<String> termName = new ArrayList<String>();
            ArrayList<String> nutritionalFilter = new ArrayList<String>();

            String[] dimArr = nutrionalDimesion.split(",");

            for(int i=0;i<dimArr.length;i++){
                if(termLowerCase.contains(dimArr[i].trim())){
                    String dimName = getNutritionalDimesionName(dimArr[i].trim());
                    nutritionalFilter.add(dimName.trim());
                    termLowerCase = termLowerCase.replaceAll(dimArr[i].trim(), "").trim();
                    s_logger.info("termLowerCase = "+termLowerCase);

                }
            }

            termName.add(termLowerCase);

            nutritionalFilterListWithNtt.add(termName);
            nutritionalFilterListWithNtt.add(nutritionalFilter);

        }catch(Exception e){
            e.printStackTrace();
        }

        return nutritionalFilterListWithNtt;
    }

    /**
     * Gets the nutritional dimesion name.
     *
     * @param value the value
     * @return the nutritional dimesion name
     */
    // Get Mapping Nutrional DimensionName from Search term
    public String getNutritionalDimesionName(String value) {

        String nutritionalDimesionName ="";

        if((value.equalsIgnoreCase("sesame free")) || (value.equalsIgnoreCase("no sesame")) || (value.equalsIgnoreCase("without sesame")) || (value.equalsIgnoreCase("without sesam")) || (value.equalsIgnoreCase("no sesam")) || (value.equalsIgnoreCase("esame free"))){
            nutritionalDimesionName = "NoSesame";
        }else if((value.equalsIgnoreCase("wheat free")) || (value.equalsIgnoreCase("no wheat")) || (value.equalsIgnoreCase("without wheat")) || (value.equalsIgnoreCase("heat free")) || (value.equalsIgnoreCase("no whea")) || (value.equalsIgnoreCase("without whea"))){
            nutritionalDimesionName = "WheatFree";
        }else if((value.equalsIgnoreCase("nuts free")) || (value.equalsIgnoreCase("no nuts")) || (value.equalsIgnoreCase("without nuts")) || (value.equalsIgnoreCase("uts free")) || (value.equalsIgnoreCase("no nut")) || (value.equalsIgnoreCase("without Nut"))){
            nutritionalDimesionName = "NoNuts";
        }else if((value.equalsIgnoreCase("shellfish free")) || (value.equalsIgnoreCase("no shellfish")) || (value.equalsIgnoreCase("without shellfish")) || (value.equalsIgnoreCase("hellfish free")) || (value.equalsIgnoreCase("no shellfis")) || (value.equalsIgnoreCase("without shellfis"))){
            nutritionalDimesionName = "NoShellfish";
        }else if((value.equalsIgnoreCase("egg free")) || (value.equalsIgnoreCase("no egg")) || (value.equalsIgnoreCase("without egg"))|| (value.equalsIgnoreCase("gg free"))|| (value.equalsIgnoreCase("no eg"))|| (value.equalsIgnoreCase("without eg"))){
            nutritionalDimesionName = "NoEgg";
        }else if((value.equalsIgnoreCase("peanuts free")) || (value.equalsIgnoreCase("no peanuts")) || (value.equalsIgnoreCase("without peanuts"))|| (value.equalsIgnoreCase("eanuts free"))|| (value.equalsIgnoreCase("no peanut"))|| (value.equalsIgnoreCase("without peanut"))){
            nutritionalDimesionName = "NoPeanuts";
        }else if((value.equalsIgnoreCase("celery free")) || (value.equalsIgnoreCase("no celery")) || (value.equalsIgnoreCase("without celery")) || (value.equalsIgnoreCase("elery free")) || (value.equalsIgnoreCase("no celer")) || (value.equalsIgnoreCase("without celer"))){
            nutritionalDimesionName = "CeleryFree";
        }else if((value.equalsIgnoreCase("sulphites free")) || (value.equalsIgnoreCase("no sulphites")) || (value.equalsIgnoreCase("without sulphites")) || (value.equalsIgnoreCase("ulphites free")) || (value.equalsIgnoreCase("no sulphite")) || (value.equalsIgnoreCase("without sulphite"))){
            nutritionalDimesionName = "SulphitesFree";
        }else if((value.equalsIgnoreCase("soya free")) || (value.equalsIgnoreCase("no soya")) || (value.equalsIgnoreCase("without soya")) || (value.equalsIgnoreCase("oya free")) || (value.equalsIgnoreCase("no soy")) || (value.equalsIgnoreCase("without soy"))){
            nutritionalDimesionName = "NoSoya";
        }else if((value.equalsIgnoreCase("oat free")) || (value.equalsIgnoreCase("no oat")) || (value.equalsIgnoreCase("without oat")) || (value.equalsIgnoreCase("at free"))|| (value.equalsIgnoreCase("no oa"))|| (value.equalsIgnoreCase("without oa"))){
            nutritionalDimesionName = "OatFree";
        }else if((value.equalsIgnoreCase("gluten free")) || (value.equalsIgnoreCase("no gluten")) || (value.equalsIgnoreCase("without gluten")) || (value.equalsIgnoreCase("gluaten free")) || (value.equalsIgnoreCase("glutan free")) || (value.equalsIgnoreCase("luten free")) || (value.equalsIgnoreCase("no glute")) || (value.equalsIgnoreCase("without glute"))){
            nutritionalDimesionName = "NoGluten";
        }else if((value.equalsIgnoreCase("yeast free")) || (value.equalsIgnoreCase("no yeast")) || (value.equalsIgnoreCase("without yeast")) || (value.equalsIgnoreCase("east free")) || (value.equalsIgnoreCase("no yeas")) || (value.equalsIgnoreCase("without yeas"))){
            nutritionalDimesionName = "YeastFree";
        }else if((value.equalsIgnoreCase("lactose free")) || (value.equalsIgnoreCase("no lactose")) || (value.equalsIgnoreCase("without lactose")) || (value.equalsIgnoreCase("actose free")) || (value.equalsIgnoreCase("no lactos")) || (value.equalsIgnoreCase("without lactos"))){
            nutritionalDimesionName = "NoLactose";
        }else if((value.equalsIgnoreCase("milk free")) || (value.equalsIgnoreCase("no milk")) || (value.equalsIgnoreCase("without milk")) || (value.equalsIgnoreCase("ilk free")) || (value.equalsIgnoreCase("no mil")) || (value.equalsIgnoreCase("without mil"))){
            nutritionalDimesionName = "NoMilk";
        }else if((value.equalsIgnoreCase("mustard free")) || (value.equalsIgnoreCase("no mustard")) || (value.equalsIgnoreCase("without mustard")) || (value.equalsIgnoreCase("without mustar")) || (value.equalsIgnoreCase("ustard free")) || (value.equalsIgnoreCase("no mustar")) || (value.equalsIgnoreCase("without mustar"))){
            nutritionalDimesionName = "NoMustard";
        }else if((value.equalsIgnoreCase("vegetarian")) || (value.equalsIgnoreCase("egetarian"))){
            nutritionalDimesionName = "Vegetarian";
        }else if(value.equalsIgnoreCase("organic")){
            nutritionalDimesionName = "Organic";
        }else if((value.equalsIgnoreCase("kosher")) || (value.equalsIgnoreCase("osher")) || (value.equalsIgnoreCase("koshar"))){
            nutritionalDimesionName = "Kosher";
        }else if((value.equalsIgnoreCase("vegan")) || (value.equalsIgnoreCase("egan")) || (value.equalsIgnoreCase("vagan"))){
            nutritionalDimesionName = "Vegan";
        }else if((value.equalsIgnoreCase("halal")) || (value.equalsIgnoreCase("alal")) || (value.equalsIgnoreCase("hala"))){
            nutritionalDimesionName = "Halal";
        }else if((value.equalsIgnoreCase("fish free")) || (value.equalsIgnoreCase("no fish")) || (value.equalsIgnoreCase("without fish"))|| (value.equalsIgnoreCase("ish free"))|| (value.equalsIgnoreCase("no fis"))){
            nutritionalDimesionName = "NoFish";
        }else if((value.equalsIgnoreCase("lupin free")) || (value.equalsIgnoreCase("no lupin")) || (value.equalsIgnoreCase("without lupin"))|| (value.equalsIgnoreCase("upin free"))|| (value.equalsIgnoreCase("no lupi"))){
            nutritionalDimesionName = "NoLupin";
        }else if((value.equalsIgnoreCase("celeryincludingceleriac free")) || (value.equalsIgnoreCase("no celeryincludingceleriac")) || (value.equalsIgnoreCase("without celeryincludingceleriac"))|| (value.equalsIgnoreCase("eleryincludingceleriac free"))|| (value.equalsIgnoreCase("no celeryincludingceleria"))){
            nutritionalDimesionName = "NoCeleryincludingceleriac";
        }

        return nutritionalDimesionName;
    }

   
    /**
     * Gets the nutritional dimesion status from DB.
     *
     * @param jb the jb
     * @param skuList the sku list
     * @param nutritionalDimesionName the nutritional dimesion name
     * @return the nutritional dimesion status from DB
     */
    // Return nutritional dimesions value
    public ArrayList<String> getNutritionalDimesionStatusFromDB(ArrayList<JSONObject> jb,ArrayList<String> skuList,String nutritionalDimesionName) {

        ArrayList<String> nutritionalDimesionStatus = new ArrayList<String>();

        try{
            String[] dimesionsName = null;
            dimesionsName = nutritionalDimesionName.split(",");
            s_logger.info("Total Nutritional Dimesions Send As Filter : "+dimesionsName.length +" : "+nutritionalDimesionName);
            for (int i = 0; i < jb.size(); i++) {
                int count = 0;
                String nutritionalStatus = "";
                if(jb.get(i)!=null){
                    JSONObject nutritionalInfo = jb.get(i);

                    if(nutritionalInfo.length()!=0){
                        for(int j =0;j<dimesionsName.length;j++){
                            if(nutritionalInfo.get(dimesionsName[j]).equals("1")){
                                count++;
                            }
                        }
                        if(count==dimesionsName.length){
                            nutritionalStatus = skuList.get(i)+" - TRUE" ;
                        }else{
                            nutritionalStatus = skuList.get(i)+" - FALSE" ;
                        }
                        nutritionalDimesionStatus.add(nutritionalStatus);

                    }
                }

            }
        }catch(Exception e){
            e.printStackTrace();
        }

        return nutritionalDimesionStatus;

    }

   



   
    /**
     * Demo utility.
     *
     * @throws JSONException the JSON exception
     */
    public void demoUtility() throws JSONException {


        String completeUrl = "https://api.whatsapp.com/send?phone=918906137778&text=I%27m%20interested%20in%20your%20car%20for%20sale";
        s_logger.info("Complete Url for SIGN IN: " + completeUrl);

        String responseMessage = post(completeUrl, "", PostBodyType.json,ProxyUsage.disable);
        s_logger.info("Response Message SIGN IN:" + responseMessage);



    }



    /**
     * Checks if is list sequence identical.
     *
     * @param list1 the list 1
     * @param list2 the list 2
     * @return true, if is list sequence identical
     */
    public boolean isListSequenceIdentical(ArrayList<String> list1 , ArrayList<String> list2) {
        boolean resultFlag= false;
        if(list1==null || list2==null || list1.size()==0 || list2.size()==0) {
            s_logger.info("Two lists can't be compared as one or either of them are null");
        }else if(list1.size()!=list2.size()){
            s_logger.info("list sizes are not matching - List1 : "+list1.size()+" , List2 : "+list2.size());
        }else {
            s_logger.info("list sizes are matching - size : "+list1.size());
            for(int i=0;i<list1.size();i++) {
                if(list1.get(i).equals(list2.get(i))) {
                    resultFlag=true;
                    continue;
                }else {
                    //s_logger.info("List values at index : "+i+" are Value1 : "+list1.get(i)+" and Value2 : "+list2.get(i));
                    resultFlag=false;
                    break;
                }
            }
        }

        return resultFlag;
    }

    /**
     * Checks if is list identical.
     *
     * @param arrayList1 the array list 1
     * @param arrayList2 the array list 2
     * @return true, if is list identical
     */
    public boolean isListIdentical(ArrayList<String> arrayList1 , ArrayList<String> arrayList2) {
        boolean resultFlag= false;
        ArrayList<String> list1 = new ArrayList<String>(arrayList1);
        ArrayList<String> list2 = new ArrayList<String>(arrayList2);
        ArrayList<String> list11 = new ArrayList<String>(arrayList1);
        if(list1==null || list2==null || list1.size()==0 || list2.size()==0) {
            s_logger.info("Two lists can't be compared as one or either of them are null");
        }else if(list1.size()!=list2.size()){
            s_logger.info("list sizes are not matching - List1 : "+list1.size()+" , List2 : "+list2.size());
        }else {
            s_logger.info("list sizes are matching - size : "+list1.size());
            list1.removeAll(list2);
            if(list1.size()>0) {
                s_logger.info("list1 size after removing list2 values -> "+list1.size());
                for(String Val1 : list1)
                    s_logger.info("List1 Value : "+Val1);
            }
            list2.removeAll(list11);
            if(list2.size()>0) {
                s_logger.info("list2 size after removing list1 values -> "+list2.size());
                for(String Val2 : list2)
                    s_logger.info("List2 Value : "+Val2);
            }
            if(list1.size()==0 && list2.size()==0) {
                s_logger.info("List1 and List2 are having same values irrespective of sequence");
                resultFlag=true;
            }
        }

        return resultFlag;
    }

    /**
     * Checks if is list similar more than threshold in sequence.
     *
     * @param arrayList1 the array list 1
     * @param arrayList2 the array list 2
     * @param thresholdPercentage the threshold percentage
     * @return true, if is list similar more than threshold in sequence
     */
    public boolean isListSimilarMoreThanThresholdInSequence(ArrayList<String> arrayList1 , ArrayList<String> arrayList2,float thresholdPercentage) {
        s_logger.info("Verifying if both list are having similarity minimum threshold percentage : "+thresholdPercentage+"% in sequence");
        boolean resultFlag= false;
        int count=0;
        int similartityPercentage = 0;
        ArrayList<String> list1 = new ArrayList<String>(arrayList1);
        ArrayList<String> list2 = new ArrayList<String>(arrayList2);
        ArrayList<String> smallerlist = null;
        ArrayList<String> biggerlist = null;
        int total_cins_to_match = 0;
        if(list1==null || list2==null || list1.size()==0 || list2.size()==0) {
            s_logger.info("Two lists can't be compared as one or either of them are null");
        }else if(list1.size()<list2.size() && list1.size()<=60){
            total_cins_to_match = list1.size();
            smallerlist = new ArrayList<String>(list1);
            biggerlist = new ArrayList<String>(list2);
        }else if(list1.size()>=list2.size() && list2.size()<=60){
            total_cins_to_match = list2.size();
            smallerlist = new ArrayList<String>(list2);
            biggerlist = new ArrayList<String>(list1);
        }else if(list1.size()>=list2.size() && list2.size()>60){
            total_cins_to_match = 60;
            biggerlist = new ArrayList<String>(list1); // considering normal term exists data
            smallerlist = new ArrayList<String>(list2);// considering stemmed data need not exactly have data every time
        }else if(list1.size()<list2.size() && list1.size()>60){
            total_cins_to_match = 60;
            biggerlist = new ArrayList<String>(list2); // considering normal term exists data
            smallerlist = new ArrayList<String>(list1);// considering stemmed data need not exactly have data every time
        }

        if(total_cins_to_match>0) {
            for (int i=0; i<total_cins_to_match;i++) {
                if(biggerlist.get(i).equals(smallerlist.get(i))) {
                    count++;
                    continue;
                }else {
                    //s_logger.info("List values at index : "+i+" are Value1 : "+biggerlist.get(i)+" and Value2 : "+smallerlist.get(i));
                }
            }

            // Calculating similarity percentage match
            similartityPercentage = (count/smallerlist.size())*100;
            s_logger.info("similartityPercentage : "+similartityPercentage);
            resultFlag	 = similartityPercentage >= thresholdPercentage;

        }
        s_logger.info("resultFlag : "+resultFlag);
        return resultFlag;
    }

    /**
     * Checks if is list similar more than threshold without sequence.
     *
     * @param arrayList1 the array list 1
     * @param arrayList2 the array list 2
     * @param thresholdPercentage the threshold percentage
     * @return true, if is list similar more than threshold without sequence
     */
    public boolean isListSimilarMoreThanThresholdWithoutSequence(ArrayList<String> arrayList1 , ArrayList<String> arrayList2,float thresholdPercentage) {
        s_logger.info("Verifying if both list are having similarity minimum threshold percentage : "+thresholdPercentage+"% without considering sequence");
        boolean resultFlag= false;
        float count=0;
        float similartityPercentage = 0;
        ArrayList<String> list1 = new ArrayList<String>(arrayList1);
        ArrayList<String> list2 = new ArrayList<String>(arrayList2);
        ArrayList<String> smallerlist = null;
        ArrayList<String> biggerlist = null;
        int total_cins_to_match = 0;

        if(list1==null || list2==null || list1.size()==0 || list2.size()==0) {
            s_logger.info("Two lists can't be compared as one or either of them are null");
        }else if(list1.size()<list2.size() && list1.size()<=60){
            total_cins_to_match = list1.size();
            smallerlist = new ArrayList<String>(list1);
            if(list2.size()>60)
                biggerlist = new ArrayList<String>(list2.subList(0,60));
            else
                biggerlist = new ArrayList<String>(list2);
        }else if(list1.size()>=list2.size() && list2.size()<=60){
            total_cins_to_match = list2.size();
            smallerlist = new ArrayList<String>(list2);
            if(list1.size()>60)
                biggerlist = new ArrayList<String>(list1.subList(0,60));
            else
                biggerlist = new ArrayList<String>(list1);
        }else if(list1.size()>=list2.size() && list2.size()>60){
            total_cins_to_match = 60;
            biggerlist = new ArrayList<String>(list1.subList(0,60)); // considering normal term exists data
            smallerlist = new ArrayList<String>(list2.subList(0,60));// considering stemmed data need not exactly have data every time
        }else if(list1.size()<list2.size() && list1.size()>60){
            total_cins_to_match = 60;
            biggerlist = new ArrayList<String>(list2.subList(0,60)); // considering normal term exists data
            smallerlist = new ArrayList<String>(list1.subList(0,60));// considering stemmed data need not exactly have data every time
        }
        s_logger.info("total_cins_to_match "+total_cins_to_match);
        if(total_cins_to_match>0) {

            count =biggerlist.size();
            s_logger.info("count : "+count);
            biggerlist.removeAll(smallerlist);
            s_logger.info("mismatch count : "+biggerlist.size());
            count = count - biggerlist.size();
            // Calculating similarity percentage match
            similartityPercentage = (count/smallerlist.size())*100;
            s_logger.info("count : "+count+" , smallerlist.size() : "+smallerlist.size());
            s_logger.info("similartityPercentage : "+similartityPercentage);
            resultFlag	 = similartityPercentage >= thresholdPercentage;

        }

        return resultFlag;
    }


    
    /**
     * Login.
     *
     * @param userName the user name
     * @param password the password
     * @param rememberme the rememberme
     * @return the response
     */
    @SuppressWarnings("unchecked")
    public Response login(String userName,String password,String rememberme){

        String baseUrl = EnvironmentConfig.getInstance().getValueForKey("CACR_API_SP_PATH");
        String uri=baseUrl+"/api/v1/login";

        Map<String,String> headers=new HashMap<String, String>();
        headers.put("Content-Type", "application/json");
        JSONObject body=new JSONObject();
        body.put("username", userName);
        body.put("password", password);
        body.put("rememberme", rememberme);
        body.put("method", "authentication");
        body.put("dfp", "fkdkfjdkfjdkf");
        body.put("redirect_uri", baseUrl);

        Response loginResponse=post(uri, null, headers, null, body,ProxyUsage.enable);



        s_logger.info("****************** Cookies ******************");
        s_logger.info("Cookies are {} " , threadcookies.get((int)Thread.currentThread().getId()));
        s_logger.info("");
        s_logger.info("****************** Headers ******************");
        s_logger.info("Headers are {} " , threadResHeaders.get((int)Thread.currentThread().getId()));
        s_logger.info("");
        s_logger.info("****************** ******************");


    			/*String SMD = threadcookies.get((int) Thread.currentThread().getId()).get("SMD");
    			String SSO_UID = threadcookies.get((int) Thread.currentThread().getId()).get("SSO_UID");
    			*/


        s_logger.info("Login Response {}  : "+loginResponse.asString());

        return loginResponse;

    }

    public String getAuthToken(){
        String token = threadcookies.get((int) Thread.currentThread().getId()).get("WM_SEC.AUTH_TOKEN");
        //String auth_token = "WM_SEC.AUTH_TOKEN="+token;
        String auth_token = "wm_sec.auth_token="+token;
        s_logger.info("Cookies : auth_token : "+auth_token);
        return auth_token;
    }


    /**
     * Login.
     *
     * @param apiKey
     * @param shipDate
     * @param cacheable
     * @param contentname
     * @param mobilecontent
     * @param requestOrigin
     * @param authToken
     * @param wm_consumer_id
     * @return the response
     */
    @SuppressWarnings("unchecked")
    public JSONObject getP10DResponse(String keyword,String storeid,String pagenum, String requestOrigin, String mobilecontent, String contentname, String cacheable, String shipDate, String apiKey, String wm_consumer_id, String authToken){

        String baseUrl = EnvironmentConfig.getInstance().getValueForKey("homepageUrl");
        String uri=baseUrl+"api/items/p10dsearch?";

        s_logger.info("authToken ================== "+authToken);
        Map<String,String> headers=new HashMap<String, String>();
        headers.put("wm_consumer.id", wm_consumer_id);
        headers.put("Content-Type", "application/json");

        Map<String,String> cookies=new HashMap<String, String>();
        headers.put("Cookie",authToken);
        //cookies.put("wm_sec.auth_token",authToken);

        Map<String,String> params=new HashMap<String, String>();
        params.put("requestorigin", requestOrigin);
        params.put("apikey", apiKey);
        params.put("keyword", keyword);
        params.put("pagenum", pagenum);
        params.put("mobilecontent", mobilecontent);
        params.put("contentname", contentname);
        params.put("cacheable", cacheable);
        params.put("storeid", storeid);
        params.put("shipDate", shipDate);

        Response p10DResponse=get(uri, null, headers, params,ProxyUsage.enable,true);

        s_logger.info("P10D Response ****************************  : "+p10DResponse.asString());

        if (p10DResponse.asString() != null) {
            JSONObject jb;
            try {
                jb = new JSONObject(p10DResponse.asString());
            } catch (JSONException e) {
                s_logger.info("JSON Exception observed ");
                jb= null;
            }
            return jb;
        } else {
            s_logger.info("Response is null");
            return null;
        }


    }

    /**
     * Post.
     *
     * @param uri the uri
     * @param cookies the cookies
     * @param headers the headers
     * @param params the params
     * @param body the body
     * @param proxyUsage the proxy usage
     * @return the response
     */
    @SuppressWarnings("static-access")
    public Response post(String uri,Map<String,String> cookies,Map<String,String> headers,Map<String,String> params,JSONObject body,ProxyUsage proxyUsage){
        RestAssured.baseURI=uri;
        RestAssured.useRelaxedHTTPSValidation();
        s_logger.info("URL : {} ", uri);
        RequestSpecification	httpRequest=RestAssured.given();
        if(headers!=null)
            httpRequest.headers(headers);


        if(cookies!=null)
            httpRequest.cookies(cookies);

        if(!(this.threadcookies.get((int)Thread.currentThread().getId())==null))
        {
            httpRequest.cookies(this.threadcookies.get((int)Thread.currentThread().getId()));
        }

        if(proxyUsage == ProxyUsage.enable){
            httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
            s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled in both local and looper");
        }

        else if (proxyUsage == ProxyUsage.disable){
            s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is disabled in both local and looper");
        }

        else if (proxyUsage == ProxyUsage.enable_local_only){
            if (System.getenv("HUDSON_URL") == null) {
                httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
                s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in local");
            }
            else{
                s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for local but not enabled");
            }
        }

        else if (proxyUsage == ProxyUsage.enable_looper_only){
            if (System.getenv("HUDSON_URL") != null && System.getenv("HUDSON_URL").contains("walmart.com")) {
                httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
                s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in looper");
            }
            else{
                s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for looper but not enabled");
            }
        }
        if(params!=null)
            httpRequest.params(params);

        if(body!=null) {
            httpRequest.body(body.toString());
            s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName()+" POST Request  {} :", body);
        }

        Response response=	httpRequest.request(Method.POST);
        s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName()+" POST Respone {} :",response.asString());
        addCookie(response);
        threadResHeaders.put((int)Thread.currentThread().getId(), response.getHeaders());
        return response;
    }

    /**
     * Adds the cookie.
     *
     * @param response the response
     */
    @SuppressWarnings("static-access")
    public void addCookie(Response response){
        Map<String,String> localCookie=new HashMap<>();
        if(this.threadcookies.get((int)Thread.currentThread().getId())!=null )
            localCookie.putAll(this.threadcookies.get((int)Thread.currentThread().getId()));
        localCookie.putAll(response.getCookies());
        this.threadcookies.put((int) Thread.currentThread().getId(),localCookie);

    }

    /**
     * Gets the API Response
     *
     * @param uri the uri
     * @param cookies the cookies
     * @param headers the headers
     * @param params the params
     * @param proxyUsage the proxy usage
     * @param urlEncoder the url encoder
     * @return the response
     */
    @SuppressWarnings("static-access")
    public Response get(String uri,Map<String,String> cookies,Map<String,String> headers,Map<String,String> params, ProxyUsage proxyUsage,boolean urlEncoder){
        RestAssured.baseURI=uri;
        RestAssured.useRelaxedHTTPSValidation();
        RequestSpecification httpRequest=RestAssured.given().urlEncodingEnabled(urlEncoder);
        if(headers!=null)
            httpRequest.headers(headers);

        if(cookies!=null)
            httpRequest.cookies(cookies);
        if(!(this.threadcookies.get((int)Thread.currentThread().getId())==null))
            httpRequest.cookies(this.threadcookies.get((int)Thread.currentThread().getId()));

        if(proxyUsage == ProxyUsage.enable){
            httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
            s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled in both local and looper");
        }

        else if (proxyUsage == ProxyUsage.disable){
            s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is disabled in both local and looper");
        }

        else if (proxyUsage == ProxyUsage.enable_local_only){
            if (System.getenv("HUDSON_URL") == null) {
                httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
                s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in local");
            }
            else{
                s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for local but not enabled");
            }
        }

        else if (proxyUsage == ProxyUsage.enable_looper_only){
            if (System.getenv("HUDSON_URL") != null && System.getenv("HUDSON_URL").contains("walmart.com")) {
                httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
                s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in looper");
            }
            else{
                s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for looper but not enabled");
            }
        }

        if(params!=null)
            httpRequest.params(params);
        Response response=	httpRequest.request("GET");
        if(!Thread.currentThread().getStackTrace()[2].getMethodName().equalsIgnoreCase("getRecipeDetail"))
            s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName()+"GET Respone {} :"+response.asString());
        addCookie(response);
        threadResHeaders.put((int)Thread.currentThread().getId(), response.getHeaders());
        return response;
    }


}
