package com.asda.qa.utility;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RoundNumberUtility {
	private static final Logger s_logger = LoggerFactory.getLogger(RoundNumberUtility.class);

	/**
	 * Round the number to given decimal places and return the number.
	 * 
	 * @param numberText
	 * @param decimalPlaces
	 * @return
	 */
	public static String roundNumber(String numberText, String decimalPlaces) {
		BigDecimal number = getAsBigDecimal(numberText);
		BigDecimal decimals = getAsBigDecimal(decimalPlaces);
		s_logger.info("Number: {} Decimal Places: {}", number, decimals);

		BigDecimal output = roundNumber(number, decimals);

		// Output
		s_logger.info("Rounded Number: " + output);
		return output.toString();
	}

	private static BigDecimal roundNumber(BigDecimal number, BigDecimal decimals) {
		try {
			double modifier = Math.pow(10.0, decimals.doubleValue());
			double result = Math.round(number.doubleValue() * modifier) / modifier;
			BigDecimal output = new BigDecimal(String.valueOf(result));
			return output;
		} catch (ArithmeticException e) {
			throw new ArithmeticException("ConversionError:" + e.getMessage());
		}
	}

	private static BigDecimal getAsBigDecimal(String numberText) {
		try {
			return new BigDecimal(numberText);
		} catch (NumberFormatException e) {
			throw new NumberFormatException("InvalidData" + e.getMessage());
		}
	}
}
