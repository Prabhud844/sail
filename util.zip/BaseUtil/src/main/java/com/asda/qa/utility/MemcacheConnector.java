package com.asda.qa.utility;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.whalin.MemCached.MemCachedClient;
import com.whalin.MemCached.SockIOPool;

public class MemcacheConnector {
	private static String memcacheServer = "meghacache-319419806-1-384061230.qa.customer-shoppinglist-qa.ms-df-cache.cdcstg2.prod.walmart.com";
	private static String memcachePort = "5000";
	private static final List<String> servers = new ArrayList<String>();
	private MemCachedClient mcc;
	private SockIOPool pool;
	private boolean isConnected = false;
	
	private static final Logger s_logger = LoggerFactory.getLogger(MemcacheConnector.class);
	
	public void connect(String server, String port) {
		if(server != null)
			memcacheServer = server;
		if(port != null)
			memcachePort = port;
		addServer(memcacheServer, memcachePort);
		pool = SockIOPool.getInstance("Test");
		pool.setServers(getServers());
		if(!pool.isInitialized()) {
			pool.setFailover( true );
			pool.setInitConn( 10 );
			pool.setMinConn( 5 );
			pool.setMaxConn( 250 );
			pool.setMaintSleep( 30 );
			pool.setNagle( false );
			pool.setSocketTO( 3000 );
			pool.setAliveCheck( true );
			pool.initialize();
		}
		
		mcc = new MemCachedClient("Test");
		isConnected = true;
		s_logger.info("MeghaCache Connected");
	}
	
	public String[] getServers() {
		String[] serverArr = new String[servers.size()];
		for(int i=0; i<servers.size(); i++) {
			serverArr[i] = servers.get(i);
		}
		return serverArr;
	}
	
	@SuppressWarnings("unchecked")
	public void addServer(String server, String port) {
		String con = server + ":" + port;
		servers.add(con);
	}
	
	public Object get(String key) {
		if(!isConnected)
			return "Megha Cache Not Connected";
		return mcc.get(key);
	}
	
	public boolean delete(String key) {
		s_logger.info("deleting : {}",key);
		if(!isConnected)
			return false;
		return mcc.delete(key);
	}
	
	public boolean flushAll() {
		if(!isConnected)
			return false;
		s_logger.info("Flushing started");
		return mcc.flushAll();
	}
	
	public void disconnnect() {
		pool.shutDown();
		s_logger.info("Connection Closed");
	}
}
