
package com.asda.qa.utility;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import com.asda.core.utils.FileReader;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

public class ExcelUtility{
	
	private final Logger s_logger  = LoggerFactory.getLogger(ExcelUtility.class);
	
	/**
	 * @param relativeExcelFile - The relative path to the excel file from current project directory.
	 * 
	 * Example: If your project name is ABC and your .xls file is in the directory com/walmart/qa/testfiles 
	 * then relativeExcelFile should be "com/walmart/qa/testfiles" 
	 * 
	 * Excel File format
	 * 
	 * <table border="1">
	 *	<tr ><td>keyword<td>          <td>           <td>         <td></tr>
	 *  <tr><td>       <td> data 1.1 <td> data 2.1  <td>         <td></tr>
	 *  <tr><td>       <td> data 1.2 <td> data 2.2  <td>         <td></tr>
	 *  <tr><td>       <td>          <td>           <td> keyword <td></tr>
	 * </table>
	 * 
	 * 
	 * @param sheetName - This represents the sheet name to be read from. 
	 * @param keyword - This represents the start/end keyword.
	 * 
	 * @return 2D data array
	 */

		public String[][] getTableArray(String relativeExcelFile, String sheetName, String keyword){
		      String[][] tabArray=null;
		      try{
		    	  
		    	  InputStream io = FileReader.getInstance().readInputStreamFromClassPath(relativeExcelFile);
		    	  Workbook workbook = Workbook.getWorkbook(io);
		    	  Sheet sheet = workbook.getSheet(sheetName);          
		          int startRow,startCol, endRow, endCol,ci,cj;          
		          Cell tableStart=sheet.findCell(keyword);
		          startRow=tableStart.getRow();
		          startCol=tableStart.getColumn();
		          Cell tableEnd= sheet.findCell(keyword, startCol+1,startRow+1, 100, 64000,  false);                               

		          endRow=tableEnd.getRow();
		          endCol=tableEnd.getColumn();
		         s_logger.info("startRow="+startRow+", endRow="+endRow+", " +
		                  "startCol="+startCol+", endCol="+endCol);
		          tabArray=new String[endRow-startRow-1][endCol-startCol-1];
		          ci=0;

		          for (int i=startRow+1;i<endRow;i++,ci++){
		              cj=0;
		              for (int j=startCol+1;j<endCol;j++,cj++){
		                  tabArray[ci][cj]=sheet.getCell(j,i).getContents();
		              }
		          }
		      }
		      catch (Exception e)    {
		    	  s_logger.error("error in getTableArray()"+e);
		    	  Assert.fail("Error reading excel file", e);
		      }
		      return(tabArray);
		  }
		
		/**
		 * @param relativeExcelFile - The relative path to the excel file from current project directory.
		 * 
		 * Example: If your project name is ABC and your .xls file is in the directory com/walmart/qa/testfiles 
		 * then relativeExcelFile should be "com/walmart/qa/testfiles"
		 * Excel File format
		 * 
		 * @param sheetName - This represents the sheet name to be read from. 
		 * @param startCell - Start Cell. Ex: "A1", "B5"
		 * @param endCell - End Cell. Ex: "D10", "F25" 
		 * 
		 * @return 2D data array
		 */
		
		public String[][] getTableArray(String relativeExcelFile, String sheetName, String startCell, String endCell){
		      String[][] tabArray=null;
		      try{
		    	  InputStream io = FileReader.getInstance().readInputStreamFromClassPath(relativeExcelFile);
		    	  Workbook workbook = Workbook.getWorkbook(io);
		    	  Sheet sheet = workbook.getSheet(sheetName);   
		    	  int startRow,startCol, endRow, endCol,ci,cj;          
		          Cell tableStart=sheet.getCell(startCell);
		          startRow=tableStart.getRow();
		          startCol=tableStart.getColumn();
		          Cell tableEnd= sheet.getCell(endCell);                              
		          endRow=tableEnd.getRow();
		          endCol=tableEnd.getColumn();
		          s_logger.info("startRow="+startRow+", endRow="+endRow+", " +
		                  "startCol="+startCol+", endCol="+endCol);
		          tabArray=new String[endRow-startRow+1][endCol-startCol+1];
		          ci=0;

		          for (int i=startRow;i<=endRow;i++,ci++){
		              cj=0;
		              for (int j=startCol;j<=endCol;j++,cj++){
		                  tabArray[ci][cj]=sheet.getCell(j,i).getContents();
		              }
		          }
		      }
		      catch (Exception e)    {
		    	  s_logger.error("error in getTableArray()"+e);
		    	  Assert.fail("Error reading excel file", e);
		      }
		      return(tabArray);
		  }
		
		/**
		 * @param relativeExcelFile - The relative path to the excel file from current project directory.
		 * 
		 * Example: If your project name is ABC and your .xls/.xlsx file is in the directory com/walmart/qa/testfiles
		 * then relativeExcelFile should be "com/walmart/qa/testfiles"
		 *
		 * 
		 * @param sheetName - This represents the sheet name to be read from. 
		 * @param appendData - This represents the boolean parameter to retain the existing value in the column
		 * @param keepHeaders - This represents the boolean parameter to retain the existing value in the column 
		 * @param tabArray - This is 2 D array to parse the data to excel
		 * 
		 * @return void
		 */
		public void writeTableArray(String relativeExcelFile, String sheetName, boolean appendData, boolean keepHeaders, String[][] tabArray) throws IOException{
			
			HSSFWorkbook hssfWorkbook;
			XSSFWorkbook xssfWorkbook;
			FileOutputStream fileOut = null ;
			InputStream io = FileReader.getInstance().readInputStreamFromClassPath(relativeExcelFile);
			try{
				int lastRow,ci,cj; 
		    	  	if(relativeExcelFile.endsWith("xls")) {
		    	  		hssfWorkbook = new HSSFWorkbook(io);
		    	  		HSSFSheet sheet;
		    	  		if(!(null==hssfWorkbook.getSheet(sheetName)))
		    	  			sheet = hssfWorkbook.getSheet(sheetName);
			    	  	else
			    	  		sheet = hssfWorkbook.createSheet(sheetName);
		    	  		
		    	  		if(appendData) 
		    	  			lastRow = sheet.getLastRowNum();
		    	  		else
		    	  		{
		    	  			int localLastRow = sheet.getLastRowNum();
		    	  			if(!keepHeaders) {
		    	  				HSSFRow row = sheet.getRow(0);
		    	  				sheet.removeRow(row);
		    	  			}
		    	  			for(int i=1;i<=localLastRow;i++) {
		    	  				HSSFRow row = sheet.getRow(i);
		    	  				sheet.removeRow(row);
		    	  			}
		    	  			lastRow=0;
		    	  		}
		    	  		
		    	  		for(ci=0;ci<tabArray.length;ci++) {
		    	  			HSSFRow row = sheet.createRow(++lastRow);
		    	  			for(cj=0;cj<tabArray[ci].length;cj++) {
		    	  				HSSFCell cell = row.createCell(cj);
		    	  				cell.setCellValue(tabArray[ci][cj]);
		    	  			}
		    	  		}
		    	  		fileOut = FileWriterLocal.getInstance().readFileOutputStreamFromClassPath(relativeExcelFile);
		    	  		hssfWorkbook.write(fileOut);
		    	  	}
		    	  	else if(relativeExcelFile.endsWith("xlsx")) {
		    	  		xssfWorkbook = new XSSFWorkbook(io);
		    	  		XSSFSheet sheet;
		    	  		if(!(null==xssfWorkbook.getSheet(sheetName)))
		    	  			sheet = xssfWorkbook.getSheet(sheetName);
			    	  	else
			    	  		sheet = xssfWorkbook.createSheet(sheetName);
		    	  		
		    	  		if(appendData) 
		    	  			lastRow = sheet.getLastRowNum();
		    	  		else
		    	  		{
		    	  			int localLastRow = sheet.getLastRowNum();
		    	  			if(!keepHeaders) {
		    	  				XSSFRow row = sheet.getRow(0);
		    	  				sheet.removeRow(row);
		    	  			}
		    	  			for(int i=1;i<=localLastRow;i++) {
		    	  				XSSFRow row = sheet.getRow(i);
		    	  				sheet.removeRow(row);
		    	  			}
		    	  			lastRow=0;
		    	  		}
		    	  		
		    	  		for(ci=0;ci<tabArray.length;ci++) {
		    	  			XSSFRow row = sheet.createRow(++lastRow);
		    	  			for(cj=0;cj<tabArray[ci].length;cj++) {
		    	  				XSSFCell cell = row.createCell(cj);
		    	  				cell.setCellValue(tabArray[ci][cj]);
		    	  			}
		    	  		}
		    	  		fileOut = FileWriterLocal.getInstance().readFileOutputStreamFromClassPath(relativeExcelFile);
		    	  		xssfWorkbook.write(fileOut);
		    	  	}
		    	  	else {
		    	  		s_logger.error("RelativeExcelFile "+relativeExcelFile+" is not a valid xls/xlsx file");
		    	  		Assert.fail("RelativeExcelFile "+relativeExcelFile+" is not a valid xls/xlsx file");
		    	  	}
		    	  
		      }
		      catch(Exception e) {
		    	  		s_logger.error("Unable to write the row", e);
					Assert.fail("Unable to write the row", e);
		      }
			finally {
				fileOut.flush();
	    			fileOut.close();
	    			io.close();
			}
	}
	public String[][] getTableArray(String relativeExcelFile, String sheetName){
		String[][] tabArray=null;
		try{
			InputStream io = FileReader.getInstance().readInputStreamFromClassPath(relativeExcelFile);
			Workbook workbook = Workbook.getWorkbook(io);
			Sheet sheet = workbook.getSheet(sheetName);
			int startRow,startCol, endRow, endCol,ci,cj;
			Cell tableStart=sheet.getCell(0, 1);
			int rows = sheet.getRows() - 1;
			int columns = sheet.getColumns();
			startRow=tableStart.getRow();
			startCol=tableStart.getColumn();
			Cell tableEnd= sheet.getCell(columns-1, rows);
			endRow=tableEnd.getRow();
			endCol=tableEnd.getColumn();
			s_logger.info("startRow="+startRow+", endRow="+endRow+", " +
					"startCol="+startCol+", endCol="+endCol);
			tabArray=new String[endRow-startRow+1][endCol-startCol+1];
			ci=0;

			for (int i=startRow;i<=endRow;i++,ci++){
				cj=0;
				for (int j=startCol;j<=endCol;j++,cj++){
					tabArray[ci][cj]=sheet.getCell(j,i).getContents();
				}
			}
		}
		catch (Exception e)    {
			s_logger.error("error in getTableArray()"+e);
			Assert.fail("Error reading excel file", e);
		}
		return(tabArray);
	}
}