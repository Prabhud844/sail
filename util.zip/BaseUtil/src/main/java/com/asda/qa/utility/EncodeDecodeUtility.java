package com.asda.qa.utility;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;

/**
 * @author i0kumar
 *
 */
/**
 * @author i0kumar
 *
 */
public class EncodeDecodeUtility {
	
	private static final Logger s_logger  = LoggerFactory.getLogger(EncodeDecodeUtility.class);
	
	/**
	 * This method will encode input string using Base64 encoding.

	 * @param stringToEncode
	 * @return
	 */
	public static String encodeByBase64(String stringToEncode){
		s_logger.info("String to encode: " + stringToEncode);
		byte[] byteArray = null;
        byteArray = stringToEncode.getBytes(StandardCharsets.UTF_8);
        Base64 base64 = new Base64();
		String encodedString = base64.encode(byteArray).toString();
		s_logger.info("Encoded string: " + encodedString);
		return encodedString;
	}
	
	/**
	 * This method will encode on the basis of algorithm and key provided.

	 * @param unSignedData
	 * @param key
	 * @param algorithm
	 * @return
	 */
	public static String encodeByAlgorithm(String unSignedData, String key, String algorithm){
		s_logger.info("unSignedData: {} key: {} algorithm: {}", unSignedData, key, algorithm);
		// for example : algorithm = "HmacSHA256"

		try {
			SecretKeySpec signingKey = new SecretKeySpec(key.getBytes(),algorithm);
			// get an hmac_sha1 Mac instance and initialize with the signing key
			Mac mac = Mac.getInstance(algorithm);
			mac.init(signingKey);
			byte[] rawHmac = mac.doFinal(unSignedData.getBytes());
			String signedData = new String(Base64.encodeBase64(rawHmac));
			s_logger.info("signedData: " + signedData);
			return signedData;
		} catch (Exception e) {
			Assert.fail("Unable to encrypt data", e);
		}
		return null;// this should never happen.
	}


	/**
	 * This Method will decode Base64 encoded string.

	 * @param stringToDecode
	 * @return
	 */
	public static String decodeByBase64(String encodedString){
		s_logger.info("String to decode: " + encodedString);
		Base64 decoder = new Base64();
		byte[] byteArrayDecoded = null;
		byteArrayDecoded = decoder.decode(encodedString);
		String decodedString = new String(byteArrayDecoded);
		s_logger.info(" decoded string: " + decodedString);
		return decodedString;
	}

}
