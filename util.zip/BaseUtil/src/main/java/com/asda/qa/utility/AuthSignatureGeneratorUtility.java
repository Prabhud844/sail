package com.asda.qa.utility;

import org.apache.commons.codec.binary.Base64;

import java.io.ObjectStreamException;
import java.nio.charset.StandardCharsets;
import java.security.KeyRep;
import java.security.PrivateKey;
import java.security.Signature;
import java.util.*;

public class AuthSignatureGeneratorUtility {

	public static void main(String[] args) {
		AuthSignatureGeneratorUtility generator = new AuthSignatureGeneratorUtility();

        String consumerId = "ba40a766-5db0-4366-8341-5641f0a72c34";
        String priviateKeyVersion = "1";
        String privateKey = "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAM9vXZvq6oCp29XBGjue6x4qpptGxzD4m0gXao3H3syxtRMEbmT08oWjo5mfaOwc1uoZ3DWJxMvPbSQktjuqpyxEc85DAPVZMX7beTokREvBqFjpNcEClcXCe+qcF0FTAf5SdIms7QdPCeO2YCK3dR2inJoX9MhK9NJQQZBs+HDjAgMBAAECgYBNIOt9feuTy5Sh9hr68CwcG1+3fKmz27xhIdPMw/Rjx++8Enm5sBo89otuI4evw0ll4hevEHrMDWRXfA8GQH3HnIed6Gn1QfuEA0fV5uQL/rbU3ziTqD/zrRnbmSkAGCVfpxT+QRDgzJ0i8NdFnn8pUVI1RAVMwiLq4ssa6kmBgQJBAOpdGF7MMdHTU8UzLXF7z5AbXreMpniTdk6AlCS1CgTXpBAYvDHMxSi5ejBrxYbR6LYEKWHIb2nd1m2HHq90md8CQQDildguaz/KF1b4kMC8QnzWP55aiHbPumkzoSaHeM+VCqt7y9y2o4Q8L/nD30j1a3yxeZxZce2PZtuNca+KXpF9AkAe77kG0neFFhtJva6y+z/z6tj+668R3Y1RYYGsssUmzHxYr5swC7K+5HTvrVo+qLjKRhRcVwP1+pWSkbKIQKELAkAfmpDloJXsJSc/UklfuNJau9Llg8U2oiSMS/zoxmQFwNA8Wyn024fVMUfgFyPA/3YL9w9ktmxRJSKYbvPyE9CtAkAe0oQoEoev+MREgXtEOrw0G5m2Pf2fNZe9CkJ0R7lj6YeicRW+lpyhtGQOzdY4LlZneJ8yt2uhBNac4nXFZiYj";

        long intimestamp = System.currentTimeMillis();

        System.out.println("intimestamp: " + intimestamp);

        Map<String, String> map = new HashMap<>();
        map.put("WM_CONSUMER.ID", consumerId);
        map.put("WM_CONSUMER.INTIMESTAMP", Long.toString(intimestamp));
        map.put("WM_SEC.KEY_VERSION", priviateKeyVersion);

        String[] array = canonicalize(map);

        String data = null;

        try {
        	data = generator.generateSignature(privateKey, array[1]);
        } catch(Exception e) {

        }

        System.out.println("Signature: " + data);
	}

	public String generateSignature(String key, String stringToSign) throws Exception {
		Signature signatureInstance = Signature.getInstance("SHA256WithRSA");

        ServiceKeyRep keyRep = new ServiceKeyRep(KeyRep.Type.PRIVATE, "RSA", "PKCS#8", Base64.decodeBase64(key));

        PrivateKey resolvedPrivateKey = (PrivateKey) keyRep.readResolve();

        signatureInstance.initSign(resolvedPrivateKey);

        byte[] bytesToSign = stringToSign.getBytes(StandardCharsets.UTF_8);
        signatureInstance.update(bytesToSign);
        byte[] signatureBytes = signatureInstance.sign();

        String signatureString = Base64.encodeBase64String(signatureBytes);

        return signatureString;
    }

	protected static String[] canonicalize(Map<String, String> headersToSign) {
		StringBuffer canonicalizedStrBuffer=new StringBuffer();
		StringBuffer parameterNamesBuffer=new StringBuffer();
        Set<String> keySet=headersToSign.keySet();

        // Create sorted key set to enforce order on the key names
        SortedSet<String> sortedKeySet=new TreeSet<String>(keySet);
        for (String key :sortedKeySet) {
        	Object val=headersToSign.get(key);
            parameterNamesBuffer.append(key.trim()).append(";");
            canonicalizedStrBuffer.append(val.toString().trim()).append("\n");
        }
        
        return new String[] {parameterNamesBuffer.toString(), canonicalizedStrBuffer.toString()};
	}
        
	class ServiceKeyRep extends KeyRep	{
		private static final long serialVersionUID = -7213340660431987616L;

		public ServiceKeyRep(Type type, String algorithm, String format, byte[] encoded) {
			super(type, algorithm, format, encoded);
        }

        protected Object readResolve() throws ObjectStreamException {
        	return super.readResolve();
        }
	}
}


