package com.asda.qa.utility;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.HashMap;

import javax.sql.DataSource;

import org.apache.commons.dbcp.ConnectionFactory;
import org.apache.commons.dbcp.DriverManagerConnectionFactory;
import org.apache.commons.dbcp.PoolableConnectionFactory;
import org.apache.commons.dbcp.PoolingDataSource;
import org.apache.commons.pool.impl.GenericObjectPool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author Gourab Banerjee
 * 
 */

public class DBConnectionPoolLayer {
		
	private static GenericObjectPool gPool = null;
	private static final Logger s_logger = LoggerFactory.getLogger(DBConnectionPoolLayer.class);
	String JDBC_DRIVER;
	String DB_URL;
	String USERNAME;
	String PASSWORD;

	public DBConnectionPoolLayer(String JDBC_DRIVER_VAL, String DB_URL_VAL,String USER, String PASS) {
		this.JDBC_DRIVER = JDBC_DRIVER_VAL;
		this.DB_URL = DB_URL_VAL;
		this.USERNAME = USER;
		this.PASSWORD = PASS;
	}
		@SuppressWarnings("unused")
		public DataSource setUpPool(String JDBC_DRIVER,String JDBC_DB_URL,String JDBC_USER,String JDBC_PASS) throws Exception {
			Class.forName(JDBC_DRIVER);

			// Creates an Instance of GenericObjectPool That Holds Our Pool of Connections Object!
			gPool = new GenericObjectPool();
			gPool.setMaxActive(5);

			// Creates a ConnectionFactory Object Which Will Be Use by the Pool to Create the Connection Object!
			ConnectionFactory cf = new DriverManagerConnectionFactory(JDBC_DB_URL, JDBC_USER, JDBC_PASS);

			// Creates a PoolableConnectionFactory That Will Wraps the Connection Object Created by the ConnectionFactory to Add Object Pooling Functionality!
			PoolableConnectionFactory pcf = new PoolableConnectionFactory(cf, gPool, null, null, false, true);
			return new PoolingDataSource(gPool);
		}

		public GenericObjectPool getConnectionPool() {
			return gPool;
		}

		// This Method Is Used To Print The Connection Pool Status
		private void printDbStatus() {
			System.out.println("Max.: " + getConnectionPool().getMaxActive() + "; Active: " + getConnectionPool().getNumActive() + "; Idle: " + getConnectionPool().getNumIdle());
		}
		
		/**
		 * Return query result.
		 *
		 * @param Query the query
		 * @param flg the flg
		 * @return the array list
		 */
		public ArrayList<HashMap<String, Object>> returnQueryResult(String Query,boolean flg){
			ResultSet resultSet = null;
			Connection conn = null;
			PreparedStatement pstmt = null;
			int count=0;
			DBConnectionPoolLayer jdbcObj = new DBConnectionPoolLayer(JDBC_DRIVER,DB_URL,USERNAME,PASSWORD);
			
			s_logger.info("The query is : " + Query);
			ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
			
			try {
				DataSource dataSource = jdbcObj.setUpPool(JDBC_DRIVER,DB_URL,USERNAME,PASSWORD);
				jdbcObj.printDbStatus();
				System.out.println("=====Making A New Connection Object For Db Transaction=====");
				
				conn = dataSource.getConnection();
				jdbcObj.printDbStatus(); 
				
				pstmt = conn.prepareStatement(Query);
				if(flg)pstmt.setFetchSize(100000);
				resultSet = pstmt.executeQuery();
				
				ResultSetMetaData md = resultSet.getMetaData();
				int columnsCount = md.getColumnCount();

				System.out.println("column" + columnsCount );
				
				while (resultSet.next()){
					
					HashMap<String, Object> row = new HashMap<String, Object>(columnsCount);
				     for(int i=1; i<=columnsCount; ++i){           
				      row.put(md.getColumnName(i),resultSet.getObject(i));
				      
				     }
				     
				     list.add(row);
				     System.out.println(count++);
				 }
				
				System.out.println("=====Releasing Connection Object To Pool=====");
				System.out.println("List Value" + list );
				
				 	
					    
			} catch(Exception sqlException) {
				sqlException.printStackTrace();
			} finally {
				try {
					// Closing ResultSet Object
					if(resultSet != null) {
						resultSet.close();
					}
					// Closing PreparedStatement Object
					if(pstmt != null) {
						pstmt.close();
					}
					// Closing Connection Object
					if(conn != null) {
						conn.close();
					}
				} catch(Exception sqlException) {
					sqlException.printStackTrace();
				}
			}
			
			jdbcObj.printDbStatus();
			return list;
			
		}
		
		public ArrayList<HashMap<String, Object>> returnQueryResult(String Query){
			ResultSet resultSet = null;
			Connection conn = null;
			PreparedStatement pstmt = null;
			DBConnectionPoolLayer jdbcObj = new DBConnectionPoolLayer(JDBC_DRIVER,DB_URL,USERNAME,PASSWORD);
			s_logger.info("The query is : " + Query);
			ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
			
			try {
				DataSource dataSource = jdbcObj.setUpPool(JDBC_DRIVER,DB_URL,USERNAME,PASSWORD);
				jdbcObj.printDbStatus();
				System.out.println("=====Making A New Connection Object For Db Transaction=====");
				
				conn = dataSource.getConnection();
				jdbcObj.printDbStatus(); 
				
				pstmt = conn.prepareStatement(Query);
				resultSet = pstmt.executeQuery();
				ResultSetMetaData md = resultSet.getMetaData();
				int columnsCount = md.getColumnCount();
				
				while (resultSet.next()){
					 HashMap<String, Object> row = new HashMap<String, Object>(columnsCount);
				     for(int i=1; i<=columnsCount; ++i){           
				      row.put(md.getColumnName(i),resultSet.getObject(i));
				     }
				     list.add(row);
				     System.out.println("adding row count "+list.size());
				 }
				System.out.println("=====Releasing Connection Object To Pool=====");
					    
			} catch(Exception sqlException) {
				sqlException.printStackTrace();
			} finally {
				try {
					// Closing ResultSet Object
					if(resultSet != null) {
						resultSet.close();
					}
					// Closing PreparedStatement Object
					if(pstmt != null) {
						pstmt.close();
					}
					// Closing Connection Object
					if(conn != null) {
						conn.close();
					}
				} catch(Exception sqlException) {
					sqlException.printStackTrace();
				}
			}
			
			jdbcObj.printDbStatus();
			return list;
			
		}
		public boolean Update_Commit(String updateEtlControl) {
			
			boolean updateflag=false; 
			Connection conn = null;
			PreparedStatement pstmt = null;
			DBConnectionPoolLayer jdbcObj = new DBConnectionPoolLayer(JDBC_DRIVER,DB_URL,USERNAME,PASSWORD);
			s_logger.info("The query is : " + updateEtlControl);
			ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
			
			try {
				DataSource dataSource = jdbcObj.setUpPool(JDBC_DRIVER,DB_URL,USERNAME,PASSWORD);
				jdbcObj.printDbStatus();
				System.out.println("=====Making A New Connection Object For Db Transaction=====");
				
				conn = dataSource.getConnection();
				jdbcObj.printDbStatus(); 
				
				pstmt = conn.prepareStatement(updateEtlControl);
				pstmt.executeQuery();
				
				int count=pstmt.executeUpdate();
				
				if(count >0)
				{
					updateflag=true;
					conn.commit();
					s_logger.info("Update success");
				}
				
				else
				{
					s_logger.info("Update failed");
				}
				
				System.out.println("=====Releasing Connection Object To Pool=====");
					    
			} catch(Exception sqlException) {
				sqlException.printStackTrace();
			} finally {
				try {
					
					// Closing PreparedStatement Object
					if(pstmt != null) {
						pstmt.close();
					}
					// Closing Connection Object
					if(conn != null) {
						conn.close();
					}
				} catch(Exception sqlException) {
					sqlException.printStackTrace();
				}
			}
			
			jdbcObj.printDbStatus();
			
			return updateflag;
		}

		
}
