package com.asda.qa.utility;

import javax.mail.*;
import java.io.IOException;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class checkMail {

public static String getMail(String email, String password) {
	String link=null;
        Properties props = new Properties();
        props.setProperty("mail.store.protocol", "imaps");
//        props.setProperty("mail.debug", "true");
        props.setProperty("mail.imaps.host", "imap.gmail.com");
        props.setProperty("mail.imaps.user", email);
        props.setProperty("mail.imaps.password", password);
        props.setProperty("mail.imaps.port", "993");
        props.setProperty("mail.imaps.auth", "true");
        props.setProperty("mail.debug", "true");
        props.setProperty("mail.imaps.starttls.enable","true");
//        props.put("mail.store.protocol", "imaps");
//        props.put("mail.imaps.host", "imaps.gmail.com");
//
//        props.put("mail.imaps.ssl.enable", "true"); // Use SSL
//
//        props.put("mail.imaps.user", email);
//
//        props.put("mail.imaps.socketFactory", 993);
//
//        props.put("mail.imaps.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
//
//        props.put("mail.imaps.port", 993);
        try {
            Session session = Session.getInstance(props, null);
            Store store = session.getStore();
            store.connect("imap.gmail.com", email , password);
          //    store.connect("imap.yopmail.com", email);
            link=  getMailFromInbox(session,store);
            if(link==null)
            {
            	link=getMailFromSpam(session,store);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
		return link; 
   
    }

 public static String getMailFromInbox(Session session, Store store) throws MessagingException
 {    String url = null;
	 Folder emailFolder = store.getFolder("INBOX");
     javax.mail.Message message = null;
	try {
	
	
		emailFolder.open(Folder.READ_WRITE);

        // retrieve the messages from the folder in an array and print it
		 javax.mail.Message[]  messages = emailFolder.getMessages();
     System.out.println("messages.length---" + messages.length);
     for (int i = 0; i < messages.length; i++) {
          message =  messages[i];
        System.out.println("---------------------------------");
        System.out.println("Email Number " + (i + 1));
        System.out.println("Subject: " + message.getSubject());
        System.out.println("From: " + message.getFrom()[0]);

        String subject = message.getSubject();
        if (subject.contains("Password reset code")) {
        	
        	 Multipart mp;
        		
     		mp = (Multipart) message.getContent();
     	
          BodyPart bp = mp.getBodyPart(0);
          
          Pattern p = Pattern.compile("<span style=\"(.*?)\">(.+?)</span>");
          Matcher m = p.matcher(bp.getContent().toString());
          System.out.println("Number of mails = " + messages.length);
         	
                         
          while (m.find()) {
        	  String regex = "\\D*\\d{6}\\D*";
              url = m.group(2); 
              if(url.contains(regex))
             		 {
            	     System.out.println("Marked DELETE for message: " + message.getSubject());
            	     message.setFlag(Flags.Flag.DELETED, true);
             	 		break;
             		 }
              System.out.println("Marked DELETE for message: " + message.getSubject());
              message.setFlag(Flags.Flag.DELETED, true);
          }
        	
        	
         
        } 
     }
//     System.out.println("Marked DELETE for message: " + message.getSubject());
//     message.setFlag(Flags.Flag.DELETED, true);
//     
     emailFolder.close(true);
     store.close();
     

  } catch (NoSuchProviderException e) {
	     emailFolder.close(true);
	     store.close();
	     return url;
  } catch (MessagingException e) {
	     emailFolder.close(true);
	     store.close();
	     return url;
  } catch (IOException io) {
	     emailFolder.close(true);
	     store.close();
	     return url;
  }
	return url;
 }
 
 public static String getMailFromSpam(Session session, Store store) throws MessagingException
 {    String url = null;
	 Folder emailFolder = store.getFolder("[Gmail]/Spam");
     javax.mail.Message message = null;
	try {
	
	
		emailFolder.open(Folder.READ_WRITE);

        // retrieve the messages from the folder in an array and print it
		 javax.mail.Message[]  messages = emailFolder.getMessages();
     System.out.println("messages.length---" + messages.length);
     for (int i = 0; i < messages.length; i++) {
          message =  messages[i];
        System.out.println("---------------------------------");
        System.out.println("Email Number " + (i + 1));
        System.out.println("Subject: " + message.getSubject());
        System.out.println("From: " + message.getFrom()[0]);

        String subject = message.getSubject();
        if (subject.contains("Password reset code")) {
        	
        	 Multipart mp;
        		
     		mp = (Multipart) message.getContent();
     	
          BodyPart bp = mp.getBodyPart(0);
          
          Pattern p = Pattern.compile("<span style=\"(.*?)\">(.+?)</span>");
          Matcher m = p.matcher(bp.getContent().toString());
          System.out.println("Number of mails = " + messages.length);
         	
                         
          while (m.find()) {
        	  String regex = "\\D*\\d{6}\\D*";
              url = m.group(2); 
              if(url.contains(regex))
             		 {
            	     System.out.println("Marked DELETE for message: " + message.getSubject());
            	     message.setFlag(Flags.Flag.DELETED, true);
             	 		break;
             		 }
              System.out.println("Marked DELETE for message: " + message.getSubject());
              message.setFlag(Flags.Flag.DELETED, true);
          }
        	
        	
         
        } 
     }
//     System.out.println("Marked DELETE for message: " + message.getSubject());
//     message.setFlag(Flags.Flag.DELETED, true);
//     
     emailFolder.close(true);
     store.close();
     

  } catch (NoSuchProviderException e) {
	     emailFolder.close(true);
	     store.close();
	     return url;
  } catch (MessagingException e) {
	     emailFolder.close(true);
	     store.close();
	     return url;
  } catch (IOException io) {
	     emailFolder.close(true);
	     store.close();
	     return url;
  }
	return url;
 }
}