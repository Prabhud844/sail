package com.asda.qa.utility;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import com.asda.core.utils.FileReader;

/**
 * Reads file from given path and returns string.
 * 
 * @author b0g00cf
 */
public class FileWriterLocal {
	
private static final Logger s_logger = LoggerFactory.getLogger(FileReader.class);
	
	private static final FileWriterLocal s_instance = new FileWriterLocal();
	
	public static FileWriterLocal getInstance() {
		return s_instance;
	}

	/**
	 * Reads a resource file from class path and returns the content as FileOutputStream.
	 * 
	 * @param path
	 * @return
	 */
	public FileOutputStream readFileOutputStreamFromClassPath(String path) {
		FileOutputStream st= null;
		try {
			st = new FileOutputStream(new File(getClass().getClassLoader().getResource(path).getPath()).getCanonicalPath());
		} catch (IOException e) {
			s_logger.error("File not found:", e);
			Assert.fail("Error reading file", e);
		}
		Assert.assertNotNull(st, "File not found: " + path);
		return st;
	}
}
