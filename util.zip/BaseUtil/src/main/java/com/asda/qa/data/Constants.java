package com.asda.qa.data;

public class Constants {
    public static final String CSV_TO_HTML_START = "<html>\n" +
            "<head>\n" +
            "    <style type=\"text/css\">\n" +
            "    table.darkTable {\n" +
            "  font-family: \"Courier New\", Courier, monospace;\n" +
            "  border: 2px solid #383838;\n" +
            "  background-color: #FFFFFF;\n" +
            "  width: 100%;\n" +
            "  height: 20px;\n" +
            "  text-align: left;\n" +
            "  border-collapse: collapse;\n" +
            "}\n" +
            "table.darkTable td, table.darkTable th {\n" +
            "  border: 1px solid #4A4A4A;\n" +
            "  padding: 3px 2px;\n" +
            "}\n" +
            "table.darkTable tbody td {\n" +
            "  font-size: 13px;\n" +
            "}\n" +
            "table.darkTable tr:nth-child(even) {\n" +
            "  background: #FBFCCA;\n" +
            "}\n" +
            "table.darkTable thead {\n" +
            "  background: #777777;\n" +
            "}\n" +
            "table.darkTable thead th {\n" +
            "  font-size: 16px;\n" +
            "  font-weight: bold;\n" +
            "  color: #E6E6E6;\n" +
            "  text-align: left;\n" +
            "  border-left: 2px solid #4A4A4A;\n" +
            "}\n" +
            "table.darkTable thead th:first-child {\n" +
            "  border-left: none;\n" +
            "}\n" +
            "\n" +
            "table.darkTable tfoot td {\n" +
            "  font-size: 12px;\n" +
            "}\n" +
            "    </style>\n" +
            "</head>\n" +
            "<body>\n" +
            "    <table class=\"darkTable\">\n" +
            "<thead>\n" +
            "<tr>";
    public static final String CSV_TO_HTML_CLOSURE = "</tbody>\n" +
            "</tr>\n" +
            "</table>\n" +
            "</body>\n" +
            "</html>";
    public static final String CSV_TO_HTML_TABLE_HEADING = "<th><<col_name>></th>\n";
    public static final String CSV_TO_HTML_TABLE_STITCH = "</tr>\n" +
            "</thead>\n" +
            "<tbody>";
    public static final String CSV_TO_HTML_TABLE_CONTENT = "<tr>\n" +
            "<td>cell1_1</td><td>cell2_1</td><td>cell3_1</td><td>cell4_1</td><td>cell5_1</td><td>cell6_1</td></tr>\n" +
            "<tr>";

    public static final String COVERAGE_EACH_PANEL_HTML_CODE = "\n\n<div class=\"<<class_name>>\" id=\"row<<row_num>>\"><a class=\"testname<<row_num>>\" href=\"#row<<row_num>>\"> <i class='far fa-file-alt' style='padding-right: 5px;'></i>  <<testcase_name>> </a>\n" +
            "\t\t\t\t<div class=\"content\">\n" +
            "\t\t\t\t\t<div class=\"inner-content\">\n" +
            "\t\t\t\t\t\t<h3> <<testcase_name>>  </h3>\n" +
            "\t\t\t\t\t\t<table style=\"border-left: 1px solid black;\">\n" +
            "\t\t\t\t\t\t\t<<put_your_row_here>>\n" +
            "\t\t\t\t\t\t</table>\n" +
            "\t\t\t\t\t</div>\n" +
            "\t\t\t\t</div>\n" +
            "\t\t\t</div>\n\n\n";

    public static final String COVERAGE_HTML_FRAME_MAIN = "<!DOCTYPE html>\n" +
            "<html lang=\"en\">\n" +
            "\n" +
            "<head>\n" +
            "\t<meta charset=\"UTF-8\" />\n" +
            "\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n" +
            "\t<meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\" />\n" +
            "\t<script src='https://kit.fontawesome.com/a076d05399.js'></script> \n" +
            "<style>"+
            "* {\n" +
            "  margin: 0;\n" +
            "  padding: 0;\n" +
            "  font-family: sans-serif;\n" +
            "  list-style: none;\n" +
            "  text-decoration: none;\n" +
            "}\n" +
            "\n" +
            ".heading p {\n" +
            "  width: 100%;\n" +
            "  height: 0%;\n" +
            "  font-weight: 500;\n" +
            "  color: #fff;\n" +
            "  font-family: inherit;\n" +
            "  font-size: 1.9375rem;\n" +
            "  padding-bottom: 20px;\n" +
            "  padding-top: 20px;\n" +
            "  margin: 0 auto;\n" +
            "  background: #333;\n" +
            "  text-align: center;\n" +
            "}\n" +
            "\n" +
            ".heading {\n" +
            "  background: #333;\n" +
            "  padding-bottom: 10px;\n" +
            "  box-shadow: 10px 10px 5px 0px rgba(0, 0, 0, 0.75);\n" +
            "}\n" +
            "\n" +
            ".heading tr {\n" +
            "  width: 100%;\n" +
            "  height: 0%;\n" +
            "  color: #fff;\n" +
            "  font-size: 0.9375rem;\n" +
            "  margin: 0 auto;\n" +
            "  align-content: center;\n" +
            "}\n" +
            "\n" +
            "body {\n" +
            "  font-size: 14px;\n" +
            "  display: flex;\n" +
            "  justify-content: center;\n" +
            "  align-items: center;\n" +
            "  height: auto;\n" +
            "  background: #444;\n" +
            "  line-height: 1.6;\n" +
            "}\n" +
            "\n" +
            ".collapse-content {\n" +
            "  width: 80vw;\n" +
            "  margin: auto;\n" +
            "  box-shadow: 10px 10px 5px 0px rgba(0, 0, 0, 0.75);\n" +
            "}\n" +
            "\n" +
            ".collapse {\n" +
            "  background: #fff;\n" +
            "}\n" +
            "\n" +
            ".collapse a {\n" +
            "  display: block;\n" +
            "  font-size: 1rem;\n" +
            "  font-weight: 500;\n" +
            "  padding: 0.9rem 1.8rem;\n" +
            "  color: #fff;\n" +
            "  position: relative;\n" +
            "  background: #00cda9;\n" +
            "}\n" +
            "\n" +
            ".collapse a:before {\n" +
            "  content: \"\";\n" +
            "  border-top: 7px solid #fff;\n" +
            "  border-left: 7px solid transparent;\n" +
            "  border-right: 7px solid transparent;\n" +
            "  position: absolute;\n" +
            "  top: 25px;\n" +
            "  right: 30px;\n" +
            "}\n" +
            "\n" +
            ".collapse_failed {\n" +
            "  background: #fff;\n" +
            "}\n" +
            "\n" +
            ".collapse_failed a {\n" +
            "  display: block;\n" +
            "  font-size: 1rem;\n" +
            "  font-weight: 500;\n" +
            "  padding: 0.9rem 1.8rem;\n" +
            "  color: #fff;\n" +
            "  position: relative;\n" +
            "  background: #ee624f;\n" +
            "}\n" +
            "\n" +
            ".collapse_failed a:before {\n" +
            "  content: \"\";\n" +
            "  border-top: 7px solid #fff;\n" +
            "  border-left: 7px solid transparent;\n" +
            "  border-right: 7px solid transparent;\n" +
            "  position: absolute;\n" +
            "  top: 25px;\n" +
            "  right: 30px;\n" +
            "}\n" +
            "\n" +
            ".collapse_failed + .collapse_failed a {\n" +
            "  border-top: 1px solid rgba(255, 255, 255, 0.7);\n" +
            "}\n" +
            "\n" +
            ".collapse_failed:target .content {\n" +
            "  max-height: 15em;\n" +
            "}\n" +
            "\n" +
            ".collapse_failed:target a:before {\n" +
            "  transform: rotate(-90deg);\n" +
            "}\n" +
            "\n" +
            ".inner-content {\n" +
            "  padding: 1.8rem;\n" +
            "}\n" +
            "\n" +
            ".inner-content td {\n" +
            "}\n" +
            "\n" +
            ".content {\n" +
            "  max-height: 0em;\n" +
            "  transition: 0.3s linear 0s;\n" +
            "  overflow: scroll;\n" +
            "}\n" +
            "\n" +
            ".collapse + .collapse a {\n" +
            "  border-top: 1px solid rgba(255, 255, 255, 0.7);\n" +
            "}\n" +
            "\n" +
            "h3 {\n" +
            "  margin-bottom: 15px;\n" +
            "}\n" +
            "\n" +
            "td {\n" +
            "  padding-left: 20px;\n" +
            "}\n" +
            "\n" +
            ".collapse:target .content {\n" +
            "  max-height: 15em;\n" +
            "}\n" +
            "\n" +
            ".collapse:target a:before {\n" +
            "  transform: rotate(-90deg);\n" +
            "}\n" +
            "\n" +
            "@media (max-width: 768px) {\n" +
            "  .collapse-content {\n" +
            "    width: 80vw;\n" +
            "    margin: auto;\n" +
            "    box-shadow: 10px 10px 5px 0px rgba(0, 0, 0, 0.75);\n" +
            "  }\n" +
            "}\n" +
            "@media (max-width: 425px) {\n" +
            "  body {\n" +
            "    line-height: 1.3;\n" +
            "  }\n" +
            "  .collapse-content {\n" +
            "    width: 80vw;\n" +
            "  }\n" +
            "  .inner-content {\n" +
            "    padding: 1.2rem;\n" +
            "  }\n" +
            "  .inner-content h3 {\n" +
            "    margin-bottom: 0.3rem;\n" +
            "  }\n" +
            "}\n" +
            "@media (max-width: 320px) {\n" +
            "  body {\n" +
            "    line-height: 1.3;\n" +
            "  }\n" +
            "  .collapse-content {\n" +
            "    width: 80vw;\n" +
            "  }\n" +
            "  .inner-content {\n" +
            "    padding: 0.8rem;\n" +
            "  }\n" +
            "  .inner-content h3 {\n" +
            "    margin-bottom: 0.3rem;\n" +
            "  }\n" +
            "}\n" +
            "</style>"+
            "\t<title> Test Report - Regression </title>\n" +
            "</head>\n" +
            "\n" +
            "<body>\n" +
            "\t<div>\n" +
            "\t\t<div class=\"heading\" align=\"Center\">\n" +
            "\t\t\t<p> Automation Regression Run Test Report </p>\n" +
            "\t\t\t<table style=\"border-left: 1px solid white;\">\n" +
            "\t\t\t\t<tbody>\n" +
            "\t\t\t\t\t<tr>\n" +
            "\t\t\t\t\t\t<td>Squad</td>\n" +
            "\t\t\t\t\t\t<td><<SQUAD_NAME>></td>\n" +
            "\t\t\t\t\t</tr>\n" +
            "\t\t\t\t\t<tr>\n" +
            "\t\t\t\t\t\t<td>Suit Name</td>\n" +
            "\t\t\t\t\t\t<td><<SUIT_NAME>></td>\n" +
            "\t\t\t\t\t</tr>\n" +
            "\t\t\t\t\t<tr>\n" +
            "\t\t\t\t\t\t<td>Run Environment</td>\n" +
            "\t\t\t\t\t\t<td><<TEST_ENV>></td>\n" +
            "\t\t\t\t\t</tr>\n" +
            "\t\t\t\t\t<tr>\n" +
            "\t\t\t\t\t\t<td>Execution Duration</td>\n" +
            "\t\t\t\t\t\t<td><<EXE_DURATION>></td>\n" +
            "\t\t\t\t\t</tr>\n" +
            "\t\t\t\t\t<tr>\n" +
            "\t\t\t\t\t\t<td>Total Number of Testcases</td>\n" +
            "\t\t\t\t\t\t<td><<TOTAL_NO_TCs>></td>\n" +
            "\t\t\t\t\t</tr>\n" +
            "\t\t\t\t</tbody>\n" +
            "\t\t\t</table>\n" +
            "\t\t</div>\n" +
            "\t\t<div class=\"collapse-content\">\n" +
            "\n" +
            "\n" +
            "\t\t\t<<ADD_YOUR_DIV_PANEL_HERE>>\n" +
            "\n" +
            "\t\t</div>\n" +
            "\t</div>\n" +
            "</body>\n" +
            "</html>";

    public static final String COVERAGE_HTML_REPORT_CSS_TEMPLATE = "* {\n" +
            "  margin: 0;\n" +
            "  padding: 0;\n" +
            "  font-family: sans-serif;\n" +
            "  list-style: none;\n" +
            "  text-decoration: none;\n" +
            "}\n" +
            "\n" +
            ".heading p{\n" +
            "  width: 100%;\n" +
            "  height: 0%;\n" +
            "  font-weight: 500;\n" +
            "  color: #FFF;\n" +
            "  font-family: inherit;\n" +
            "  font-size: 1.9375rem;\n" +
            "  padding-bottom: 20px;\n" +
            "  padding-top: 20px;  \n" +
            "  margin: 0 auto;\n" +
            "  background: #333;\n" +
            "  text-align: center;\n" +
            "}\n" +
            "\n" +
            ".heading{\n" +
            "  background: #333;\n" +
            "  padding-bottom: 10px; \n" +
            "  box-shadow: 10px 10px 5px 0px rgba(0, 0, 0, 0.75); \n" +
            "}\n" +
            "\n" +
            ".heading tr{\n" +
            "  width: 100%;\n" +
            "  height: 0%;\n" +
            "  color: #FFF;\n" +
            "  font-size: 0.9375rem;\n" +
            "  margin: 0 auto;\n" +
            "  align-content: center;\n" +
            "}\n" +
            "\n" +
            "body {\n" +
            "  font-size: 14px;\n" +
            "  display: flex;\n" +
            "  justify-content: center;\n" +
            "  align-items: center;\n" +
            "  height: auto;\n" +
            "  background: #444;\n" +
            "  line-height: 1.6;\n" +
            "}\n" +
            "\n" +
            ".collapse-content {\n" +
            "  width: 80vw;\n" +
            "  margin: auto;\n" +
            "  box-shadow: 10px 10px 5px 0px rgba(0, 0, 0, 0.75);\n" +
            "}\n" +
            "\n" +
            ".collapse {\n" +
            "  background: #fff;\n" +
            "}\n" +
            "\n" +
            ".collapse a {\n" +
            "  display: block;\n" +
            "  font-size: 1rem;\n" +
            "  font-weight: 500;\n" +
            "  padding: 0.9rem 1.8rem;\n" +
            "  color: #fff;\n" +
            "  position: relative;\n" +
            "  background: #00cda9;\n" +
            "}\n" +
            "\n" +
            ".collapse a:before {\n" +
            "  content: \"\";\n" +
            "  border-top: 7px solid #fff;\n" +
            "  border-left: 7px solid transparent;\n" +
            "  border-right: 7px solid transparent;\n" +
            "  position: absolute;\n" +
            "  top: 25px;\n" +
            "  right: 30px;\n" +
            "}\n" +
            "\n" +
            ".inner-content {\n" +
            "  padding: 1.8rem;\n" +
            "}\n" +
            "\n" +
            ".inner-content td{\n" +
            "  \n" +
            "}\n" +
            "\n" +
            ".content {\n" +
            "  max-height: 0em;\n" +
            "  transition: 0.3s linear 0s;\n" +
            "  overflow: scroll;\n" +
            "}\n" +
            "\n" +
            ".collapse + .collapse a {\n" +
            "  border-top: 1px solid rgba(255, 255, 255, 0.7);\n" +
            "}\n" +
            "\n" +
            "h3 {\n" +
            "  margin-bottom: 15px;\n" +
            "}\n" +
            "\n" +
            "td{\n" +
            "  padding-left: 20px;\n" +
            "}\n" +
            "\n" +
            ".collapse:target .content {\n" +
            "  max-height: 15em;\n" +
            "}\n" +
            "\n" +
            ".collapse:target a:before {\n" +
            "  transform: rotate(-90deg);\n" +
            "}\n" +
            "\n" +
            "@media (max-width: 768px) {\n" +
            "  .collapse-content {\n" +
            "    width: 80vw;\n" +
            "    margin: auto;\n" +
            "    box-shadow: 10px 10px 5px 0px rgba(0, 0, 0, 0.75);\n" +
            "  }\n" +
            "}\n" +
            "@media (max-width: 425px) {\n" +
            "  body {\n" +
            "    line-height: 1.3;\n" +
            "  }\n" +
            "  .collapse-content {\n" +
            "    width: 80vw;\n" +
            "  }\n" +
            "  .inner-content {\n" +
            "    padding: 1.2rem;\n" +
            "  }\n" +
            "  .inner-content h3 {\n" +
            "    margin-bottom: 0.3rem;\n" +
            "  }\n" +
            "}\n" +
            "@media (max-width: 320px) {\n" +
            "  body {\n" +
            "    line-height: 1.3;\n" +
            "  }\n" +
            "  .collapse-content {\n" +
            "    width: 80vw;\n" +
            "  }\n" +
            "  .inner-content {\n" +
            "    padding: 0.8rem;\n" +
            "  }\n" +
            "  .inner-content h3 {\n" +
            "    margin-bottom: 0.3rem;\n" +
            "  }\n" +
            "}" +
            ".collapse_failed {\n" +
            "  background: #fff;\n" +
            "}\n" +
            "\n" +
            ".collapse_failed a {\n" +
            "  display: block;\n" +
            "  font-size: 1rem;\n" +
            "  font-weight: 500;\n" +
            "  padding: 0.9rem 1.8rem;\n" +
            "  color: #fff;\n" +
            "  position: relative;\n" +
            "  background: #ee624f;\n" +
            "}\n" +
            "\n" +
            "\n" +
            ".collapse_failed a:before {\n" +
            "  content: \"\";\n" +
            "  border-top: 7px solid #fff;\n" +
            "  border-left: 7px solid transparent;\n" +
            "  border-right: 7px solid transparent;\n" +
            "  position: absolute;\n" +
            "  top: 25px;\n" +
            "  right: 30px;\n" +
            "}\n" +
            "\n" +
            ".collapse_failed + .collapse_failed a {\n" +
            "  border-top: 1px solid rgba(255, 255, 255, 0.7);\n" +
            "}\n" +
            "\n" +
            ".collapse_failed:target .content {\n" +
            "  max-height: 15em;\n" +
            "}\n" +
            "\n" +
            ".collapse_failed:target a:before {\n" +
            "  transform: rotate(-90deg);\n" +
            "}" +
            "\n";
    public static final String JSON_COVERAGE_TEMPLATE =
            "{\n" +
                    "    \"functionAssertion\": [\n" +
                    "      {\n" +
                    "        \"variable\": \"NA\",\n" +
                    "        \"operator\": \"-\",\n" +
                    "        \"expectedValue\": \"NA\",\n" +
                    "        \"actualValue\": \"NA\",\n" +
                    "        \"assertionStatus\": \"<<step_status>>\",\n" +
                    "        \"functionName\": \"<<step_name>>\"\n" +
                    "      }],\n" +
                    "    \"functionStatus\": \"<<step_status>>\",\n" +
                    "    \"stepName\": \"<<step_name>>\"\n" +
                    "  } ";
}
