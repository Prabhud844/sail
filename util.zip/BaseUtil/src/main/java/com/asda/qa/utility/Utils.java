package com.asda.qa.utility;

import org.apache.commons.lang.RandomStringUtils;

import java.util.Iterator;
import java.util.List;

public class Utils {

    public enum SORT_ORDER {ASC, DESC}

    public String getRandomEmailId(int count)
    {
        return getRandomString(count)+"@sptest.com";

    }

    public String getRandomString(int count)
    {
        String AlphaString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"+"0123456789"
                + "abcdefghijklmnopqrstuvxyz";
        return RandomStringUtils.random(count,AlphaString) ;
    }

    public <T extends Comparable<? super T>> boolean isSorted(Iterable<T> iterable, SORT_ORDER sortorder) {
        Iterator<T> iter = iterable.iterator();
        if (!iter.hasNext()) {
            return true;
        }
        if(sortorder == SORT_ORDER.ASC){
            T t = iter.next();
            while (iter.hasNext()) {
                T t2 = iter.next();
                if (t.compareTo(t2) > 0) {
                    return false;
                }
                t = t2;
            }
        }else{
            T t = iter.next();
            while (iter.hasNext()) {
                T t2 = iter.next();
                if (t.compareTo(t2) < 0) {
                    return false;
                }
                t = t2;
            }
        }
        return true;
    }

    public <T> boolean isPartOfList(List<T> parent, List<T> child){
       if(null == parent && null == child) return true;
       if(null != parent && null != child) {
           if (parent.size() == 0 && parent.size() == child.size()) return true;
           if(parent.size() < child.size()) return false;
           for(T childValue : child){
               if(!parent.contains(childValue)) return false;
           }
           return true;
       }
       return false;
    }

}
