package com.asda.qa.utility;

import com.asda.core.baseexecution.BaseWebPage;
import com.asda.core.utils.MigrationUtil;
import com.asda.qa.environment.EnvironmentConfig;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Properties;

public class CacheFlush extends BaseWebPage {
	

	WebDriverWait wait = new WebDriverWait(driver, 30);
	private static final Logger s_logger = LoggerFactory.getLogger(CacheFlush.class);
	
	/*
	 * Class object declaration
	 */
	
	//*******************************Exployer*****************************//
	public enum Application {
	    ESTORE, CA, CSC, OFS
	}
	
	public enum Environment {
	    QA2, LQA2, QA3, QA4, QA5, PQA, LPQA, STAGEVM, STAGEAK
	}	
	
	@FindBy(name="userName")
	private WebElement ExployeruserNameField;

	@FindBy(name="password")
	private WebElement ExployerpasswordField;
	
	@FindBy(name="submit")
	private WebElement ExployerloginBtn;
	
	@FindBy(name="Invoke Method")
	private WebElement ExployerinvokeMethodBtn;
	
	
	@FindBy(name="component")
	private WebElement ExployercomponentTextBox;
	
	@FindBy(name="method")
	private WebElement ExployermethodTextBox;
	
	@FindBy(name="methodSubmit")
	private WebElement ExployerexecuteBtn;	
	
	@FindBy(linkText="Logout")
	private WebElement Exployerlogout;
	
	@FindBy(xpath="//input[@name='checkAll']")
	private WebElement ExployerallBtn;
	
	@FindBy(xpath="//input[@name='Invalidate Cache']")
	private WebElement ExployerinvalidateCacheBtn;
	
	@FindBy(xpath="//input[@name='flushSubmit']")
	private WebElement ExployerflushBtn;	
	
	@FindBy(xpath="html/body/form/div[2]/table/tbody/tr[4]/td/input")
	private WebElement exployerAkamailFlushBtn;

	@FindBy(xpath=".//*[@id='gradient-style']/tbody[1]/tr/td[2]")
	private WebElement successMsg; 
	@FindBy(xpath=".//*[@id='imageBoxList']/p")
	private WebElement clickToUtlities;

	@FindBy(xpath=".//*[@id='akamaiButton']")
	private WebElement akamaiButton;

	@FindBy(xpath=".//*[@id='ui-id-2']")
	private WebElement cpCode; 

	@FindBy(xpath=".//*[@id='searchField']")
	private WebElement searchbox;
	
	@FindBy(xpath="//input[@value='Search']")
	private WebElement searchclick;
	
	@FindBy(xpath = "//a[contains(text(),'Search')]")
	private WebElement clicksearchlink;
	
	@FindBy(xpath = "//td/a[contains(text(),'prepareSwitch')]")
	private WebElement prepareSwitch;
	
	@FindBy(xpath = "//td/a[contains(text(),'performSwitch')]")
	private WebElement performSwitch;
	
	@FindBy(xpath = "//input[@value='Invoke Method']")
	private WebElement invokemethod;
	
	@FindBy(xpath = "//h1[contains(text(),'Method')]")
	private WebElement invokesuccess;

	
	
	public CacheFlush(BaseWebPage page) {
		super(page);
		PageFactory.initElements(driver, this);
	}

	/*public void navigateToExplyerToolPage(String env){
		Properties props = new Properties();
		try {
			props.load(EnvironmentConfig.class.getClassLoader().getResourceAsStream("com/asda/qa/environment/"+env+"config.properties"));
		} catch (IOException e) {
			throw new RuntimeException("Unable intialize environment.", e);
		}
		driver.get(EnvironmentConfig.getInstance().getExployerURL());
	}*/
	
	public void login(String UserName, String Password) {
		
		ExployeruserNameField.sendKeys(UserName);
		ExployerpasswordField.sendKeys(Password);
		ExployerloginBtn.click();
	}
	
	public void selectEnvMenuAndApplication(String env,String application){
		s_logger.info("Select Env : "+env+" and application :"+application);
		s_logger.info("Mouse hover on Environment menu");
		String envMenu="//span[contains(text(),'"+env+"')]/..";
		MigrationUtil.unconditionalWait(2000);
		SeleniumWebDriverUtility.mouseOver(driver, envMenu);
		s_logger.info("Step: Clicked env:"+env+" menu");
		int appPlaceHolder =0;
		switch(Environment.valueOf(env)){
		case QA2:
			appPlaceHolder = 1;
			break;
		 case LQA2:
			 appPlaceHolder = 1;
             break;
		 case QA3:
			 appPlaceHolder = 2;
             break;
		 case QA4:
			 appPlaceHolder = 3;
             break;
		 case QA5:
			 appPlaceHolder = 4;
             break;
		case PQA:
			 appPlaceHolder = 5;
			break;
		 case LPQA:
			 appPlaceHolder = 6;
             break;
		case STAGEVM:
			appPlaceHolder = 7;
			break;
		case STAGEAK:
			appPlaceHolder = 8;
			break;	
		default:
			break;
		}
		// Select application for particular environment
		s_logger.info("Step: About to click application with xpath : "+"(//a[contains(text(),'"+application+"')])["+appPlaceHolder+"]");
		SeleniumWebDriverUtility.mouseOver(driver, envMenu);
		driver.findElement(By.xpath("(//a[contains(text(),'"+application+"')])["+appPlaceHolder+"]")).click();
		MigrationUtil.unconditionalWait(1000);			
	}
	
	public void executeSSR(String env){
		selectAllInstances();
		//Click invoke method
		ExployerinvokeMethodBtn.click();	
		ExployercomponentTextBox.sendKeys("/com/walmart/mtep/selfservice/SelfServiceRefundScheduler");
		ExployermethodTextBox.sendKeys("processRefundRequests");				
		ExployerexecuteBtn.click();
		MigrationUtil.unconditionalWait(2000);
		logout();
	}
	
	public void selectAllInstances(){
		MigrationUtil.unconditionalWait(4000);
		ExployerallBtn.click();

	}
	
	

	public void invalidateCache(String env,String application){
		s_logger.info("Executing step :selecting All Instances");
		selectAllInstances();
		s_logger.info("Executing step :Clicking on Invalidate Cache Button");
		ExployerinvalidateCacheBtn.click();
		MigrationUtil.unconditionalWait(5000);
		s_logger.info("Executing step :Clicking all for flushing");
		ExployerallBtn.click();
		s_logger.info("Executing step :Clicking on flushing button");
		ExployerflushBtn.click();
		MigrationUtil.unconditionalWait(6000);
		
	}
	
	public void logout(){
		Exployerlogout.click();
		s_logger.info("Step: Logout from Exployer tool");		
		MigrationUtil.unconditionalWait(5000);
	}
	
	public WebElement ExployerAssertionWebElement1(String InputStr){
		List<WebElement> ele= driver.findElements(By.xpath("//td/a[text()='" + InputStr + "']/parent::td/following-sibling::td[2]"));
		return ele.get(0);
	}
	
	public WebElement ExployerAssertionWebElement2(String InputStr){
		List<WebElement> ele= driver.findElements(By.xpath("//td/a[text()='" + InputStr + "']/parent::td/following-sibling::td[2]"));
		return ele.get(1);
	}
	
	public boolean isExployerAkamaiCacheSuccessful(){
		SeleniumWebDriverUtility.waitForPageLoad(driver);
		MigrationUtil.unconditionalWait(3000);
		return successMsg.isDisplayed();
		}

		public WebElement getExployerAkamaiCacheConfirmationMsg() {
		return successMsg;
		}

		public void exployerAkamaiFlush(String env){
		String addbutn1 = "//b[text()='L" + env + "']/parent::td/parent::tr/following-sibling::tr[1]/td[1]";
		WebElement addButn1 = driver.findElement(By.xpath(addbutn1));
		String addbutn2 = "//b[text()='L" + env + "']/parent::td/parent::tr/following-sibling::tr[2]/td[1]";
		WebElement addButn2 = driver.findElement(By.xpath(addbutn2));
		System.out.println("barnamala" + addbutn1 + addbutn2);
		s_logger.info("add the environment specific");
		JavascriptExecutor je = (JavascriptExecutor) driver;
		        je.executeScript("arguments[0].scrollIntoView(true);", addButn1,addButn2);
		addButn1.click();
		MigrationUtil.unconditionalWait(1000);
		addButn2.click();
		MigrationUtil.unconditionalWait(1000);
		exployerAkamailFlushBtn.click();
		}

		public void navigateToExployerAkamai(){
		s_logger.info("Navigate to utilities tab");
		clickToUtlities.click();
		s_logger.info("utilities tab clicked");
		MigrationUtil.unconditionalWait(1000);
		s_logger.info("click on Akamai Button from the list");
		akamaiButton.click();
		s_logger.info("Akamai Button clicked");
		MigrationUtil.unconditionalWait(1000);
		s_logger.info("click on CP code");
		cpCode.click();
		}
	//*******************************Exployer End*****************************//
	
	//*******************************Catalog Maintenance*****************************//
	
	@FindBy(xpath = "//*[@type='submit']")
	private WebElement StartProcess;

	@FindBy(xpath = "//*[@name='/atg/commerce/catalog/RunServiceFormHandler.repositoryPath']")
	private WebElement CatalogRepository;
	
	@FindBy(xpath = "html/body/blockquote[3]")
	private WebElement ExecutionLog;
	
	@FindBy(xpath = "//tbody/tr[3]/td[2]/a")
	private WebElement RefreshLink;
	
	@FindBy(xpath = "//tbody/tr[3]/td[2]")
	private WebElement FinishButton;
	
	@FindBy(xpath = "//table/tbody/tr[2]/td[2]")
	private WebElement StartTime;
	String Status;
	public void CatalogMaintenance()
	{
	MigrationUtil.unconditionalWait(3000);
	if (CatalogRepository.isDisplayed()) {
		s_logger.info("Catalog Maintanance Start Process button is displayed");
		StartProcess.click();
		MigrationUtil.unconditionalWait(3000);
	} else {
		s_logger.info("Catalog Maintanance page is not available");
	}	
}	
	public void loadSearchDynAdminComp() {
		
		String URL = EnvironmentConfig.getInstance().getSearchdynadmincompURL();
		s_logger.info("Search Dyn admin Component url = "+URL);
		driver.get(URL);
		MigrationUtil.unconditionalWait(5000);
		s_logger.info("Search Dyn admin Component url is loaded");
	}
	
	public void SearchDynAdminComp(String comp){
	//loadSearchDynAdminComp();
	MigrationUtil.unconditionalWait(1000);
	clicksearchlink.click();
        if (searchbox.isDisplayed()) {
		s_logger.info("Searching For the ATG Component");
		searchbox.click();
		searchbox.sendKeys(comp);
		//FluentWaitImplicit.waitForWebElementFluently30(driver,searchclick);
		MigrationUtil.unconditionalWait(1000);
		Actions action = new Actions(driver);
		action.sendKeys(Keys.ENTER);
		action.perform(); 
		MigrationUtil.unconditionalWait(1000);
		WebElement clkcomp = driver.findElement(By.xpath("//td/a[contains(text(),'"+comp+"')]"));
		if (clkcomp.isDisplayed()) {
			clkcomp.click();
		}
			else {
			s_logger.info("No ATG Components Found in the name :",comp);
			}
	} else {
		s_logger.info("DynAdmin Search page is not available");
	}	
}	
	public void PrepareInvokeMethod(){
		if (prepareSwitch.isDisplayed()) {
		Actions action = new Actions(driver);
		action.moveToElement(prepareSwitch);
		prepareSwitch.click();
		if (invokemethod.isDisplayed()) {
			FluentWaitImplicit.waitForWebElementFluently30(driver,invokemethod);
			invokemethod.click();
		} else{
			s_logger.info("Invoke Method not found for Prepare Switch");
		}

	} else {
		s_logger.info("Prepare Switch is missing");
	}	
}	
	public void PerformInvokeMethod(){
		if (prepareSwitch.isDisplayed()) {
		Actions action = new Actions(driver);
		action.moveToElement(performSwitch);
		performSwitch.click();
		if (invokemethod.isDisplayed()) {
			FluentWaitImplicit.waitForWebElementFluently30(driver,invokemethod);
			invokemethod.click();
		} else{
			s_logger.info("Invoke Method not found for Perform Switch");
		}

	} else {
		s_logger.info("Perform Switch is missing");
	}	
}	
	public void goBackToComp(String comp) {
		
		WebElement clkh1comp = driver.findElement(By.xpath("//h1/a[contains(text(),'"+comp+"')]"));
		if (clkh1comp.isDisplayed()) {
			FluentWaitImplicit.waitForWebElementFluently30(driver,clkh1comp);
			Actions action = new Actions(driver);
			action.moveToElement(clkh1comp);
			clkh1comp.click();
		}
	}
	public void initSectDataSourceName() {
		String sec ="DataSourceB";
		String cur ="DataSourceA";
		List<WebElement> secDS = driver.findElements(By.xpath("//td/span[contains(text(),'DataSourceB')]"));
		int seccnt = secDS.size();
		if (seccnt == 1) {
		s_logger.info("Secondary Data Srouce is :" +sec + " Current Data Source is :"+ cur);
			} else
				s_logger.info("Secondary Data Srouce is :" +cur + " Current Data Source is :"+ sec);
	}
	public boolean isInvokeMethodSucceed() {
		s_logger.info("Verifying Invoke Method is A Success");
		boolean resultFlag = false;
		try {
			resultFlag = invokesuccess.isDisplayed();
			s_logger.info("Invoke method is a Success");
		} catch (NoSuchElementException ignored) {
			resultFlag = false;
			s_logger.info("Invoke Method was not a Success");
		}
		return resultFlag;
	}
	public void ClickOnRefresh()
	{
	MigrationUtil.unconditionalWait(3000);
	if (RefreshLink.isDisplayed()) {
		s_logger.info("Refresh link is displayed");
		RefreshLink.click();
		MigrationUtil.unconditionalWait(20000);
	} else {
		s_logger.info("Refresh link is not available");
	}		
	int count = 0;
	do{		
		MigrationUtil.unconditionalWait(20000);
		driver.navigate().refresh();
		count++;
		Status=FinishButton.getText();		
		s_logger.info("Catalog Maintanance Status is " + Status);
	}while(Status.equalsIgnoreCase("still executing  Refresh Status"));
	if(count<2){
		s_logger.info("Catalog Maintanance Status is failed");
	}else{
		s_logger.info("Catalog Maintanance Status is Passed");
		s_logger.info("Catalog Maintanance Start time is : "+ StartTime.getText());
		s_logger.info("Catalog Maintanance End time is : "+ FinishButton.getText());		
	}	
	}
		

	public boolean isLastExecutionLogDisplayed() {
		s_logger.info("Verifying Last Execution log is displayed or not");
		boolean resultFlag = false;
		try {
			resultFlag = ExecutionLog.isDisplayed();
		} catch (NoSuchElementException ignored) {
			resultFlag = false;
		}
		return resultFlag;
	}
	
	public boolean isMaintenanceButtonDisplayed() {
		s_logger.info("Verifying Maintenance button is displayed or not");
		boolean resultFlag = false;
		try {
			resultFlag = StartProcess.isDisplayed();
		} catch (NoSuchElementException ignored) {
			resultFlag = false;
		}
		return resultFlag;
	}
	
	
	
	//*******************************Catalog Maintenance End*****************************//
	
	
	//*******************************Akamai Cache Flush*****************************//
	
	@FindBy(id="login")
	private WebElement RundeckuserNameField;
	
	@FindBy(id="password")
	private WebElement RundeckpasswordField;


	@FindBy(xpath="//button[@class='btn btn-primary']")
	private WebElement RundeckloginBtn;
	
	@FindBy(xpath="//a[@class='h3']")
	private WebElement RundeckASDA;
	
	@FindBy(linkText="LPQA")
	private WebElement RundeckLPQA;
	
	@FindBy(xpath="//*[@id='jobrow_1']/td/a")
	private WebElement RundeckAKAMAICACHEFLUSH;
	
	@FindBy(xpath="//input[contains(@class,'optionvalues')] ")
	private WebElement RundeckemailField;
	
	
	@FindBy(linkText="LQA2")
	private WebElement RundeckLQA2;
	
	@FindBy(xpath=".//*[@id='jobrow_5']/td/a")
	private WebElement RundeckAKAMAICACHEFLUSH2;
	
	@FindBy(xpath="//input[contains(@class,'optionvalues')] ")
	private WebElement RundeckemailField2;
	
	@FindBy(linkText="LQA3")
	private WebElement RundeckLQA3;
	
	@FindBy(xpath=".//*[@id='jobrow_4']/td/a")
	private WebElement RundeckAKAMAICACHEFLUSH3;
	
	@FindBy(xpath="//input[contains(@class,'optionvalues')] ")
	private WebElement RundeckemailField3;
	
	@FindBy(linkText="LQA4")
	private WebElement RundeckLQA4;
	
	@FindBy(xpath=".//*[@id='jobrow_3']/td/a")
	private WebElement RundeckAKAMAICACHEFLUSH4;
	
	@FindBy(xpath="//input[contains(@class,'optionvalues')] ")
	private WebElement RundeckemailField4;
	
	@FindBy(linkText="LQA5")
	private WebElement RundeckLQA5;
	
	@FindBy(xpath=".//*[@id='jobrow_2']/td/a")
	private WebElement RundeckAKAMAICACHEFLUSH5;
	
	@FindBy(xpath="//input[contains(@class,'optionvalues')] ")
	private WebElement RundeckemailField5;
	
	@FindBy(linkText="PROD")
	private WebElement RundeckPROD;
	
	@FindBy(xpath="//button[@id='execFormRunButton']")
	private WebElement RundeckrunJobBtn;
	
	@FindBy(xpath="//a[@class='dropdown-toggle']")
	private WebElement RundeckdevUser;
	
	@FindBy(xpath="//a[@title='Logout user: devuser']")
	private WebElement Rundecklogout;
	
	@FindBy(xpath="//*[@id='progressContainer2']/div[@role='progressbar']")
	private WebElement RundeckProgressbar;
	
	@FindBy(xpath="//div[@id='execution_main']/div[1]/div/div[1]/div[2]/div/div[2]")
	private WebElement RundeckSucceededMsg;
	
	@FindBy(xpath="//*[@id='execution_main']/div[1]/div/div[1]/div[2]/div/div[2]/div/span[1]")
	private WebElement ProgressMsg;
	
	Properties props = new Properties();
	
	 public void rundecklogIn() {
			String RundeckuserName =EnvironmentConfig.getInstance().getRundeckuserName();
			String Rundeckpass=EnvironmentConfig.getInstance().getRundeckPass();
			s_logger.info("Username: "+RundeckuserName   +"   Password :"+Rundeckpass);
			
			RundeckuserNameField.clear();
			RundeckuserNameField.sendKeys(RundeckuserName);
			MigrationUtil.unconditionalWait(1000);
			RundeckpasswordField.sendKeys(Rundeckpass);
			MigrationUtil.unconditionalWait(1000);
			RundeckloginBtn.click();		
	}	 
	  
	public void clickrundeckASDA(){
		RundeckASDA.click();
		MigrationUtil.unconditionalWait(1000);
		s_logger.info("Step: Click on ASDA hierarchy");				
		MigrationUtil.unconditionalWait(5000);  		
	}

	public void clickOnENV(String env){
		if(env.equalsIgnoreCase("Qa4"))
		{
		RundeckLQA4.click();
		MigrationUtil.unconditionalWait(1000);
		RundeckAKAMAICACHEFLUSH4.click();
		}else
		if(env.equalsIgnoreCase("Qa5")){
		RundeckLQA5.click();
		MigrationUtil.unconditionalWait(1000);
		RundeckAKAMAICACHEFLUSH5.click();
		}
		else 
		if(env.equalsIgnoreCase("Qa2")){
		RundeckLQA2.click();	
		MigrationUtil.unconditionalWait(1000);
		RundeckAKAMAICACHEFLUSH2.click();
		}
		else
		if(env.equalsIgnoreCase("Qa3")){
		RundeckLQA3.click();
		MigrationUtil.unconditionalWait(1000);
		RundeckAKAMAICACHEFLUSH3.click();
		}
		else
			if(env.equalsIgnoreCase("PQA")){
			//RundeckLPQA.click();
			MigrationUtil.unconditionalWait(1000);
			RundeckAKAMAICACHEFLUSH.click();
			}
		else{
			s_logger.info("No Environment Found");	
		}
		
		MigrationUtil.unconditionalWait(5000); 		
		s_logger.info("Step: Clicked on AKAMAICACHEFLUSH");
		String RundeckEmail=EnvironmentConfig.getInstance().getRundeckEmail();
		RundeckemailField5.sendKeys(RundeckEmail);
		s_logger.info("Enter Email id: "+RundeckEmail);
		RundeckrunJobBtn.click();
		s_logger.info("Step: Clicked on run job");
		//Waiting to capture to succeeded message
		MigrationUtil.unconditionalWait(5000);
		String RunStatus;
		MigrationUtil.unconditionalWait(4000);
		int count = 0;
		do{
			
			MigrationUtil.unconditionalWait(55000);
			driver.navigate().refresh();
			count++;
			RunStatus=ProgressMsg.getAttribute("data-execstate");
			System.out.println("AKAMAICACHEFLUSH Status is " + RunStatus);
		}while(RunStatus.equalsIgnoreCase("Running"));
		
		if(count<2){
			s_logger.info("Rundeck Execution is failed");
		}else{
			s_logger.info("Rundeck Execution is Passed");
		}	
	}
	public void Akamailogout(){
		RundeckdevUser.click();
		MigrationUtil.unconditionalWait(1000);
		Rundecklogout.click();
		s_logger.info("Step: Logout from Rundeck tool");		
		MigrationUtil.unconditionalWait(5000);  
	}	
	
	public boolean isASDADisplayed(){
		s_logger.info("Verifying ASDA hierarchy is displayed or not");
		boolean resultFlag = false;
		try {
			resultFlag = RundeckASDA.isDisplayed();
		} catch (NoSuchElementException ignored) {
			resultFlag = false;
		}
		return resultFlag;
	}
	
	public boolean isLoginDisplayed(){
		s_logger.info("Verifying Login is displayed or not");
		boolean resultFlag = false;
		try {
			resultFlag = RundeckloginBtn.isDisplayed();
		} catch (NoSuchElementException ignored) {
			resultFlag = false;
		}
		return resultFlag;
	}
	
	public boolean isEnvDisplayed(){
		s_logger.info("Verifying Env is displayed or not");
		boolean resultFlag = false;
		try {
			resultFlag = RundeckLPQA.isDisplayed();
		} catch (NoSuchElementException ignored) {
			resultFlag = false;
		}
		return resultFlag;
	}
			
	public boolean isRundeckSucceededMsgDisplayed()   {
		s_logger.info("Verifying RundeckSucceededMsg is displayed or not");
		boolean resultFlag = false;
		try {
			resultFlag = RundeckSucceededMsg.isDisplayed();
			String Secceededmsg=RundeckSucceededMsg.getText().trim();
			s_logger.info("Rundeck Succeeded time is: "+Secceededmsg);
		} catch (NoSuchElementException ignored) {
			resultFlag = false;
		}
		return resultFlag;
	}
	
	
	/*	****************Endeca search Indexing*********************************
	 * Author: Vijay
	 * */
		
		@FindBy(xpath = "//*[@name='baselineAction']")
		private WebElement baseLineIndex;
		
		@FindBy(xpath = "html/body/p[5]/a")
		private WebElement indexHistory;

		@FindBy(xpath = "//*[@id='refreshCheckbox']")
		private WebElement autoRefreshCheck;
		
		@FindBy(xpath = "//*[@id='statusSpan']/table/tbody")
		private WebElement componentsTable;
		
		@FindBy(xpath = "//*[@id='statusSpan']/table/tbody//tr[@class='even']")
		private WebElement componentsTableRowsEven;
		
		public void loadSearchIndexingPage() {
			
			String URL = EnvironmentConfig.getInstance().getSearchIndexURL();
			s_logger.info("Dyn admin url = "+URL);
			driver.get(URL);
			MigrationUtil.unconditionalWait(5000);
			s_logger.info("Dynadmin Search indexing page is loaded");
		}
		
		public void loadSearchIndexingPageforHistory() {
			
			String URL = EnvironmentConfig.getInstance().getSearchIndexingURL();
			s_logger.info("Dyn admin url = "+URL);
			driver.get(URL);
			MigrationUtil.unconditionalWait(5000);
			s_logger.info("Dynadmin Search indexing page is loaded");
		}

		public void clickBaseLineIndex() {
			s_logger.info("Waiting for page to load...");
			SeleniumWebDriverUtility.waitForPageLoad(driver);
			s_logger.info("STEP5: Clicking on BaseLine Index");
			baseLineIndex.click();
			s_logger.info("Clicked on header Sign in Tab");
		}
		
		public void clickIndexingHistory() throws InterruptedException {
			s_logger.info("Waiting for page to load...");
			SeleniumWebDriverUtility.waitForPageLoad(driver);
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollBy(0,500)", "");
			Thread.sleep(3000);
			s_logger.info("Clicking on Indexing History");
			indexHistory.click();
			Thread.sleep(3000);
			jse.executeScript("window.scrollBy(0,600)", "");
			Thread.sleep(3000);
			s_logger.info("Clicked on Indexing History link");
		}
		
		public boolean getIndexStatus(){
			boolean statusFlag = false;
			s_logger.info("Waiting for page to load...");
			SeleniumWebDriverUtility.waitForPageLoad(driver);
			s_logger.info("Getting the index status value");
			for(int i=2;i<5;i++){
				if(driver.findElement(By.xpath("html/body/table[1]/tbody/tr["+i+"]/td[6]")).getText().equalsIgnoreCase("true")){
					s_logger.info("INDEXING GOT PASSED...");
					statusFlag = true;
					break;
				}
			}
			
			if(statusFlag==false){
				int rowCount=driver.findElements(By.xpath("html/body/table[1]/tbody/tr")).size();
				s_logger.info("Total RowCount is "+rowCount);
				
				for(int i=5;i<=rowCount;i++){
					if(driver.findElement(By.xpath("html/body/table[1]/tbody/tr["+i+"]/td[6]")).getText().equalsIgnoreCase("true")){
						s_logger.info("Last Indexing Got Passed On ::: "+driver.findElement(By.xpath("html/body/table[1]/tbody/tr["+i+"]/td[2]")).getText());
						break;
					}
				}
				
			}
			s_logger.info("Copied the index status "+statusFlag);
			return statusFlag;
		}

		public void selectAutoRefreshCheckBox() {
			if (!isautoRefreshCheckBoxSelected()) {
				s_logger.info("STEP6: Selecting Search Indexing page Auto refresh checkBox");
				MigrationUtil.unconditionalWait(2000);
				autoRefreshCheck.click();
				MigrationUtil.unconditionalWait(2000);
			} else
				s_logger.info("Selected Search Indexing page Auto refresh checkBox");
		}

		public boolean isautoRefreshCheckBoxSelected() {
			s_logger.info("Verifying  Search Indexing page Auto refresh checkBox is selected or not");
			return autoRefreshCheck.isSelected();
		}
		
		public boolean CheckUrlContains(String Input) {
			s_logger.info("STEP2: Verifying whether redirected to Dynadmin SearchIndex url");
			boolean resultFlag = false;
			try {
				SeleniumWebDriverUtility.waitForPageLoad(driver);
				MigrationUtil.unconditionalWait(1000);
				resultFlag = driver.getCurrentUrl().contains(Input);
				MigrationUtil.unconditionalWait(1000);
			} catch (NoSuchElementException ignored) {
				resultFlag = false;
			}
			return resultFlag;
		}

		public boolean isBaseLineIndexPresent() {
			s_logger.info("STEP3: Verifying whether Baseline Index button is present");
			boolean resultFlag = false;
			try {
				resultFlag = baseLineIndex.isDisplayed();
				MigrationUtil.unconditionalWait(1000);
			} catch (NoSuchElementException ignored) {
				resultFlag = false;
			}
			return resultFlag;
		}

		public boolean isAutoRefreshCheckboxPresent() {
			s_logger.info("STEP4: Verifying whether AutoRefresh Checkbox is present");
			boolean resultFlag = false;
			try {
				resultFlag = autoRefreshCheck.isDisplayed();
			} catch (NoSuchElementException ignored) {
				resultFlag = false;
			}
			return resultFlag;
		}
		
		public boolean checkCompletionStatus(){
			s_logger.info("STEP8: Verifying whether all the jobs are finished or not");
			boolean resultFlag = false;
			List<WebElement> rows=componentsTable.findElements(By.xpath("//*[@id='statusSpan']/table/tbody//tr[@class='odd'] | //*[@id='statusSpan']/table/tbody//tr[@class='even']"));
			int rows_count = rows.size();
			for (int row=0; row<rows_count; row++){
			   List<WebElement> Columns = rows.get(row).findElements(By.tagName("td"));
			   int columns_count = Columns.size();
			   String component= Columns.get(1).getText();
			   String status = Columns.get(columns_count-1).getText();
			   s_logger.info("Status of "+component+" is: "+status);
			   if (status.equalsIgnoreCase("COMPLETE (Succeeded)"))	{	    	
			    		resultFlag=true;
			   } 		
			   else{
			    	resultFlag=false;
			    	break;
			   }	
			} 
			return resultFlag;
		}
		
		public boolean getRecordSentCount_prodCatOutConfig(){
			boolean resultFlag = false;
			List<WebElement> rows=componentsTable.findElements(By.xpath("//*[@id='statusSpan']/table/tbody//tr[@class='even']"));
			int rows_count = rows.size();
			for (int row=0; row<rows_count; row++){
			   List<WebElement> Columns = rows.get(row).findElements(By.tagName("td"));
			   int columns_count = Columns.size();
			   String component= Columns.get(1).getText();
			   if(component.equals("/atg/commerce/search/ProductCatalogOutputConfig")){
				   int numRecordsSent=Integer.parseInt(Columns.get(columns_count-3).getText());
				   s_logger.info("component : "+component+" - numRecordsSent : "+numRecordsSent);
				   if(numRecordsSent>1500){
					   resultFlag=true;
				   }
				   break;
			   }
			}
			s_logger.info("Verifying whether records sent count is greater than 1500 or not : "+resultFlag);
			return resultFlag;
		}

		public void waitForAllJobsToComplete() {
			s_logger.info("STEP7: Waiting for all jobs run to be completed");		
			do{
				MigrationUtil.unconditionalWait(55000);
				driver.navigate().refresh();
			} while(!isBaseLineIndexPresent());
			s_logger.info("all jobs run completed");			
		}
		
		public void navigateToExplyerIndexerPage(String env, String uri) {
			String URL = uri.replace("login.jsp", "")+"box.jsp?sid=1531932541787&list="+ env.toUpperCase()+"_SEARCHINDEXER";
			s_logger.info("Exployer Search Indexer url = "+URL);
			driver.navigate().to(URL);
			MigrationUtil.unconditionalWait(5000);
			s_logger.info("Exployer Search indexing page is loaded");
		}
		
}