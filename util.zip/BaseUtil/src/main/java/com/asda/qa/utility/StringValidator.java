package com.asda.qa.utility;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class to validate Strings.
 *  
 * @author jkandula
 *
 */

public class StringValidator {
	
	private static final Logger s_logger = LoggerFactory.getLogger(StringValidator.class);
	private static final StringValidator s_instance = new StringValidator();
	private StringValidator(){}
	
	public static StringValidator getInstance() {
		return s_instance;
	}
	
	public enum StringComparision {
		EQUALS,
		EQUALS_IGNORE_CASE,
		NOTEQUALS,
		CONTAINS,
		DOESNOTCONTAIN,
		REGEX
	}

	public boolean validateEquals(String actual, String expected) {
		return validateStrings(actual, expected, StringComparision.EQUALS);
	}
	
	public boolean validateEqualsIgnoreCase(String actual, String expected) {
		return validateStrings(actual, expected, StringComparision.EQUALS_IGNORE_CASE);
	}
	
	public boolean validateNotEquals(String actual, String expected) {
		return validateStrings(actual, expected, StringComparision.NOTEQUALS);
	}
	
	public boolean validateContains(String actual, String expected) {
		return validateStrings(actual, expected, StringComparision.CONTAINS);
	}
	
	public boolean validateNotContains(String actual, String expected) {
		return validateStrings(actual, expected, StringComparision.DOESNOTCONTAIN);
	}
	
	public boolean validateStrings(String actual, String expected, StringComparision comparison) {
		if(comparison == StringComparision.REGEX) {
			return validateRegularExpression(expected, actual);
		}
		
		boolean match = validateStringInternal(actual, expected, comparison);
		
		if(match) {
			s_logger.info("Comparison successful - Expected string '{}' actual string '{}' for comparison {}", expected, actual, comparison);
			return true;
		} else {
			s_logger.info("Comparison un-successful - Expected string '{}' actual string '{}' for comparison {}", expected, actual, comparison);
			return false;
		}
	}
	
	private boolean validateStringInternal(String actual, String expected, StringComparision comparison) {
		if(comparison == StringComparision.EQUALS) {
			if(actual == null && expected == null) { // Both are null
				return true;
			}
			if(actual == null || expected ==null) { // One of them is null
				return false;
			}
			return actual.equals(expected);
		}
		
		if(comparison == StringComparision.EQUALS_IGNORE_CASE) {
			if(actual == null && expected == null) { // Both are null
				return true;
			}
			if(actual == null || expected ==null) { // One of them is null
				return false;
			}
			return actual.equalsIgnoreCase(expected);
		}
		
		if(comparison == StringComparision.NOTEQUALS) {
			if(actual == null && expected == null) { // Both are null
				return false;
			}
			if(actual == null || expected ==null) { // One of them is null
				return true;
			}
			return !actual.equals(expected);
		}
		
		if(comparison == StringComparision.CONTAINS) {
			if(actual == null || expected ==null) { // One of them is null
				return false;
			}
			return actual.contains(expected);
		}
		
		if(comparison == StringComparision.DOESNOTCONTAIN) {
			if(actual == null || expected ==null) { // One of them is null
				return false;
			}
			return !actual.contains(expected);
		}
		
		return false;
	}

	/**
	 * Checks if value contains regular expression pattern.
	 * 
	 * @param value
	 * @param regExp
	 * @return
	 */
	public boolean validateRegularExpression(String value, String regExp) {
		boolean result = false;

		if(regExp != null && value != null) { // Both are not null
			result = IsMatchFound(value, regExp,false);
		}
		if(result == false) {
			s_logger.info("Expeded reg ex: {} but found value: {}", regExp, value);
		} else {
			s_logger.info("Expeded reg ex: {} found.", regExp);
		}
		return result;
	}
	
    /**
     *  This method will use regular expression matching and return "true" or "false" based
     *  on whether the match is found.
     * @param str - This is a string to search.
     * @param matchPattern - This is a Regular Expression pattern such as "\\d+" or "\\m+" and so on.
     * @param caseInsensitive - This is a flag which indicates whether we want to
     * perform a case insensitive string matching. If it's set to 'true' case insensitive matching is used.
     *
     * IsMatchFound ( "124856", "\\d+", true );
     *
     *          or
     *
     * String value = "blaha haha";
     * IsMatchFound ( value, "haha" );
     *
     * @return
     */
    public static boolean IsMatchFound(String str, String matchPattern, boolean caseInsensitive) {

        Pattern p = (caseInsensitive) ? Pattern.compile(matchPattern, Pattern.CASE_INSENSITIVE) :
            Pattern.compile(matchPattern);

        Matcher m = p.matcher(str);

        return (m.find());
    }
}
