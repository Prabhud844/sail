package com.asda.qa.utility;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.asda.qa.environment.EnvironmentConfig;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParser;
import io.restassured.RestAssured;
import io.restassured.authentication.PreemptiveBasicAuthScheme;
import io.restassured.http.Headers;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

/**
 * The Class RestAssuredAPIUtility.
 */
public class RestAssuredAPIUtility {

	/**
	 * The Constant s_logger.
	 */
	private static final Logger s_logger = LoggerFactory.getLogger(RestAssuredAPIUtility.class);

	/**
	 * The threadcookies.
	 */
	public static Map<Integer, Map<String, String>> threadcookies = new ConcurrentHashMap<Integer, Map<String, String>>();

	/**
	 * The threadreq headers.
	 */
	public static Map<Integer, Map<String, String>> threadreqHeaders = new ConcurrentHashMap<Integer, Map<String, String>>();
	//public static Map<String,String> cookies=new HashMap<String, String>();

	//public static Map<String,String> reqHeaders=new HashMap<String, String>();

	/**
	 * The thread res headers.
	 */
	public static Map<Integer, Headers> threadResHeaders = new ConcurrentHashMap<Integer, Headers>();
	//public static Headers resHeaders;


	/**
	 * The Enum ProxyUsage.
	 */
	public enum ProxyUsage {

		/**
		 * The enable.
		 */
		enable,
		/**
		 * The disable.
		 */
		disable,
		enable_local_only,
		enable_looper_only
    }

	/**
	 * Post.
	 *
	 * @param uri        the uri
	 * @param cookies    the cookies
	 * @param headers    the headers
	 * @param params     the params
	 * @param body       the body
	 * @param proxyUsage the proxy usage
	 * @return the response
	 */
	@SuppressWarnings("static-access")
	public Response post(String uri, Map<String, String> cookies, Map<String, String> headers, Map<String, String> params, JSONObject body, ProxyUsage proxyUsage) {
		String subenv = EnvironmentConfig.getInstance().getSubenv();
		RestAssured.baseURI = uri;
		RestAssured.useRelaxedHTTPSValidation();
		s_logger.info("URL : {} ", uri);
		RequestSpecification httpRequest = RestAssured.given();
		httpRequest.log().all();
        if (headers != null) headers.put("qaTocken", "4nmsww3cwe5054hq8l9jvnnao0fczc");
		if (null != headers) headers.put("User-Agent", "asda-uk-selenium-automation-agent");
		if (headers != null)
			httpRequest.headers(headers);

		if (cookies != null)
			httpRequest.cookies(cookies);

		if (!(this.threadcookies.get((int) Thread.currentThread().getId()) == null)) {
			httpRequest.cookies(this.threadcookies.get((int) Thread.currentThread().getId()));
		}

		if (System.getenv("JENKINS_HOME") == null) {
			proxyUsage = ProxyUsage.disable;
		}

		if (proxyUsage == ProxyUsage.enable) {
			httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.disable) {
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is disabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.enable_local_only) {
			if (System.getenv("HUDSON_URL") == null) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in local");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for local but not enabled");
			}
		} else if (proxyUsage == ProxyUsage.enable_looper_only) {
			if (System.getenv("HUDSON_URL") != null && System.getenv("HUDSON_URL").contains("walmart.com")) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in looper");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for looper but not enabled");
			}
		}


		if (params != null)
			httpRequest.params(params);

		if (body != null) {
			httpRequest.body(body.toString());
//			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName()+" POST Request  {} :",body.toString());
		}

		Response response = httpRequest.request(Method.POST);
		if (!Thread.currentThread().getStackTrace()[2].getMethodName().equalsIgnoreCase("getIro"))
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + " POST Respone {} :", response.asString());
		addCookie(response);
		threadResHeaders.put((int) Thread.currentThread().getId(), response.getHeaders());
		return response;
	}

	public String getAuthToken() {
		return threadcookies.get((int) Thread.currentThread().getId()).get("WM_SEC.AUTH_TOKEN");
	}

	public String invalidAuthToken() {
		return threadcookies.get((int) Thread.currentThread().getId()).put("WM_SEC.AUTH_TOKEN", null);
	}

	public String setAuthToken(String auth_token) {
		return threadcookies.get((int) Thread.currentThread().getId()).put("WM_SEC.AUTH_TOKEN", auth_token);
	}

	/**
	 * Adds the cookie.
	 *
	 * @param response the response
	 */
	@SuppressWarnings("static-access")
	public void addCookie(Response response) {
		Map<String, String> localCookie = new HashMap<>();
		if (this.threadcookies.get((int) Thread.currentThread().getId()) != null)
			localCookie.putAll(this.threadcookies.get((int) Thread.currentThread().getId()));
		localCookie.putAll(response.getCookies());
		this.threadcookies.put((int) Thread.currentThread().getId(), localCookie);

	}

	/**
	 * Gets the API Response
	 *
	 * @param uri        the uri
	 * @param cookies    the cookies
	 * @param headers    the headers
	 * @param params     the params
	 * @param proxyUsage the proxy usage
	 * @param urlEncoder the url encoder
	 * @return the response
	 */
	@SuppressWarnings("static-access")
	public Response get(String uri, Map<String, String> cookies, Map<String, String> headers, Map<String, String> params, ProxyUsage proxyUsage, boolean urlEncoder) {
		String subenv = EnvironmentConfig.getInstance().getSubenv();
		RestAssured.baseURI = uri;
		RestAssured.useRelaxedHTTPSValidation();
		RequestSpecification httpRequest = RestAssured.given().urlEncodingEnabled(urlEncoder);
		httpRequest.log().all();
		if (headers != null) headers.put("qaTocken", "4nmsww3cwe5054hq8l9jvnnao0fczc");
		if (null != headers) headers.put("User-Agent", "asda-uk-selenium-automation-agent");
		if (headers != null)
			httpRequest.headers(headers);

		if (cookies != null)
			httpRequest.cookies(cookies);
		if (!(this.threadcookies.get((int) Thread.currentThread().getId()) == null))
			httpRequest.cookies(this.threadcookies.get((int) Thread.currentThread().getId()));

		if (System.getenv("JENKINS_HOME") == null) {
			proxyUsage = ProxyUsage.disable;
		}

		if (proxyUsage == ProxyUsage.enable) {
			httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.disable) {
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is disabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.enable_local_only) {
			if (System.getenv("HUDSON_URL") == null) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in local");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for local but not enabled");
			}
		} else if (proxyUsage == ProxyUsage.enable_looper_only) {
			if (System.getenv("HUDSON_URL") != null && System.getenv("HUDSON_URL").contains("walmart.com")) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in looper");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for looper but not enabled");
			}
		}

		if (params != null)
			httpRequest.params(params);
		Response response = httpRequest.request("GET");
		if (!Thread.currentThread().getStackTrace()[2].getMethodName().equalsIgnoreCase("getRecipeDetail")
				&& !Thread.currentThread().getStackTrace()[2].getMethodName().equalsIgnoreCase("p13nViewItem")
				&& !Thread.currentThread().getStackTrace()[2].getMethodName().equalsIgnoreCase("getRecipeDtoForRecipes"))
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "GET Respone {}", response.asString());
		addCookie(response);
		threadResHeaders.put((int) Thread.currentThread().getId(), response.getHeaders());
		return response;
	}

	/**
	 * Gets the API Response
	 *
	 * @param uri     the uri
	 * @param cookies the cookies
	 * @param headers the headers
	 * @param params  the params
	 * @return the response
	 */
	public Response get(String uri, Map<String, String> cookies, Map<String, String> headers, Map<String, String> params) {
		String subenv = EnvironmentConfig.getInstance().getSubenv();
		RestAssured.baseURI = uri;
		RestAssured.useRelaxedHTTPSValidation();
		RequestSpecification httpRequest = RestAssured.given();
		if (headers != null) headers.put("qaTocken", "4nmsww3cwe5054hq8l9jvnnao0fczc");
		if (null != headers) headers.put("User-Agent", "asda-uk-selenium-automation-agent");
		if (headers != null)
			httpRequest.headers(headers);

		if (cookies != null)
			httpRequest.cookies(cookies);
		if (!(threadcookies.get((int) Thread.currentThread().getId()) == null))
			httpRequest.cookies(threadcookies.get((int) Thread.currentThread().getId()));
		httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
		s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled");

		if (params != null)
			httpRequest.params(params);

		Response response = httpRequest.request("GET");
		s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "GET Respone {} :" + response.asString());
		addCookie(response);
		threadResHeaders.put((int) Thread.currentThread().getId(), response.getHeaders());
		return response;
	}

	/**
	 * Put Data as API Response
	 *
	 * @param uri        the uri
	 * @param cookies    the cookies
	 * @param headers    the headers
	 * @param params     the params
	 * @param body       the body
	 * @param proxyUsage the proxy usage
	 * @return the response
	 */
	@SuppressWarnings("static-access")
	public Response put(String uri, Map<String, String> cookies, Map<String, String> headers, Map<String, String> params, JSONObject body, ProxyUsage proxyUsage) {
		String subenv = EnvironmentConfig.getInstance().getSubenv();
		RestAssured.baseURI = uri;
		RestAssured.useRelaxedHTTPSValidation();
		s_logger.info("URL : {} ", uri);
		RequestSpecification httpRequest = RestAssured.given();
		httpRequest.log().all();
		if (headers != null) headers.put("qaTocken", "4nmsww3cwe5054hq8l9jvnnao0fczc");
		if (null != headers) headers.put("User-Agent", "asda-uk-selenium-automation-agent");
		if (headers != null)
			httpRequest.headers(headers);


		if (cookies != null)
			httpRequest.cookies(cookies);
		if (!(this.threadcookies.get((int) Thread.currentThread().getId()) == null)) {
			httpRequest.cookies(this.threadcookies.get((int) Thread.currentThread().getId()));
		}

		if (System.getenv("JENKINS_HOME") == null) {
			proxyUsage = ProxyUsage.disable;
		}

		if (proxyUsage == ProxyUsage.enable) {
			httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.disable) {
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is disabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.enable_local_only) {
			if (System.getenv("HUDSON_URL") == null) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in local");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for local but not enabled");
			}
		} else if (proxyUsage == ProxyUsage.enable_looper_only) {
			if (System.getenv("HUDSON_URL") != null && System.getenv("HUDSON_URL").contains("walmart.com")) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in looper");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for looper but not enabled");
			}
		}

		if (params != null)
			httpRequest.params(params);

		if (body != null) {
			httpRequest.body(body.toString());
//			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName()+" PUT Request  {} :",body.toString());
		}


		Response response = httpRequest.request(Method.PUT);
		s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + " PUT Response {} :", response.asString());
		addCookie(response);
		threadResHeaders.put((int) Thread.currentThread().getId(), response.getHeaders());
		return response;
	}

	/**
	 * Patch Data as API Response
	 *
	 * @param uri        the uri
	 * @param cookies    the cookies
	 * @param headers    the headers
	 * @param params     the params
	 * @param body       the body
	 * @param proxyUsage the proxy usage
	 * @return the response
	 */
	@SuppressWarnings("static-access")
	public Response patch(String uri, Map<String, String> cookies, Map<String, String> headers, Map<String, String> params, JSONObject body, ProxyUsage proxyUsage) {
		String subenv = EnvironmentConfig.getInstance().getSubenv();
		RestAssured.baseURI = uri;
		RestAssured.useRelaxedHTTPSValidation();
		s_logger.info("URL : {} ", uri);
		RequestSpecification httpRequest = RestAssured.given();
		httpRequest.log().all();
		if (null != headers) headers.put("User-Agent", "asda-uk-selenium-automation-agent");
		if (headers != null)
			httpRequest.headers(headers);


		if (cookies != null)
			httpRequest.cookies(cookies);
		if (!(this.threadcookies.get((int) Thread.currentThread().getId()) == null)) {
			httpRequest.cookies(this.threadcookies.get((int) Thread.currentThread().getId()));
		}

		if (System.getenv("JENKINS_HOME") == null) {
			proxyUsage = ProxyUsage.disable;
		}

		if (proxyUsage == ProxyUsage.enable) {
			httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.disable) {
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is disabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.enable_local_only) {
			if (System.getenv("HUDSON_URL") == null) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in local");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for local but not enabled");
			}
		} else if (proxyUsage == ProxyUsage.enable_looper_only) {
			if (System.getenv("HUDSON_URL") != null && System.getenv("HUDSON_URL").contains("walmart.com")) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in looper");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for looper but not enabled");
			}
		}

		if (params != null)
			httpRequest.params(params);

		if (body != null) {
			httpRequest.body(body.toString());
//			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName()+" PUT Request  {} :",body.toString());
		}


		Response response = httpRequest.request(Method.PATCH);
		s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + " PATCH Response {} :", response.asString());
		addCookie(response);
		threadResHeaders.put((int) Thread.currentThread().getId(), response.getHeaders());
		return response;
	}

	/**
	 * Delete Data through API
	 *
	 * @param uri        the uri
	 * @param cookies    the cookies
	 * @param headers    the headers
	 * @param params     the params
	 * @param proxyUsage the proxy usage
	 * @return the response
	 */
	public Response delete(String uri, Map<String, String> cookies, Map<String, String> headers, Map<String, String> params, ProxyUsage proxyUsage) {
		String subenv = EnvironmentConfig.getInstance().getSubenv();
		RestAssured.baseURI = uri;
		RestAssured.useRelaxedHTTPSValidation();
		s_logger.info("URL : {} ", uri);
		RequestSpecification httpRequest = RestAssured.given();
		httpRequest.log().all();
		if (headers != null) headers.put("qaTocken", "4nmsww3cwe5054hq8l9jvnnao0fczc");
		if (null != headers) headers.put("User-Agent", "asda-uk-selenium-automation-agent");
		if (headers != null)
			httpRequest.headers(headers);


		if (cookies != null)
			httpRequest.cookies(cookies);
		if (!(threadcookies.get((int) Thread.currentThread().getId()) == null)) {
			httpRequest.cookies(threadcookies.get((int) Thread.currentThread().getId()));
		}

		if (System.getenv("JENKINS_HOME") == null) {
			proxyUsage = ProxyUsage.disable;
		}

		if (proxyUsage == ProxyUsage.enable) {
			httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.disable) {
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is disabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.enable_local_only) {
			if (System.getenv("HUDSON_URL") == null) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in local");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for local but not enabled");
			}
		} else if (proxyUsage == ProxyUsage.enable_looper_only) {
			if (System.getenv("HUDSON_URL") != null && System.getenv("HUDSON_URL").contains("walmart.com")) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in looper");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for looper but not enabled");
			}
		}

		if (params != null)
			httpRequest.params(params);
//		s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName()+"DELETE Request {} , {}:",uri, params);

		Response response = httpRequest.request("DELETE");
		s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "DELETE Response {} :", response.asString());
		addCookie(response);
		threadResHeaders.put((int) Thread.currentThread().getId(), response.getHeaders());
		return response;
	}

	/**
	 * Gets the value from response.
	 *
	 * @param response the response
	 * @param jsonPath the json path
	 * @return the value from response
	 */
	public String getValueFromResponse(Response response, String jsonPath) {
		JsonPath jsonPathEvaluator = response.jsonPath();
		return jsonPathEvaluator.getString(jsonPath);

	}




	/**
	 * Gets the obj from response.
	 *
	 * @param response the response
	 * @param jsonPath the json path
	 * @return the obj from response
	 */
	public JSONObject getObjFromResponse(Response response, String jsonPath) {
		JsonPath jsonPathEvaluator = response.jsonPath();
		JSONObject obj = jsonPathEvaluator.getJsonObject(jsonPath);
		return obj;
	}

	/**
	 * Gets the list from response.
	 *
	 * @param response the response
	 * @param jsonPath the json path
	 * @return the list from response
	 */
	/*
	 * @param response
	 * @param jsonPath eg:- list.dt (or) list.main
	 * @return list of strings
	 * */
	public List<String> getListFromResponse(Response response, String jsonPath) {
		JsonPath jsonPathEvaluator = response.jsonPath();
		List<String> list = jsonPathEvaluator.getList(jsonPath);
		return list;
	}

	/**
	 * Gets the objects from response.
	 *
	 * @param response the response
	 * @param jsonPath the json path
	 * @return the objects from response
	 */
	/*
	 * @params response
	 * @params jsonPath
	 * @return array of objects
	 * */
	public List<JSONObject> getObjectsFromResponse(Response response, String jsonPath) {
		JsonPath jsonPathEvaluator = response.jsonPath();
		List<JSONObject> objs = jsonPathEvaluator.getJsonObject(jsonPath);
		return objs;
	}


	/**
	 * Post raw.
	 *
	 * @param uri        the uri
	 * @param cookies    the cookies
	 * @param headers    the headers
	 * @param params     the params
	 * @param body       the body
	 * @param proxyUsage the proxy usage
	 * @return the response
	 */
	@SuppressWarnings("static-access")
	public Response postRaw(String uri, Map<String, String> cookies, Map<String, String> headers, Map<String, String> params, String body, ProxyUsage proxyUsage) {
		String subenv = EnvironmentConfig.getInstance().getSubenv();
		RestAssured.baseURI = uri;
		RestAssured.useRelaxedHTTPSValidation();
		s_logger.info("URL : {} ", uri);
		RequestSpecification httpRequest = RestAssured.given();
		if (headers != null) headers.put("qaTocken", "4nmsww3cwe5054hq8l9jvnnao0fczc");
		if (headers != null)
			httpRequest.headers(headers);


		if (cookies != null)
			httpRequest.cookies(cookies);

		if (!(this.threadcookies.get((int) Thread.currentThread().getId()) == null)) {
			httpRequest.cookies(this.threadcookies.get((int) Thread.currentThread().getId()));
		}

		if (System.getenv("JENKINS_HOME") == null) {
			proxyUsage = ProxyUsage.disable;
		}

		if (proxyUsage == ProxyUsage.enable) {
			httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.disable) {
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is disabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.enable_local_only) {
			if (System.getenv("HUDSON_URL") == null) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in local");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for local but not enabled");
			}
		} else if (proxyUsage == ProxyUsage.enable_looper_only) {
			if (System.getenv("HUDSON_URL") != null && System.getenv("HUDSON_URL").contains("walmart.com")) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in looper");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for looper but not enabled");
			}
		}

		if (params != null)
			httpRequest.params(params);

		if (body != null) {
			httpRequest.body(body);
//			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName()+" POST Request  {} :",body.toString());
		}

		Response response = httpRequest.request(Method.POST);
		s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + " POST Respone {} :", response.asString());
		addCookie(response);
		threadResHeaders.put((int) Thread.currentThread().getId(), response.getHeaders());
		return response;
	}

	/**
	 * Post with query param.
	 *
	 * @param uri        the uri
	 * @param cookies    the cookies
	 * @param headers    the headers
	 * @param params     the params
	 * @param body       the body
	 * @param proxyUsage the proxy usage
	 * @return the response
	 */
	@SuppressWarnings("static-access")
	public Response postWithQueryParam(String uri, Map<String, String> cookies, Map<String, String> headers, Map<String, String> params, JSONObject body, ProxyUsage proxyUsage) {
		String subenv = EnvironmentConfig.getInstance().getSubenv();
		RestAssured.baseURI = uri;
		RestAssured.useRelaxedHTTPSValidation();
		s_logger.info("URL : {} ", uri);
		RequestSpecification httpRequest = RestAssured.given();
		httpRequest.log().all();
		if (headers != null) headers.put("qaTocken", "4nmsww3cwe5054hq8l9jvnnao0fczc");
		if (headers != null)
			httpRequest.headers(headers);


		if (cookies != null)
			httpRequest.cookies(cookies);

		if (!(this.threadcookies.get((int) Thread.currentThread().getId()) == null)) {
			httpRequest.cookies(this.threadcookies.get((int) Thread.currentThread().getId()));
		}

		if (System.getenv("JENKINS_HOME") == null) {
			proxyUsage = ProxyUsage.disable;
		}

		if (proxyUsage == ProxyUsage.enable) {
			httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.disable) {
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is disabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.enable_local_only) {
			if (System.getenv("HUDSON_URL") == null) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in local");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for local but not enabled");
			}
		} else if (proxyUsage == ProxyUsage.enable_looper_only) {
			if (System.getenv("HUDSON_URL") != null && System.getenv("HUDSON_URL").contains("walmart.com")) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in looper");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for looper but not enabled");
			}
		}

		if (params != null)
			httpRequest.queryParams(params);

		if (body != null) {
			httpRequest.body(body.toString());
//			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName()+" POST Request {}",body.toString());
		}

		Response response = httpRequest.request(Method.POST);
		s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + " POST Respone {}", response.asString());
		addCookie(response);
		threadResHeaders.put((int) Thread.currentThread().getId(), response.getHeaders());
		return response;
	}

	/**
	 * Post call for uploading file along with query param.
	 *
	 * @param uri        the uri
	 * @param cookies    the cookies
	 * @param headers    the headers
	 * @param params     the params
	 * @param fileName   the body
	 * @param proxyUsage the proxy usage
	 * @return the response
	 */
	@SuppressWarnings("static-access")
	public Response postForUploadFileWithQueryParam(String uri, Map<String, String> cookies, Map<String, String> headers, Map<String, String> params, File fileName, ProxyUsage proxyUsage) {
		String subenv = EnvironmentConfig.getInstance().getSubenv();
		RestAssured.baseURI = uri;
		RestAssured.useRelaxedHTTPSValidation();
		s_logger.info("URL : {} ", uri);
		RequestSpecification httpRequest = RestAssured.given().multiPart(fileName);
		if (headers != null)
			httpRequest.headers(headers);

		if (System.getenv("JENKINS_HOME") == null) {
			proxyUsage = ProxyUsage.disable;
		}

		if (cookies != null)
			httpRequest.cookies(cookies);

		if (!(this.threadcookies.get((int) Thread.currentThread().getId()) == null)) {
			httpRequest.cookies(this.threadcookies.get((int) Thread.currentThread().getId()));
		}

		if (proxyUsage == ProxyUsage.enable) {
			httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.disable) {
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is disabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.enable_local_only) {
			if (System.getenv("HUDSON_URL") == null) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in local");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for local but not enabled");
			}
		} else if (proxyUsage == ProxyUsage.enable_looper_only) {
			if (System.getenv("HUDSON_URL") != null && System.getenv("HUDSON_URL").contains("walmart.com")) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in looper");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for looper but not enabled");
			}
		}

		if (params != null)
			httpRequest.queryParams(params);

		Response response = httpRequest.request(Method.POST);
		s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + " POST Respone {} :", response.asString());
		addCookie(response);
		threadResHeaders.put((int) Thread.currentThread().getId(), response.getHeaders());
		return response;
	}


	/**
	 * Put with query param.
	 *
	 * @param uri        the uri
	 * @param cookies    the cookies
	 * @param headers    the headers
	 * @param params     the params
	 * @param body       the body
	 * @param proxyUsage the proxy usage
	 * @return the response
	 */
	@SuppressWarnings("static-access")
	public Response putWithQueryParam(String uri, Map<String, String> cookies, Map<String, String> headers, Map<String, String> params, JSONObject body, ProxyUsage proxyUsage) {
		String subenv = EnvironmentConfig.getInstance().getSubenv();
		RestAssured.baseURI = uri;
		RestAssured.useRelaxedHTTPSValidation();
		s_logger.info("URL : {} ", uri);
		RequestSpecification httpRequest = RestAssured.given();
		httpRequest.log().all();
		if (headers != null) headers.put("qaTocken", "4nmsww3cwe5054hq8l9jvnnao0fczc");
		if (headers != null)
			httpRequest.headers(headers);


		if (cookies != null)
			httpRequest.cookies(cookies);
		if (!(this.threadcookies.get((int) Thread.currentThread().getId()) == null)) {
			httpRequest.cookies(this.threadcookies.get((int) Thread.currentThread().getId()));
		}

		if (System.getenv("JENKINS_HOME") == null) {
			proxyUsage = ProxyUsage.disable;
		}

		if (proxyUsage == ProxyUsage.enable) {
			httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.disable) {
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is disabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.enable_local_only) {
			if (System.getenv("HUDSON_URL") == null) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in local");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for local but not enabled");
			}
		} else if (proxyUsage == ProxyUsage.enable_looper_only) {
			if (System.getenv("HUDSON_URL") != null && System.getenv("HUDSON_URL").contains("walmart.com")) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in looper");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for looper but not enabled");
			}
		}

		if (params != null)
			httpRequest.queryParams(params);

		if (body != null) {
			httpRequest.body(body.toString());
//			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName()+" PUT Request  {} :",body.toString());
		}


		Response response = httpRequest.request(Method.PUT);
		s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + " PUT Response {} :", response.asString());
		addCookie(response);
		threadResHeaders.put((int) Thread.currentThread().getId(), response.getHeaders());
		return response;
	}

	/**
	 * Put Data as API Response
	 *
	 * @param uri        the uri
	 * @param cookies    the cookies
	 * @param headers    the headers
	 * @param params     the params
	 * @param jsonArray  the body
	 * @param proxyUsage the proxy usage
	 * @return the response
	 */
	@SuppressWarnings("static-access")
	public Response putForJSONArray(String uri, Map<String, String> cookies, Map<String, String> headers, Map<String, String> params, JSONArray jsonArray, ProxyUsage proxyUsage) {
		String subenv = EnvironmentConfig.getInstance().getSubenv();
		RestAssured.baseURI = uri;
		RestAssured.useRelaxedHTTPSValidation();
		s_logger.info("URL : {} ", uri);
		RequestSpecification httpRequest = RestAssured.given();
		if (headers != null)
			httpRequest.headers(headers);


		if (cookies != null)
			httpRequest.cookies(cookies);
		if (!(this.threadcookies.get((int) Thread.currentThread().getId()) == null)) {
			httpRequest.cookies(this.threadcookies.get((int) Thread.currentThread().getId()));
		}

		if (System.getenv("JENKINS_HOME") == null) {
			proxyUsage = ProxyUsage.disable;
		}

		if (proxyUsage == ProxyUsage.enable) {
			httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.disable) {
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is disabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.enable_local_only) {
			if (System.getenv("HUDSON_URL") == null) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in local");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for local but not enabled");
			}
		} else if (proxyUsage == ProxyUsage.enable_looper_only) {
			if (System.getenv("HUDSON_URL") != null && System.getenv("HUDSON_URL").contains("walmart.com")) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in looper");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for looper but not enabled");
			}
		}

		if (params != null)
			httpRequest.params(params);

		if (jsonArray != null) {
			httpRequest.body(jsonArray.toString());
//			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName()+" PUT Request  {} :",jsonArray.toString());
		}


		Response response = httpRequest.request(Method.PUT);
		s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + " PUT Response {} :", response.asString());
		addCookie(response);
		threadResHeaders.put((int) Thread.currentThread().getId(), response.getHeaders());
		return response;
	}

	@SuppressWarnings("static-access")
	public Response postWithAuth(String username, String password, String uri, Map<String, String> cookies, Map<String, String> headers,
								 Map<String, String> params, JSONObject body, ProxyUsage proxyUsage) {
		String subenv = EnvironmentConfig.getInstance().getSubenv();
		RestAssured.baseURI = uri;
		RestAssured.useRelaxedHTTPSValidation();

		PreemptiveBasicAuthScheme authScheme = new PreemptiveBasicAuthScheme();
		authScheme.setUserName(username);
		authScheme.setPassword(password);
		RestAssured.authentication = authScheme;
		RequestSpecification httpRequest = RestAssured.given();
		if (headers != null) headers.put("qaTocken", "4nmsww3cwe5054hq8l9jvnnao0fczc");
		if (headers != null)
			httpRequest.headers(headers);
		if (cookies != null)
			httpRequest.cookies(cookies);
		if (!(this.threadcookies.get((int) Thread.currentThread().getId()) == null))
			httpRequest.cookies(this.threadcookies.get((int) Thread.currentThread().getId()));

		if (System.getenv("JENKINS_HOME") == null) {
			proxyUsage = ProxyUsage.disable;
		}

		if (proxyUsage == ProxyUsage.enable) {
			httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.disable) {
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is disabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.enable_local_only) {
			if (System.getenv("HUDSON_URL") == null) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in local");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for local but not enabled");
			}
		} else if (proxyUsage == ProxyUsage.enable_looper_only) {
			if (System.getenv("HUDSON_URL") != null && System.getenv("HUDSON_URL").contains("walmart.com")) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in looper");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for looper but not enabled");
			}
		}

		if (params != null) httpRequest.queryParams(params);

		if (body != null) httpRequest.body(body.toString());

		Response response = httpRequest.request(Method.POST);
		s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + " POST Response {} :", response.asString());
		addCookie(response);
		threadResHeaders.put((int) Thread.currentThread().getId(), response.getHeaders());
		return response;
	}

	public String getFormattedJson(Response jsonResponse) {
		if (jsonResponse.getContentType().contains("json")) {
			return new GsonBuilder()
					.setPrettyPrinting()
					.create()
					.toJson(new JsonParser().parse(jsonResponse.asString()));
		} else {
			return jsonResponse.asString();
		}
	}

	public Response post_search(String uri, Map<String, String> cookies, Map<String, String> headers, Map<String, String> params, org.json.JSONObject bodyObj, ProxyUsage proxyUsage) {
		RestAssured.baseURI = uri;
		RestAssured.useRelaxedHTTPSValidation();
		s_logger.info("URL : {} ", uri);
		RequestSpecification httpRequest = RestAssured.given();
		if (headers != null) headers.put("qaTocken", "4nmsww3cwe5054hq8l9jvnnao0fczc");
		if (headers != null)
			httpRequest.headers(headers);


		if (cookies != null)
			httpRequest.cookies(cookies);

		if (!(threadcookies.get((int) Thread.currentThread().getId()) == null)) {
			httpRequest.cookies(threadcookies.get((int) Thread.currentThread().getId()));
		}

		if (System.getenv("JENKINS_HOME") == null) {
			proxyUsage = ProxyUsage.disable;
		}

		if (proxyUsage == ProxyUsage.enable) {
			httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.disable) {
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is disabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.enable_local_only) {
			if (System.getenv("HUDSON_URL") == null) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in local");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for local but not enabled");
			}
		} else if (proxyUsage == ProxyUsage.enable_looper_only) {
			if (System.getenv("HUDSON_URL") != null && System.getenv("HUDSON_URL").contains("walmart.com")) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in looper");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for looper but not enabled");
			}
		}

		if (params != null)
			httpRequest.params(params);

		if (bodyObj != null) {
			httpRequest.body(bodyObj.toString());
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + " POST Request  {} :", bodyObj);
		}

		Response response = httpRequest.request(Method.POST);
		String responseMessage = response.asString();
		//s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName()+" POST Respone {} :",responseMessage);

		addCookie(response);
		threadResHeaders.put((int) Thread.currentThread().getId(),
				response.getHeaders());
		return response;

	}

	public Response patch1(String uri, Map<String, String> cookies, Map<String, String> headers, Map<String, String> params, org.json.simple.JSONArray body, ProxyUsage proxyUsage) {
		String subenv = EnvironmentConfig.getInstance().getSubenv();
		RestAssured.baseURI = uri;
		RestAssured.useRelaxedHTTPSValidation();
		s_logger.info("URL : {} ", uri);
		RequestSpecification httpRequest = RestAssured.given();
		httpRequest.log().all();
		if (null != headers) headers.put("User-Agent", "asda-uk-selenium-automation-agent");
		if (headers != null)
			httpRequest.headers(headers);


		if (cookies != null)
			httpRequest.cookies(cookies);
		if (!(threadcookies.get((int) Thread.currentThread().getId()) == null)) {
			httpRequest.cookies(threadcookies.get((int) Thread.currentThread().getId()));
		}

		if (System.getenv("JENKINS_HOME") == null) {
			proxyUsage = ProxyUsage.disable;
		}

		if (proxyUsage == ProxyUsage.enable) {
			httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.disable) {
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is disabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.enable_local_only) {
			if (System.getenv("HUDSON_URL") == null) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in local");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for local but not enabled");
			}
		} else if (proxyUsage == ProxyUsage.enable_looper_only) {
			if (System.getenv("HUDSON_URL") != null && System.getenv("HUDSON_URL").contains("walmart.com")) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in looper");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for looper but not enabled");
			}
		}

		if (params != null)
			httpRequest.params(params);

		if (body != null) {
			httpRequest.body(body.toString());
//			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName()+" PUT Request  {} :",body.toString());
		}


		Response response = httpRequest.request(Method.PATCH);
		s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + " PATCH Response {} :", response.asString());
		addCookie(response);
		threadResHeaders.put((int) Thread.currentThread().getId(), response.getHeaders());
		return response;
	}

	public Response post1(String uri, Map<String, String> cookies, Map<String, String> headers, Map<String, String> params, org.json.simple.JSONArray body, ProxyUsage proxyUsage) {
		String subenv = EnvironmentConfig.getInstance().getSubenv();
		RestAssured.baseURI = uri;
		RestAssured.useRelaxedHTTPSValidation();
		s_logger.info("URL : {} ", uri);
		RequestSpecification httpRequest = RestAssured.given();
		httpRequest.log().all();
        if (headers != null) headers.put("qaTocken", "4nmsww3cwe5054hq8l9jvnnao0fczc");
		if (null != headers) headers.put("User-Agent", "asda-uk-selenium-automation-agent");
		if (headers != null)
			httpRequest.headers(headers);

		if (cookies != null)
			httpRequest.cookies(cookies);

		if (!(threadcookies.get((int) Thread.currentThread().getId()) == null)) {
			httpRequest.cookies(threadcookies.get((int) Thread.currentThread().getId()));
		}

		if (System.getenv("JENKINS_HOME") == null) {
			proxyUsage = ProxyUsage.disable;
		}

		if (proxyUsage == ProxyUsage.enable) {
			httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.disable) {
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is disabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.enable_local_only) {
			if (System.getenv("HUDSON_URL") == null) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in local");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for local but not enabled");
			}
		} else if (proxyUsage == ProxyUsage.enable_looper_only) {
			if (System.getenv("HUDSON_URL") != null && System.getenv("HUDSON_URL").contains("walmart.com")) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in looper");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for looper but not enabled");
			}
		}


		if (params != null)
			httpRequest.params(params);

		if (body != null) {
			httpRequest.body(body.toString());
//			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName()+" POST Request  {} :",body.toString());
		}

		Response response = httpRequest.request(Method.POST);
		if (!Thread.currentThread().getStackTrace()[2].getMethodName().equalsIgnoreCase("getIro"))
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + " POST Respone {} :", response.asString());
		addCookie(response);
		threadResHeaders.put((int) Thread.currentThread().getId(), response.getHeaders());
		return response;
	}



	public Response deletewithbody(String uri, Map<String, String> cookies, Map<String, String> headers, Map<String, String> params, org.json.simple.JSONArray body, ProxyUsage proxyUsage) {
		String subenv = EnvironmentConfig.getInstance().getSubenv();
		RestAssured.baseURI = uri;
		RestAssured.useRelaxedHTTPSValidation();
		s_logger.info("URL : {} ", uri);
		RequestSpecification httpRequest = RestAssured.given();
		httpRequest.log().all();
		if (headers != null) headers.put("qaTocken", "4nmsww3cwe5054hq8l9jvnnao0fczc");
		if (null != headers) headers.put("User-Agent", "asda-uk-selenium-automation-agent");
		if (headers != null)
			httpRequest.headers(headers);


		if (cookies != null)
			httpRequest.cookies(cookies);
		if (!(threadcookies.get((int) Thread.currentThread().getId()) == null)) {
			httpRequest.cookies(threadcookies.get((int) Thread.currentThread().getId()));
		}

		if (System.getenv("JENKINS_HOME") == null) {
			proxyUsage = ProxyUsage.disable;
		}

		if (proxyUsage == ProxyUsage.enable) {
			httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.disable) {
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is disabled in both local and looper");
		} else if (proxyUsage == ProxyUsage.enable_local_only) {
			if (System.getenv("HUDSON_URL") == null) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in local");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for local but not enabled");
			}
		} else if (proxyUsage == ProxyUsage.enable_looper_only) {
			if (System.getenv("HUDSON_URL") != null && System.getenv("HUDSON_URL").contains("walmart.com")) {
				httpRequest.proxy("http://sysproxy.wal-mart.com:8080");
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable in looper");
			} else {
				s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "Proxy Usage is enable for looper but not enabled");
			}
		}

		if (params != null)
			httpRequest.params(params);
//		s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName()+"DELETE Request {} , {}:",uri, params);

		if (body != null) {
			httpRequest.body(body.toString());
//			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName()+" PUT Request  {} :",body.toString());
		}
			Response response = httpRequest.request("DELETE");
			s_logger.info(Thread.currentThread().getStackTrace()[2].getMethodName() + "DELETE Response {} :", response.asString());
			addCookie(response);
			threadResHeaders.put((int) Thread.currentThread().getId(), response.getHeaders());
			return response;
		}

	}


