package com.asda.qa.utility;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class URLConnectionHelper {

	private static final int URL_CONNECTION_TIMEOUT = 60000;
	private final Logger s_logger = LoggerFactory.getLogger(URLConnectionHelper.class);
	
	public URLConnectionResponse triggerCallToUrl(String urlToInvoke) throws IOException {
		URLConnectionResponse urlConnectionResponse = new URLConnectionResponse();
		try {
			
			s_logger.info("Invoking url:" + urlToInvoke);
			
			URL url = new URL(urlToInvoke);

			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(URL_CONNECTION_TIMEOUT);
			conn.setReadTimeout(URL_CONNECTION_TIMEOUT);
			conn.connect();
			s_logger.info("Completed invoking url.");
			int responseCode = conn.getResponseCode();
			s_logger.info("Response Code:" + responseCode);

			BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			StringBuilder sb = new StringBuilder();
			String line = null;
			while((line = br.readLine()) != null) {
				sb.append(line);
			}
			String response = sb.toString();
			urlConnectionResponse.setResponseCode(responseCode);
			urlConnectionResponse.setResponse(response);
		} catch (MalformedURLException e) {
			s_logger.error("Error in URL:" + urlToInvoke, e);
			throw e;
		} catch (IOException e) {
			s_logger.error("Error invoking URL:" + urlToInvoke, e);
			throw e;
		} 
		return urlConnectionResponse;
	}


}