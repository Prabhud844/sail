package com.asda.qa.utility;

import com.asda.core.utils.MigrationUtil;
import com.asda.core.utils.Utility.ListUtility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * This utility class provide methods to convert String to Document object.
 * 
 * Additionally provides methods to pick a specific value from with in the xml.
 * 
 * @author jkandul
 *
 */
public class XMLDomHelper {

	private static final Logger s_logger = LoggerFactory.getLogger(XMLDomHelper.class);
	private static final XMLDomHelper s_instance = new XMLDomHelper();
	
	public static XMLDomHelper getInstance() {
		return s_instance;
	}
	
	public Document getDocumentFromXml(String xmlString) {
        InputStream ioStream = new ByteArrayInputStream(xmlString.getBytes(StandardCharsets.UTF_8));
        return getDocumentFromXml(ioStream);
	}
	
	public Document getDocumentFromXml(InputStream ioStream) {
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			return db.parse(ioStream);
		} catch (UnsupportedEncodingException e1) {
			s_logger.error("Unable to convert stream  to dom.", e1);
		} catch (ParserConfigurationException e) {
			s_logger.error("Unable to convert stream  to dom.", e);
		} catch (SAXException e) {
			s_logger.error("Unable to convert stream  to dom.", e);
		} catch (IOException e) {
			s_logger.error("Unable to convert stream  to dom.", e);
		} catch (Throwable te) {
			s_logger.error("Unable to convert stream  to dom.", te);
		}
		return null;
	}
	
	public Document getDocumentFromFile(File file){
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			return db.parse(file);
		} catch (UnsupportedEncodingException e1) {
			s_logger.error("Unable to convert file  to dom.", e1);
		} catch (ParserConfigurationException e) {
			s_logger.error("Unable to convert file  to dom.", e);
		} catch (SAXException e) {
			s_logger.error("Unable to convert file  to dom.", e);
		} catch (IOException e) {
			s_logger.error("Unable to convert file  to dom.", e);
		} catch (Throwable te) {
			s_logger.error("Unable to convert file  to dom.", te);
		}
		
		return null;
	}
	
	

	public String getValueAtXpath(String xmlString, String xpath){
		return getValueAtXpath(getDocumentFromXml(xmlString), xpath);
	}
	
	public String getValueAtXpath(Document xmlDoc, String xpath){
		try{
			XPathExpression xpathExpression = XPathFactory.newInstance().newXPath().compile(xpath);
			Object result = xpathExpression.evaluate(xmlDoc, XPathConstants.NODE);
			if(result == null) {
				s_logger.error("Value not found at xpath:{}", xpath);
				return null;
			}
			return ((Node)result).getTextContent();
		}catch(XPathExpressionException e){
			s_logger.error("Invalid Xpath used.", e);
		}
		return null;
	}
	
	public void setValueInDocument(Document xmlDoc, String xpath, String value){
		try{
			XPathExpression xpathExpression = XPathFactory.newInstance().newXPath().compile(xpath);
			Object result = xpathExpression.evaluate(xmlDoc, XPathConstants.NODE);
			 ((Node)result).setTextContent(value);
		}catch(XPathExpressionException e){
			s_logger.error("Invalid xpath used.", e);
		}
	}
	
	public String getXmlFromDocument(Document doc) {

		try {
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");

			// initialize StreamResult with File object to save to file
			StreamResult result = new StreamResult(new StringWriter());
			DOMSource source = new DOMSource(doc);

			transformer.transform(source, result);
			return result.getWriter().toString();
		} catch (TransformerException e) {
			s_logger.error("Error converting dom to xml.", e);
		}

		return null; // Default string
	}
	
	/**
	 * Get raw value(with tags) from xml at the given xpath.
	 * 
	 * @param xmlString
	 * @param xpath
	 * @return
	 */
	public String getRawValueAtXpath(String xmlString, String xpath){
		return getRawValueAtXpath(getDocumentFromXml(xmlString), xpath);
	}
	
	/**
	 * Get raw value(with tags) from xmlDoc at the given xpath.
	 * 
	 * @param xmlDoc
	 * @param xpath
	 * @return
	 */
	public String getRawValueAtXpath(Document xmlDoc, String xpath){
		try{
			XPathExpression xpathExpression = XPathFactory.newInstance().newXPath().compile(xpath);
			Object result = xpathExpression.evaluate(xmlDoc, XPathConstants.NODE);
			if(result == null) {
				s_logger.error("Value not found at xpath:{}", xpath);
				return null;
			}
			return getRAW((Node)result);
		}catch(XPathExpressionException e){
			s_logger.error("Invalid Xpath used.", e);
		}
		return null;
	}
	
	/**
	 * Get RAW XML of XML Node
	 * Only NodeName and TextContent supproted by now
	 * @param xmlNode
	 * @return RAW XML
	 */
	private String getRAW(Node xmlNode){
		StringBuffer result = new StringBuffer();
		
		String nodeName = xmlNode.getNodeName();
		
		// exclude <text> node
		if (!"#text".equals(nodeName)){
			result.append("<").append(nodeName).append(">");
		}
		
		if (xmlNode.hasChildNodes()) {
			NodeList nodeList = xmlNode.getChildNodes();
			int nodeLength = nodeList.getLength();
			for (int i = 0; i < nodeLength; i++) {
				Node node = nodeList.item(i);
				result.append(getRAW(node));
			}
		} else {
			String nodeContent = xmlNode.getTextContent();
			result.append(nodeContent);
		}
		
		// exclude </text> node
		if (!"#text".equals(nodeName)){
			result.append("</").append(nodeName).append(">");
		}
		
		return result.toString();
	}
	
	/**
	 * Returns values as a comma separated string from multiple xpaths after replacing the dynamic values.
	 *  
	 * @param xmlString
	 * @param xpath
	 * @param dynamicValues
	 * @return
	 */
	public String getValueAtIndexedXpathAsString(String xmlString, String xpath, Map<String, String> dynamicValues){
		return ListUtility.getCommaSeperatedString(getValueAtIndexedXpath(xmlString, xpath, dynamicValues));
	}
	
	/**
	 * Returns values from multiple xpaths after replacing the dynamic values.
	 * 
	 * @param xmlString
	 * @param xpath
	 * @param dynamicValues
	 * @return
	 */
	public List<String> getValueAtIndexedXpath(String xmlString, String xpath, Map<String, String> dynamicValues){
		List<String> allXpaths = MigrationUtil.getLocatorsForIndexedValues(xpath, dynamicValues);
		List<String> resultValues = new ArrayList<String>();
		Document xmlDoc = getDocumentFromXml(xmlString);
		for(String xp : allXpaths) {
			resultValues.add(getValueAtXpath(xmlDoc, xp));
		}
		return resultValues;
	}
}
