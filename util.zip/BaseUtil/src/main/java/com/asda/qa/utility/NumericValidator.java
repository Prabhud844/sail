package com.asda.qa.utility;

import java.math.BigDecimal;


/**
 * Class to validate Numbers
 * 
 * @author i0kumar
 *
 */
public class NumericValidator {

	
	public enum NumericComparision {
		LT(1, "Less Than"),
		GT(2, "Greater Than"),
		EQ(3, "Equals"),
		NE(4, "Not Equals"),
		GE(5, "Greater than or Equal"),
		LE(6, "Less than or Equal"),
		;
		
		int id;
		String name;
		NumericComparision(int id, String name) {
			this.id = id;
			this.name = name;
		}
	}
	
	public static boolean validateNumbers(String actual, String expected, String operation) {
		BigDecimal actualNumber = new BigDecimal(actual);
		BigDecimal expectedNumber = new BigDecimal(expected);
		return validateNumbers(actualNumber, expectedNumber, operation);
	}
	
	public static boolean validateNumbers(long actual, long expected, String operation) {
		return validateNumbers(new BigDecimal(actual), new BigDecimal(expected), operation);
	}
	
	public static boolean validateNumbers(BigDecimal actual, BigDecimal expected, String operation) {
		NumericComparision comparison = getNumericComparision(operation);
		return validateNumbers(actual, expected, comparison);
	}
	
	/**
	 * Compares actual with expected for the given comparison and returns true if comparison is successful, false otherwise
	 * 
	 * @param actual
	 * @param expected
	 * @param comparison
	 * @return
	 */
	public static boolean validateNumbers(BigDecimal actual, BigDecimal expected, NumericComparision comparison) {
		switch(comparison) {
			case LT:
				return actual.compareTo(expected) < 0;
			case GT:
				return actual.compareTo(expected) > 0;
			case EQ:
				return actual.compareTo(expected) == 0;
			case NE:
				return actual.compareTo(expected) != 0;
			case GE:
				return actual.compareTo(expected) >= 0;
			case LE:
				return actual.compareTo(expected) <= 0;
			default:
				return false;
		}
	}
	
	public static NumericComparision getNumericComparision(String stringNumericComparision){
		if(stringNumericComparision.equals(NumericComparision.LT.name())){
			return NumericComparision.LT;
		}
		if(stringNumericComparision.equals(NumericComparision.GT.name())){
			return NumericComparision.GT;
		}
		if(stringNumericComparision.equals(NumericComparision.EQ.name())){
			return NumericComparision.EQ;
		}
		if(stringNumericComparision.equals(NumericComparision.NE.name())){
			return NumericComparision.NE;
		}
		if(stringNumericComparision.equals(NumericComparision.GE.name())){
			return NumericComparision.GE;
		}
		if(stringNumericComparision.equals(NumericComparision.LE.name())){
			return NumericComparision.LE;
		}
		return null;
		
	}
	
}
