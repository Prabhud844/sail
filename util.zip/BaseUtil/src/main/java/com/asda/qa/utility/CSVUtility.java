package com.asda.qa.utility;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The Class CSVUtility.
 */
public class CSVUtility {

	/** The file. */
	private File file;

	/** The br. */
	private BufferedReader br;

	/** The headers. */
	private List<String> headers;

	/**
	 * Gets the headers.
	 *
	 * @return the headers
	 */
	public List<String> getHeaders(){
		return headers;
	}

	private BufferedWriter bw;

	/**
	 * Instantiates a new CSV utility.
	 *
	 * @param fileLocation the file location
	 */
	public CSVUtility(String fileLocation) {
		try {
			if(fileLocation.contains("\\"))
				fileLocation=fileLocation.replace("\\", "/");
			if(!(fileLocation.lastIndexOf("/")+1==fileLocation.length())){
				fileLocation= fileLocation.concat("/");
			}
//			file = new File(fileLocation);
			file = new File(CSVUtility.class.getClassLoader().getResource(fileLocation).getFile());
			br = new BufferedReader(new FileReader(file));
			headers = new ArrayList<String>();
			readHeaders();
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public CSVUtility(String fileLocation, boolean isWriter, boolean isAppend) {
		if(!isWriter) {
			new CSVUtility(fileLocation);
		}else {
			file = new File(fileLocation);
			try {
				bw = new BufferedWriter(new FileWriter(file, isAppend));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * Read headers.
	 */
	private void readHeaders() {
		try {
			headers.addAll(Arrays.asList(br.readLine().split(",")));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * read one line from the csv file.
	 * Use it in a while loop
	 * @return
	 */
	public List<String> readOneLine(){
		List<String> values = null;
		try {
			String line;
			if( (line = br.readLine()) != null ) {
				values = new ArrayList<String>();
				String[] arr = line.split(",");
				values = Arrays.asList(arr);
			}
		}catch(IOException e) {
			System.out.println("Error while reading the file");
		}
		return values;
	}

	/**
	 * Only Read an omniture file.
	 *
	 * @return the list
	 */
	public List<String> read() {
		List<String> values = null;
		try {
			String line;
			if((line=br.readLine()) != null) {
				values = new ArrayList<String>();
				line = line.replace("”","???").replace("™", "???").replace("≥", "???").replace("“", "???").replace("‘", "???");
				line = line.replace("≥", "???").replace("™", "???").replace("–", "???");
				//.replace("’", "???").replace("£", "???") .replace("é", "??") --- valid for tibco processing but not for spark

				line = line.replace("«", "??").replace("æ", "??").replace("ª", "??").replace("§", "??").replace("ç", "??").replace("è", "??").replace("ü","??");
				Pattern pat = Pattern.compile("([\"]{3,}(.*?)[\"]{3,})");
				Matcher match = pat.matcher(line);
				if(match.find()) {
					String tempLine = match.group();
					String remove = tempLine.replace("\"\"\"", "\"");
					line = line.replace(tempLine, remove);
				}else {
					line = line.replace("\"", "");
				}
//				System.out.println(line);
				String[] arr = line.split(",");
				StringBuilder builder = new StringBuilder();
				if(arr.length > headers.size()) {
					builder.append(arr[0].replace("\"", ""));builder.append(",");
					builder.append("\"");
					for(int i=1; i<headers.size(); i++) {
						builder.append(arr[i]);
						if(i < headers.size() - 1)
							builder.append("2*2");
					}
					builder.append("\"");
					for(int i=headers.size(); i<arr.length-1; i++) {
						builder.append(arr[i]);
					}
					builder.append(",");
					builder.append(arr[arr.length - 1]);
				}else {
					builder.append(arr[0].replace("\"", ""));builder.append(",");
					builder.append(arr[1]);builder.append(",");
					builder.append(arr[2]);builder.append(",");
				}
				values.addAll(Arrays.asList(builder.toString().split(",")));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return values;
	}

	/**
	 * Gets the table array.
	 *
	 * @param filepath the filepath
	 * @return the table array
	 */
	public static String[][] getTableArray(String filepath){
		String[][] data = null;
		try {
			BufferedReader br = new BufferedReader(new FileReader(filepath));
			List<String> temp = new ArrayList<String>();
			String line = null;
			while((line = br.readLine()) != null) {
				temp.add(line);
			}
			String[] arr = temp.get(0).split(",");
			int r = temp.size(), c = arr.length;
			data = new String[r][c];
			for(int i=0; i<r; i++) {
				arr = temp.get(i).split(",");
				for(int j=0; j<c; j++) {
					data[i][j] = arr[j];
				}
			}
			br.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return data;
	}

	public boolean write(List<String> line) {
		try {
			int i=0;
			for(; i<line.size() - 1; i++) {
				if(null == line.get(i)) bw.write("");
				else bw.write(line.get(i));
				bw.write(",");
			}
			if(null == line.get(i)) bw.write("");
			else bw.write(line.get(i));
			bw.write("\n");
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public void close() {
		try {
			if(bw != null) bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			if(br != null) br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static String[][] getTableArray(String filepath, boolean removeHeaders){
		String[][] data = null;
		try {
			BufferedReader br = new BufferedReader(new FileReader(filepath));
			List<String> temp = new ArrayList<String>();
			String line = null;
			if(removeHeaders == true) {
				br.readLine();
			}
			while((line = br.readLine()) != null) {
				temp.add(line);
			}
			String[] arr = temp.get(0).split(",");
			int r = temp.size(), c = arr.length;
			data = new String[r][c];
			for(int i=0; i<r; i++) {
				arr = temp.get(i).split(",");
//				System.out.println("Reading Line " + i + " data : ");
				for(int j=0; j<c; j++) {
					data[i][j] = arr[j];
				}
			}
			br.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return data;
	}

	public String[][] getTableArray(){
		String[][] data = null;
		try {
			List<String> temp = new ArrayList<String>();
			String line = null;
			while((line = br.readLine()) != null) {
				temp.add(line);
			}
			String[] arr = temp.get(0).split(",");
			int r = temp.size(), c = arr.length;
			data = new String[r][c];
			for(int i=0; i<r; i++) {
				arr = temp.get(i).split(",");
				for(int j=0; j<c; j++) {
					data[i][j] = arr[j];
				}
			}
			br.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return data;
	}
}
