package com.asda.qa.utility;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.imageio.IIOException;
import javax.imageio.ImageIO;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import com.asda.qa.data.Constants;
import io.restassured.http.Header;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Reporter;

import com.asda.core.baseexecution.TestExecutionContext;
import com.asda.core.utils.SeleniumWebDriverUtility;
import com.asda.core.utils.MigrationUtil;

import io.restassured.response.Response;

public class GeneralUtility {
	private static final Logger s_logger = LoggerFactory.getLogger(GeneralUtility.class);

	public static String getCurrencySymbol() {
		Locale locale = Locale.UK;
		Currency curr = Currency.getInstance(locale);
		String symbol = curr.getSymbol(locale);
		return getUTF8EncodedString(symbol);
	}

	public static String getQuestionMarkSymbol() {
		return getUTF8EncodedString("?");
	}

	public static String generateRandomEmailAddress(String emailDomain) {

		String randomString = com.asda.core.utils.Utility.StringUtility.getRandomString();
		String emailAddress = randomString
				.concat(com.asda.core.utils.Utility.StringUtility.getNonNull(emailDomain));

		return emailAddress;
	}

	public static String getUTF8EncodedString(String str) {
		byte[] b1;
		String szUT8 = str;
        b1 = str.getBytes(StandardCharsets.UTF_8);
        szUT8 = new String(b1, StandardCharsets.UTF_8);
        return szUT8;
	}

	public static void autoScrolltoElement(WebElement ele, WebDriver driver) {
		try {
			Actions actions = new Actions(driver);
			actions.moveToElement(ele);
			actions.click();
			actions.perform();
		} catch (WebDriverException e) {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].click();", ele);
		} catch (Exception e) {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].click();", ele);
		}

	}

	public static void scroll(String width, String height, WebDriver driver) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(" + width + "," + height + ")");
	}

	/***
	 * The below method returns a list of value for any attribute of a element
	 *
	 * @param elemntLst
	 * @param attributeName
	 * @return
	 */
	@SuppressWarnings("null")
	public static List<String> getAttributeValuesFromList(List<WebElement> elemntLst, String attributeName) {
		List<String> valueList = new ArrayList<String>();
        for (int i = 0; i < elemntLst.size(); i++) {
			s_logger.info("%%%%%%%%%%%%%%%%%%%" + elemntLst.get(i).getAttribute(attributeName));
			valueList.add(elemntLst.get(i).getAttribute(attributeName));
		}
		return valueList;
	}

	/**
	 * Generate random email id
	 *
	 * @return
	 */

	public static String generateRandomEmail() {
		Calendar currentDate = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("MMddyyyyhhmmss");
		String randomName = "asda_qe_auto_user_" + formatter.format(currentDate.getTime())
				.concat(Integer.toString(new Random().nextInt(1000)));
		return randomName + "@asdatest.com";
	}

	/**
	 * Generate random card name
	 *
	 */

	public static String CardRandName() {
		Calendar currentDate = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("MMddyyhhmmss");
		String randNickName = formatter.format(currentDate.getTime());
		return "Visa" + " " + randNickName;
	}

	public static String getRandomString() {
		Calendar currentDate = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("MMddyyhhmmss");
		return formatter.format(currentDate.getTime());
	}

	public static String getRandomEmailAddress() {
		Calendar currentDate = Calendar.getInstance();
		try{Thread.sleep(3);}catch (Exception e){}
        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss:SSSSSSS");
		return "sp_test_user_"+formatter.format(currentDate.getTime()).replace(":","").replace(".","").replace(" ","")+"@sptest.com";
	}

	public static String getRandomString(int count)
	{
		String AlphaString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
				+ "abcdefghijklmnopqrstuvxyz";
		return RandomStringUtils.random(count,AlphaString) ;
	}

	/***
	 * The below method returns a list of value for any attribute of a element
	 *
	 * @param elemntLst
	 * @return
	 */
	@SuppressWarnings("null")
	public static List<String> getTextValuesFromList(List<WebElement> elemntLst) {
		List<String> textValueList = new ArrayList<String>();
        for (int i = 0; i < elemntLst.size(); i++) {
			s_logger.info("*******************" + elemntLst.get(i).getText().trim());
			textValueList.add(elemntLst.get(i).getText().trim());
		}
		return textValueList;
	}

	/***
	 * The below method returns a list of value for any attribute of a element
	 *
	 * @param elemntLst
	 * @return
	 */
	@SuppressWarnings("null")
	public static List<String> getTextValuesFromListRemoveExtraChar(List<WebElement> elemntLst, char ch) {
		List<String> textValueList = new ArrayList<String>();
		String text;
		for (int i = 0; i < elemntLst.size(); i++) {

			text = elemntLst.get(i).getText().trim();
			if (text.contains(String.valueOf(ch))) {
				s_logger.info("*******************" + text.substring(0, text.indexOf(ch)).trim());
				textValueList.add(text.substring(0, text.indexOf(ch)).trim());
			} else
				textValueList.add(elemntLst.get(i).getText().trim());
		}
		return textValueList;
	}

	/***
	 * The below method refresh the page.
	 */

	public static void pageRefresh(WebDriver driver) {
		// this.driver.navigate().refresh();
		driver.navigate().to(driver.getCurrentUrl());
		MigrationUtil.unconditionalWait(8000);
	}

	public static void slowScrolldown(WebDriver driver) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		for (int second = 0;; second++) {
			if (second >= 11) {
				break;
			}
			jse.executeScript("window.scrollBy(0,800)");
			MigrationUtil.unconditionalWait(1000);
		}
	}

	/*
	 * Compares two Maps with equal Keys and returns the difference as a Map with
	 * matching key and difference in values as a#b where a is value from the first
	 * Map and b, the second.
	 *
	 * @author rkanni.
	 *
	 * @param Map A. First Map.
	 *
	 * @param Map B. Second Map.
	 *
	 * @return Map. Zero size indicates that the Maps are equal, Non-zero size
	 * indicates there is difference.
	 *
	 * @throws No Exception.
	 */
	public static HashMap<String, String> compareEqualKeyMaps(Map<String, String> mapOne, Map<String, String> mapTwo) {
		HashMap<String, String> diffMap = null;
		StringBuffer stringBuffer = null;
		try {
			if (mapOne.size() == mapTwo.size() && mapOne != null && mapTwo != null) {
				diffMap = new HashMap<String, String>();

				for (Map.Entry entry : mapOne.entrySet()) {
					String keyMapOne = (String) entry.getKey();
					String valueMapOne = (String) entry.getValue();
					String valueMapTwo = mapTwo.get(keyMapOne);

					if (!valueMapOne.equals(valueMapTwo)) {
						stringBuffer = new StringBuffer();
						diffMap.put(keyMapOne,
								(stringBuffer.append(valueMapOne).append("#").append(valueMapTwo)).toString());
					}
				}
			} else {
				s_logger.info("These Maps cannot be compared! Either their sizes are different OR they are null...");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (stringBuffer != null)
				stringBuffer = null;
		}
		s_logger.info("Diff Map: " + diffMap);
		if (diffMap != null && diffMap.size() == 0) {
			s_logger.info("Maps are equal by value! No difference");
			return diffMap;
		}
		return diffMap;
	}

	/*
	 * Removes the entries from Map that matches the Keys from List, using Lambda
	 * Expression (Java 8).
	 *
	 * @author rkanni.
	 *
	 * @param Map.
	 *
	 * @param Key.
	 *
	 * @return boolean indicating if removal was successful.
	 *
	 * @throws No Exception.
	 */

	public static boolean removeEntry(Map<String, String> map, List<String> keys) {

		int mapSizeInitial = 0;
		try {
			mapSizeInitial = map.size();
			for (String key : keys) {
				map.entrySet().removeIf(entries -> entries.getKey().equals(key));
			}
			return ((map.size() == (mapSizeInitial - keys.size())));

		} catch (Exception ex) {
			s_logger.warn("Exception occured whilte trying to remove entries from Map...");
		}
		return false;
	}

	// Validate if two array lists are equal or not
	public static boolean isStringArraylistsEqual(ArrayList<String> list1, ArrayList<String> list2) {
		boolean resultFlag = false;
		ArrayList<String> list1_bkp1 = new ArrayList<String>(list1);
		ArrayList<String> list1_bkp2 = new ArrayList<String>(list1);
		ArrayList<String> list2_bkp1 = new ArrayList<String>(list2);
		ArrayList<String> list2_bkp2 = new ArrayList<String>(list2);

		if (list1 != null && list2 != null && list1.size() > 0 && list2.size() > 0) {

			list1_bkp1.removeAll(list2_bkp1);
			s_logger.error("Non matching record in List1 : " + list1_bkp1.size());
			for (String listVal : list1_bkp1) {
				s_logger.error("<" + listVal + ">");
			}

			list2_bkp2.removeAll(list1_bkp2);
			s_logger.error("Non matching record in List2 : " + list2_bkp2.size());
			for (String listVal : list2_bkp2) {
				s_logger.error("<" + listVal + ">");
			}

			if (list1_bkp1.size() == 0 && list2_bkp2.size() == 0)
				resultFlag = true;

		}
		return resultFlag;
	}

	public static boolean isStringArraylistsEqualNew(ArrayList<String> list1, ArrayList<String> list2) {
		boolean resultFlag = false;
		int count = 0;
		for (int i = 0; i < list1.size(); i++) {
			if (list1.get(i).equalsIgnoreCase(list2.get(i))) {
				count = count + 1;
			}
		}

		if (list1.size() == count) {
			resultFlag = true;
		}
		return resultFlag;
	}

	public static void slowScrollUpForFindingElementAndClick(WebDriver driver, WebElement ele, String finalEle) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		for (int second = 0;; second++) {
			if (second >= 10) {
				break;
			}
			jse.executeScript("window.scrollBy(0,-800)");
			MigrationUtil.unconditionalWait(1000);
			try {
				if (ele.isDisplayed()) {
					ele.click();
					MigrationUtil.unconditionalWait(4000);
					String currentURL = driver.getCurrentUrl();
					if (currentURL.contains(finalEle)) {
						break;
					} else {
						continue;
					}

				}
			} catch (Exception ignored) {
				String currentURL = driver.getCurrentUrl();
				if (currentURL.contains(finalEle)) {
					break;
				} else {
					continue;
				}
			}
		}

	}

	public static void menuClick(boolean isappium, WebDriver driver) {
		if (isappium) {
			try {
				WebElement el = driver.findElement(By.xpath("//body/div[contains(@class,'collapse')]"));

				if (!(el.isDisplayed())) {
					driver.findElement(By.xpath("//div[@class='responsive-menu-btn']/a")).click();
				} else {
					s_logger.info("Menubtn click not required");
				}

			} catch (Exception e) {
				// s_logger.info("Error " + e);
				driver.findElement(By.xpath("//div[@class='responsive-menu-btn']/a")).click();
			}
		} else {
			System.out.println("Not Appium");
		}

	}

	public static void menuClickClose(boolean isappium, WebDriver driver) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		if (isappium) {
			try {
				WebElement el = driver.findElement(By.xpath("//body/div[contains(@class,'collapse')]"));

				if ((el.isDisplayed())) {
					jse.executeScript("window.document.getElementsByClassName('responsive-menu-btn')[0].click();");
				} else {
					s_logger.info("Menubtn click not required");
				}
				if (el.isDisplayed()) {
					driver.navigate().refresh();
					MigrationUtil.unconditionalWait(4000);
				}

			} catch (Exception e) {
				s_logger.error("Exception while closing menu for appium");

			}
		} else {
			System.out.println("Not Appium");
		}

	}

	public static void appiumMyAccountclick(boolean isappium, WebDriver driver) {

		try {
			menuClick(isappium, driver);
			// driver.findElement(By
			// .xpath("//div[@class='flyout-btn sign-in']")).click();
			WebElement el = driver.findElement(By.xpath("//li[@class='flyout-btn sign-in']"));
			el.click();

		} catch (Exception ignored) {
			driver.findElement(By.xpath("//li[@class='flyout-btn sign-in']")).click();
		}

	}

	public static String executeAndReturnConsoleCommand(String cmd, WebDriver driver) {

		return String.valueOf(((JavascriptExecutor) driver).executeScript("return window.co.analyticsData"));

	}

	public static boolean checkIfWebElementIsDispalyed(WebElement ele, WebDriver driver, int waitTime) {
		s_logger.info("check if the web element is dispalyed or not");

		try {
			return com.asda.qa.utility.FluentWaitImplicit.waitForElementToLoadWithCustomWait(ele, driver, waitTime);
		} catch (Exception err) {
			s_logger.info("Element is not visible even after waiting for" + waitTime);
			return false;
		}
	}

	public static boolean checkIfWebElementIsDispalyed(String xpath, WebDriver driver, int waitTime) {
		s_logger.info("check if the web element is dispalyed or not");

		try {
			return com.asda.qa.utility.FluentWaitImplicit.waitForElementToLoadWithCustomWait(
					com.asda.qa.utility.SeleniumWebDriverUtility.returnWebElement(xpath, driver), driver, waitTime);
		} catch (Exception err) {
			s_logger.info("Element is not visible even after waiting for" + waitTime);
			return false;
		}
	}

	public static String returnTextFromWebElement(WebElement ele, WebDriver driver, int waitTime) {
		s_logger.info("check if the web element is dispalyed or not");

		try {
			com.asda.qa.utility.FluentWaitImplicit.waitForElementToLoadWithCustomWait(ele, driver, waitTime);
			return ele.getText();

		} catch (Exception err) {
			s_logger.info("Element is not visible even after waiting for" + waitTime);
			return "";
		}
	}

	public static String returnTextFromWebElementUsingXpath(String ele, WebDriver driver, int waitTime) {
		s_logger.info("check if the web element is dispalyed or not");

		try {
			com.asda.qa.utility.FluentWaitImplicit.waitForElementToLoadWithCustomWait(driver.findElement(By.xpath(ele)),
					driver, waitTime);
			return driver.findElement(By.xpath(ele)).getText();

		} catch (Exception err) {
			s_logger.info("Element is not visible even after waiting for" + waitTime);
			return "";
		}
	}

	public static boolean checkboxIsChecked(String xpath, WebDriver driver, int waitTime) {
		if (com.asda.qa.utility.FluentWaitImplicit.waitForElementToLoadWithCustomWait(
				com.asda.qa.utility.SeleniumWebDriverUtility.returnWebElement(xpath, driver), driver, waitTime))
			return com.asda.qa.utility.SeleniumWebDriverUtility.returnWebElement(xpath, driver).isSelected();
		else
			return false;

	}

	public static void clearInputBoxValue(WebElement ele, WebDriver driver, int waitTime) {
		WebElement toClear = ele;
		s_logger.info("clearing value for input box");
		String selectAll = Keys.chord(Keys.CONTROL, "a");

		toClear = ele;
		toClear.click();
		toClear.sendKeys(selectAll);

		toClear.clear();
	}

	private static final String dbPropPath = System.getProperty("user.dir").replace("/target", "")
			+ "/src/test/resources/com/asda/qa/environment/DBDetails.properties";

//	private static String looperEnvVariableConfig = System.getProperty("user.dir").split("asdaidc-mma-repo")[0]+"asdaidc-mma-repo"
////			+ "/BaseUtil/src/main/resources/env_variables.properties";
//				+ "/BaseUtil/target/classes/env_variables.properties";
/////Users/s0p00zn/Documents/Automation_Repos/asdaidc-mma-repo/BaseUtil/target/classes/env_variables.properties
	public static HashMap<String, String> getMariaDBDetails(String env, String utype) {
		HashMap<String, String> mariaDetails = new HashMap<String, String>();
		Properties prop = new Properties();
		try {
			// load a properties file from class path, inside static method
			prop.load(new FileInputStream(dbPropPath));
			// get the property value and print it out
			mariaDetails.put("DB_DRIVER", prop.getProperty("MARIADB_JDBC_DRIVER"));
			mariaDetails.put("DB_CONNECTION_URL",
					prop.getProperty("MARIADB_CONNECTION_URL").replace("<<test.env>>", env.toUpperCase()));
			// different user assignments switch
			if (utype.equals("SomeSpecficeUser")) {
				// Change the key here!!
			} else {
				mariaDetails.put("DB_USERNAME", prop.getProperty("MARIADB_USERNAME"));
				mariaDetails.put("DB_PASSWORD", prop.getProperty("MARIADB_PASSWORD"));
			}
		} catch (IOException ex) {
			System.out.println("-------|x| There problem reading maria db details  |x|--------");
			ex.printStackTrace();
		}
		return mariaDetails;
	}

	public static HashMap<String, String> getOracleDBDetails(String env, String utype) {
		HashMap<String, String> mariaDetails = new HashMap<String, String>();
		Properties prop = new Properties();
		try {
			// load a properties file from class path, inside static method
			prop.load(new FileInputStream(dbPropPath));
			// get the property value and print it out
			mariaDetails.put("DB_DRIVER", prop.getProperty("ORACLE_JDBC_DRIVER"));
			mariaDetails.put("DB_CONNECTION_URL",
					prop.getProperty("ORACLE_CONNECTION_URL").replace("<<test.env>>", env.toLowerCase()));
			// Different users assignment switch
			if (utype.equals("CSDBUSER")) {
				mariaDetails.put("DB_USERNAME", prop.getProperty("ORACLE_CSDB_USERNAME"));
				mariaDetails.put("DB_PASSWORD", prop.getProperty("ORACLE_CSDB_PASSWORD"));
			} else if (utype.equals("CAVERSION")) {
				mariaDetails.put("DB_USERNAME", prop.getProperty("ORACLE_CAVERSION_USERNAME"));
				mariaDetails.put("DB_PASSWORD", prop.getProperty("ORACLE_CAVERSION_PASSWORD"));
			} else {
				mariaDetails.put("DB_USERNAME", prop.getProperty("ORACLE_USERNAME"));
				mariaDetails.put("DB_PASSWORD", prop.getProperty("ORACLE_PASSWORD"));
			}
		} catch (IOException ex) {
			System.out.println("-------|x| There problem reading maria db details  |x|--------");
			ex.printStackTrace();
		}
		return mariaDetails;
	}

	public static void browserBackButtonClick(WebDriver driver) {

		String browserType = TestExecutionContext.getInstance().getBrowserType().toString();
		s_logger.info("Clicking browser back button");
		String beforeBack = driver.getCurrentUrl();
		SeleniumWebDriverUtility selWD = new SeleniumWebDriverUtility(driver);
		if (browserType.equalsIgnoreCase("SAFARI") || browserType.equalsIgnoreCase("SAFARIIPAD")
				|| browserType.equalsIgnoreCase("INTERNET_EXPLORER_11")) {
			selWD.executeJavaScript("javascript: setTimeout(\"history.go(-1)\", 2000)");
		} else
			driver.navigate().back();
		// sometimes browser back doesnt happen. So adding step to click browser
		// back again
		if (beforeBack == driver.getCurrentUrl())
			selWD.executeJavaScript("javascript: setTimeout(\"history.go(-1)\", 2000)");
		// / adding some wait after the clicking back button / browser back
		// button
		MigrationUtil.unconditionalWait(3000);
		// SeleniumWebDriverUtility.waitForPageLoad(driver);
		s_logger.info("Clicked browser back button");

	}

	public static void handleCookieconcent(WebDriver driver) {
//		try {
//			ASDAAnonymousUserHomePage page=getPage(ASDAAnonymousUserHomePage.class);
//			if(page.getCookieConsent().isDisplayed()) {
//			com.asda.qa.page.ASDAAnonymousUserHomePage homePage = getPage(ASDAAnonymousUserHomePage.class);
//			homePage.clickCookieConsent();
//			MigrationUtil.unconditionalWait(2000);
//			}
//			}
//			catch(NoSuchElementException ele)
//			{
//				s_logger.info("continue as cookie consent is not displayed");
//			}

		try {
			// logic to click on cookie concent
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("document.querySelector(submitCookieConsent());");
		} catch (JavascriptException ele) {
			s_logger.info("Cookie concent not dispalyed");
		} catch (WebDriverException ele) {
			s_logger.info("Cookie concent not dispalyed");
		} catch (Exception ele) {
			s_logger.info("Cookie concent not dispalyed");
		}
	}

	/*
	Method: It will convert the valid csv or text file into HTML file.
	Pre-condition: It can be any file with equal number of records in each rows (no of columns should be same for all rows)
	Input: Path to CSV file
	Output: HTML file at the same place where csv file was place. It return path of the HTML file.
	 */

	public static String convertCSVFileToHTMLReport(String filePath) {

		String[][] file_content = readCsvFileIntoArray(filePath);

		int noOfRows = file_content.length;
		int noOfCols = file_content[0].length;

		String htmlFile = Constants.CSV_TO_HTML_START;

		for(int i = 0; i < noOfCols; i++){
			htmlFile =  htmlFile + Constants.CSV_TO_HTML_TABLE_HEADING.replace("<<col_name>>", file_content[0][i]);
		}

		htmlFile = htmlFile + Constants.CSV_TO_HTML_TABLE_STITCH;

		String content = "";
		for(int i = 1; i < noOfRows; i++){
			content = content + "<tr>";
			for(int j = 0; j < noOfCols; j++) {
				String cellValue = "- no value -";
				try {
					cellValue = file_content[i][j].length() > 0 ? file_content[i][j].trim() : "- blank -";
				}catch (NullPointerException e){}
				if(cellValue.equalsIgnoreCase("pass") || cellValue.equalsIgnoreCase("passed"))
					content = content + "<td style=\"background-color: #A6E2AB;\">" + cellValue+"</td>";
				else if(cellValue.equalsIgnoreCase("fail") || cellValue.equalsIgnoreCase("failed"))
					content = content + "<td style=\"background-color: #E29E98;\">" + cellValue+"</td>";
				else
					content = content + "<td>" + cellValue+"</td>";
			}
			content = content + "</tr>";
		}

		htmlFile = htmlFile + content + Constants.CSV_TO_HTML_CLOSURE;

		String writePath = filePath.substring(0, filePath.indexOf('.'))+".html";
		writeFile(writePath, htmlFile);

		return writePath;
	}

	public static CharSequence getRandomPostCode() {
		String[] arrayPostCode = {"IP333SP", "DN211ZA", "S137RN", "HU33BE", "IP15PD", "SL19LA", "LS211FE", "B421AB", "B761XL", "PR90TY", "WA58UQ"};
		return arrayPostCode[GeneralUtility.getRandomInteger(0, 10)];
	}

	public static boolean waitForPageToLoad(WebDriver driver){
		int countdown = 20;
		JavascriptExecutor js = (JavascriptExecutor) driver;
		while(true) {
			if (js.executeScript("return document.readyState;").toString().equalsIgnoreCase("complete"))
				return true;
			else {
				MigrationUtil.unconditionalWait(1000);
				countdown--;
				if (countdown <= 0) break;
			}
		}
		return false;
	}

	public static void hoverMouseOver(WebDriver driver, WebElement webele){
		Actions actions = new Actions(driver);
		actions.moveToElement(webele);
		actions.build().perform();
	}

	public static boolean validateDatesOrdering(Date[] dates, int order) {
		boolean flag = true;
		boolean orderFlag;
		Date previousDate = dates[0];
		for(Date eachDate: dates){
			if(order==1000)
				orderFlag = eachDate.before(previousDate);
			else
				orderFlag = eachDate.after(previousDate);

			if (orderFlag || eachDate.equals(previousDate)) {
				previousDate = eachDate;
			} else {
				flag = false;
				break;
			}
		}
		return flag;
	}

    public static boolean isInteger(String input) {
		try{
			Integer.parseInt(input);
		}catch(Exception e ){
			return false;
		}
		return true;
    }

    public static String getCookieFromResponse(Response response, String cookie_name) {
		List<Header> listHeaders = response.getHeaders().getList("Set-Cookie");
		String cookie_content = null;
		for(Header each: listHeaders){
			if(each.toString().contains(cookie_name)){
				String temp = each.toString().split(cookie_name)[1];
				cookie_content = temp.split(";")[0].substring(1);
				break;
			}
		}
		return cookie_content;
	}

	public static int getAnyURLResponseCode(String link) throws IOException {
		link = "http://asdagroceries.scene7.com/is/image/asdagroceriesQA/319b3e40-89a8-11ea-b324-c57e094da2dd_Square";
		URL url = new URL(link);
		HttpURLConnection http = (HttpURLConnection)url.openConnection();
		return http.getResponseCode();
	}

	public static boolean getAnyURLResolvesToImage(String link){
		try {
			if (ImageIO.read(new URL(link)) != null) {
				System.out.println("IMAGE");
				return true;
			} else {
				System.out.println("NOT IMAGE");
				return false;
			}
		}catch (IIOException e ){
			System.out.println("NOT IMAGE");
			return false;
		}catch (MalformedURLException e){
			System.out.println("URL mal-formatted!!");
			return false;
		}catch (IOException e){
			System.out.println("INPUT EXCEPTION");
			return false;
		}
	}

//    public static void setLooperEnvironmentVariable(String key, String value) {
//		HashMap<String, String> prevValues = new HashMap<>();
//
//		Properties properties = new Properties();
//		Properties prop = new Properties();
//		try{
//			prop.load(new FileInputStream(looperEnvVariableConfig));
//			Enumeration<String> enums = (Enumeration<String>) prop.propertyNames();
//			while (enums.hasMoreElements()) {
//				String k = enums.nextElement();
//				String v = prop.getProperty(k);
//				prevValues.put(k, v);
//			}
//
//			OutputStream outputStream = new FileOutputStream(looperEnvVariableConfig);
//
//			Iterator hmIterator = prevValues.entrySet().iterator();
//			while (hmIterator.hasNext()) {
//				Map.Entry mapElement = (Map.Entry)hmIterator.next();
//				String k = (String)mapElement.getKey();
//				String v = (String)mapElement.getValue();
//				properties.setProperty(k, v);
//			}
//			properties.setProperty(key, value);
//			properties.store(outputStream, null);
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//    }

    /**
	 * Browser back button click.
	 *
	 * @param driver the driver
	 * @param browserType the browser type
	 */
	public void browserBackButtonClick(WebDriver driver,String browserType) {
		s_logger.info("Clicking browser back button");
		String beforeBack = driver.getCurrentUrl();
		SeleniumWebDriverUtility selWD= new SeleniumWebDriverUtility(driver);
		if (browserType.equalsIgnoreCase("SAFARI")
				|| browserType.equalsIgnoreCase("SAFARIIPAD")
				|| browserType.equalsIgnoreCase(
				"INTERNET_EXPLORER_11")) {
			selWD.executeJavaScript("javascript: setTimeout(\"history.go(-1)\", 2000)");
		} else
			driver.navigate().back();
		// sometimes browser back doesnt happen. So adding step to click browser
		// back again
		if (beforeBack == driver.getCurrentUrl())
			selWD.executeJavaScript("javascript: setTimeout(\"history.go(-1)\", 2000)");
		// / adding some wait after the clicking back button / browser back
		// button
		MigrationUtil.unconditionalWait(3000);
		// SeleniumWebDriverUtility.waitForPageLoad(driver);
		s_logger.info("Clicked browser back button");

	}

	/**
	 * Return web element.
	 *
	 * @param xpath the xpath
	 * @param driver the driver
	 * @return the web element
	 */
	/*
	 * Return WebElement from Xpath
	 *
	 * @author sgowda
	 *
	 * @param none
	 *
	 * @return WebElement
	 *
	 * @throws Exception.
	 */
	public static WebElement returnWebElement(String xpath,WebDriver driver) {
		s_logger.info("Returning web element for xpath" + xpath);
		return driver.findElement(By.xpath(xpath));

	}

	public static void clickWebElement(String xpath, WebDriver driver, int waitTime)
	{
		s_logger.info("Clicking web element for xpath" + xpath);
		com.asda.qa.utility.FluentWaitImplicit.waitForElemenAndClick(returnWebElement(xpath,driver),driver,waitTime);
		//JavascriptExecutor jse = (JavascriptExecutor) driver;
//			jse.executeScript("arguments[0].click();", returnWebElement("//*[@class='co-fund-check__button-group']/button",driver));
//

	}

	public static void jsSetInputBoxText(WebDriver driver, WebElement input, String value) {
		s_logger.info("Setting input box value using javascript | value: " + value);
		com.asda.qa.utility.FluentWaitImplicit.waitForElementToLoad(input, driver);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].setAttribute('type', arguments[1]);", input, value);
	}



	public static void updateINSTProfileWithIPInRunnerFile() {
		String propFilePath = GeneralUtility.class.getClassLoader().getResource("com/asda/qa/environment/INSTconfig.properties").getPath();
		String ip_address = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("test.ip");
		Properties properties = new Properties();
		try {
			PropertiesConfiguration config = new PropertiesConfiguration(propFilePath);
			FileInputStream fis = new FileInputStream(propFilePath);
			properties.load(fis);
			Set<Object> all_keys = properties.keySet();
			for(Object each: all_keys){
				String key = each.toString();
				if(properties.getProperty(key).contains("<<ip_address>>")){
					config.setProperty(key, properties.getProperty(key).replace("<<ip_address>>", ip_address));
				}
			}
			config.save();
			System.out.println("INSTconfig.properties files updated with IP address successfully!!");
		}
		catch(Exception e) {
			System.out.println("FAILED to update INSTconfig.properties with IP address");
		}
	}

	/**
	 * Write file.
	 *
	 * @param saveLocation the save location and content
	 * @return the string
	 */
	public static void writeFile(String saveLocation, String content) {
		try {
			FileUtils.writeStringToFile(new File(saveLocation), content);
		}catch(Exception e) {
			s_logger.info("-------- File Write Error: Unable to write to location ---------");
		}
	}

	public static String getArrayAsCommaSeparatedString(String[] arr) {
		return Arrays.toString(arr).substring(1, Arrays.toString(arr).length()-1);
	}

	public static String getArrayAsCommaSeparatedString(Object[] arr) {
		return Arrays.toString(arr).substring(1, Arrays.toString(arr).length()-1);
	}

	public static String getArrayAsCommaSeparatedString(Double[] intArray) {
		String result = "";
		for(Double each: intArray) result = result + ", " + each;
		return result.substring(1);
	}

	public static void sendMail(String sendTo, String subject, String msgContent, String attachmentPath){
		//String to = "sudip.prasad@walmartlabs.com";//change accordingly
		//String from = "asdacatalognotifs@email.wal-mart.com";//change accordingly
		String from = "asda.com.qe@walmart.com";
		String host = "172.26.45.89";//or IP address

		//Get the session object
		Properties properties = System.getProperties();
		properties.setProperty("mail.smtp.host", host);
		Session session = Session.getDefaultInstance(properties);

		//compose the message
		try{
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(sendTo));
			message.setSubject(subject);

			// Create the message part
			BodyPart messageBodyPart = new MimeBodyPart();

			// Now set the actual message
			messageBodyPart.setText(msgContent);

			// Create a multipar message
			Multipart multipart = new MimeMultipart();

			// Set text message part
			multipart.addBodyPart(messageBodyPart);

			// Part two is attachment
			messageBodyPart = new MimeBodyPart();
			//String filename = "/home/manisha/file.txt";
			DataSource source = new FileDataSource(attachmentPath);
			messageBodyPart.setDataHandler(new DataHandler(source));
			messageBodyPart.setFileName(attachmentPath);
			multipart.addBodyPart(messageBodyPart);

			// Send the complete message parts
			message.setContent(multipart);

			// Send message
			Transport.send(message);
			System.out.println("message sent successfully....");

		}catch (MessagingException mex) {mex.printStackTrace();}
	}

	public static void sendMail(String sendTo,String sendCc, String subject, String msgContent, String attachmentPath){

		//String to = "sudip.prasad@walmartlabs.com";//change accordingly
		//String from = "asdacatalognotifs@email.wal-mart.com";//change accordingly
		String from = "asda.com.qe@walmart.com";
		String host = "172.26.45.89";//or IP address

		//Get the session object
		Properties properties = System.getProperties();
		properties.setProperty("mail.smtp.host", host);
		Session session = Session.getDefaultInstance(properties);

		//compose the message
		try{
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(sendTo));
			message.addRecipients(Message.RecipientType.CC,
								  InternetAddress.parse(sendCc));
			message.setSubject(subject);

			// Create the message part
			BodyPart messageBodyPart = new MimeBodyPart();

			// Now set the actual message
			messageBodyPart.setText(msgContent);

			// Create a multipar message
			Multipart multipart = new MimeMultipart();

			// Set text message part
			multipart.addBodyPart(messageBodyPart);

			// Part two is attachment
			messageBodyPart = new MimeBodyPart();
			//String filename = "/home/manisha/file.txt";

			// attachmentPath
			for (String eachAttachmentPath : attachmentPath.split(";")) {
				new GeneralUtility().attachFile(new File(eachAttachmentPath), multipart, new MimeBodyPart());
			}
			// Send the complete message parts
			message.setContent(multipart);
			// Send message
			Transport.send(message);
			System.out.println("message sent successfully....");

		}catch (MessagingException mex) {mex.printStackTrace();}
	}

	public void attachFile(File file, Multipart multipart, MimeBodyPart messageBodyPart) throws MessagingException {
		DataSource source = new FileDataSource(file);
		messageBodyPart.setDataHandler(new DataHandler(source));
		messageBodyPart.setFileName(file.getName());
		multipart.addBodyPart(messageBodyPart);
	}

	public static boolean TwoDArrayComparator(String[][] arr1, String[][] arr2) {
		boolean status = true;
		List<String> list1 = new ArrayList<String>();
		List<String> list2 = new ArrayList<String>();
		String t1="", t2="";
		for(int i = 0; i < arr1.length; i++) {
			for(int j = 0; j < arr1[0].length; j++) {
				t1 = t1 + "-" + arr1[i][j];
				t2 = t2 + "-" + arr2[i][j];
			}
			list1.add(t1.substring(1));
			list2.add(t2.substring(1));
			t1="";t2="";
		}

		Collections.sort(list1);
		Collections.sort(list2);

		for(int i = 0; i < list1.size(); i++) {
			if(!list1.get(i).equals(list2.get(i))) {
				s_logger.info("--------  Data Mismatch !! ---------");
				s_logger.info("--------    Actual Data: " +list1.get(i)+ " ");
				s_logger.info("--------  Expected Data: " +list2.get(i)+ " ");
				status = false;
			}
		}

		return status;
	}

	public static String[][] readCsvFileIntoArray(String path) {
		String[][] csvData;
		try {
			String temp = GeneralUtility.readFile(path);

			String[] rows = temp.split("\n");
			csvData = new String[rows.length][rows[0].split(",").length];
			for (int i = 0; i < rows.length; i++) {
				String[] cols = rows[i].split(",");
				for (int j = 0; j < cols.length; j++) {
					csvData[i][j] = cols[j];
				}
			}
		}catch (Exception e){
			csvData = new String[1][1];
			csvData[0][0] = "Error Reading CSV File / Invalid CSV File!!";
		}

		return csvData;
	}

	public static String readFile(String saveLocation) {
		String content = null;
		try {
			BufferedReader br = new BufferedReader(new FileReader(saveLocation));
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append(System.lineSeparator());
				line = br.readLine();
			}
			content = sb.toString();
			br.close();
		}catch(Exception e) {
			s_logger.info("-------- File Read Error: Unable to read Input file for Comparing with DB ---------");
		}
		return content;
	}

	/**
	 * Gets the cassandra DB details.
	 *
	 * @param env the env
	 * @param utype the utype
	 * @return the cassandra DB details
	 */
	public static HashMap<String, String> getCassandraDBDetails(String env, String utype) {
		HashMap<String, String> cassandraDetails = new HashMap<String, String>();
		Properties prop = new Properties();
		try {
			// load a properties file from class path, inside static method
			prop.load(new FileInputStream(dbPropPath));
			// get the property value and print it out
			cassandraDetails.put("DB_DRIVER", prop.getProperty("CASSANDRA_JDBC_DRIVER"));
			cassandraDetails.put("DB_CONNECTION_URL",
					prop.getProperty("CASSANDRA_CONNECTION_URL").replace("<<test.env>>", env.toLowerCase()));

			cassandraDetails.put("DB_KEYSPACE", prop.getProperty("CASSANDRA_KEYSPACE"));
			cassandraDetails.put("DB_USERNAME", prop.getProperty("CASSANDRA_USERNAME_"+ env.toUpperCase()));
			cassandraDetails.put("DB_PASSWORD", prop.getProperty("CASSANDRA_PASSWORD_"+ env.toUpperCase()));

		} catch (IOException ex) {
			s_logger.info("-------|x| There problem reading cassandra db details  |x|--------");
			ex.printStackTrace();
		}
		return cassandraDetails;
	}

	public static HashMap<String, String> getAzureDBDetails(String dbEnv, String userType) {
		HashMap<String, String> azureDetails = new HashMap<String, String>();
		if(dbEnv.equals("PQA")) dbEnv = "QA";
		Properties prop = new Properties();
		try {
			// load a properties file from class path, inside static method
			prop.load(new FileInputStream(dbPropPath));
			// get the property value and print it out
			azureDetails.put("DB_DRIVER", prop.getProperty("AZURE_JDBC_DRIVER"));
			azureDetails.put("DB_CONNECTION_URL", "jdbc:sqlserver://"+
					prop.getProperty("AZURE_HOSTNAME_"+dbEnv)+";databaseName="+prop.getProperty("AZURE_DBNAME"));

			azureDetails.put("DB_USERNAME", prop.getProperty("AZURE_USERNAME_"+dbEnv));
			azureDetails.put("DB_PASSWORD", prop.getProperty("AZURE_PASSWORD_"+dbEnv));

		} catch (IOException ex) {
			s_logger.info("-------|x| There problem reading Azure db details  |x|--------");
			ex.printStackTrace();
		}
		return azureDetails;
	}

	public static HashMap<String, String> getCatalogAzureDBDetails(String dbEnv, String userType) {
		HashMap<String, String> azureDetails = new HashMap<String, String>();
		if(dbEnv.equals("PQA")) dbEnv = "QA";
		Properties prop = new Properties();
		try {
			// load a properties file from class path, inside static method
			prop.load(new FileInputStream(dbPropPath));
			// get the property value and print it out
			azureDetails.put("DB_DRIVER", prop.getProperty("AZURE_JDBC_DRIVER"));
			azureDetails.put("DB_CONNECTION_URL", "jdbc:sqlserver://"+
					prop.getProperty("AZURE_HOSTNAME_"+dbEnv+"_CAT")+";databaseName="+prop.getProperty("AZURE_DBNAME_CAT"));

			azureDetails.put("DB_USERNAME", prop.getProperty("AZURE_USERNAME_"+dbEnv+"_CAT"));
			azureDetails.put("DB_PASSWORD", prop.getProperty("AZURE_PASSWORD_"+dbEnv+"_CAT"));

		} catch (IOException ex) {
			s_logger.info("-------|x| There problem reading Azure db details  |x|--------");
			ex.printStackTrace();
		}
		return azureDetails;
	}

	public static HashMap<String, String> getDB2Details(String dbEnv, String userType) {
		HashMap<String, String> azureDetails = new HashMap<String, String>();
		Properties prop = new Properties();
		try {
			// load a properties file from class path, inside static method
			prop.load(new FileInputStream(dbPropPath));
			// get the property value and print it out
			azureDetails.put("DB_DRIVER", prop.getProperty("DB2_JDBC_DRIVER"));
			azureDetails.put("DB_CONNECTION_URL", prop.getProperty("DB2_CONNECTION_URL"));
			azureDetails.put("DB_USERNAME", prop.getProperty("DB2_USERNAME"));
			azureDetails.put("DB_PASSWORD", prop.getProperty("DB2_PASSWORD"));

		} catch (IOException ex) {
			s_logger.info("-------|x| There problem reading DB2 db details  |x|--------");
			ex.printStackTrace();
		}
		return azureDetails;
	}

	/**
	 * Gets the random Long.
	 *
	 * @param min the min
	 * @param max the max
	 * @return the random Long
	 */
	public static long getRandomLong(long min, long max) {
//		Random rand = new Random();
//		return rand.nextLong((max - min) + 1) + min;
		return ThreadLocalRandom.current().nextLong(min,max);
	}

	public static String readLogFromVM(String host, String pattern){

//        Map<String, String> matches = new HashMap<String, String>();
//        Session session = null;
//
//        try {
//            session = sshUtility.connectSSHWithPrivateKey(host, username, SSHUtility.class.getClassLoader().getResource(privatekey).getPath());
//            String data = sshUtility.executeShellCommand(command, session);
//
//            for(String patternToCapture : patterns) {
//                Pattern pattern = Pattern.compile(patternToCapture);
//                Matcher matcher = pattern.matcher(data);
//
//                StringBuilder sb = new StringBuilder();
//                while(matcher.find()) {
//                    sb.append(matcher.group());
//                }
//                matches.put(patternToCapture, sb.toString());
//            }
//        }catch(Exception e) {
//            e.printStackTrace();
//        }finally {
//            if(session != null)
//                session.disconnect();
//        }
//        return matches;
		return null;
	}

	public static boolean isAddressContainAddressResponse(Response response, String address_id){
		boolean flag = false;

		try{
			JSONArray addressArray = (JSONArray) JsonUtil.convertStringToJsonObject(response.asString()).get("addresses");

			for(Object each: addressArray){
				JSONObject obj = (JSONObject) each;

				if(obj.get("addressId").equals(address_id)){
					flag = true;
					break;
				}
			}
		}catch (Exception e){
			return false;
		}

		return flag;
	}

	public static boolean isContactContainContactResponse(Response response, String contact_id){
		boolean flag = false;

		try{
			JSONArray addressArray = (JSONArray) JsonUtil.convertStringToJsonObject(response.asString()).get("contacts");

			for(Object each: addressArray){
				JSONObject obj = (JSONObject) each;

				if(obj.get("contactId").equals(contact_id)){
					flag = true;
					break;
				}
			}
		}catch (Exception e){
			return false;
		}

		return flag;
	}

	/**
	 * Gets the random integer.
	 *
	 * @param min the min
	 * @param max the max
	 * @return the random integer
	 */
	public static int getRandomInteger(int min, int max) {
		Random rand = new Random();
		System.out.println("Max: "+ max +" | Min: "+ min);
		return rand.nextInt((max - min) + 1) + min;
	}

	public static boolean isCardContainCardResponse(Response response, String card_id){
		boolean flag = false;

		try{
			JSONArray addressArray = (JSONArray) JsonUtil.convertStringToJsonObject(response.asString()).get("cards");

			for(Object each: addressArray){
				JSONObject obj = (JSONObject) each;

				if(obj.get("cardId").equals(card_id)){
					flag = true;
					break;
				}
			}
		}catch (Exception e){
			return false;
		}

		return flag;
	}

	public static boolean isPreferenceContainPrefernceResponse(Response response, String pref_id){
		boolean flag = false;

		try{
			JSONArray addressArray = (JSONArray) JsonUtil.convertStringToJsonObject(response.asString()).get("preferences");

			for(Object each: addressArray){
				JSONObject obj = (JSONObject) each;

				if(obj.get("preference_id").equals(pref_id)){
					flag = true;
					break;
				}
			}
		}catch (Exception e){
			return false;
		}

		return flag;
	}

	public static boolean checkStringMatchesRegEx(String inTestString, String RegEx) {
		Pattern pattern = Pattern.compile(RegEx);
		try {
			Matcher matcher = pattern.matcher(inTestString);
			return matcher.matches();
		} catch (PatternSyntaxException exception) {
			System.err.println(exception.getDescription());
			return false;
		}
	}

	public static void clearPasswordField(WebElement passwordWebEle) {
		int len = -1;
		do{
			try{passwordWebEle.click();}catch(ElementClickInterceptedException e){}
			passwordWebEle.sendKeys(Keys.BACK_SPACE);
			passwordWebEle.sendKeys(Keys.BACK_SPACE);
			passwordWebEle.sendKeys(Keys.BACK_SPACE);
			len = passwordWebEle.getAttribute("value").length();
		}while (len>0);

	}

	public static boolean compareTwoLists(List<String> l1, List<String> l2){
		boolean flag = true;
		Collections.sort(l1);
		Collections.sort(l2);

		if(l1.size()!=l2.size()){
			s_logger.info("Both lists are unequal bcos no of row contained in both lists doesn't match!!");
			return false;
		}

		for(int i = 0; i < l1.size(); i++){
			if(!l1.get(i).equals(l2.get(i))){
				s_logger.info("Record mis-matched!!");
				s_logger.info("Expected: "+ l1.get(i));
				s_logger.info("  Actual: "+ l2.get(i));
				flag = false;
			}
		}


		return flag;
	}

	public static  <T> Set<T> findDuplicates(Collection<T> collection) {

		Set<T> duplicates = new LinkedHashSet<>();
		Set<T> uniques = new HashSet<>();

		for(T t : collection) {
			if(!uniques.add(t)) {
				duplicates.add(t);
			}
		}

		return duplicates;
	}

	public static String getRandomPhoneNumber(String country){
		String phoneNumber = "0";
		switch (country){
			case "UK":
				phoneNumber = phoneNumber + GeneralUtility.getRandomInteger(700, 799)
						+ GeneralUtility.getRandomInteger(1111, 9999) + GeneralUtility.getRandomInteger(111, 999);
				break;
			case "IND":
			default:
				phoneNumber = phoneNumber + GeneralUtility.getRandomInteger(700, 999)
						+ GeneralUtility.getRandomInteger(1111, 9999) + GeneralUtility.getRandomInteger(111, 999);
		}
		return phoneNumber;
	}
}
